steps to compile the Bootrom project
	1. cd to your workarea
	2. svn co http://10.1.10.62/svn/mkb_sw
	3. untar the toolchain.tar.gz
	4. cd e21_sdk/
	5. export RISCV_PATH=../e21_toolchain/riscv64-unknown-elf-toolchain-10.2.0-2020.12.8-x86_64-linux-ubuntu14/
	6. make TARGET=design-rtl_bl PROGRAM=Bootrom CONFIGURATION=debug software
	7. you can find the .hex file in software/Bootrom/debug/ folder

Steps to compile the reg_read_write project and load directly to TIM
	1. cd to your workarea
	2. svn co http://10.1.10.62/svn/mkb_sw
	3. untar the toolchain.tar.gz
	4. cd e21_sdk/
	5. export RISCV_PATH=../e21_toolchain/riscv64-unknown-elf-toolchain-10.2.0-2020.12.8-x86_64-linux-ubuntu14/
	6. make TARGET=design-rtl_bl PROGRAM=reg_read_write LINK_TARGET=scratchpad CONFIGURATION=debug software
	7. you can find the .hex file in software/reg_read_write/debug/ folder

steps to compile the standalone ipm_fw project
	1. cd to your workarea
	2. svn co http://10.1.10.62/svn/mkb_sw
	3. untar the toolchain.tar.gz
	4. cd e21_sdk/
	5. export RISCV_PATH=../e21_toolchain/riscv64-unknown-elf-toolchain-10.2.0-2020.12.8-x86_64-linux-ubuntu14/
	6. make TARGET=design-rtl_bl PROGRAM=ipm_fw CONFIGURATION=debug software
	7. you can find the .hex file in software/ipm_fw/debug/ folder
