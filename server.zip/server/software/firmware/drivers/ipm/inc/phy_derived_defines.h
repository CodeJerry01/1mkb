// Copyright (c) 2020 Blue Cheetah Analog Design, Inc. 
// All Rights Reserved.
// The information contained herein is confidential and proprietary information
// of Blue Cheetah Analog Design, Inc. and its licensors, if any, and is
// subject to applicable non-disclosure agreement with Blue Cheetah Analog
// Design, Inc. Dissemination of information, use of this material, or
// reproduction of this material is strictly forbidden unless prior written
// permission is obtained from Blue Cheetah Analog Design, Inc.

//========== CA TRAINING=========//
//========== WRITE LEVELING=========//
#define DR_WDQS_PIPE_OE_DLY TR_WDQS_PIPE_DLY>2 ? TR_WDQS_PIPE_DLY - 2 : 0

#define DR_WRITE_EN_EARLY_PIPE_DLY TR_WDQS_PIPE_DLY>4 ? TR_WDQS_PIPE_DLY-4 : 0 

//Need to update as max of rank0 and rank1 
//#define DR_W_DQS_CS_PIPE_DLY max_of_two(DR_WDQS_PIPE_OE_DLY,DR_WDQS_PIPE_OE_DLY)
#define DR_W_DQS_CS_PIPE_DLY DR_WDQS_PIPE_OE_DLY

//========== READ PREAMBLE TRAINING =========//
#define DR_RXDQEN_PIPE_DLY TR_RDQSEN_PIPE_DLY>2 ? TR_RDQSEN_PIPE_DLY-2 : 0 

#define DR_RXDQSEN_PIPE_DLY TR_RDQSEN_PIPE_DLY>2 ? TR_RDQSEN_PIPE_DLY-2 : 0

#define DR_RDQODTEN_PIPE_DLY TR_RDQSEN_PIPE_DLY>2 ? TR_RDQSEN_PIPE_DLY-2 : 0

#define DR_RDQSODTEN_PIPE_DLY TR_RDQSEN_PIPE_DLY>2 ? TR_RDQSEN_PIPE_DLY-2 : 0

#define DR_READ_EN_EARLY_PIPE_DLY TR_RDQSEN_PIPE_DLY>4 ? TR_RDQSEN_PIPE_DLY-4 : 0

//Need to update as max of rank0 and rank1 
//#define DR_RXCS_PIPE_DLY max_of_two(DR_RDQSODTEN_PIPE_DLY,DR_RDQSODTEN_PIPE_DLY)
#define DR_RXCS_PIPE_DLY DR_RDQSODTEN_PIPE_DLY

//========== READ DQ CALIBRATION TRAINING =========//
//========== WRITE DQS2DQ TRAINING ==========//
//#ifdef FR_1_1
//#define DR_WDQ_PIPE_OE_DLY  TR_WDQ_PIPE_DLY+4  
//#else
#define DR_WDQ_PIPE_OE_DLY  TR_WDQ_PIPE_DLY+2
//#endif

//Need to update as max of rank0 and rank1 
//#define DR_W_DQ_CS_PIPE_DLY_RISE max_of_two(DR_WDQ_PIPE_OE_DLY,DR_WDQ_PIPE_OE_DLY)
#define DR_W_DQ_CS_PIPE_DLY DR_WDQ_PIPE_OE_DLY

