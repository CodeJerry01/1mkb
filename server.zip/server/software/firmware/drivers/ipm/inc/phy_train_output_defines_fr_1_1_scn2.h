// Copyright (c) 2020 Blue Cheetah Analog Design, Inc. 
// All Rights Reserved.
// The information contained herein is confidential and proprietary information
// of Blue Cheetah Analog Design, Inc. and its licensors, if any, and is
// subject to applicable non-disclosure agreement with Blue Cheetah Analog
// Design, Inc. Dissemination of information, use of this material, or
// reproduction of this material is strictly forbidden unless prior written
// permission is obtained from Blue Cheetah Analog Design, Inc.
//========== PHY TRAINING With 1:1 Frequency Ratio Scenario 1 =========//


//============= CCR Block defaults for skip training ===========//
// For this implementation there is no rank specific delays. So, using suffix Rx to 
// indicate that same value can be used for both ranks

// MCD,NUI digital delays.
#define TR_CK_PIPE_DLY 0
#define TR_CC_PIPE_DLY 1 
#define TR_CS_PIPE_DLY 1 
#define TR_HV_PIPE_DLY 0
// SDL analog delays. This is represented in terms of ideal code from 0-> 20
// This is obtained from previous hybrid models code by (round) (hybrid_code*21/64)
#define TR_ANA_CK_SDL_DLY 0
#define TR_ANA_CC_SDL_DLY 8  //6*(21/64)
#define TR_ANA_HV_SDL_DLY 0

//============= DQ Block defaults for skip training ===========//
// MCD,NUI Delays
#define TR_WDQS_PIPE_DLY 4

//#define TR_WDQ_PIPE_DLY 2	// Modifed from 2 to 3 to get DQS2DQ timing right
#define TR_WDQ_PIPE_DLY 1	

#define TR_RDQSEN_PIPE_DLY 5 

//SDL analog delays
#define TR_ANA_WDQS_SDL_DLY 0 //16 //10*(21/64)

#define TR_ANA_WDQ_SDL_DLY 7

#define TR_ANA_RDQSEN_SDL_DLY 14 //52*(21/64)

#define TR_ANA_RDQS_SDL_DLY_RISE 13 // 20*(21/64)

#define TR_ANA_RDQS_SDL_DLY_FALL 13

#define ST_ANA_CC_SDL_DLY_BOOT 8  // DDR for CA. Need 1/2 UI offset 
#define TR_ANA_CS_PBD_DLY_CATRAIN 31 
//TBD: PBD delays are all zero for now. Later we can add trained values

//CAP_EN for various delay lines
#define CSR_CAP_EN_CK_SDL       2
#define CSR_CAP_EN_HV_SDL       2
#define CSR_CAP_EN_CC_SDL       2
#define CSR_CAP_EN_WDQ_SDL      2
#define CSR_CAP_EN_WDQS_SDL     2
#define CSR_CAP_EN_RDQSEN_SDL   2
//#define CSR_CAP_EN_RDQS_SDL     2 
#define CSR_CAP_EN_RDQS_SDL     3 
#define CSR_CAP_EN_CC_SDL_BOOT  6
#define CSR_CAP_EN_PBD          2

//Code at which the delay wraps around a UI
#define TR_WRP_CODE_CK_SDL      16
#define TR_WRP_CODE_HV_SDL      16
#define TR_WRP_CODE_CC_SDL      16
#define TR_WRP_CODE_WDQ_SDL     16
#define TR_WRP_CODE_WDQS_SDL    16
#define TR_WRP_CODE_RDQSEN_SDL  16
#define TR_WRP_CODE_RDQS_SDL    16
//Code zero has a non-zero delay compared to pipe_clk_2x. 
//That must be acocunted for when computing the xover
//This value comes from the analog SDL code and is
//the delay (in steps) of the zero code for that 
//particular cap_en
#define TR_ZOFFSET_CODE_CK_SDL      3
#define TR_ZOFFSET_CODE_HV_SDL      3
#define TR_ZOFFSET_CODE_CC_SDL      3
#define TR_ZOFFSET_CODE_WDQ_SDL     3
#define TR_ZOFFSET_CODE_WDQS_SDL    3
#define TR_ZOFFSET_CODE_RDQSEN_SDL  3
#define TR_ZOFFSET_CODE_RDQS_SDL    3

//########## Defines for postamble ##############//

#define POST_0P5_STRCH_DELAY   0
#define POST_1P5_STRCH_DELAY   2

//########## MR1 configurations ##############//
#define BL8              0     
#define BL16             1     
#define BL_ON_THE_FLY     2     
#define WR_PRE            1     
#define RD_PRE            1     
#define nWR               3     
#define RD_POST_0P5       0  
#define RD_POST_1P5       1
 
//########## MR2configurations ##############//
#define DRAM_RL       3 
#define DRAM_WL_SETA  3 
#define DRAM_WL_SETB  3 
#define DRAM_nWR_SETA 0 
#define DRAM_nWR_SETB 1 
#define WR_LEV	      0
 
//########## MR12configurations ##############//
#define VREF_CA 0 
#define VR_CA   1 //op[6]

//########## MR14 configurations ##############//
#define VREF_DQ 0 
#define VR_DQ   1

//########## MR13 configurations ##############//
#define CBT 	0 
#define RPT 	0 
#define VRO 	0 
#define VRCG 	1 
#define RRO 	0 
#define DMD 	0 
#define FSP_WR  1 
#define FSP_OP  1 

//########## MR3 configurations ##############//
#define WR_POST_1P5 1
#define WR_POST_0P5 0










