
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
//#include <metal/compiler.h>
#include "flc.h"
#include "platform_def.h"

#define ENABLE 1
//#define DISABLE 1
#define QM_FLC2 1
//#define STANDALONE 1
void flc12_init_cfg_zeros(int idx)
{
	int i;
	uint32_t base1 = FLC1_BASE_ADDR + idx * FLC_SLICE_RANGE;
	uint32_t base2 = FLC2_BASE_ADDR;
	for (i = 0; i < 16; i ++) {
		writel(0, base1 + FLC_ADDR_MAP_0_H + i * 8);
		writel(0, base1 + FLC_ADDR_MAP_0 + i * 8);
	}
	writel(0, base1 + FLC_SHADOW_ADDR_MAP_H);
	writel(0, base1 + FLC_SHADOW_ADDR_MAP);
	writel(0, base1 + FLC_FLC1_NC_ADDR_MAP_H);
	writel(0, base1 + FLC_FLC1_NC_ADDR_MAP);
	writel(0, base1 + FLC_FLC2_NC_ADDR_MAP_H);
	writel(0, base1 + FLC_FLC2_NC_ADDR_MAP);
	writel(0, base1 + FLC_FLC2_NC_ADDR_MAP_4_H);
	writel(0, base1 + FLC_FLC2_NC_ADDR_MAP_4);

	for (i = 0; i < 16; i ++) {
		writel(0, base2 + FLC2_ADDR_MAP_0_H + i * 8);
		writel(0, base2 + FLC2_ADDR_MAP_0 + i * 8);
	}
	writel(0, base2 + FLC2_NC_ADDR_MAP_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP);
	writel(0, base2 + FLC2_NC_ADDR_MAP_0_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP_0);
	writel(0, base2 + FLC2_NC_ADDR_MAP_1_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP_1);
	writel(0, base2 + FLC2_NC_ADDR_MAP_2_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP_2);
	writel(0, base2 + FLC2_NC_ADDR_MAP_3_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP_3);
	writel(0, base2 + FLC2_NC_ADDR_MAP_4_H);
	writel(0, base2 + FLC2_NC_ADDR_MAP_4);

	return;
}
void flc12_init_cfg(int idx)
{
	uint32_t base1 = FLC1_BASE_ADDR;
	writel(0x00000000, base1 + FLC_FLC1_NC_ADDR_MAP_H);
	writel(0x0000003F, base1 + FLC_FLC1_NC_ADDR_MAP); // 2GB noncacheble
	writel(0x00000080, base1 + FLC_ADDR_MAP_0_H);
	writel(0x0000001F, base1 + FLC_ADDR_MAP_0);

	writel(0x00000000, base1 + FLC_INTERLEAVE_CONTROL);
	writel(0x00010001, base1 + FLC_UNLOCK_LINE_SET);
	writel(0x00000002, base1 + FLC_SRAM_INIT);
	return;
}
void flc12_init_cfg_1(int idx)
{
	uint32_t base1 = FLC1_BASE_ADDR + 0x10000;

	//cache
	writel(0x00000900, base1 + FLC_FLC1_NC_ADDR_MAP_H);
	writel(0x00000021, base1 + FLC_FLC1_NC_ADDR_MAP); // 1GB noncacheble
	writel(0x00000000, base1 + FLC_ADDR_MAP_0_H);
	writel(0x00000029, base1 + FLC_ADDR_MAP_0);
	writel(0x00000000, base1 + FLC_INTERLEAVE_CONTROL);
	writel(0x00010001, base1 + FLC_UNLOCK_LINE_SET);
	writel(0x00000002, base1 + FLC_SRAM_INIT);

	return;
}


int flc1_common_cfg(int idx, int flc1Enable)
{
	uint32_t val0, i, ret = 1;
	uint32_t base = FLC1_BASE_ADDR + idx * FLC_SLICE_RANGE;

	val0 = readl(base + FLC_DEBUG_CONTROL);
	writel(val0 | (1 << 25), base + FLC_DEBUG_CONTROL);

#if 0	/* Ignore FLC_CHI_NODE in AXI version. */
	val0 = (DEF_UPLINK_NID & 0x7ff) | (DEF_DOWNLINK_NID << 16);
	writel(val0, base + FLC_CHI_NODE);
#endif

	writel(0x0, base + FLC_INTERLEAVE_CONTROL);

	if (flc1Enable) {
		val0 = ((FLC1_CACHEABLE_LINE & 0xfffff) << 1) | 1;
		writel(val0, base + FLC_UNLOCK_LINE_SET);

		writel(0x2, base + FLC_SRAM_INIT);
		i = 1;
		while (i < 3000) {
			val0 = readl(base + FLC_SRAM_INIT);
			if (val0 & 0x1) {
				ret = 0;
				break;
			}
			i ++;
		}
		if (i == 3000) {
			//sprintf(buf, "Warn: FLC1 SRAM INIT timeout.\n");
			//write(STDOUT_FILENO, buf, strlen(buf));
		}
	}

	return ret;
}

void flc2_cfg(int idx, int flc2Enable)
{
		uint32_t base1 = FLC2_BASE_ADDR;
		uint32_t res = 0;
#if ENABLE
		writel(0x00000000, base1 + 0x58 );
		writel(0x00000029, base1 + 0x54 );
		writel(0x80000025, base1 + 0xD4 );
		writel(0x00000000, base1 + 0xD8 );
		writel(0x00000925, base1 + 0xDC );
		writel(0x00000001, base1 + 0xE0 );
		writel(0x00000000, base1 + 0x288 );
		writel(0x80000000, base1 + 0x284 );
		writel(0x00000080, base1 + 0x290 );
		writel(0x80800000, base1 + 0x28C );
		writel(0x21200090, base1 + 0x238 );
		writel(0x00000001, base1 + 0x240 );
		writel(0x00000001, base1 + 0x220 );
		writel(0x00000002, base1 + 0x21C );
#endif

#if DISABLE
		writel(0x00000000, base1 + 0xE8 );
		writel(0x00000027, base1 + 0xE4 );
		writel(0x21200090, base1 + 0x238 );
		writel(0x00000001, base1 + 0x240 );
		writel(0x00000001, base1 + 0x220 );
		writel(0x00000002, base1 + 0x21C );
#endif


		/*
		do
		{
			res = readl(base1+ 0x21C);
		}
		while(res==0);
		*/
}

void qm_cfg()
{
	uint32_t res = 0;
		//qm_prog

		/*
		writel(0x22040000,0x21200010);
		*/
		writel(0x00000002,0x212000d8);
		writel(0x00000001,0x21200000);
		writel(0x00000001,0x21200004);
		writel(0x21301008,0x21200008);
		writel(0x2130100C,0x2120000C);
#ifdef QM_FLC2
		writel(0x2202023C,0x21200010);
		writel(0x22020240,0x21200014);
		writel(0x22020244,0x21200018);
		writel(0x22020248,0x2120001C);
		writel(0x2202024C,0x21200020);
		writel(0x22020250,0x21200024);
		writel(0x22020254,0x21200028);
		writel(0x22020258,0x2120002C);
#endif
#ifdef STANDALONE
		writel(0x22040000,0x21200010);
		writel(0x22040004,0x21200014);
		writel(0x22040018,0x21200018);
		writel(0x2204001C,0x2120001C);
		writel(0x22040028,0x21200020);
		writel(0x2204002C,0x21200024);
		writel(0x22040040,0x21200028);
		writel(0x22040044,0x2120002C);
#endif
		writel(0x00000001,0x212000C0);
		writel(0x21200000,0x212000C4);
		writel(0x00000005,0x212000C8);
		writel(0x21208000,0x212000CC); //QM_SQ_Map_H
		writel(0x00000005,0x212000D0);
		writel(0x2120C000,0x212000D4); //QM_CQ_Map_H

}




