#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <metal/compiler.h>
#include <metal/machine.h>
#include "d2d.h"
//#include "uc.h"
//#include "platform_def.h"
#include "generic_defines.h"
//RS_TODO: #include "../../../RTL/D2D_IP/top/bc_lynx_03n_v0p2p2/csr/blynx_phy_csr_map.h"
#include "blynx_bow_csr_map_03e_v0p2p1.h"


void deassert_phy_tx_reset(uint32_t d2d_base_addr)
{
  uint32_t rd, wd;
  rd = readl(d2d_base_addr + 0x8004); 
  writel(rd&0xFFFFF0FF, (d2d_base_addr + 0x8004));

}

//--------------------------------------------------------------
// D2D TX init cfg
//--------------------------------------------------------------
void d2d_tx_init_cfg(uint32_t d2d_base_addr, int slice_idx)
{
  int i;
  uint32_t val0;
  uint32_t tx_base;
  uint32_t base1;
  uint32_t base2;

  if(slice_idx==1)
    {
      tx_base = d2d_base_addr + ((TX_SLICE_1_ADDR << 1));
    }
  else
    {
      tx_base = d2d_base_addr + ((TX_SLICE_0_ADDR << 1));
    }

  //2.2.2 Serialization and Deserialization Ratio Variables
  
  
  //2.2.3 Clock Frequency Dependent Variables
  uint32_t phase_sel = 0x0003; //4GHz (RX) //RS_CHECK??
  uint32_t rdata;
  uint32_t FlitSample00,FlitSample02;
  uint32_t offset_init_slice_0, offset_init_slice_1;
  uint8_t tx_bits_per_channel = 1,rx_bits_per_channel =1,bpc = 0;
  uint32_t final_adjustment = 0;
  
  //char vreg_fd_per_mult[] = “80”;
  bool vreg_fd_fltrd_freq = true;
  int vreg_fd_cnt_tol = 0;
  
  
  int apb_clk_period_in_ps = 2000;//Choose apb_clk_period_in_ps as per SoC usage dummy 
  //Note: This is the SoC APB Clock Period
  int vreg_target_per_ps = 1686;//1686ps; // 593Mhz
  int  vreg_exp_freq_cnt,vreg_freq_trgt_min,vreg_freq_trgt_max;
  
  vreg_exp_freq_cnt = (int) ((80* apb_clk_period_in_ps) / vreg_target_per_ps);
  vreg_freq_trgt_min = vreg_exp_freq_cnt - vreg_fd_cnt_tol;
  vreg_freq_trgt_max = vreg_exp_freq_cnt + vreg_fd_cnt_tol;
  
  uint32_t tx_tx_qpump_vreg_config = 0;
  uint32_t tx_vr_acm_ctrl = 0;
  uint32_t tx_vr_clk_gate = 0;
  uint32_t tx_vr_reset = 0;
  uint32_t shift_reg_value = 0xFF;// 8:1
  uint32_t ser_ratio_value = 10;
  uint32_t mux_sel_value = 0x0000;
  uint32_t deser_ratio_value = 10;
  uint32_t deser_lat_trans = 0;
  
  uint32_t ovrd_clktx_ctrl_p = 0x051F ;
  uint32_t ovrd_clktx_ctrl_n = 0x04F4 ;
  uint32_t ovrd_clktxb_ctrl_p = 0x051F;
  uint32_t ovrd_clktxb_ctrl_n = 0x04F4;
  uint32_t tx_dcc_comp_sel_overrides = 0;
 
  
  //Lock Detector setting variables:
  uint32_t lockdet_thresh = (1 << 15);
  uint32_t lockdet_period = (1 << 10);
  uint32_t lockdet_live = 0; // default: 0 - capture mode; 1 - live
  
  
  // 2.3.1.1 De-assert the TX PHY reset
  //rdata = readl(d2d_base_addr + 0x8004); 
  //writel( rdata&0xFFFFF0FF,(d2d_base_addr + 0x8004));
  //wait10nanoseconds(4); //wait 20ns
  
  //2.3.1.2 Enable Global Clock
  // Enable clk dist for TX slice N
  //val0 |= 1<<0;
  //writel(val0, base1 + TX_CLK_DIST_ENABLE);
  //write_field(1, TX_CLK_DIST_ENABLE__ENABLE, tx_base);
  writel(0x1, d2d_base_addr);
	
  // Config TX VREG
#ifdef POST_SILICON_CODE
  write_field(0x0, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW, tx_base);
  
  uint32_t vreg_acm_adj_pos = 0x00000400;
  uint32_t vreg_acm_adj_neg = ((-1)*(vreg_acm_adj_pos));
  uint32_t vreg_acm_start = 0x54C7FF;
  
  uint32_t vreg_acm_adj_pos_lo = vreg_acm_adj_pos&0xFFFF;
  uint32_t vreg_acm_adj_pos_hi = vreg_acm_adj_pos>>16;
  
  uint32_t vreg_acm_adj_neg_lo = vreg_acm_adj_neg&0xFFFF;
  uint32_t vreg_acm_adj_neg_hi = vreg_acm_adj_neg>>16;
  
  uint32_t vreg_acm_start_lo = vreg_acm_start&0xFFFF;
  uint32_t vreg_acm_start_hi = vreg_acm_start>>16;
 

  write_field(vreg_acm_adj_pos_lo,TX_VR_ACM_ADJ_POS_LO__ACM_ADJ_POS_LO, tx_base);
  write_field(vreg_acm_adj_pos_hi,TX_VR_ACM_ADJ_POS_HI__ACM_ADJ_POS_HI, tx_base);
  write_field(vreg_acm_adj_neg_lo,TX_VR_ACM_ADJ_NEG_LO__ACM_ADJ_NEG_LO, tx_base);
  write_field(vreg_acm_adj_neg_hi,TX_VR_ACM_ADJ_NEG_HI__ACM_ADJ_NEG_HI, tx_base);
  write_field(vreg_acm_start_lo,TX_VR_ACM_PRLD_VAL_LO__ACM_PRLD_VAL_LO, tx_base);
  write_field(vreg_acm_start_hi,TX_VR_ACM_PRLD_VAL_HI__ACM_PRLD_VAL_HI, tx_base);

  write_field(0x1, TX_VR_ACM_CTRL__ACM_PRLD, tx_base);
  write_field(0x0, TX_VR_LD_CTRL__LOCK_SEL, tx_base);
  
  write_field(0x041A, TX_VR_LD_LOCK_THRESH__LD_LOCK_THRESH, tx_base);
  write_field(0xBB8, TX_VR_LD_MEAS_PER__LD_MEAS_PER, tx_base);

  write_field(0x1, TX_VR_LD_LOCK_CNT__LD_LOCK_CNT, tx_base);
  write_field(0x50, TX_VR_FD_PER_MULT__PER_MULT, tx_base);
  write_field(0x1, TX_VR_FD_CTRL__SEL_FLTRD_FREQ, tx_base);
  
  write_field(vreg_freq_trgt_min, TX_VR_FD_FREQ_CNT_TRGT_MIN__FREQ_CNT_TRGT_MIN, tx_base);
  write_field(vreg_freq_trgt_max, TX_VR_FD_FREQ_CNT_TRGT_MAX__FREQ_CNT_TRGT_MAX, tx_base);
  
  write_field(0x0, TX_VR_CLK_GATE__GATE_CLK_CTRL, tx_base);

  // VREG Init sequence
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, tx_base);
  wait10nanoseconds(100); //wait 0.5 us
 	
  //reset read clarification
  // De-assert accumulator reset. Preload value will be on accm output
  write_field(0x1, TX_VR_RESET__ACM_RST_N, tx_base);
  wait10nanoseconds(10); //Wait 10 pclk cycles
  // De-assert dsm reset. DSM will output values corresponding to the above accm preload
  write_field(0x1, TX_VR_RESET__DSM_RST_N, tx_base);
  wait10nanoseconds(10); //Wait 10 pclk cycles
  
  // Drive DAC from controller
  write_field(0x1, TX_VR_RESET__DSM_OUT_RST_N, tx_base);
  wait10nanoseconds(10); //Wait 10 pclk cycles
 	
  // De-assert start
  write_field(0x0, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, tx_base);
  // Assert the regulator enable and allow vreg to stabilize
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__VREG_EN_FROM_RTL, tx_base);
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__VREG_DIV_EN_FROM_RTL, tx_base);
  wait10nanoseconds(20); //Wait 0.1 us
 	
  // Enable clk_vco clk gate. it should now be stable.	
  write_field(0x0, TX_VR_CLK_GATE__GATE_CLK_VCO, tx_base);
  wait10nanoseconds(10); //Wait 10 pclk cycles
 	
  // De-assert freq detect reset
  write_field(0x1, TX_VR_RESET__FD_RST_N, tx_base);
  wait10nanoseconds(100); //Wait 10 pclk cycles
 	
  // Remove the preload from the accumulator
  write_field(0x0, TX_VR_ACM_CTRL__ACM_PRLD, tx_base);
  wait10nanoseconds(40); //Wait 0.2us
 	
  // De-assert lock detector reset	
  write_field(0x1, TX_VR_RESET__LD_RST_N, tx_base);
 	
  //Poll Lock Detector to find Lock Status
  wait10nanoseconds(200); //Wait 10 pclk cycles
 
  val0 = readl(tx_base + TX_VR_LD_STAT);
  do 
    {
      val0 = readl(tx_base + TX_VR_LD_STAT);
    } while ((val0 & 0x0001) != 0x0001);

#else
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_DIV_EN_FROM_RTL,tx_base);
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_EN_FROM_RTL, tx_base);
  write_field(0x0, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW, tx_base);
  write_field(0x0, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV8_RTL, tx_base);
  write_field(0x1, TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, tx_base);
#endif
	
  //2.3.1.4 Wild Clock enable
  write_field(0x1, TX_WILD_CLK_CONFIG1__MPCG_WILD_EN, tx_base);
  write_field(0x1, TX_WILD_CLK_CONFIG1__MPCG_WILD_RST_N, tx_base);
  
  // Set MPCG pseudo-static control bits
  ser_ratio_value = 0x3 ;//8:1 serializer ratio
  write_field(ser_ratio_value, TX_SER_RATIO_CTRL__MPCG_SER_RATIO_CTRL, tx_base);
  write_field(0x1, TX_CLK_EN__MPCG_CLK_REG_EN, tx_base);
  write_field(0x1, TX_CLK_EN__MPCG_CLK_RTL_EN, tx_base);
  write_field(0x1, TX_CLK_EN__MPCG_CLK_LINK_LAYER_EN, tx_base);
  write_field(0x1, TX_CLK_SEL__MPCG_SEL_REG, tx_base);
  write_field(0x1, TX_SEL_LOAD__MPCG_SEL_LOAD, tx_base);
  
  //Assert and de-assert MPCG shift regs
  write_field(shift_reg_value, TX_SHIFT_REG_SETB__MPCG_SHIFT_REG_SETH_N, tx_base);
  write_field(shift_reg_value, TX_SHIFT_REG_RST__MPCG_SHIFT_REG_SETL, tx_base);
  write_field(0xffff, TX_SHIFT_REG_SETB__MPCG_SHIFT_REG_SETH_N, tx_base);
  write_field(0x0000, TX_SHIFT_REG_RST__MPCG_SHIFT_REG_SETL, tx_base);
 
  // Override DCC accumulators
  //tx_dcc_overrides_multi_slice(): from sv
  write_field(ovrd_clktx_ctrl_p, TX_DCC_CLKTX_CTRL_P_DSM_V_FIXED_VAL__VAL, tx_base);
  write_field(0x4, TX_DCC_COMP_SEL_OVERRIDES__COMP_SEL_INP_OVERRIDE_VAL, tx_base);
  write_field(0x1, TX_DCC_COMP_SEL_OVERRIDES__COMP_SEL_INM_OVERRIDE_VAL, tx_base);
  write_field(0x1, TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN, tx_base);
  write_field(ovrd_clktx_ctrl_n, TX_DCC_CLKTX_CTRL_N_ACC_OVERRIDE_VAL__VAL, tx_base);
  write_field(0x1, TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_OVERRIDE_EN, tx_base);
  write_field(ovrd_clktxb_ctrl_p, TX_DCC_CLKTXB_CTRL_P_ACC_OVERRIDE_VAL__VAL, tx_base);
  write_field(0x1, TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN, tx_base);
  write_field(ovrd_clktxb_ctrl_n, TX_DCC_CLKTXB_CTRL_N_ACC_OVERRIDE_VAL__VAL, tx_base);
  
  // Enable DCC Controller Clocks
  write_field(0x1, TX_DCC_MISC_CTRL__COMP_SEL_INP_OVERRIDE_EN, tx_base);
  write_field(0x1, TX_DCC_MISC_CTRL__COMP_SEL_INM_OVERRIDE_EN, tx_base);
  write_field(0x1, TX_DCC_MISC_CTRL__ACC_INPUT_OVERRIDE_EN, tx_base);
  write_field(0x0, TX_DCC_MISC_CTRL__DISABLE_WCLK, tx_base);
  wait10nanoseconds(4); //Wait 20 ns
  
  // Take DCC controller and DAC out of reset; enable analog portion of DCC
  write_field(0x1, TX_DCC_MISC_CTRL__SW_RST_N, tx_base);
  wait10nanoseconds(4); //Wait 20 ns
  // Take DCC DAC out of reset
  write_field(0x0, TX_DCC_CONFIG__DCC_DAC_RST, tx_base);
  wait10nanoseconds(4); //Wait 20 ns
  // Enable analog portion of the DCC
  write_field(0x1, TX_DCC_CONFIG__DCC_EN_DCC, tx_base);
#ifdef FAST_DCC_OVERRIDE
  wait10nanoseconds(1000); //Wait 5 US //RS_CHECK: Looks wrong as per the define?? 
#else 
  wait10nanoseconds(10);
#endif

  //2.3.1.7 Switch link layer clock from APB clock to PHY clock 
  //tx_clksel_apb2linklayer_d2d: sv task
  write_field(0x0, TX_LINK_LAYER_CLOCK_SEL__APB_CLK_EN, tx_base);
  write_field(0x1, TX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_ASYNC_CLK_EN, tx_base);
  write_field(0x1, TX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_SYNC_CLK_EN, tx_base);

  //2.3.1.8 Enable drivers
  //tx_fe_config_d2d: SV task
  write_field(0x5, TX_FE_DRV_EN_W0__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W1__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W2__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W3__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W4__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W5__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W6__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W7__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W8__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W9__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W10__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W11__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W12__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W13__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W14__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W15__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W16__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W17__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W18__TX_FE_DRV_EN_N,  tx_base);
  write_field(0x5, TX_FE_DRV_EN_W19__TX_FE_DRV_EN_N,  tx_base);
  
#ifdef TX_DCC_EN

  tx_dcc_adjustments_multi_slice(tx_base, 0);
  tx_dcc_adjustments_multi_slice(tx_base, 1);

  // Configure DCC lock detector
#ifndef DCC_DISABLE_LOCKDET
  write_field((0xFFFF&lockdet_thresh), TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_L__LSB, tx_base);
  write_field((0xFF&(lockdet_thresh>>16)), TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_M__MSB, tx_base);
  write_field(lockdet_period, TX_DCC_CLKTX_CTRL_N_LOCKDET_PERIOD__VAL, tx_base);
  write_field((0xFFFF&lockdet_thresh), TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_L__LSB, tx_base);
  write_field((0xFF&(lockdet_thresh>>16)), TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_M__MSB, tx_base);
  write_field(lockdet_period, TX_DCC_CLKTXB_CTRL_P_LOCKDET_PERIOD__VAL, tx_base);
  write_field((0xFFFF&lockdet_thresh), TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_L__LSB, tx_base);
  write_field((0xFF&(lockdet_thresh>>16)), TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_M__MSB, tx_base);
  write_field(lockdet_period , TX_DCC_CLKTXB_CTRL_N_LOCKDET_PERIOD__VAL, tx_base);
  write_field(lockdet_live, TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCK_SEL, tx_base);
  write_field(lockdet_live, TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCK_SEL, tx_base);
  write_field(lockdet_live, TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCK_SEL, tx_base);
  
  write_field(0x1, TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCKDET_RST_N, tx_base);
  write_field(0x1, TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCKDET_RST_N, tx_base);
  write_field(0x1, TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCKDET_RST_N, tx_base);

  // Allow time for DCC analog circuits to stabilize
  wait10nanoseconds(1000); //Wait 4.5 Us
  
  // Poll DCC lock detector locks
  do 
    {
      val0 = readl(tx_base + TX_DCC_LOCKDET_STAT);
    }while ((val0 & 0x0001) != 0x0001);
  
  do 
    {
      val0 = readl(tx_base + TX_DCC_LOCKDET_STAT);
      
    }while (((val0>>1) & 0x0001) != 0x0001);
  
  do 
    {
      val0 = readl(tx_base + TX_DCC_LOCKDET_STAT);
    }while (((val0>>2) & 0x0001) != 0x0001);
#endif

#else
  write_field(0x1, TX_PHYREADY_OVERRIDE__OVRD_VALUE, tx_base);
  write_field(0x1, TX_PHYREADY_OVERRIDE__OVRD, tx_base);
#endif

}

//--------------------------------------------------------------
// D2D RX init cfg
//--------------------------------------------------------------
void d2d_rx_init_cfg(uint32_t d2d_base_addr, int slice_idx)
{
  int i;
  uint32_t val0;
  uint32_t rx_base;
  uint32_t base1;
  uint32_t base2;

  if(slice_idx==1)
    {
      rx_base = d2d_base_addr + ((RX_SLICE_1_ADDR << 1));
    }
  else
    {
      rx_base = d2d_base_addr + ((RX_SLICE_0_ADDR << 1));
    }

  //2.2.2 Serialization and Deserialization Ratio Variables
  
  
  //2.2.3 Clock Frequency Dependent Variables
  uint32_t phase_sel = 0x0003; //4GHz (RX) //RS_CHECK??
  
  uint32_t rdata;
  uint32_t FlitSample00,FlitSample02;
  uint32_t offset_init_slice_0, offset_init_slice_1;
  uint8_t tx_bits_per_channel = 1,rx_bits_per_channel =1,bpc = 0;
  uint32_t final_adjustment = 0;
  
  //char vreg_fd_per_mult[] = “80”;
  bool vreg_fd_fltrd_freq = true;
  int vreg_fd_cnt_tol = 0;
  
  
  int apb_clk_period_in_ps = 2000;//Choose apb_clk_period_in_ps as per SoC usage dummy 
  //Note: This is the SoC APB Clock Period
  int vreg_target_per_ps = 1686;//1686ps; // 593Mhz
  int  vreg_exp_freq_cnt,vreg_freq_trgt_min,vreg_freq_trgt_max;
  
  vreg_exp_freq_cnt = (int) ((80* apb_clk_period_in_ps) / vreg_target_per_ps);
  vreg_freq_trgt_min = vreg_exp_freq_cnt - vreg_fd_cnt_tol;
  vreg_freq_trgt_max = vreg_exp_freq_cnt + vreg_fd_cnt_tol;
  
  uint32_t tx_tx_qpump_vreg_config = 0;
  uint32_t tx_vr_acm_ctrl = 0;
  uint32_t tx_vr_clk_gate = 0;
  uint32_t tx_vr_reset = 0;
  uint32_t shift_reg_value = 0x0F0F;// 8:1
  uint32_t ser_ratio_value = 10;
  uint32_t mux_sel_value = 0x0000;
  uint32_t deser_ratio_value = 10;
  uint32_t deser_lat_trans = 0;
  
  uint32_t ovrd_clktx_ctrl_p = 0x051F ;
  uint32_t ovrd_clktx_ctrl_n = 0x04F4 ;
  uint32_t ovrd_clktxb_ctrl_p = 0x051F;
  uint32_t ovrd_clktxb_ctrl_n = 0x04F4;
  uint32_t tx_dcc_comp_sel_overrides = 0;
 
  
  //Lock Detector setting variables:
  uint32_t lockdet_thresh = (1 << 15);
  uint32_t lockdet_period = (1 << 10);
  uint32_t lockdet_live = 0; // default: 0 - capture mode; 1 - live
  
#ifdef RX_VREG_EN
  // Config RX VREG // Write one-time settings

  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW, rx_base); 
  write_field(vreg_acm_adj_pos_lo, RX_VR_ACM_ADJ_POS_LO__ACM_ADJ_POS_LO, rx_base);
  write_field(vreg_acm_adj_pos_hi, RX_VR_ACM_ADJ_POS_HI__ACM_ADJ_POS_HI, rx_base);
  write_field(vreg_acm_adj_neg_lo, RX_VR_ACM_ADJ_NEG_LO__ACM_ADJ_NEG_LO, rx_base);
  write_field(vreg_acm_adj_neg_hi, RX_VR_ACM_ADJ_NEG_HI__ACM_ADJ_NEG_HI, rx_base);
  write_field(vreg_acm_start_lo, RX_VR_ACM_PRLD_VAL_LO__ACM_PRLD_VAL_LO, rx_base);
  write_field(vreg_acm_start_hi, RX_VR_ACM_PRLD_VAL_HI__ACM_PRLD_VAL_HI, rx_base);
  write_field(0x1, RX_VR_ACM_CTRL__ACM_PRLD, rx_base);
  write_field(0x0, RX_VR_LD_CTRL__LOCK_SEL, rx_base);
  write_field(0x41A, RX_VR_LD_LOCK_THRESH__LD_LOCK_THRESH, rx_base);
  write_field(0xBB8, RX_VR_LD_MEAS_PER__LD_MEAS_PER, rx_base);
  write_field(0x1, RX_VR_LD_LOCK_CNT__LD_LOCK_CNT, rx_base);
  write_field(0x50, RX_VR_FD_PER_MULT__PER_MULT, rx_base);
  write_field(0x1, RX_VR_FD_CTRL__SEL_FLTRD_FREQ, rx_base);
  write_field(vreg_freq_trgt_min, RX_VR_FD_FREQ_CNT_TRGT_MIN__FREQ_CNT_TRGT_MIN, rx_base);
  write_field(vreg_freq_trgt_max, RX_VR_FD_FREQ_CNT_TRGT_MAX__FREQ_CNT_TRGT_MAX, rx_base);
  write_field(0x0, RX_VR_CLK_GATE__GATE_CLK_CTRL, rx_base);

  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, rx_base);
  wait10nanoseconds(50);
  
  // De-assert accumulator reset. Preload value will
  // be on accm output
  write_field(0x1, RX_VR_RESET__ACM_RST_N, rx_base);
  wait10nanoseconds(10);
  
  // De-assert dsm reset. DSM will output values corresponding
  // to the above accm preload
  write_field(0x1, RX_VR_RESET__DSM_RST_N, rx_base);
  wait10nanoseconds(10);
  
  // Drive DAC from controller
  write_field(0x1, RX_VR_RESET__DSM_OUT_RST_N, rx_base);
  wait10nanoseconds(10);
  
  // Assert the regulator enable and allow vreg to stabilize
  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_EN_FROM_RTL, rx_base);
  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_DIV_EN_FROM_RTL, rx_base);
  wait10nanoseconds(10);
  
  // De-assert start
  write_field(0x0, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, rx_base);
  
  // Enable clk_vco clk gate. it shud be stable now.
  write_field(0x0, RX_VR_CLK_GATE__GATE_CLK_VCO, rx_base);
  wait10nanoseconds(100);
  
  // De-assert freq detect reset
  write_field(0x1, RX_VR_RESET__FD_RST_N, rx_base);
  wait10nanoseconds(100);
   
  // Remove the preload from the accumulator
  write_field(0x0, RX_VR_ACM_CTRL__ACM_PRLD, rx_base);
  wait10nanoseconds(20);
  
  // De-assert lock detector reset
  write_field(0x1, RX_VR_RESET__LD_RST_N, rx_base);
  // Poll Lock Detector to find Lock Status
  do
    {
      wait10nanoseconds(20);
      val0 = readl(rx_base + RX_VR_LD_STAT);
    } while((val0&0x1) != 0x1);

#else 
  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_DIV_EN_FROM_RTL, rx_base);
  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_EN_FROM_RTL, rx_base);
  write_field(0x0, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW, rx_base);
  write_field(0x0, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV8_RTL, rx_base);
  write_field(0x1, RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_START, rx_base);
#endif

  //2.3.2.3 Wild Clock enable
  //RS_TODO: Need to update the register write as per the rx_cfg[id].dll.mpcg_wild_hcount/lcount later rather than fixed value directly.
  //write_field(rx_cfg[id].dll.mpcg_wild_hcount, RX_WILD_CLK_CONFIG0__MPCG_WILD_HCOUNT, rx_base);
  //write_field(rx_cfg[id].dll.mpcg_wild_lcount, RX_WILD_CLK_CONFIG0__MPCG_WILD_LCOUNT, rx_base);
  write_field(0x0, RX_WILD_CLK_CONFIG0__MPCG_WILD_HCOUNT, rx_base);
  write_field(0x0, RX_WILD_CLK_CONFIG0__MPCG_WILD_LCOUNT, rx_base);
  write_field(0x1 , RX_WILD_CLK_CONFIG1__MPCG_WILD_EN, rx_base);
  write_field(0x1, RX_WILD_CLK_CONFIG1__MPCG_WILD_RST_N, rx_base);
  
  //2.3.2.4 Reset DLL
  // DLL Initialization

  rx_dll_config_d2d(rx_base, 1);
  rx_dll_config_d2d(rx_base, 0);

  //2.3.2.5 Clock generation config
  deser_ratio_value = 0x03;
  write_field(deser_ratio_value, RX_DESER_RATIO_CTRL__MPCG_DESER_RATIO_CTRL, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W0__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W1__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W2__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W3__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W4__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W5__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W6__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W7__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W8__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W9__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W10__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W11__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W12__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W13__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W14__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W15__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W16__DESER_LAT_TRANS_O, rx_base);
  write_field(deser_lat_trans, RX_DESER_LAT_TRANS_W17__DESER_LAT_TRANS_O, rx_base);
  
  write_field(0x1, RX_CLK_EN__MPCG_CLK_DES_EN, rx_base);
  write_field(0x1, RX_CLK_EN__MPCG_CLK_REG_EN, rx_base);
  write_field(0x1, RX_CLK_EN__MPCG_CLK_RTL_EN, rx_base);
  write_field(0x1, RX_CLK_EN__MPCG_CLK_LINK_LAYER_EN,rx_base);

  //uint32_t sel_phase = 0x1;
  uint32_t sel_phase = 0x0;
  write_field(sel_phase, RX_CLK_SEL__MPCG_SEL_DES, rx_base);
  write_field(sel_phase, RX_CLK_SEL__MPCG_SEL_REG, rx_base);
  write_field(sel_phase, RX_CLK_SEL__MPCG_SEL_RTL, rx_base);
  write_field(sel_phase, RX_CLK_SEL__MPCG_SEL_LINK_LAYER, rx_base);
  write_field(sel_phase, RX_SEL_DESER_MUX__MPCG_SEL_DESER_MUX, rx_base);

  // Assert and de-assert shift regs
  uint32_t shift_reg_out = 0xFF; //16:1
  write_field(shift_reg_out, RX_SHIFT_REG_OUT_SETH_N__MPCG_SHIFT_REG_OUT_SETH_N, rx_base);
  write_field(shift_reg_out, RX_SHIFT_REG_OUT_SETL__MPCG_SHIFT_REG_OUT_SETL, rx_base);
  write_field(0x0, RX_SHIFT_REG_MUX_SEL_SETH_N__MPCG_SHIFT_REG_MUX_SEL_SETH_N, rx_base);
  write_field(0x0, RX_SHIFT_REG_MUX_SEL_SETL__MPCG_SHIFT_REG_MUX_SEL_SETL, rx_base);

  write_field(0xFFFF, RX_SHIFT_REG_OUT_SETH_N__MPCG_SHIFT_REG_OUT_SETH_N, rx_base);
  write_field(0x0, RX_SHIFT_REG_OUT_SETL__MPCG_SHIFT_REG_OUT_SETL, rx_base);
  write_field(0xFFFF, RX_SHIFT_REG_MUX_SEL_SETH_N__MPCG_SHIFT_REG_MUX_SEL_SETH_N, rx_base);
  write_field(0x0, RX_SHIFT_REG_MUX_SEL_SETL__MPCG_SHIFT_REG_MUX_SEL_SETL, rx_base);
  
  write_field(0x1, RX_DLL_CONFIG__DLL_CLK_DIV_EN, rx_base);

  //2.3.2.6 Initialize DLL
  // Configure DLL/Override RX DLL accumulator values
#ifdef DLL_DISABLE_OVRD
  rx_dll_adjustments();
  rx_dll_disable_hold();
  //
  //
#else
  //rx_dll_config_override: sv test
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_0__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_1__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_2__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_3__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_4__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_5__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_6__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_R_PPHD_7__VAL, rx_base);
  
  write_field(0x353, RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL, rx_base);
  write_field(0x353, RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL, rx_base);

  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_0__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_1__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_2__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_3__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_4__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_5__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_6__VAL, rx_base);
  write_field(0x100, RX_DLL_OVRD_VAL_CTRL_D_PPHD_7__VAL, rx_base);
  
  write_field(0x804, RX_DLL_OVRD_VAL_CTRL_D_INT__VAL, rx_base);

  // Enable RX DLL Override
  //rx_dll_enable_override: sv test
  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_R__PPHD, rx_base);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_EV, rx_base);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_OD, rx_base);
  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_D__PPHD, rx_base);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_D__CTRL_D_INT, rx_base);
  
  // Enable DLL controller clocks
  write_field(0x0, RX_DLL_MISC_CTRL__GATE_CLK, rx_base);

  // De-assert DLL controller reset
  write_field(0x1, RX_DLL_MISC_CTRL__RST_N, rx_base);
#endif
  
  // Start: Structural Model - The code in this block is used for the structural model
  // Allow time for DLL analog circuits to stabilize

  // Not implemented in DV Simulation

  // End: Structural Model - The code in this block is used for the structural model

  
  // Start: Behavioral Model - The code in this block is used for the Behavioral model
  // Force DLL lock detector to lock
  // rx_dll_lock_det_force: sv task
  write_field(0x1, RX_DLL_LD_CTRL__FORCE_CTRL_R_INT_EV, rx_base);
  write_field(0x1, RX_DLL_LD_CTRL__FORCE_CTRL_R_INT_OD, rx_base);
  write_field(0x1, RX_DLL_LD_CTRL__FORCE_CTRL_D_INT, rx_base);
  // End: Behavioral Model - The code in this block is used for the Behavioral model
 
  //2.3.2.7 Switch link layer clock from APB clock to PHY clock
  //rx_clksel_apb2linklayer_d2d
  write_field(0x0, RX_LINK_LAYER_CLOCK_SEL__APB_CLK_EN, rx_base);
  write_field(0x1, RX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_ASYNC_CLK_EN, rx_base);
  write_field(0x1, RX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_SYNC_CLK_EN, rx_base);

  //rx_override_phyready_d2d
  write_field(0x1, RX_PHYREADY_OVERRIDE__OVRD_VALUE, rx_base);
  write_field(0x1, RX_PHYREADY_OVERRIDE__OVRD, rx_base);

}

//--------------------------------------------------------------
// D2D init cfg
//--------------------------------------------------------------
void d2d_init_cfg(uint32_t d2d_base_addr, int num_slice)
{
  int i;
  uint32_t val0;
  uint32_t tx_base;
  uint32_t rx_base;
  uint32_t base1;
  uint32_t base2;
  if(num_slice==2)
    {
      d2d_tx_init_cfg (d2d_base_addr, 0);
      d2d_tx_init_cfg (d2d_base_addr, 1);
      d2d_rx_init_cfg (d2d_base_addr, 0);
      d2d_rx_init_cfg (d2d_base_addr, 1);
    }
  else
    {
      d2d_tx_init_cfg (d2d_base_addr, 0);
      d2d_rx_init_cfg (d2d_base_addr, 0);
    }
}

//--------------------------------------------------------------
// D2D init cfg
//--------------------------------------------------------------
void link_training_and_word_alignment(uint32_t d2d1_base_addr, uint32_t d2d2_base_addr, int num_slice)
{
 
  if(num_slice == 2)  {
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_TRAIN)
    writel(0x59, (d2d1_base_addr + 0x9004));
    writel(0x59, (d2d2_base_addr + 0x9004));
 	  
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b01 (TX_TRAIN)
    writel(0x99, (d2d2_base_addr + 0x8004));
    writel(0x99, (d2d1_base_addr + 0x8004));
  }  else   {
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_TRAIN)
    writel(0x49, (d2d1_base_addr + 0x9004));
    writel(0x49, (d2d2_base_addr + 0x9004));
   	
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b01 (TX_TRAIN)
    writel(0x89, (d2d2_base_addr + 0x8004));
    writel(0x89, (d2d1_base_addr + 0x8004));
  }
  // Nudge the slice 1 read pointers twice
  // This is a workaround for any clock shifting during phase alignment
  writel(0x4, (d2d2_base_addr + 0x9144));
  writel(0x4, (d2d2_base_addr + 0x9144));
  
  writel(0x4, (d2d1_base_addr + 0x9144));
  writel(0x4, (d2d1_base_addr + 0x9144));
  
  // Trigger sample for intra-slice phase alignment (i.e. word alignment)
  writel(0x1, (d2d2_base_addr + 0x9140));
  writel(0x1, (d2d1_base_addr + 0x9140));

  // Fix the alignment in the PHYs. Read the sample data and set the config with the alignment offset
  //first the responder and then repeat it for requester

  uint32_t rdata;
  uint32_t rdata2;
  int timeout;
  uint32_t FlitSample00_d2d1, FlitSample00_d2d2;
  uint32_t FlitSample02_d2d1, FlitSample02_d2d2;
  int offset_init_slice_0_d2d1, offset_init_slice_1_d2d1;
  int offset_init_slice_0_d2d2, offset_init_slice_1_d2d2;
  
  FlitSample00_d2d2 = readl((d2d2_base_addr +0x9400));
  FlitSample02_d2d2 = readl((d2d2_base_addr +0x9408));
 
  uint8_t firstbyte_FlitSample00_d2d2  = (FlitSample00_d2d2)&0xff;
  uint8_t firstbyte_FlitSample02_d2d2  = (FlitSample02_d2d2 )&0xff;
 	
  offset_init_slice_0_d2d2 = get_word_alignment_offset(firstbyte_FlitSample00_d2d2,firstbyte_FlitSample02_d2d2); //Slice-0
  
  if(num_slice == 2) {
    uint8_t secondbyte_FlitSample00_d2d2 = (FlitSample00_d2d2 >> 8)&0xff;
    uint8_t secondbyte_FlitSample02_d2d2 = (FlitSample02_d2d2 >> 8)&0xff;
    
    offset_init_slice_1_d2d2 = get_word_alignment_offset(secondbyte_FlitSample00_d2d2,secondbyte_FlitSample02_d2d2); //Slice-1
  }

  FlitSample00_d2d1 = readl((d2d1_base_addr +0x9400));
  FlitSample02_d2d1 = readl((d2d1_base_addr +0x9408));
  
  uint8_t firstbyte_FlitSample00_d2d1  = (FlitSample00_d2d1)&0xff;
  uint8_t firstbyte_FlitSample02_d2d1  = (FlitSample02_d2d1)&0xff;

  offset_init_slice_0_d2d1 = get_word_alignment_offset(firstbyte_FlitSample00_d2d1,firstbyte_FlitSample02_d2d1); //Slice-0
  
  if(num_slice == 2) {
    uint8_t secondbyte_FlitSample00_d2d1 = (FlitSample00_d2d1 >> 8)&0xff;
    uint8_t secondbyte_FlitSample02_d2d1 = (FlitSample02_d2d1 >> 8)&0xff;
    
    offset_init_slice_1_d2d1 = get_word_alignment_offset(secondbyte_FlitSample00_d2d1,secondbyte_FlitSample02_d2d1); //Slice-1
  }
 
  if((offset_init_slice_0_d2d1 != 0) || (offset_init_slice_0_d2d2 != 0)) {
    rx_dll_word_alignment(d2d1_base_addr, d2d2_base_addr, offset_init_slice_0_d2d1, offset_init_slice_0_d2d2,0);
  }

  if(num_slice == 2) {
    if((offset_init_slice_1_d2d1 != 0) || (offset_init_slice_1_d2d2 != 0)) {
      rx_dll_word_alignment(d2d1_base_addr, d2d2_base_addr,offset_init_slice_1_d2d1, offset_init_slice_1_d2d2,1);
    }
  }

  if(num_slice == 2) {
    // Reset deskew FIFOs: This is a workaround to update the FIFO pointers with the new clock relationship;
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_IDLE) both slices, 256 bit width
    writel(0x58, (d2d1_base_addr+0x9004));
    writel(0x58, (d2d2_base_addr+0x9004));
    
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_TRAIN) both slices, 256 bit width
    writel(0x59, (d2d1_base_addr+0x9004));
    writel(0x59, (d2d2_base_addr+0x9004));
  } else {
    // Reset deskew FIFOs: This is a workaround to update the FIFO pointers with the new clock relationship;
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_IDLE) both slices, 256 bit width
    writel(0x48, (d2d1_base_addr+0x9004));
    writel(0x48, (d2d2_base_addr+0x9004));
    
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b01 (RX_TRAIN) both slices, 256 bit width
    writel(0x49, (d2d1_base_addr+0x9004));
    writel(0x49, (d2d2_base_addr+0x9004));
  }
  // Trigger sample for inter-slice fragment skew
  writel(0x1, (d2d1_base_addr+0x9140));
  writel(0x1, (d2d2_base_addr+0x9140));

  //read back the interslice error and call the correction task
  rdata = readl((d2d2_base_addr+0x9400));
  correct_relative_skew(d2d2_base_addr, rdata);
  
  rdata = readl((d2d1_base_addr+0x9400));
  correct_relative_skew(d2d1_base_addr, rdata);
  
  if(num_slice == 2) {
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b00 (TX_IDLE) and
    //TxInterfaceControlStatus.LinkReset[7] = 0b1
    writel(0x98, (d2d2_base_addr+0x8004));
    writel(0x98, (d2d1_base_addr+0x8004));

    //clear tx link reset
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b00 (TX_IDLE) and
    //TxInterfaceControlStatus.LinkReset[7] = 0b0
    writel(0x18, (d2d2_base_addr+0x8004));
    writel(0x18, (d2d1_base_addr+0x8004));
  } else {
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b00 (TX_IDLE) and
    //TxInterfaceControlStatus.LinkReset[7] = 0b1
    writel(0x88, (d2d2_base_addr+0x8004));
    writel(0x88, (d2d1_base_addr+0x8004));

    //clear tx link reset
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b00 (TX_IDLE) and
    //TxInterfaceControlStatus.LinkReset[7] = 0b0
    writel(0x8, (d2d2_base_addr+0x8004));
    writel(0x8, (d2d1_base_addr+0x8004));
  }

  //Trigger sample to check idle
  timeout = 100;
  do{
    writel(0x1, (d2d2_base_addr+0x9140));
    rdata = readl((d2d2_base_addr+0x9410));
    timeout -= 1;
    if(timeout == 0)
      {EOT_FAIL_MSG}
  } while (rdata != 0x0);


  timeout = 100;
  do{
    writel(0x1, (d2d1_base_addr+0x9140));
    rdata = readl((d2d1_base_addr+0x9410));
    timeout -= 1;
    if(timeout == 0)
      {EOT_FAIL_MSG}
  } while (rdata != 0x0);


  if(num_slice == 2)  {
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b10 (RX_WAIT) and //RxInterfaceControlStatus.LinkReset[6] = 0b1
    writel(0x5A, (d2d1_base_addr+0x9004));
    writel(0x5A, (d2d2_base_addr+0x9004));

    //Write RxInterfaceControlStatus.Mode[1:0] = 0b10 (RX_WAIT) and //RxInterfaceControlStatus.LinkReset[6] = 0b0
    writel(0x1A, (d2d1_base_addr+0x9004));
    writel(0x1A, (d2d2_base_addr+0x9004));
    
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b11 (TX_RUN)
    writel(0x1B, (d2d1_base_addr+0x8004));
    writel(0x1B, (d2d2_base_addr+0x8004));
  }  else   {
    //Write RxInterfaceControlStatus.Mode[1:0] = 0b10 (RX_WAIT) and //RxInterfaceControlStatus.LinkReset[6] = 0b1
    writel(0x4A, (d2d1_base_addr+0x9004));
    writel(0x4A, (d2d2_base_addr+0x9004));

    //Write RxInterfaceControlStatus.Mode[1:0] = 0b10 (RX_WAIT) and //RxInterfaceControlStatus.LinkReset[6] = 0b0
    writel(0xA, (d2d1_base_addr+0x9004));
    writel(0xA, (d2d2_base_addr+0x9004));
    
    //Write TxInterfaceControlStatus.Mode[1:0] = 0b11 (TX_RUN)
    writel(0xB, (d2d1_base_addr+0x8004));
    writel(0xB, (d2d2_base_addr+0x8004));
  }
  
  //Read RxInterfaceControlStatus.Mode[1:0] until 0b11 (RX_RUN) then write RxVirtualWireDisable00 = 0
  rdata = readl((d2d1_base_addr+0x9004));
  timeout = 100;
  while((rdata & 0x3) != 0x3){
    rdata = readl((d2d1_base_addr+0x9004));
    timeout -= 1;
    if(timeout == 0)
      {EOT_FAIL_MSG}
  }
  writel(0x0, (d2d1_base_addr+0x9800));
  
  rdata = readl((d2d2_base_addr+0x9004));
  timeout = 100;
  while((rdata & 0x3) != 0x3){
    rdata = readl((d2d2_base_addr+0x9004));
    timeout -= 1;
    if(timeout == 0)
      {EOT_FAIL_MSG}
  }
  writel(0x0, (d2d2_base_addr+0x9800));

  //Write TxVirtualWireDisable00 = 0
  writel(0x0, (d2d2_base_addr+0x8800));
  writel(0x0, (d2d1_base_addr+0x8800));

}


static int get_word_alignment_offset(uint8_t sample00, uint8_t sample02) {
    int adjustment = 0;
    switch (sample00 & 0x07) {
        case 0: adjustment = 0; break;
        case 1: adjustment = -2; break;
        case 2: adjustment = -4; break;
        case 3: adjustment = -6; break;
        case 4: adjustment = 8; break;
        case 5: adjustment = 6; break;
        case 6: adjustment = 4; break;
        case 7: adjustment = 2; break;
        default: adjustment = 0; break;
    }
    
    // extra tweak incase the behavioral DLL locks on a half word boundary
    if (sample00 != sample02) {
        adjustment = adjustment - 1;
    }
    return adjustment;
}

static void wait10nanoseconds(int time)
{
	int i=0;
	while(i<time)
	{
		asm("nop");
		i++;	
	}
}

//------------
//Added By SandeshK
//------------
static void tx_dcc_adjustments_multi_slice(uint32_t base_addr, int adj_slow)
{
  uint32_t val;
  //fast mode
  int pos_adj_clktx_ctrl_n_fast = (1 << 17);
  int pos_adj_clktxb_ctrl_p_fast = pos_adj_clktx_ctrl_n_fast;
  int pos_adj_clktxb_ctrl_n_fast = (1 << 11);
  int neg_adj_clktx_ctrl_n_fast = -pos_adj_clktx_ctrl_n_fast;
  int neg_adj_clktxb_ctrl_p_fast = -pos_adj_clktxb_ctrl_p_fast;
  int neg_adj_clktxb_ctrl_n_fast = -pos_adj_clktxb_ctrl_n_fast;

  //slow mode
  int pos_adj_clktx_ctrl_n_slow = (1 << 11);
  int pos_adj_clktxb_ctrl_p_slow = pos_adj_clktx_ctrl_n_slow;
  int pos_adj_clktxb_ctrl_n_slow = pos_adj_clktxb_ctrl_p_slow;
  int neg_adj_clktx_ctrl_n_slow = -pos_adj_clktx_ctrl_n_slow;
  int neg_adj_clktxb_ctrl_p_slow = -pos_adj_clktxb_ctrl_p_slow;
  int neg_adj_clktxb_ctrl_n_slow = -pos_adj_clktxb_ctrl_n_slow;
  
  write_field(0x1, TX_DCC_DCC_FREEZE__FREEZE, base_addr);
  write_field(0x1, TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_EN, base_addr);

  if(adj_slow) {
    val = 0xFFFF&pos_adj_clktx_ctrl_n_slow;
  }
  else {
    val = 0xFFFF&pos_adj_clktx_ctrl_n_fast;
  }
  write_field(val, TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_L__LSB, base_addr);

  if(adj_slow) {
    val = 0xFF&(pos_adj_clktx_ctrl_n_slow>>16);
  }
  else {
    val = 0xFF&(pos_adj_clktx_ctrl_n_fast>>16);
  }
  write_field(val, TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_M__MSB, base_addr);

  if(adj_slow) {
    val = 0xFFFF&neg_adj_clktx_ctrl_n_slow;
  }
  else {
    val = 0xFFFF&neg_adj_clktx_ctrl_n_fast;
  }
  write_field(val, TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_L__LSB, base_addr);

  if(adj_slow) {
    val = 0xFF&(neg_adj_clktx_ctrl_n_slow>>16);
  }
  else {
    val = 0xFF&(neg_adj_clktx_ctrl_n_fast>>16);
  }
  write_field(val, TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_M__MSB, base_addr);
  
  write_field(0x1, TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_EN, base_addr);

  if(adj_slow) {
    val = 0xFFFF&pos_adj_clktxb_ctrl_p_slow;
  }
  else {
    val = 0xFFFF&pos_adj_clktxb_ctrl_p_fast;
  }

  write_field(val, TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_L__LSB, base_addr);

  if(adj_slow) {
    val = 0xFF&(pos_adj_clktxb_ctrl_p_slow>>16);
  }
  else {
    val = 0xFF&(pos_adj_clktxb_ctrl_p_fast>>16);
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_M__MSB, base_addr);

  if(adj_slow) {
    val = 0xFFFF&neg_adj_clktxb_ctrl_p_slow;
  }
  else {
    val = 0xFFFF&neg_adj_clktxb_ctrl_p_fast;
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_L__LSB, base_addr);

  if(adj_slow) {
    val = 0xFF&(neg_adj_clktxb_ctrl_p_slow>>16);
  }
  else {
    val = 0xFF&(neg_adj_clktxb_ctrl_p_fast>>16);
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_M__MSB, base_addr);


  write_field(0x1, TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_EN, base_addr);

  if(adj_slow) {
    val = 0xFFFF&pos_adj_clktxb_ctrl_n_slow;
  }
  else {
    val = 0xFFFF&pos_adj_clktxb_ctrl_n_fast;
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_L__LSB, base_addr);

  if(adj_slow) {
    val = 0xFF&(pos_adj_clktxb_ctrl_n_slow>>16);
  }
  else {
    val = 0xFF&(pos_adj_clktxb_ctrl_n_fast>>16);
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_M__MSB, base_addr);

  if(adj_slow) {
    val = 0xFFFF&neg_adj_clktxb_ctrl_n_slow;
  }
  else {
    val = 0xFFFF&neg_adj_clktxb_ctrl_n_fast;
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_L__LSB, base_addr);
  
  if(adj_slow) {
    val = 0xFF&(neg_adj_clktxb_ctrl_n_slow>>16);
  }
  else {
    val = 0xFF&(neg_adj_clktxb_ctrl_n_fast>>16);
  }
  write_field(val, TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_M__MSB, base_addr);
  
  write_field(0x0, TX_DCC_DCC_FREEZE__FREEZE, base_addr);
  
  // Disable DCC accumulator overrides
  write_field(0x0, TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN, base_addr);
  write_field(0x0, TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_OVERRIDE_EN, base_addr);
  write_field(0x0, TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN, base_addr);
} 


static void rx_dll_config_d2d(uint32_t rx_base_addr, uint8_t enable_clock)
{
  // Configure DLL
  write_field(0xFF, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETH_N, rx_base_addr);
  write_field(0xFF, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETL, rx_base_addr);
  write_field(0x1, RX_DLL_CONFIG__DLL_PPHD_DAC_RST, rx_base_addr);
  write_field(0x1, RX_DLL_CONFIG__DLL_PPHD_DAC_BIAS_RST, rx_base_addr);
  write_field(0x1, RX_DLL_CONFIG__DLL_INT_RST, rx_base_addr);
  write_field(0x1, RX_DLL_CONFIG__DLL_LVL_RST, rx_base_addr);
  write_field(0x0, RX_DLL_CONFIG__DLL_DAC_INT_SET_N, rx_base_addr);

  // Enable clock receiver
  write_field(0x1, RX_CLKRX_CONFIG__CLKRX_EN, rx_base_addr);
  // De-assert internal DLL reset
  write_field(0x0, RX_DLL_CONFIG__DLL_INT_RST, rx_base_addr);
  // Reset the divider by asserting and de-asserting shift regs
  write_field(0x0, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETL, rx_base_addr);
  write_field(0x3F, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETH_N, rx_base_addr);
  write_field(0x3F, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETL, rx_base_addr);
  write_field(0xFF, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETH_N, rx_base_addr);
  write_field(0x0, RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETL, rx_base_addr);
  // De-assert 4 active-low DLL resets and 1 active-high set
  write_field(0x0, RX_DLL_CONFIG__DLL_PPHD_DAC_RST, rx_base_addr);
  write_field(0x0, RX_DLL_CONFIG__DLL_PPHD_DAC_BIAS_RST, rx_base_addr);
  write_field(0x0, RX_DLL_CONFIG__DLL_INT_RST, rx_base_addr);
  write_field(0x0, RX_DLL_CONFIG__DLL_LVL_RST, rx_base_addr);
  write_field(0x1, RX_DLL_CONFIG__DLL_DAC_INT_SET_N, rx_base_addr);
  wait10nanoseconds(1);

  if(enable_clock == 0x1)
    {
      write_field(0x1, RX_DLL_CONFIG__DLL_CLK_DIV_EN, rx_base_addr);
      write_field(0x0, RX_DLL_CONFIG__DLL_CLK_DIV_EN, rx_base_addr);
    }
}


static void rx_dll_word_alignment(uint32_t d2d1_base_addr, uint32_t d2d2_base_addr, int adjustment, int adjustment_2, int slice_idx)
{
  int ctrl_r_pphd[8], ctrl_d_pphd[8]; //9bits
  int ctrl_r_int_ev_msb_cur, ctrl_r_int_od_msb_cur, ctrl_d_int_msb_cur; //3bits, need 4bits signed to achieve adjustment >=8 or <=-8
  int ctrl_r_int_ev_msb_tgt, ctrl_r_int_od_msb_tgt, ctrl_d_int_msb_tgt; //3bits, need 4bits signed to achieve adjustment >=8 or <=-8
  int ctrl_r_int_ev_lsb_cur, ctrl_r_int_od_lsb_cur, ctrl_d_int_lsb_cur; //11bits
  int ctrl_r_int_ev_lsb_tgt, ctrl_r_int_od_lsb_tgt, ctrl_d_int_lsb_tgt; //11bits
  int rdata_lo, rdata_hi; //16bits

  int ctrl_r_pphd_2[8], ctrl_d_pphd_2[8]; //9bits
  int ctrl_r_int_ev_msb_cur_2, ctrl_r_int_od_msb_cur_2, ctrl_d_int_msb_cur_2; //3bits, need 4bits signed to achieve adjustment >=8 or <=-8
  int ctrl_r_int_ev_msb_tgt_2, ctrl_r_int_od_msb_tgt_2, ctrl_d_int_msb_tgt_2; //3bits, need 4bits signed to achieve adjustment >=8 or <=-8
  int ctrl_r_int_ev_lsb_cur_2, ctrl_r_int_od_lsb_cur_2, ctrl_d_int_lsb_cur_2; //11bits
  int ctrl_r_int_ev_lsb_tgt_2, ctrl_r_int_od_lsb_tgt_2, ctrl_d_int_lsb_tgt_2; //11bits
  //int rdata_lo, rdata_hi; //16bits
  uint32_t d2d1_base_and_slice_addr,d2d2_base_and_slice_addr;

  if(slice_idx == 1) 
  {
    d2d1_base_and_slice_addr = d2d1_base_addr + (RX_SLICE_1_ADDR << 1);
    d2d2_base_and_slice_addr = d2d2_base_addr + (RX_SLICE_1_ADDR << 1);
  } 
  else
  {
    d2d1_base_and_slice_addr = d2d1_base_addr + (RX_SLICE_0_ADDR << 1);
    d2d2_base_and_slice_addr = d2d2_base_addr + (RX_SLICE_0_ADDR << 1);
  }
  
  write_field(0x1, RX_DLL_DLL_FREEZE__FREEZE, d2d1_base_and_slice_addr);
  write_field(0x1, RX_DLL_DLL_FREEZE__FREEZE, d2d2_base_and_slice_addr);

  //---- 1st D2D ---
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_0__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_0__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[0] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_1__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_1__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[1] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_2__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_2__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[2] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_3__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_3__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[3] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_4__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_4__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[4] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_5__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_5__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[5] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_6__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_6__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[6] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_7__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_7__MSW, d2d1_base_and_slice_addr);
  ctrl_r_pphd[7] = ((rdata_hi<<16) + rdata_lo) >> 15;

  //---- 2nd D2D ---
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_0__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_0__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[0] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_1__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_1__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[1] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_2__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_2__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[2] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_3__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_3__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[3] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_4__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_4__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[4] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_5__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_5__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[5] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_6__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_6__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[6] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_7__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_7__MSW, d2d2_base_and_slice_addr);
  ctrl_r_pphd_2[7] = ((rdata_hi<<16) + rdata_lo) >> 15;

  //--- D2D 1st
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_LO__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_HI__MSW, d2d1_base_and_slice_addr);
  ctrl_r_int_ev_msb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_r_int_ev_lsb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_LO__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_HI__MSW, d2d1_base_and_slice_addr);
  ctrl_r_int_od_msb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_r_int_od_lsb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);

  //--- D2D 2nd
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_LO__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_HI__MSW, d2d2_base_and_slice_addr);
  ctrl_r_int_ev_msb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_r_int_ev_lsb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_LO__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_HI__MSW, d2d2_base_and_slice_addr);
  ctrl_r_int_od_msb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_r_int_od_lsb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);

  //--- D2D 1st
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_0__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_0__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[0] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_1__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_1__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[1] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_2__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_2__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[2] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_3__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_3__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[3] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_4__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_4__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[4] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_5__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_5__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[5] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_6__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_6__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[6] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_7__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_7__MSW, d2d1_base_and_slice_addr);
  ctrl_d_pphd[7] = ((rdata_hi<<16) + rdata_lo) >> 15;
  
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_INT_LO__LSW, d2d1_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_INT_HI__MSW, d2d1_base_and_slice_addr);
  ctrl_d_int_msb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_d_int_lsb_cur = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);

  //--- D2D 2nd
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_0__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_0__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[0] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_1__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_1__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[1] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_2__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_2__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[2] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_3__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_3__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[3] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_4__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_4__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[4] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_5__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_5__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[5] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_6__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_6__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[6] = ((rdata_hi<<16) + rdata_lo) >> 15;

  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_7__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_7__MSW, d2d2_base_and_slice_addr);
  ctrl_d_pphd_2[7] = ((rdata_hi<<16) + rdata_lo) >> 15;
  
  rdata_lo = read_field(rdata_lo, RX_DLL_ACCUM_OBSV_CTRL_D_INT_LO__LSW, d2d2_base_and_slice_addr);
  rdata_hi = read_field(rdata_hi, RX_DLL_ACCUM_OBSV_CTRL_D_INT_HI__MSW, d2d2_base_and_slice_addr);
  ctrl_d_int_msb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) >> 11;
  ctrl_d_int_lsb_cur_2 = (((rdata_hi<<16) + rdata_lo) >> 10) & ((1<<11)-1);
  
  
  write_field(0x0, RX_DLL_DLL_FREEZE__FREEZE, d2d1_base_and_slice_addr);
  write_field(0x0, RX_DLL_DLL_FREEZE__FREEZE, d2d2_base_and_slice_addr);

  ///////////////////////////////////////////////////
  // Override accumulators at current sample point //
  ///////////////////////////////////////////////////
  write_field(ctrl_r_pphd[0]  , RX_DLL_OVRD_VAL_CTRL_R_PPHD_0__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[0], RX_DLL_OVRD_VAL_CTRL_R_PPHD_0__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[1]  , RX_DLL_OVRD_VAL_CTRL_R_PPHD_1__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[1], RX_DLL_OVRD_VAL_CTRL_R_PPHD_1__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[2] , RX_DLL_OVRD_VAL_CTRL_R_PPHD_2__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[2], RX_DLL_OVRD_VAL_CTRL_R_PPHD_2__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[3] , RX_DLL_OVRD_VAL_CTRL_R_PPHD_3__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[3], RX_DLL_OVRD_VAL_CTRL_R_PPHD_3__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[4]  , RX_DLL_OVRD_VAL_CTRL_R_PPHD_4__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[4], RX_DLL_OVRD_VAL_CTRL_R_PPHD_4__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[5]  , RX_DLL_OVRD_VAL_CTRL_R_PPHD_5__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[5], RX_DLL_OVRD_VAL_CTRL_R_PPHD_5__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[6]  , RX_DLL_OVRD_VAL_CTRL_R_PPHD_6__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[6], RX_DLL_OVRD_VAL_CTRL_R_PPHD_6__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_r_pphd[7] , RX_DLL_OVRD_VAL_CTRL_R_PPHD_7__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_r_pphd_2[7], RX_DLL_OVRD_VAL_CTRL_R_PPHD_7__VAL, d2d2_base_and_slice_addr);

  write_field(((ctrl_r_int_ev_msb_cur&0x7)<<11) + ctrl_r_int_ev_lsb_cur, RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL, d2d1_base_and_slice_addr);
  write_field(((ctrl_r_int_ev_msb_cur_2&0x7)<<11) + ctrl_r_int_ev_lsb_cur_2, RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL, d2d2_base_and_slice_addr);
  
  write_field(((ctrl_r_int_od_msb_cur&0x7)<<11) + ctrl_r_int_od_lsb_cur, RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL, d2d1_base_and_slice_addr);
  write_field(((ctrl_r_int_od_msb_cur_2&0x7)<<11) + ctrl_r_int_od_lsb_cur_2, RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL, d2d2_base_and_slice_addr);
  

  write_field(ctrl_d_pphd[0], RX_DLL_OVRD_VAL_CTRL_D_PPHD_0__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[0], RX_DLL_OVRD_VAL_CTRL_D_PPHD_0__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[1], RX_DLL_OVRD_VAL_CTRL_D_PPHD_1__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[1], RX_DLL_OVRD_VAL_CTRL_D_PPHD_1__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[2], RX_DLL_OVRD_VAL_CTRL_D_PPHD_2__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[2], RX_DLL_OVRD_VAL_CTRL_D_PPHD_2__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[3], RX_DLL_OVRD_VAL_CTRL_D_PPHD_3__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[3], RX_DLL_OVRD_VAL_CTRL_D_PPHD_3__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[4], RX_DLL_OVRD_VAL_CTRL_D_PPHD_4__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[4], RX_DLL_OVRD_VAL_CTRL_D_PPHD_4__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[5], RX_DLL_OVRD_VAL_CTRL_D_PPHD_5__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[5], RX_DLL_OVRD_VAL_CTRL_D_PPHD_5__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[6], RX_DLL_OVRD_VAL_CTRL_D_PPHD_6__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[6], RX_DLL_OVRD_VAL_CTRL_D_PPHD_6__VAL, d2d2_base_and_slice_addr);

  write_field(ctrl_d_pphd[7], RX_DLL_OVRD_VAL_CTRL_D_PPHD_7__VAL, d2d1_base_and_slice_addr);
  write_field(ctrl_d_pphd_2[7], RX_DLL_OVRD_VAL_CTRL_D_PPHD_7__VAL, d2d2_base_and_slice_addr);
  
  
  write_field(((ctrl_d_int_msb_cur&0x7)<<11) + ctrl_d_int_lsb_cur, RX_DLL_OVRD_VAL_CTRL_D_INT__VAL, d2d1_base_and_slice_addr);
  write_field(((ctrl_d_int_msb_cur_2&0x7)<<11) + ctrl_d_int_lsb_cur, RX_DLL_OVRD_VAL_CTRL_D_INT__VAL, d2d2_base_and_slice_addr);

  //rx_dll_enable_override
  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_R__PPHD, d2d1_base_and_slice_addr);
  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_R__PPHD, d2d2_base_and_slice_addr);

  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_EV, d2d1_base_and_slice_addr);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_EV, d2d2_base_and_slice_addr);
 
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_OD, d2d1_base_and_slice_addr);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_R__INT_OD, d2d2_base_and_slice_addr);

  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_D__PPHD, d2d1_base_and_slice_addr);
  write_field(0xFF, RX_DLL_OVRD_ACCUM_CTRL_D__PPHD, d2d2_base_and_slice_addr);
 
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_D__CTRL_D_INT, d2d1_base_and_slice_addr);
  write_field(0x1, RX_DLL_OVRD_ACCUM_CTRL_D__CTRL_D_INT, d2d2_base_and_slice_addr);
  
  //////////////////////////////////////
  // Calculate target override values //
  //////////////////////////////////////
  ctrl_r_int_ev_msb_tgt = ctrl_r_int_ev_msb_cur + adjustment;
  ctrl_r_int_od_msb_tgt = ctrl_r_int_od_msb_cur + adjustment;
  ctrl_d_int_msb_tgt = ctrl_d_int_msb_cur + adjustment;
  ctrl_r_int_ev_lsb_tgt = ctrl_r_int_ev_lsb_cur;
  ctrl_r_int_od_lsb_tgt = ctrl_r_int_od_lsb_cur;
  ctrl_d_int_lsb_tgt = ctrl_d_int_lsb_cur;

  ctrl_r_int_ev_msb_tgt_2 = ctrl_r_int_ev_msb_cur_2 + adjustment_2;
  ctrl_r_int_od_msb_tgt_2 = ctrl_r_int_od_msb_cur_2 + adjustment_2;
  ctrl_d_int_msb_tgt_2 = ctrl_d_int_msb_cur_2 + adjustment_2;
  ctrl_r_int_ev_lsb_tgt_2 = ctrl_r_int_ev_lsb_cur_2;
  ctrl_r_int_od_lsb_tgt_2 = ctrl_r_int_od_lsb_cur_2;
  ctrl_d_int_lsb_tgt_2 = ctrl_d_int_lsb_cur_2;
  
  /////////////////////////////////////////////////
  // Move one UI at a time until reaching target //
  // If moving across 'h200, break into 2 steps  //
  /////////////////////////////////////////////////
  //--- D2D 1
  while ((ctrl_r_int_ev_msb_cur!=ctrl_r_int_ev_msb_tgt) ||
	 (ctrl_r_int_od_msb_cur!=ctrl_r_int_od_msb_tgt) ||
	 (ctrl_d_int_msb_cur!=ctrl_d_int_msb_tgt) ||
	 (ctrl_r_int_ev_lsb_cur!=ctrl_r_int_ev_lsb_tgt) ||
	 (ctrl_r_int_od_lsb_cur!=ctrl_r_int_od_lsb_tgt) ||
	 (ctrl_d_int_lsb_cur!=ctrl_d_int_lsb_tgt)) {
    if (adjustment>0) { // Moving to the right
      if (ctrl_r_int_ev_msb_cur == ctrl_r_int_ev_msb_tgt) { // At the target UI
	if((ctrl_r_int_ev_lsb_cur < 0x200) && (ctrl_r_int_ev_lsb_tgt > 0x200))
	  ctrl_r_int_ev_lsb_cur = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur = ctrl_r_int_ev_lsb_tgt;
	
	if((ctrl_r_int_od_lsb_cur<0x200) && (ctrl_r_int_od_lsb_tgt>0x200)) 
	  ctrl_r_int_od_lsb_cur = 0x200;
	else 
	  ctrl_r_int_od_lsb_cur =  ctrl_r_int_od_lsb_tgt;
	
	if((ctrl_d_int_lsb_cur   < 0x200) && (ctrl_d_int_lsb_tgt > 0x200))
	  ctrl_d_int_lsb_cur = 0x200;
	else
	  ctrl_d_int_lsb_cur = ctrl_d_int_lsb_tgt;
	
      } else if ((ctrl_r_int_ev_lsb_cur != 0x7ff) || 
		 (ctrl_r_int_od_lsb_cur != 0x7ff) || 
		 (ctrl_d_int_lsb_cur != 0x7ff)) { // Moving within UI
	
	if(ctrl_r_int_ev_lsb_cur < 0x200)
	  ctrl_r_int_ev_lsb_cur = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur = 0x7ff;
	
	if(ctrl_r_int_od_lsb_cur<0x200)
	  ctrl_r_int_od_lsb_cur = 0x200;
	else
	  ctrl_r_int_od_lsb_cur =0x7ff;
	
	if(ctrl_d_int_lsb_cur < 0x200)
	  ctrl_d_int_lsb_cur = 0x200;
	else
	  ctrl_d_int_lsb_cur = 0x7ff;
	}
   else 
   {
	ctrl_r_int_ev_msb_cur += 1;
	ctrl_r_int_od_msb_cur += 1;
	ctrl_d_int_msb_cur += 1;
	ctrl_r_int_ev_lsb_cur = 0x0;
	ctrl_r_int_od_lsb_cur = 0x0;
	ctrl_d_int_lsb_cur = 0x0;
	
      }
    } else { // Moving to the left
      if (ctrl_r_int_ev_msb_cur == ctrl_r_int_ev_msb_tgt) { // At the target UI
	
	if((ctrl_r_int_ev_lsb_cur > 0x200) && (ctrl_r_int_ev_lsb_tgt < 0x200))
	  ctrl_r_int_ev_lsb_cur = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur = ctrl_r_int_ev_lsb_tgt;
	
	if ((ctrl_r_int_od_lsb_cur > 0x200) && (ctrl_r_int_od_lsb_tgt < 0x200))
	  ctrl_r_int_od_lsb_cur = 0x200;
	else
	  ctrl_r_int_od_lsb_cur = ctrl_r_int_od_lsb_tgt;
	
	if((ctrl_d_int_lsb_cur > 0x200) && (ctrl_d_int_lsb_tgt < 0x200))
	  ctrl_d_int_lsb_cur = 0x200;
	else
	  ctrl_d_int_lsb_cur = ctrl_d_int_lsb_tgt   ;
      }
      else if ((ctrl_r_int_ev_lsb_cur != 0x0) ||
	       (ctrl_r_int_od_lsb_cur != 0x0) ||
	       (ctrl_d_int_lsb_cur != 0x0)) { // Moving within UI
	if (ctrl_r_int_ev_lsb_cur>0x200)
	  ctrl_r_int_ev_lsb_cur = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur = 0x0;
	
	if(ctrl_r_int_od_lsb_cur>0x200)
	  ctrl_r_int_od_lsb_cur = 0x200;
	else
	  ctrl_r_int_od_lsb_cur =  0x0;
	
	if(ctrl_d_int_lsb_cur   >0x200)
	  ctrl_d_int_lsb_cur    = 0x200;
	else
	  ctrl_d_int_lsb_cur    = 0x0;
	
      } else { // Moving across UI
	ctrl_r_int_ev_msb_cur -= 1;
	ctrl_r_int_od_msb_cur -= 1;
	ctrl_d_int_msb_cur -= 1;
	ctrl_r_int_ev_lsb_cur = 0x7ff;
	ctrl_r_int_od_lsb_cur = 0x7ff;
	ctrl_d_int_lsb_cur = 0x7ff;
      }
    }
    write_field((((ctrl_r_int_ev_msb_cur&0x7)<<11) + ctrl_r_int_ev_lsb_cur), RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL, d2d1_base_and_slice_addr);
    write_field((((ctrl_r_int_od_msb_cur&0x7)<<11) + ctrl_r_int_od_lsb_cur), RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL, d2d1_base_and_slice_addr);
    write_field((((ctrl_d_int_msb_cur&0x7)<<11) + ctrl_d_int_lsb_cur), RX_DLL_OVRD_VAL_CTRL_D_INT__VAL, d2d1_base_and_slice_addr);
  } //While..
  
  
  //--- D2D 2
  while ((ctrl_r_int_ev_msb_cur_2 != ctrl_r_int_ev_msb_tgt_2) ||
	 (ctrl_r_int_od_msb_cur_2 != ctrl_r_int_od_msb_tgt_2) ||
	 (ctrl_d_int_msb_cur_2 != ctrl_d_int_msb_tgt_2) ||
	 (ctrl_r_int_ev_lsb_cur_2 != ctrl_r_int_ev_lsb_tgt_2) ||
	 (ctrl_r_int_od_lsb_cur_2 != ctrl_r_int_od_lsb_tgt_2) ||
	 (ctrl_d_int_lsb_cur_2 != ctrl_d_int_lsb_tgt_2)) {
    if (adjustment_2>0) { // Moving to the right
      if (ctrl_r_int_ev_msb_cur_2 == ctrl_r_int_ev_msb_tgt_2) { // At the target UI
	if((ctrl_r_int_ev_lsb_cur_2 < 0x200) && (ctrl_r_int_ev_lsb_tgt_2 > 0x200))
	  ctrl_r_int_ev_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur_2 = ctrl_r_int_ev_lsb_tgt_2;
	  
	if((ctrl_r_int_od_lsb_cur_2 < 0x200) && (ctrl_r_int_od_lsb_tgt_2 > 0x200)) 
	  ctrl_r_int_od_lsb_cur_2 = 0x200;
	else 
	  ctrl_r_int_od_lsb_cur_2 =  ctrl_r_int_od_lsb_tgt_2;
	
	if((ctrl_d_int_lsb_cur_2   < 0x200) && (ctrl_d_int_lsb_tgt_2 > 0x200))
	  ctrl_d_int_lsb_cur_2 = 0x200;
	else
	  ctrl_d_int_lsb_cur_2 = ctrl_d_int_lsb_tgt_2;
	
      } else if ((ctrl_r_int_ev_lsb_cur_2 != 0x7ff) || 
		 (ctrl_r_int_od_lsb_cur_2 != 0x7ff) || 
		 (ctrl_d_int_lsb_cur_2 != 0x7ff)) { // Moving within UI
	    
	if(ctrl_r_int_ev_lsb_cur_2 < 0x200)
	  ctrl_r_int_ev_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur_2 = 0x7ff;
	    
	if(ctrl_r_int_od_lsb_cur_2 < 0x200)
	  ctrl_r_int_od_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_od_lsb_cur_2 =0x7ff;
	    
	if(ctrl_d_int_lsb_cur_2 < 0x200)
	  ctrl_d_int_lsb_cur_2 = 0x200;
	else
	  ctrl_d_int_lsb_cur_2 = 0x7ff;
	} else {  
	ctrl_r_int_ev_msb_cur_2 += 1;
	ctrl_r_int_od_msb_cur_2 += 1;
	ctrl_d_int_msb_cur_2 += 1;
	ctrl_r_int_ev_lsb_cur_2 = 0x0;
	ctrl_r_int_od_lsb_cur_2 = 0x0;
	ctrl_d_int_lsb_cur_2 = 0x0;
	
      }
    } else { // Moving to the left
      if (ctrl_r_int_ev_msb_cur_2 == ctrl_r_int_ev_msb_tgt_2) { // At the target UI
	
	if((ctrl_r_int_ev_lsb_cur_2 > 0x200) && (ctrl_r_int_ev_lsb_tgt_2 < 0x200))
	  ctrl_r_int_ev_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur_2 = ctrl_r_int_ev_lsb_tgt_2;
	
	if ((ctrl_r_int_od_lsb_cur_2 > 0x200) && (ctrl_r_int_od_lsb_tgt_2 < 0x200))
	  ctrl_r_int_od_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_od_lsb_cur_2 = ctrl_r_int_od_lsb_tgt_2;
	
	if((ctrl_d_int_lsb_cur_2 > 0x200) && (ctrl_d_int_lsb_tgt_2 < 0x200))
	  ctrl_d_int_lsb_cur_2 = 0x200;
	else
	  ctrl_d_int_lsb_cur_2 = ctrl_d_int_lsb_tgt_2;
      }
      else if ((ctrl_r_int_ev_lsb_cur_2 != 0x0) ||
	       (ctrl_r_int_od_lsb_cur_2 != 0x0) ||
	       (ctrl_d_int_lsb_cur_2 != 0x0)) { // Moving within UI
	if (ctrl_r_int_ev_lsb_cur_2 > 0x200)
	  ctrl_r_int_ev_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_ev_lsb_cur_2 = 0x0;
	
	if(ctrl_r_int_od_lsb_cur_2>0x200)
	  ctrl_r_int_od_lsb_cur_2 = 0x200;
	else
	  ctrl_r_int_od_lsb_cur_2 =  0x0;
	
	if(ctrl_d_int_lsb_cur_2 > 0x200)
	  ctrl_d_int_lsb_cur_2 = 0x200;
	else
	  ctrl_d_int_lsb_cur_2 = 0x0;
	
      }
      else { // Moving across UI
	ctrl_r_int_ev_msb_cur_2 -= 1;
	ctrl_r_int_od_msb_cur_2 -= 1;
	ctrl_d_int_msb_cur_2 -= 1;
	ctrl_r_int_ev_lsb_cur_2 = 0x7ff;
	ctrl_r_int_od_lsb_cur_2 = 0x7ff;
	ctrl_d_int_lsb_cur_2 = 0x7ff;
      }
    }

    write_field((((ctrl_r_int_ev_msb_cur_2&0x7)<<11) + ctrl_r_int_ev_lsb_cur_2), RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL, d2d2_base_and_slice_addr);
    write_field((((ctrl_r_int_od_msb_cur_2&0x7)<<11) + ctrl_r_int_od_lsb_cur_2), RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL, d2d2_base_and_slice_addr);
    write_field((((ctrl_d_int_msb_cur_2&0x7)<<11) + ctrl_d_int_lsb_cur_2), RX_DLL_OVRD_VAL_CTRL_D_INT__VAL, d2d2_base_and_slice_addr);
      
  }//While...
}


static void correct_relative_skew(uint32_t d2d_base_addr, uint32_t rdata)
{
  int frag_width = 256;
  int shift_amt =  4; //$clog2(frag_width/32); //Hardcoding in C
  int s0 = (rdata&0xFF) >> shift_amt;
  int s1 = (rdata&0xFF00) >> shift_amt;
  int div = 256 >> shift_amt;
  // distance = min(abs(s1 - s0), div - abs(s1 - s0))
  int abs_s1_s0;
  
  if((s1-s0)<=0)
    abs_s1_s0 = -(s1-s0);
  else
    abs_s1_s0 = (s1-s0);
  
  int div_abs_s1_s0 = div - abs_s1_s0;
  int distance;
  if(abs_s1_s0 < div_abs_s1_s0)
    distance = abs_s1_s0;
  else
    distance = div_abs_s1_s0;

  uint32_t addr;

  if (distance == 0){
  }
  else if (distance > 4) {
    // RS_TODO: Need to correct the calculation for frag_width other than 256
    //`uvm_error("correct_relative_skew", $sformatf("Training Error distance:%0d, id: %0d",distance,requester))
  }
  else if (((s1+distance)%div) == s0) {
    for (int i = 0 ; i<distance ; i++) {
      writel(0x1, (d2d_base_addr + 0x9144));
    }
  }
  else if (((s0+distance)%div) == s1) {
    for (int i = 0 ; i<distance ; i++) {
      writel(0x4, (d2d_base_addr + 0x9144));
    }
  }
}

//Used during bypass mode: Link training sequence for 2 slice d2d
void link_training_2slice(uint32_t d2d_base_addr1, uint32_t d2d_base_addr2)
{
  uint32_t rd1, rd2;

  writel(0x59, (d2d_base_addr1+0x9004));
  writel(0x59, (d2d_base_addr2+0x9004));
  
  writel(0x99, (d2d_base_addr1+0x8004));
  writel(0x99, (d2d_base_addr2+0x8004));
  
  writel(0x18, (d2d_base_addr1+0x8004));
  writel(0x18, (d2d_base_addr2+0x8004));
  
  writel(0x1a, (d2d_base_addr1+0x9004));
  writel(0x1a, (d2d_base_addr2+0x9004));
  
  writel(0x1b, (d2d_base_addr1+0x8004));
  writel(0x1b, (d2d_base_addr2+0x8004));

  rd1 = readl((d2d_base_addr1+0x8004));
  rd2 = readl((d2d_base_addr2+0x8004));
  
  while ( ((rd1 & 0x3) != 0x3) && ((rd2 & 0x3) != 0x3)) {
    rd1 = readl((d2d_base_addr1+0x8004));
    rd2 = readl((d2d_base_addr2+0x8004));
  }
  
  writel(0x0, (d2d_base_addr1+0x9800));
  writel(0x0, (d2d_base_addr2+0x9800));
  
  writel(0x0, (d2d_base_addr1+0x8800));
  writel(0x0, (d2d_base_addr2+0x8800));
}

//Used during bypass mode: Link training sequence for 1 slice d2d
void link_training_1slice(uint32_t d2d_base_addr1, uint32_t d2d_base_addr2)
{
  uint32_t rd1, rd2;

  writel(0x49, (d2d_base_addr1+0x9004));
  writel(0x49, (d2d_base_addr2+0x9004));
  
  writel(0x89, (d2d_base_addr1+0x8004));
  writel(0x89, (d2d_base_addr2+0x8004));
  
  writel(0x08, (d2d_base_addr1+0x8004));
  writel(0x08, (d2d_base_addr2+0x8004));
  
  writel(0x0a, (d2d_base_addr1+0x9004));
  writel(0x0a, (d2d_base_addr2+0x9004));
  
  writel(0x0b, (d2d_base_addr1+0x8004));
  writel(0x0b, (d2d_base_addr2+0x8004));

  rd1 = readl((d2d_base_addr1+0x8004));
  rd2 = readl((d2d_base_addr2+0x8004));
  
  while ( ((rd1 & 0x3) != 0x3) && ((rd2 & 0x3) != 0x3)) {
    rd1 = readl((d2d_base_addr1+0x8004));
    rd2 = readl((d2d_base_addr2+0x8004));
  }
  
  writel(0x0, (d2d_base_addr1+0x9800));
  writel(0x0, (d2d_base_addr2+0x9800));
  
  writel(0x0, (d2d_base_addr1+0x8800));
  writel(0x0, (d2d_base_addr2+0x8800));
}

void nop_loop(uint32_t num)
{
  uint32_t i = 0;
  for(i=0; i<num; i++)
    {
      asm("nop");
    }
}


void write_field(uint32_t val, uint32_t field, uint32_t base_addr)
{
  uint32_t csr_addr;
  uint32_t rd, wd, mask;
  uint8_t lsb, msb;
  uint8_t num_bits;
  
  csr_addr = base_addr + ((0xFFF&field) << 1);
  lsb = 0xF & (field >> 13);
  msb = lsb + (0xF & (field >> 17));
  num_bits = msb - lsb + 1;

  mask = ((1 << num_bits) - 1) << lsb;
  
  rd = readl(csr_addr);
  wd = ( (rd & ~(mask)) | (val << lsb) );
  writel(wd, csr_addr);
}

uint32_t read_field(uint32_t val, uint32_t field, uint32_t base_addr)
{
  uint32_t field_value;
  uint32_t csr_addr;
  uint32_t rd, wd, mask;
  uint8_t lsb, msb;
  uint8_t num_bits;
  
  csr_addr = base_addr + ((0xFFF&field) << 1);
  lsb = 0xF & (field >> 13);
  msb = lsb + (0xF & (field >> 17));
  num_bits = msb - lsb + 1;

  mask = ((1 << num_bits) - 1) << lsb;
  
  rd = readl(csr_addr);
  
  field_value = ((rd & mask) >> lsb);

  return field_value; 

}

void program_gpio_19_oe()
{
  uint32_t val;
  val = readl(GPIO_CFGCTL9_ADDR);
  val = val & 0x0000FFFF;
  val = val | 0x00020000; 
  writel(val, GPIO_CFGCTL9_ADDR);

  val = readl(GPIO_CFGCTL34_ADDR);
  val = val | 0x80000;
  writel(val, GPIO_CFGCTL34_ADDR);
}

void pull_down_all_gpios()
{
  uint32_t val;
  writel(0x00230023, GPIO_CFGCTL0_ADDR);
  writel(0x00230023, GPIO_CFGCTL1_ADDR);
  writel(0x00230023, GPIO_CFGCTL2_ADDR);
  writel(0x00230023, GPIO_CFGCTL3_ADDR);
  writel(0x00230023, GPIO_CFGCTL4_ADDR);
  writel(0x00230023, GPIO_CFGCTL5_ADDR);
  writel(0x00230023, GPIO_CFGCTL6_ADDR);
  writel(0x00230023, GPIO_CFGCTL7_ADDR);
  writel(0x00230023, GPIO_CFGCTL8_ADDR);
  writel(0x00230023, GPIO_CFGCTL9_ADDR);

}

void set_gpio_19()
{
  uint32_t val;
  val = readl(GPIO_CFGCTL32_ADDR);
  val = val | 0x80000;
  writel(val, GPIO_CFGCTL32_ADDR);
}

void toggle_gpio_19()
{
  uint32_t val;
  val = readl(GPIO_CFGCTL32_ADDR);
  val = (val ^ 0x80000);
  writel(val, GPIO_CFGCTL32_ADDR);
}

void wait_for_gpio_19_toggle(uint32_t *curr_val)
{
  uint32_t new_val;
  
  new_val = readl(GPIO_CFGCTL30_ADDR);
  new_val = ((new_val & 0x00080000) >> 19 );
  
  do {
    new_val = readl(GPIO_CFGCTL30_ADDR);
    new_val = ((new_val & 0x00080000) >> 19);

    nop_loop(10);
    
  } while (*curr_val == new_val);

  *curr_val = new_val;
}

void wait_for_slave_chiplet_ready()
{
  uint32_t gpio19;
  uint32_t val;
  
  do {
    val = readl(GPIO_CFGCTL30_ADDR);
    val = val & 0x00080000;

    nop_loop(10);
  } while (val != 0x00080000);
  
}



//These were created for 2 chiplet simulation
//Used during bypass mode: Link training sequence for 1 slice d2d
void one_d2d_link_training_1slice(uint32_t d2d_base_addr)
{
  uint32_t rd;

  writel(0x49, (d2d_base_addr+0x9004));
  nop_loop(5);
  writel(0x89, (d2d_base_addr+0x8004));
  nop_loop(5);
  writel(0x08, (d2d_base_addr+0x8004));
  nop_loop(5);
  writel(0x0a, (d2d_base_addr+0x9004));
  nop_loop(5);
  writel(0x0b, (d2d_base_addr+0x8004));
  nop_loop(5);
  rd = readl((d2d_base_addr+0x8004));
  while ((rd & 0x3) != 0x3) {
    rd = readl((d2d_base_addr+0x8004));
    nop_loop(10);
  }
  
  writel(0x0, (d2d_base_addr+0x9800));
  nop_loop(5);
  writel(0x0, (d2d_base_addr+0x8800));
}
