#include <stdio.h>
#include "generic_defines.h"

#include "d2d.h"

int d2d_p2_p4_link_training() {
  
  deassert_d2d_rst();
  //deassert_axi4tg_reset();
  //deassert_axi_s_reset();
  //deassert_a5l_a4_and_time_out_reset();
  
  preload_mstram(10);
  setup_cmdram();
  
  link_training_1slice(D2D_1S_PORT2_SLV_BASE_ADDR, D2D_1S_PORT4_SLV_BASE_ADDR);

  nop_loop(1000);

  xbar_sel_mode(0);
  //Program the xbar config first and then program the mode sel
  xbar_config_p1_p3();
  xbar_sel_mode(2);
 

  nop_loop(1000);

  //start_axi4tg();
  //axi4tg_wait_for_masten_clear();

  nop_loop(100);

  
  EOT_PASS_MSG
    return 0;
}
void d2d_link_training()
{
	d2d_p2_p4_link_training();
}
