#include <stdio.h>
#include "generic_defines.h"

#include "d2d.h"
//#include "platform_def.h"

int d2d_p1_p3_full_init() {
  uint16_t i;
  uint32_t rd, wd;
  
  deassert_d2d_rst();
  //bcphy_en_clk();
  bcphy_sys_rstn();
  d2d_pll_cfg();
  //deassert_axi4tg_reset();
  //deassert_axi_s_reset();
  //deassert_a5l_a4_and_time_out_reset();
  
  preload_mstram(10);
  setup_cmdram();
  
  // 2.3.1.1 De-assert the TX PHY reset
  rd = readl(D2D_2S_PORT1_SLV_BASE_ADDR + 0x8004); 
  writel(rd&0xFFFFF0FF, (D2D_2S_PORT1_SLV_BASE_ADDR + 0x8004));

  rd = readl(D2D_2S_PORT1_SLV_BASE_ADDR + 0x9004);
  wd = rd&0xFFFFF07F;
  writel(wd,(D2D_2S_PORT1_SLV_BASE_ADDR + 0x9004));
  
  rd = readl(D2D_2S_PORT3_SLV_BASE_ADDR + 0x8004); 
  writel(rd&0xFFFFF0FF, (D2D_2S_PORT3_SLV_BASE_ADDR + 0x8004));

  rd = readl(D2D_2S_PORT3_SLV_BASE_ADDR + 0x9004);
  wd = rd&0xFFFFF07F;
  writel(wd,(D2D_2S_PORT3_SLV_BASE_ADDR + 0x9004));

  //TX
  d2d_tx_init_cfg (D2D_2S_PORT1_SLV_BASE_ADDR, 0);
  d2d_tx_init_cfg (D2D_2S_PORT1_SLV_BASE_ADDR, 1);
  d2d_tx_init_cfg (D2D_2S_PORT3_SLV_BASE_ADDR, 0);
  d2d_tx_init_cfg (D2D_2S_PORT3_SLV_BASE_ADDR, 1);

  //RX
  d2d_rx_init_cfg (D2D_2S_PORT1_SLV_BASE_ADDR, 0);
  d2d_rx_init_cfg (D2D_2S_PORT1_SLV_BASE_ADDR, 1);
  d2d_rx_init_cfg (D2D_2S_PORT3_SLV_BASE_ADDR, 0);
  d2d_rx_init_cfg (D2D_2S_PORT3_SLV_BASE_ADDR, 1);
  
  link_training_and_word_alignment(D2D_2S_PORT1_SLV_BASE_ADDR, D2D_2S_PORT3_SLV_BASE_ADDR, 2);
  
  nop_loop(10);
  
  xbar_sel_mode(0);
  
  //Program the xbar config first and then program the mode sel
  xbar_config_p0_p2();
  xbar_sel_mode(2);

  nop_loop(10);
  //start_axi4tg();
  //axi4tg_wait_for_masten_clear();
  
  nop_loop(100);

  EOT_PASS_MSG
    return 0;
}
int d2d_p2_p4_full_init()
{
  uint16_t i;
  uint32_t rd, wd;
  
  deassert_d2d_rst();
  //bcphy_en_clk();
  bcphy_sys_rstn();
  d2d_pll_cfg();
//  deassert_axi4tg_reset();
  //deassert_axi_s_reset();
  //deassert_a5l_a4_and_time_out_reset();
  
  preload_mstram(10);
  setup_cmdram();
    
  // 2.3.1.1 De-assert the TX PHY reset
  rd = readl(D2D_1S_PORT2_SLV_BASE_ADDR + 0x8004); 
  writel(rd&0xFFFFF0FF, (D2D_1S_PORT2_SLV_BASE_ADDR + 0x8004));

  rd = readl(D2D_1S_PORT2_SLV_BASE_ADDR + 0x9004);
  wd = rd&0xFFFFF07F;
  writel(wd,(D2D_1S_PORT2_SLV_BASE_ADDR + 0x9004));
  
  rd = readl(D2D_1S_PORT4_SLV_BASE_ADDR + 0x8004); 
  writel(rd&0xFFFFF0FF, (D2D_1S_PORT4_SLV_BASE_ADDR + 0x8004));

  rd = readl(D2D_1S_PORT4_SLV_BASE_ADDR + 0x9004);
  wd = rd&0xFFFFF07F;
  writel(wd,(D2D_1S_PORT4_SLV_BASE_ADDR + 0x9004));

  //TX
  d2d_tx_init_cfg (D2D_1S_PORT2_SLV_BASE_ADDR, 0);
  d2d_tx_init_cfg (D2D_1S_PORT4_SLV_BASE_ADDR, 0);

  //RX
  d2d_rx_init_cfg (D2D_1S_PORT2_SLV_BASE_ADDR, 0);
  d2d_rx_init_cfg (D2D_1S_PORT4_SLV_BASE_ADDR, 0);
  
  link_training_and_word_alignment(D2D_1S_PORT2_SLV_BASE_ADDR, D2D_1S_PORT4_SLV_BASE_ADDR, 1);
  
  nop_loop(10);
  xbar_sel_mode(0);
  
  //Program the xbar config first and then program the mode sel
  xbar_config_p1_p3();
  xbar_sel_mode(2);

  nop_loop(10);
  
  //start_axi4tg();
  //axi4tg_wait_for_masten_clear();

  nop_loop(100);

  EOT_PASS_MSG
    return 0;
}

void d2d_full_init()
{
	d2d_p1_p3_full_init();
	d2d_p2_p4_full_init();
}
