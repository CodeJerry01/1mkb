
#include <stdio.h>
#include "generic_defines.h"


void deassert_d2d_rst()
{
  writel(0x10f, D2D_RST_CSR_ADDR); 
}


// 2.3.1.1 De-assert the TX/RX Slice PHY reset
void deassert_phy_reset(uint32_t d2d_base_addr)
{
  uint32_t val;
  val = readl(d2d_base_addr + 0x8004); 
  writel((val&0xFFFFF0FF), (d2d_base_addr + 0x8004));
 
  val = readl(d2d_base_addr + 0x9004);
  writel((val&0xFFFFF07F),(d2d_base_addr  + 0x9004));
}


//XBAR related settings (2 Slice D2Ds)
// REQ : AXI4TG -> P0 -> P2 -> BRAM
// RSP : BRAM -> P2 -> P0 -> AXI4TG
void xbar_config_p0_p2()
{
  uint32_t val;
  
  val = 0;
  val = val | (4 << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0 << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (2 << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (4 << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (2 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (0 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
  
}

//XBAR related settings (2 Slice D2Ds)
// REQ : AXI4TG -> P2 -> P0 -> BRAM
// RSP : BRAM -> P0 -> P2 -> AXI4TG
void xbar_config_p2_p0()
{
  uint32_t val;
  
  val = 0;
  val = val | (2 << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (4 << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (4 << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (0 << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (0 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (2 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
  
}

//XBAR related settings (1 slice D2Ds)
// REQ Path: AXI4TG -> P1 -> P3 -> BRAM
// RSP Path: BRAM -> P3 -> P1 -> AXI4TG
void xbar_config_p1_p3()
{
  uint32_t val;
  
  val = 0;
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (1   << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (3   << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (3 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (1 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

//XBAR related settings (1 slice D2Ds)
// REQ Path: AXI4TG -> P3 -> P1 -> BRAM
// RSP Path: BRAM -> P1 -> P3 -> AXI4TG
void xbar_config_p3_p1()
{
  uint32_t val;
  
  val = 0;
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (3   << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (1   << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (1 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (3 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

// XBAR related settings (1 slice D2Ds and 2 slice D2Ds)
// REQ Path: AXI4TG -> BRAM
// REQ Path: P0 -> P2 -> P1 -> P3 -> P0
// RSP Path: P3 -> P1 -> P2 -> P0 -> P3
// RSP Path: BRAM -> AXI4TG
void xbar_vip_config_p0_p2_p1_p3()
{
  uint32_t val;
  
  val = 0;
  val = val | (3  << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (2  << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0  << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (1  << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (2  << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (3  << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (1  << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0  << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (4 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (4 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

// XBAR related settings (1 slice D2Ds and 2 slice D2Ds)
// REQ Path: AXI4TG -> P0 -> P2 -> P1 -> P3 -> BRAM
// RSP Path: BRAM -> P3 -> P1 -> P2 -> P0 -> AXI4TG
void xbar_config_p0_p2_p1_p3()
{
  uint32_t val;
  
  val = 0;
  val = val | (4  << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (2  << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0  << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (1  << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (2  << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (3  << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (1  << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (4  << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (3 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (0 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

// XBAR related settings (1 slice D2Ds and 2 slice D2Ds)
// REQ Path: AXI4TG -> P1 -> P3 -> P0 -> P2 -> BRAM
// RSP Path: BRAM -> P2 -> P0 -> P3 -> P1 -> AXI4TG
void xbar_config_p1_p3_p0_p2()
{
  uint32_t val;
  
  val = 0;
  val = val | (3  << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (4  << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0  << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (1  << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (2  << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (3  << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (4  << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0  << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (2 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (1 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

// XBAR ID related settings 
void xbar_config_id_all_ports()
{
  uint32_t val;
  
  //REQ Ports
  val = 0;
  val = val | (0  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT0_ID_CSR_ADDR);
  
  val = 0;
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT1_ID_CSR_ADDR);
  
  val = 0;
  val = val | (5  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  val = val | (6  << A4_XBAR_REQ_PORT_ID_1_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_1_VAILD_BIT_POS);
  val = val | (7  << A4_XBAR_REQ_PORT_ID_2_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_2_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT2_ID_CSR_ADDR);

  val = 0;
  val = val | (3  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT3_ID_CSR_ADDR);
  
  val = 0;
  val = val | (4  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT4_ID_CSR_ADDR);  //BRAM SLV

  //RESP Ports
  val = 0;
  val = val | (0  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT0_ID_CSR_ADDR);
  
  val = 0;
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT1_ID_CSR_ADDR);
  
  val = 0;
  val = val | (5  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  val = val | (6  << A4_XBAR_RESP_PORT_ID_1_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_1_VAILD_BIT_POS);
  val = val | (7  << A4_XBAR_RESP_PORT_ID_2_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_2_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT2_ID_CSR_ADDR);

  val = 0;
  val = val | (3  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT3_ID_CSR_ADDR);
  
  val = 0;
  val = val | (2  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT4_ID_CSR_ADDR);  //TG Master

  val = 0;
  val = val | (5  << A4_TG_DEST_ID_BIT_POS);
  val = val | (2  << A4_TG_SRC_ID_BIT_POS);
  //val = val | (5  << A4_SLV_DEST_ID_BIT_POS);
  //val = val | (2  << A4_SLV_SRC_ID_BIT_POS);
  writel(val, TG_SLV_SRC_DEST_ID_CSR_ADDR);  //TG Master

  //Set the A4 XBAR timeout to 300us
  writel(0x33, SYSCTRL_GENERIC_REG160);

}

// XBAR ID related settings 
void xbar_config_cp_port_id()
{
  uint32_t val;
  
  //REQ Ports
  val = 0;
  val = val | (0  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT0_ID_CSR_ADDR);
  
  val = 0;
  val = val | (3  << A4_XBAR_REQ_PORT_ID_0_BIT_POS); //Main
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT1_ID_CSR_ADDR);
  
  val = 0;
  val = val | (5  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  val = val | (6  << A4_XBAR_REQ_PORT_ID_1_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_1_VAILD_BIT_POS);
  val = val | (7  << A4_XBAR_REQ_PORT_ID_2_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_2_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT2_ID_CSR_ADDR);

  val = 0;
  val = val | (3  << A4_XBAR_REQ_PORT_ID_0_BIT_POS); //Copy
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT3_ID_CSR_ADDR);
  
  val = 0;
  val = val | (4  << A4_XBAR_REQ_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_REQ_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_REQ_PORT4_ID_CSR_ADDR);  //BRAM SLV

  //RESP Ports
  val = 0;
  val = val | (0  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT0_ID_CSR_ADDR);
  
  val = 0;
  val = val | (3  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT1_ID_CSR_ADDR);
  
  val = 0;
  val = val | (5  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  val = val | (6  << A4_XBAR_RESP_PORT_ID_1_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_1_VAILD_BIT_POS);
  val = val | (7  << A4_XBAR_RESP_PORT_ID_2_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_2_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT2_ID_CSR_ADDR);

  val = 0;
  val = val | (3  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT3_ID_CSR_ADDR);
  
  val = 0;
  val = val | (2  << A4_XBAR_RESP_PORT_ID_0_BIT_POS);
  val = val | (1  << A4_XBAR_RESP_PORT_ID_0_VAILD_BIT_POS);
  writel(val, XBAR_RESP_PORT4_ID_CSR_ADDR);  //TG Master

  val = 0;
  val = val | (4  << A4_TG_DEST_ID_BIT_POS);
  val = val | (2  << A4_TG_SRC_ID_BIT_POS);
  //val = val | (5  << A4_SLV_DEST_ID_BIT_POS);
  //val = val | (2  << A4_SLV_SRC_ID_BIT_POS);
  writel(val, TG_SLV_SRC_DEST_ID_CSR_ADDR);  //TG Master

  //Set the A4 XBAR timeout to 300us
  writel(0x33, SYSCTRL_GENERIC_REG160);

}


// XBAR Addr mode related settings 
void xbar_addr_mode_cfg()
{
  uint32_t val_base_addr;
  uint32_t val_high_addr;
  
  //REQ Port0
  val_base_addr = 0x00040000;
  val_high_addr = 0x0004ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG109);
  writel(val_high_addr, SYSCTRL_GENERIC_REG110);
  
  //REQ Port1
  val_base_addr = 0x00010000;
  val_high_addr = 0x0001ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG119);
  writel(val_high_addr, SYSCTRL_GENERIC_REG120);
  
  //REQ Port2
  val_base_addr = 0x00020000;
  val_high_addr = 0x0002ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG129);
  writel(val_high_addr, SYSCTRL_GENERIC_REG130);

  //REQ Port3
  val_base_addr = 0x00030000;
  val_high_addr = 0x0003ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG139);
  writel(val_high_addr, SYSCTRL_GENERIC_REG140);

  //REQ Port4 (BRAM Slave)
  val_base_addr = 0x00000000;
  val_high_addr = 0x0000ffff;

  writel(val_base_addr, SYSCTRL_GENERIC_REG149);
  writel(val_high_addr, SYSCTRL_GENERIC_REG150);
   
  //Set port addr valids:[31:0]= 0000_0000_0001_0000_1000_0100_0010_0001
  writel(0x108421, SYSCTRL_GENERIC_REG159);

  //Set the A4 XBAR timeout to 300us
  writel(0x33, SYSCTRL_GENERIC_REG160);

}


// XBAR Addr mode cp port related settings 
void xbar_addr_mode_cp_port_cfg()
{
  uint32_t val_base_addr;
  uint32_t val_high_addr;
  
  //REQ Port0
  val_base_addr = 0x00040000;
  val_high_addr = 0x0004ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG109);
  writel(val_high_addr, SYSCTRL_GENERIC_REG110);
  
  //REQ Port1 (Main)
  val_base_addr = 0x00010000;
  val_high_addr = 0x0001ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG119);
  writel(val_high_addr, SYSCTRL_GENERIC_REG120);
  
  //REQ Port2
  val_base_addr = 0x00020000;
  val_high_addr = 0x0002ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG129);
  writel(val_high_addr, SYSCTRL_GENERIC_REG130);

  //REQ Port3 (CP)
  val_base_addr = 0x00010000;
  val_high_addr = 0x0001ffff;
  writel(val_base_addr, SYSCTRL_GENERIC_REG139);
  writel(val_high_addr, SYSCTRL_GENERIC_REG140);

  //REQ Port4 (BRAM Slave)
  val_base_addr = 0x00000000;
  val_high_addr = 0x0000ffff;

  writel(val_base_addr, SYSCTRL_GENERIC_REG149);
  writel(val_high_addr, SYSCTRL_GENERIC_REG150);
   
  //Set port addr valids:[31:0]= 0000_0000_0001_0000_1000_0100_0010_0001
  writel(0x108421, SYSCTRL_GENERIC_REG159);

  //Set the A4 XBAR timeout to 300us
  writel(0x33, SYSCTRL_GENERIC_REG160);

}


//SYSCTRL_GENERIC_REG161
void xbar_copy_port()
{
  uint32_t val;

  writel(0x28, SYSCTRL_GENERIC_REG161);

}

//SYSCTRL_GENERIC_REG16
void bcphy_en_clk()
{
  uint32_t val;

  writel(0xF, SYSCTRL_GENERIC_REG16);

}

//SYSCTRL_GENERIC_REG16
void bcphy_sys_rstn()
{
  uint32_t val;

  writel(0xF, SYSCTRL_GENERIC_REG16);

}

//SYSCTRL_GENERIC_REG0
void d2d_pll_cfg()
{
  uint32_t val;

  writel(0xFF00, SYSCTRL_GENERIC_REG0);

}


//sel_val : 0: ID based
//sel_val : 1: Addr based
//sel_val : 2: Bind based
//sel_val : 3: Invalid
void xbar_sel_mode(uint32_t sel_val)
{
  uint32_t val;

  val = ( (sel_val << 18) | (sel_val << 16) | (sel_val << 14) | (sel_val << 12) | (sel_val << 10) | (sel_val << 8) | (sel_val << 6) | (sel_val << 4) | (sel_val << 2) | (sel_val << 0));

  writel(val, XBAR_MODE_SEL_CSR_ADDR);
}



void program_axi4tg_rd_req (uint8_t num, uint32_t addr)
{

  srand(time(NULL));
  
  uint32_t word0 = 0; // Addr
  uint32_t word1 = 0 ; //Len[7:0], Lock, Burst, Size[2:0], id[5:0], Prot[2:0], last_addr[2:0], Valid_cmd
  uint32_t word2 = 0; //Setting Mstram_index[12:0] = 0; in the begenning. Other_depend[8:0], My_depend[8:0] to also 0
  uint32_t word3;
  uint32_t word3_bit31_to_bit3 = 0;
  
  uint32_t prot  = 0;
  uint32_t id    = 0; //Will start with 0
  uint32_t size  = 5; //32B transfer
  //uint32_t size  = 3; //8B transfer
  uint32_t burst = 1;
  uint32_t len   = 1;

  uint32_t rd_data_offset = 0x1000;
  uint32_t my_depend, other_depend;

  
  //CMDRAM (0x000 to 0xFFF) is for Read
  for (int i=0; i< num; i++){
    id = i;
    
    word0 = addr + (i * 64); //Increament the addr by 64 (or '40)
    word1 = 0x80000000 | (id << 15) | (size << 12) | (burst << 10) | (len << 0);
    
    //Adding dependency, execute rd only after wr
    my_depend = i;
    if(i==0){
      other_depend = 1;
    } else {
      other_depend = i;
    };

    //word2 = ((my_depend << 22) | (other_depend << 13) | ((0x20*i)<<2));
    word2 = ((my_depend << 22) | (other_depend << 13) | (rd_data_offset +(64*i)));
    word3 =  (word3_bit31_to_bit3 << 3) | 0x7 ;
    //This was added to increase toggle coverage
    word3_bit31_to_bit3 = ~word3_bit31_to_bit3;
    
    writel(word0, (AXI4TG_CMDRAM + ( i * 0x10)));
    writel(word1, (AXI4TG_CMDRAM + ((i * 0x10) + 0x4)));
    writel(word2, (AXI4TG_CMDRAM + ((i * 0x10) + 0x8)));
    writel(word3, (AXI4TG_CMDRAM + ((i * 0x10) + 0xc)));

    //Program corresponding Paramram
    writel(0, (AXI4TG_PARAMRAM + (i*0x4)));
  }
  //Program the last cmdram to 0
  writel(0x0, (AXI4TG_CMDRAM + ( num * 0x10)));
  writel(0x0, (AXI4TG_CMDRAM + ((num * 0x10) + 0x4)));
  writel(0x0, (AXI4TG_CMDRAM + ((num * 0x10) + 0x8)));
  writel(0x0, (AXI4TG_CMDRAM + ((num * 0x10) + 0xc)));
}

void program_axi4tg_wr_req (uint8_t num, uint32_t addr)
{

  uint32_t word0 = 0; // Addr
  uint32_t word1 = 0; //Len[7:0], Lock, Burst, Size[2:0], id[5:0], Prot[2:0], last_addr[2:0], Valid_cmd
  uint32_t word2 = 0; //Setting Mstram_index[12:0] = 0; in the begenning. Other_depend[8:0], My_depend[8:0] to also 0
  uint32_t word3;     

  uint32_t word3_bit31_to_bit3 = 0;
  uint32_t prot  = 0;
  uint32_t id    = 0; //Will start with 0
  uint32_t size  = 5; //32B transfer
  //uint32_t size  = 3; //8B transfer
  uint32_t burst = 1;
  uint32_t len   = 1;

  uint32_t wr_data_offset = 0;
  uint32_t my_depend, other_depend;
  
  //CMDRAM (0x000 to 0xFFF) is for Read
  for (int i=0; i< num; i++){
    id = i;

    
    word0 = addr + (i * 64); //Increament the addr by 64 (or '40)
    word1 = 0x80000000 | (id << 15) | (size << 12) | (burst << 10) | (len << 0);

    //word2 = (((i*8) + wr_data_offset) << 2);
    //word2 = (((i* 0x20) + wr_data_offset) << 2);
    //word2 = ((i* 0x20) + wr_data_offset);
    word2 = ((i*64) + wr_data_offset);

    //Setting Expected_resp: Any response is allowed. Setting cache,user,qos to all 0's and all 1's for coverage purposes;
    word3 =  (word3_bit31_to_bit3 << 3) | 0x7 ;
    //This was added to increase toggle coverage
    word3_bit31_to_bit3 = ~word3_bit31_to_bit3;
      
    writel(word0, (AXI4TG_CMDRAM + 0x1000 + ( i * 0x10)));
    writel(word1, (AXI4TG_CMDRAM + 0x1000 + ((i * 0x10) + 0x4)));
    writel(word2, (AXI4TG_CMDRAM + 0x1000 + ((i * 0x10) + 0x8)));
    writel(word3, (AXI4TG_CMDRAM + 0x1000 + ((i * 0x10) + 0xc)));
    
    writel(0, (AXI4TG_PARAMRAM + 0x400 + (i*0x4)));
  }

  //Write the last cmdram with 0, so that the generation stops
  writel(0x0, (AXI4TG_CMDRAM + 0x1000 + ( num * 0x10)));
  writel(0x0, (AXI4TG_CMDRAM + 0x1000 + ((num * 0x10) + 0x4)));
  writel(0x0, (AXI4TG_CMDRAM + 0x1000 + ((num * 0x10) + 0x8)));
  writel(0x0, (AXI4TG_CMDRAM + 0x1000 + ((num * 0x10) + 0xc)));
}


/* Preload_mstram and check_mstram_rddata functions go hand in hand */

void preload_mstram(uint32_t num_64B_accesses)
{
  uint32_t val0;
  uint32_t num_apb_writes = num_64B_accesses*16;
  for (int i=0; i < num_apb_writes; i++){
    val0 = i;
    writel(val0, (AXI4TG_MSTRAM + (i * 0x4)));
  }
  
}

void check_mstram_rddata(uint32_t num_bytes, uint32_t ram_offset)
{
  uint32_t num_32bits = (num_bytes/4) + 1;
  
  //Read the data from MSTRAM
  uint32_t val0;
  uint32_t rddata;
  
  for (int i=0; i < num_32bits; i++){
    rddata = readl((AXI4TG_MSTRAM + ram_offset + (i*0x4)));

    val0 = i;
    if(rddata != val0){
      EOT_FAIL_MSG;
      return 1;
    }
  }
}

//This will setup for 10 read and 10 writes
void setup_cmdram(){
  program_axi4tg_rd_req(10, 0x2000);
  program_axi4tg_wr_req(10, 0x2000);
 
}

void axi4tg_wait_for_masten_clear() {

uint32_t val;
  val = readl(AXI4TG_BASE_ADDR); //Read Master Control
  do {
    val = readl(AXI4TG_BASE_ADDR); //Read Master Control
  } while ((val & 0x100000) == 0x100000);
}




///These functions are created to be run on 2 chiplet simulation
// u0 -> Primary chiplet
// u1 -> Secondary chiplet

// Xbar config for u0
//REQ path: AXI4TG -> P1 -> Goes to the other chiplet
//RSP Path: Comes from other chiplet -> P1 -> AXI4TG 
void u0_xbar_config()
{
 uint32_t val;
  
  val = 0;
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (0xf << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (1 << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}


//Xbar config for u1
//REQ path: Comes from other chiplet -> P1 -> AXI4BRAM 
//RSP Path: AXI4BRAM -> P1 -> Goes to the other chiplet 
void u1_xbar_config()
{
 uint32_t val;
  
  val = 0;
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P0_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_REQ_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_REQ_SEL_P2_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_REQ_SEL_P3_BIT_POS);
 
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P0_BIT_POS);
  val = val | (4   << A4_XBAR_SETTINGS_0_RESP_SEL_P1_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_0_RESP_SEL_P2_BIT_POS);
  val = val | (0xf   << A4_XBAR_SETTINGS_0_RESP_SEL_P3_BIT_POS);
  
  writel(val, A4_XBAR_SETTINGS_0_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_0_CSR_ADDR);

  val = 0;
  val = val | (1 << A4_XBAR_SETTINGS_1_REQ_SEL_P4_BIT_POS);
  val = val | (0xf << A4_XBAR_SETTINGS_1_RESP_SEL_P4_BIT_POS);

  writel(val, A4_XBAR_SETTINGS_1_CSR_ADDR);
  writel(val, A5L_XBAR_SETTINGS_1_CSR_ADDR);
}

