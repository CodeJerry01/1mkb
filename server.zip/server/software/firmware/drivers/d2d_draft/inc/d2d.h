

#ifndef __FREERTOS_FLC_H
#define __FREERTOS_FLC_H

#include <stdint.h>
#include <metal/compiler.h>
#include "blynx_bow_csr_map_03e_v0p2p1.h"
#include "generic_defines.h"
//#include "platform_def.h"

#define TX_SLICE_0_ADDR	0x200
#define RX_SLICE_0_ADDR 0x800
#define TX_SLICE_1_ADDR	0x1200
#define RX_SLICE_1_ADDR 0x1800


void d2d_init_cfg(uint32_t D2D_BASE_ADDRESS, int num_slice);
static int get_word_alignment_offset(uint8_t sample00, uint8_t sample02);

static void wait10nanoseconds(int time);

//Added by sandesh
void link_training_2slice(uint32_t d2d_base_addr1, uint32_t d2d_base_addr2);
void link_training_1slice(uint32_t d2d_base_addr1, uint32_t d2d_base_addr2);
void nop_loop(uint32_t num);

static void tx_dcc_adjustments_multi_slice(uint32_t base_addr, int adj_slow);
static void rx_dll_config_d2d(uint32_t rx_base_addr, uint8_t enable_clock);
static void correct_relative_skew(uint32_t d2d_base_addr, uint32_t rdata);
static void rx_dll_word_alignment(uint32_t d2d1_base_addr, uint32_t d2d2_base_addr, int adjustment, int adjustment_2, int slice_idx);
  
void write_field(uint32_t val, uint32_t field, uint32_t base_addr);
uint32_t read_field(uint32_t val, uint32_t field, uint32_t base_addr);

#endif /* __FREERTOS_FLC_H */



