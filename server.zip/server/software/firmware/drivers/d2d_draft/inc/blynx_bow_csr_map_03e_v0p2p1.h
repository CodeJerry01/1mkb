// Copyright (c) 2020 Blue Cheetah Analog Design, Inc.
// All Rights Reserved.
// The information contained herein is confidential and proprietary information
// of Blue Cheetah Analog Design, Inc. and its licensors, if any, and is
// subject to applicable non-disclosure agreement with Blue Cheetah Analog
// Design, Inc. Dissemination of information, use of this material, or
// reproduction of this material is strictly forbidden unless prior written
// permission is obtained from Blue Cheetah Analog Design, Inc.

// Automatically generated
//
// Do not manually edit!

#ifndef BLYNX_BOW_CSR_MAP_H
#define BLYNX_BOW_CSR_MAP_H

#include <stdlib.h>
#include <stdint.h>

#define REG_ADDR_MASK 0x1fff
#define FIELD_ADDR_MASK 0x1fff
#define FIELD_SHIFT_OFFSET 13
#define FIELD_SHIFT_MASK 0xf
#define FIELD_MSB_OFFSET 17
#define FIELD_MSB_MASK 0xf
#define FIELD_RO_OFFSET 21
#define FIELD_RO_MASK 0x1
#define FIELD_W1C_OFFSET 22
#define FIELD_W1C_MASK 0x1

#define BLYNX_BOW_BASE ((uint16_t) 0x0)

#define BOW_TOP ((uint16_t) 0x0)
#define TX_SLICE_0 ((uint16_t) 0x200)
#define RX_SLICE_0 ((uint16_t) 0x800)

#define CLK_DIST_ENABLE ((uint16_t) 0x0)
#define CLK_DIST_ENABLE__ENABLE ((uint32_t) 0x0)

#define TX_FREEZE ((uint16_t) 0x0)
#define TX_FREEZE__FREEZE_PI_DAC ((uint32_t) 0x0)
#define TX_FREEZE__FREEZE_DCC_SAMP ((uint32_t) 0x2000)

#define TX_DCC_CONFIG ((uint16_t) 0x2)
#define TX_DCC_CONFIG__DCC_DAC_RST ((uint32_t) 0x2)
#define TX_DCC_CONFIG__DCC_EN_DCC ((uint32_t) 0x2002)
#define TX_DCC_CONFIG__DCC_EN_DCC_TAIL_SW ((uint32_t) 0x4002)

#define TX_DCC_SENSOR_CONFIG ((uint16_t) 0x4)
#define TX_DCC_SENSOR_CONFIG__DCC_SAMP_SEL_INP ((uint32_t) 0x40004)
#define TX_DCC_SENSOR_CONFIG__DCC_SAMP_SEL_INM ((uint32_t) 0x46004)

#define TX_SER_RATIO_CTRL ((uint16_t) 0x6)
#define TX_SER_RATIO_CTRL__MPCG_SER_RATIO_CTRL ((uint32_t) 0x20006)

#define TX_SHIFT_REG_SETB ((uint16_t) 0x8)
#define TX_SHIFT_REG_SETB__MPCG_SHIFT_REG_SETH_N ((uint32_t) 0x1e0008)

#define TX_SHIFT_REG_RST ((uint16_t) 0xa)
#define TX_SHIFT_REG_RST__MPCG_SHIFT_REG_SETL ((uint32_t) 0x1e000a)

#define TX_CLK_SEL ((uint16_t) 0xc)
#define TX_CLK_SEL__MPCG_SEL_REG ((uint32_t) 0x6000c)
#define TX_CLK_SEL__MPCG_SEL_RTL ((uint32_t) 0x6800c)
#define TX_CLK_SEL__MPCG_SEL_LINK_LAYER ((uint32_t) 0x7000c)

#define TX_SEL_LOAD ((uint16_t) 0xe)
#define TX_SEL_LOAD__MPCG_SEL_LOAD ((uint32_t) 0x6000e)

#define TX_CLK_EN ((uint16_t) 0x10)
#define TX_CLK_EN__MPCG_CLK_REG_EN ((uint32_t) 0x10)
#define TX_CLK_EN__MPCG_CLK_RTL_EN ((uint32_t) 0x2010)
#define TX_CLK_EN__MPCG_CLK_LINK_LAYER_EN ((uint32_t) 0x4010)

#define TX_WILD_CLK_CONFIG0 ((uint16_t) 0x12)
#define TX_WILD_CLK_CONFIG0__MPCG_WILD_SLOW ((uint32_t) 0x12)
#define TX_WILD_CLK_CONFIG0__MPCG_WILD_HCOUNT ((uint32_t) 0xa2012)
#define TX_WILD_CLK_CONFIG0__MPCG_WILD_LCOUNT ((uint32_t) 0xae012)
#define TX_WILD_CLK_CONFIG0__MPCG_WILD_DIV_MODE ((uint32_t) 0x5a012)

#define TX_WILD_CLK_CONFIG1 ((uint16_t) 0x14)
#define TX_WILD_CLK_CONFIG1__MPCG_WILD_EN ((uint32_t) 0x14)
#define TX_WILD_CLK_CONFIG1__MPCG_WILD_RST_N ((uint32_t) 0x2014)

#define TX_TX_QPUMP_VREG_CONFIG ((uint16_t) 0x16)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_DIV_EN_FROM_RTL ((uint32_t) 0x16)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW ((uint32_t) 0x2016)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV1_RTL ((uint32_t) 0x4016)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV4_RTL ((uint32_t) 0x6016)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV8_RTL ((uint32_t) 0x8016)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_START ((uint32_t) 0xa016)
#define TX_TX_QPUMP_VREG_CONFIG__QPUMP_VREG_EN_FROM_RTL ((uint32_t) 0xc016)

#define TX_LPBK_DCC_VREF_CONFIG ((uint16_t) 0x18)
#define TX_LPBK_DCC_VREF_CONFIG__LPBK_DCC_VREF_DAC_EN_N ((uint32_t) 0x18)
#define TX_LPBK_DCC_VREF_CONFIG__LPBK_DCC_VREF_CK_SAMP_CAL_EN ((uint32_t) 0x2018)
#define TX_LPBK_DCC_VREF_CONFIG__LPBK_DCC_VREF_DAC_POS ((uint32_t) 0x4018)

#define TX_LPBK_CAL_CTRL_W0 ((uint16_t) 0x1a)
#define TX_LPBK_CAL_CTRL_W0__LPBK_CALP ((uint32_t) 0x4001a)
#define TX_LPBK_CAL_CTRL_W0__LPBK_CALN ((uint32_t) 0x4601a)

#define TX_LPBK_CAL_CTRL_W1 ((uint16_t) 0x1c)
#define TX_LPBK_CAL_CTRL_W1__LPBK_CALP ((uint32_t) 0x4001c)
#define TX_LPBK_CAL_CTRL_W1__LPBK_CALN ((uint32_t) 0x4601c)

#define TX_LPBK_CAL_CTRL_W2 ((uint16_t) 0x1e)
#define TX_LPBK_CAL_CTRL_W2__LPBK_CALP ((uint32_t) 0x4001e)
#define TX_LPBK_CAL_CTRL_W2__LPBK_CALN ((uint32_t) 0x4601e)

#define TX_LPBK_CAL_CTRL_W3 ((uint16_t) 0x20)
#define TX_LPBK_CAL_CTRL_W3__LPBK_CALP ((uint32_t) 0x40020)
#define TX_LPBK_CAL_CTRL_W3__LPBK_CALN ((uint32_t) 0x46020)

#define TX_LPBK_CAL_CTRL_W4 ((uint16_t) 0x22)
#define TX_LPBK_CAL_CTRL_W4__LPBK_CALP ((uint32_t) 0x40022)
#define TX_LPBK_CAL_CTRL_W4__LPBK_CALN ((uint32_t) 0x46022)

#define TX_LPBK_CAL_CTRL_W5 ((uint16_t) 0x24)
#define TX_LPBK_CAL_CTRL_W5__LPBK_CALP ((uint32_t) 0x40024)
#define TX_LPBK_CAL_CTRL_W5__LPBK_CALN ((uint32_t) 0x46024)

#define TX_LPBK_CAL_CTRL_W6 ((uint16_t) 0x26)
#define TX_LPBK_CAL_CTRL_W6__LPBK_CALP ((uint32_t) 0x40026)
#define TX_LPBK_CAL_CTRL_W6__LPBK_CALN ((uint32_t) 0x46026)

#define TX_LPBK_CAL_CTRL_W7 ((uint16_t) 0x28)
#define TX_LPBK_CAL_CTRL_W7__LPBK_CALP ((uint32_t) 0x40028)
#define TX_LPBK_CAL_CTRL_W7__LPBK_CALN ((uint32_t) 0x46028)

#define TX_LPBK_CAL_CTRL_W8 ((uint16_t) 0x2a)
#define TX_LPBK_CAL_CTRL_W8__LPBK_CALP ((uint32_t) 0x4002a)
#define TX_LPBK_CAL_CTRL_W8__LPBK_CALN ((uint32_t) 0x4602a)

#define TX_LPBK_CAL_CTRL_W9 ((uint16_t) 0x2c)
#define TX_LPBK_CAL_CTRL_W9__LPBK_CALP ((uint32_t) 0x4002c)
#define TX_LPBK_CAL_CTRL_W9__LPBK_CALN ((uint32_t) 0x4602c)

#define TX_LPBK_CAL_CTRL_W10 ((uint16_t) 0x2e)
#define TX_LPBK_CAL_CTRL_W10__LPBK_CALP ((uint32_t) 0x4002e)
#define TX_LPBK_CAL_CTRL_W10__LPBK_CALN ((uint32_t) 0x4602e)

#define TX_LPBK_CAL_CTRL_W11 ((uint16_t) 0x30)
#define TX_LPBK_CAL_CTRL_W11__LPBK_CALP ((uint32_t) 0x40030)
#define TX_LPBK_CAL_CTRL_W11__LPBK_CALN ((uint32_t) 0x46030)

#define TX_LPBK_CAL_CTRL_W12 ((uint16_t) 0x32)
#define TX_LPBK_CAL_CTRL_W12__LPBK_CALP ((uint32_t) 0x40032)
#define TX_LPBK_CAL_CTRL_W12__LPBK_CALN ((uint32_t) 0x46032)

#define TX_LPBK_CAL_CTRL_W13 ((uint16_t) 0x34)
#define TX_LPBK_CAL_CTRL_W13__LPBK_CALP ((uint32_t) 0x40034)
#define TX_LPBK_CAL_CTRL_W13__LPBK_CALN ((uint32_t) 0x46034)

#define TX_LPBK_CAL_CTRL_W14 ((uint16_t) 0x36)
#define TX_LPBK_CAL_CTRL_W14__LPBK_CALP ((uint32_t) 0x40036)
#define TX_LPBK_CAL_CTRL_W14__LPBK_CALN ((uint32_t) 0x46036)

#define TX_LPBK_CAL_CTRL_W15 ((uint16_t) 0x38)
#define TX_LPBK_CAL_CTRL_W15__LPBK_CALP ((uint32_t) 0x40038)
#define TX_LPBK_CAL_CTRL_W15__LPBK_CALN ((uint32_t) 0x46038)

#define TX_LPBK_CAL_CTRL_W16 ((uint16_t) 0x3a)
#define TX_LPBK_CAL_CTRL_W16__LPBK_CALP ((uint32_t) 0x4003a)
#define TX_LPBK_CAL_CTRL_W16__LPBK_CALN ((uint32_t) 0x4603a)

#define TX_LPBK_CAL_CTRL_W17 ((uint16_t) 0x3c)
#define TX_LPBK_CAL_CTRL_W17__LPBK_CALP ((uint32_t) 0x4003c)
#define TX_LPBK_CAL_CTRL_W17__LPBK_CALN ((uint32_t) 0x4603c)

#define TX_LPBK_CAL_CTRL_W18 ((uint16_t) 0x3e)
#define TX_LPBK_CAL_CTRL_W18__LPBK_CALP ((uint32_t) 0x4003e)
#define TX_LPBK_CAL_CTRL_W18__LPBK_CALN ((uint32_t) 0x4603e)

#define TX_LPBK_CAL_CTRL_W19 ((uint16_t) 0x40)
#define TX_LPBK_CAL_CTRL_W19__LPBK_CALP ((uint32_t) 0x40040)
#define TX_LPBK_CAL_CTRL_W19__LPBK_CALN ((uint32_t) 0x46040)

#define TX_SER_MUX_DRV_CTRL_W0 ((uint16_t) 0x42)
#define TX_SER_MUX_DRV_CTRL_W0__SER_IN0_DRV_PU ((uint32_t) 0x40042)
#define TX_SER_MUX_DRV_CTRL_W0__SER_IN0_DRV_PD_N ((uint32_t) 0x46042)
#define TX_SER_MUX_DRV_CTRL_W0__SER_IN1_DRV_PU ((uint32_t) 0x4c042)
#define TX_SER_MUX_DRV_CTRL_W0__SER_IN1_DRV_PD_N ((uint32_t) 0x52042)

#define TX_SER_MUX_DRV_CTRL_W1 ((uint16_t) 0x44)
#define TX_SER_MUX_DRV_CTRL_W1__SER_IN0_DRV_PU ((uint32_t) 0x40044)
#define TX_SER_MUX_DRV_CTRL_W1__SER_IN0_DRV_PD_N ((uint32_t) 0x46044)
#define TX_SER_MUX_DRV_CTRL_W1__SER_IN1_DRV_PU ((uint32_t) 0x4c044)
#define TX_SER_MUX_DRV_CTRL_W1__SER_IN1_DRV_PD_N ((uint32_t) 0x52044)

#define TX_SER_MUX_DRV_CTRL_W2 ((uint16_t) 0x46)
#define TX_SER_MUX_DRV_CTRL_W2__SER_IN0_DRV_PU ((uint32_t) 0x40046)
#define TX_SER_MUX_DRV_CTRL_W2__SER_IN0_DRV_PD_N ((uint32_t) 0x46046)
#define TX_SER_MUX_DRV_CTRL_W2__SER_IN1_DRV_PU ((uint32_t) 0x4c046)
#define TX_SER_MUX_DRV_CTRL_W2__SER_IN1_DRV_PD_N ((uint32_t) 0x52046)

#define TX_SER_MUX_DRV_CTRL_W3 ((uint16_t) 0x48)
#define TX_SER_MUX_DRV_CTRL_W3__SER_IN0_DRV_PU ((uint32_t) 0x40048)
#define TX_SER_MUX_DRV_CTRL_W3__SER_IN0_DRV_PD_N ((uint32_t) 0x46048)
#define TX_SER_MUX_DRV_CTRL_W3__SER_IN1_DRV_PU ((uint32_t) 0x4c048)
#define TX_SER_MUX_DRV_CTRL_W3__SER_IN1_DRV_PD_N ((uint32_t) 0x52048)

#define TX_SER_MUX_DRV_CTRL_W4 ((uint16_t) 0x4a)
#define TX_SER_MUX_DRV_CTRL_W4__SER_IN0_DRV_PU ((uint32_t) 0x4004a)
#define TX_SER_MUX_DRV_CTRL_W4__SER_IN0_DRV_PD_N ((uint32_t) 0x4604a)
#define TX_SER_MUX_DRV_CTRL_W4__SER_IN1_DRV_PU ((uint32_t) 0x4c04a)
#define TX_SER_MUX_DRV_CTRL_W4__SER_IN1_DRV_PD_N ((uint32_t) 0x5204a)

#define TX_SER_MUX_DRV_CTRL_W5 ((uint16_t) 0x4c)
#define TX_SER_MUX_DRV_CTRL_W5__SER_IN0_DRV_PU ((uint32_t) 0x4004c)
#define TX_SER_MUX_DRV_CTRL_W5__SER_IN0_DRV_PD_N ((uint32_t) 0x4604c)
#define TX_SER_MUX_DRV_CTRL_W5__SER_IN1_DRV_PU ((uint32_t) 0x4c04c)
#define TX_SER_MUX_DRV_CTRL_W5__SER_IN1_DRV_PD_N ((uint32_t) 0x5204c)

#define TX_SER_MUX_DRV_CTRL_W6 ((uint16_t) 0x4e)
#define TX_SER_MUX_DRV_CTRL_W6__SER_IN0_DRV_PU ((uint32_t) 0x4004e)
#define TX_SER_MUX_DRV_CTRL_W6__SER_IN0_DRV_PD_N ((uint32_t) 0x4604e)
#define TX_SER_MUX_DRV_CTRL_W6__SER_IN1_DRV_PU ((uint32_t) 0x4c04e)
#define TX_SER_MUX_DRV_CTRL_W6__SER_IN1_DRV_PD_N ((uint32_t) 0x5204e)

#define TX_SER_MUX_DRV_CTRL_W7 ((uint16_t) 0x50)
#define TX_SER_MUX_DRV_CTRL_W7__SER_IN0_DRV_PU ((uint32_t) 0x40050)
#define TX_SER_MUX_DRV_CTRL_W7__SER_IN0_DRV_PD_N ((uint32_t) 0x46050)
#define TX_SER_MUX_DRV_CTRL_W7__SER_IN1_DRV_PU ((uint32_t) 0x4c050)
#define TX_SER_MUX_DRV_CTRL_W7__SER_IN1_DRV_PD_N ((uint32_t) 0x52050)

#define TX_SER_MUX_DRV_CTRL_W8 ((uint16_t) 0x52)
#define TX_SER_MUX_DRV_CTRL_W8__SER_IN0_DRV_PU ((uint32_t) 0x40052)
#define TX_SER_MUX_DRV_CTRL_W8__SER_IN0_DRV_PD_N ((uint32_t) 0x46052)
#define TX_SER_MUX_DRV_CTRL_W8__SER_IN1_DRV_PU ((uint32_t) 0x4c052)
#define TX_SER_MUX_DRV_CTRL_W8__SER_IN1_DRV_PD_N ((uint32_t) 0x52052)

#define TX_SER_MUX_DRV_CTRL_W9 ((uint16_t) 0x54)
#define TX_SER_MUX_DRV_CTRL_W9__SER_IN0_DRV_PU ((uint32_t) 0x40054)
#define TX_SER_MUX_DRV_CTRL_W9__SER_IN0_DRV_PD_N ((uint32_t) 0x46054)
#define TX_SER_MUX_DRV_CTRL_W9__SER_IN1_DRV_PU ((uint32_t) 0x4c054)
#define TX_SER_MUX_DRV_CTRL_W9__SER_IN1_DRV_PD_N ((uint32_t) 0x52054)

#define TX_SER_MUX_DRV_CTRL_W10 ((uint16_t) 0x56)
#define TX_SER_MUX_DRV_CTRL_W10__SER_IN0_DRV_PU ((uint32_t) 0x40056)
#define TX_SER_MUX_DRV_CTRL_W10__SER_IN0_DRV_PD_N ((uint32_t) 0x46056)
#define TX_SER_MUX_DRV_CTRL_W10__SER_IN1_DRV_PU ((uint32_t) 0x4c056)
#define TX_SER_MUX_DRV_CTRL_W10__SER_IN1_DRV_PD_N ((uint32_t) 0x52056)

#define TX_SER_MUX_DRV_CTRL_W11 ((uint16_t) 0x58)
#define TX_SER_MUX_DRV_CTRL_W11__SER_IN0_DRV_PU ((uint32_t) 0x40058)
#define TX_SER_MUX_DRV_CTRL_W11__SER_IN0_DRV_PD_N ((uint32_t) 0x46058)
#define TX_SER_MUX_DRV_CTRL_W11__SER_IN1_DRV_PU ((uint32_t) 0x4c058)
#define TX_SER_MUX_DRV_CTRL_W11__SER_IN1_DRV_PD_N ((uint32_t) 0x52058)

#define TX_SER_MUX_DRV_CTRL_W12 ((uint16_t) 0x5a)
#define TX_SER_MUX_DRV_CTRL_W12__SER_IN0_DRV_PU ((uint32_t) 0x4005a)
#define TX_SER_MUX_DRV_CTRL_W12__SER_IN0_DRV_PD_N ((uint32_t) 0x4605a)
#define TX_SER_MUX_DRV_CTRL_W12__SER_IN1_DRV_PU ((uint32_t) 0x4c05a)
#define TX_SER_MUX_DRV_CTRL_W12__SER_IN1_DRV_PD_N ((uint32_t) 0x5205a)

#define TX_SER_MUX_DRV_CTRL_W13 ((uint16_t) 0x5c)
#define TX_SER_MUX_DRV_CTRL_W13__SER_IN0_DRV_PU ((uint32_t) 0x4005c)
#define TX_SER_MUX_DRV_CTRL_W13__SER_IN0_DRV_PD_N ((uint32_t) 0x4605c)
#define TX_SER_MUX_DRV_CTRL_W13__SER_IN1_DRV_PU ((uint32_t) 0x4c05c)
#define TX_SER_MUX_DRV_CTRL_W13__SER_IN1_DRV_PD_N ((uint32_t) 0x5205c)

#define TX_SER_MUX_DRV_CTRL_W14 ((uint16_t) 0x5e)
#define TX_SER_MUX_DRV_CTRL_W14__SER_IN0_DRV_PU ((uint32_t) 0x4005e)
#define TX_SER_MUX_DRV_CTRL_W14__SER_IN0_DRV_PD_N ((uint32_t) 0x4605e)
#define TX_SER_MUX_DRV_CTRL_W14__SER_IN1_DRV_PU ((uint32_t) 0x4c05e)
#define TX_SER_MUX_DRV_CTRL_W14__SER_IN1_DRV_PD_N ((uint32_t) 0x5205e)

#define TX_SER_MUX_DRV_CTRL_W15 ((uint16_t) 0x60)
#define TX_SER_MUX_DRV_CTRL_W15__SER_IN0_DRV_PU ((uint32_t) 0x40060)
#define TX_SER_MUX_DRV_CTRL_W15__SER_IN0_DRV_PD_N ((uint32_t) 0x46060)
#define TX_SER_MUX_DRV_CTRL_W15__SER_IN1_DRV_PU ((uint32_t) 0x4c060)
#define TX_SER_MUX_DRV_CTRL_W15__SER_IN1_DRV_PD_N ((uint32_t) 0x52060)

#define TX_SER_MUX_DRV_CTRL_W16 ((uint16_t) 0x62)
#define TX_SER_MUX_DRV_CTRL_W16__SER_IN0_DRV_PU ((uint32_t) 0x40062)
#define TX_SER_MUX_DRV_CTRL_W16__SER_IN0_DRV_PD_N ((uint32_t) 0x46062)
#define TX_SER_MUX_DRV_CTRL_W16__SER_IN1_DRV_PU ((uint32_t) 0x4c062)
#define TX_SER_MUX_DRV_CTRL_W16__SER_IN1_DRV_PD_N ((uint32_t) 0x52062)

#define TX_SER_MUX_DRV_CTRL_W17 ((uint16_t) 0x64)
#define TX_SER_MUX_DRV_CTRL_W17__SER_IN0_DRV_PU ((uint32_t) 0x40064)
#define TX_SER_MUX_DRV_CTRL_W17__SER_IN0_DRV_PD_N ((uint32_t) 0x46064)
#define TX_SER_MUX_DRV_CTRL_W17__SER_IN1_DRV_PU ((uint32_t) 0x4c064)
#define TX_SER_MUX_DRV_CTRL_W17__SER_IN1_DRV_PD_N ((uint32_t) 0x52064)

#define TX_SER_MUX_DRV_CTRL_W18 ((uint16_t) 0x66)
#define TX_SER_MUX_DRV_CTRL_W18__SER_IN0_DRV_PU ((uint32_t) 0x40066)
#define TX_SER_MUX_DRV_CTRL_W18__SER_IN0_DRV_PD_N ((uint32_t) 0x46066)
#define TX_SER_MUX_DRV_CTRL_W18__SER_IN1_DRV_PU ((uint32_t) 0x4c066)
#define TX_SER_MUX_DRV_CTRL_W18__SER_IN1_DRV_PD_N ((uint32_t) 0x52066)

#define TX_SER_MUX_DRV_CTRL_W19 ((uint16_t) 0x68)
#define TX_SER_MUX_DRV_CTRL_W19__SER_IN0_DRV_PU ((uint32_t) 0x40068)
#define TX_SER_MUX_DRV_CTRL_W19__SER_IN0_DRV_PD_N ((uint32_t) 0x46068)
#define TX_SER_MUX_DRV_CTRL_W19__SER_IN1_DRV_PU ((uint32_t) 0x4c068)
#define TX_SER_MUX_DRV_CTRL_W19__SER_IN1_DRV_PD_N ((uint32_t) 0x52068)

#define TX_FE_TIMING_W0 ((uint16_t) 0x6a)
#define TX_FE_TIMING_W0__TX_FE_DIN_PD_EN ((uint32_t) 0x6006a)
#define TX_FE_TIMING_W0__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6806a)

#define TX_FE_TIMING_W1 ((uint16_t) 0x6c)
#define TX_FE_TIMING_W1__TX_FE_DIN_PD_EN ((uint32_t) 0x6006c)
#define TX_FE_TIMING_W1__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6806c)

#define TX_FE_TIMING_W2 ((uint16_t) 0x6e)
#define TX_FE_TIMING_W2__TX_FE_DIN_PD_EN ((uint32_t) 0x6006e)
#define TX_FE_TIMING_W2__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6806e)

#define TX_FE_TIMING_W3 ((uint16_t) 0x70)
#define TX_FE_TIMING_W3__TX_FE_DIN_PD_EN ((uint32_t) 0x60070)
#define TX_FE_TIMING_W3__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68070)

#define TX_FE_TIMING_W4 ((uint16_t) 0x72)
#define TX_FE_TIMING_W4__TX_FE_DIN_PD_EN ((uint32_t) 0x60072)
#define TX_FE_TIMING_W4__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68072)

#define TX_FE_TIMING_W5 ((uint16_t) 0x74)
#define TX_FE_TIMING_W5__TX_FE_DIN_PD_EN ((uint32_t) 0x60074)
#define TX_FE_TIMING_W5__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68074)

#define TX_FE_TIMING_W6 ((uint16_t) 0x76)
#define TX_FE_TIMING_W6__TX_FE_DIN_PD_EN ((uint32_t) 0x60076)
#define TX_FE_TIMING_W6__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68076)

#define TX_FE_TIMING_W7 ((uint16_t) 0x78)
#define TX_FE_TIMING_W7__TX_FE_DIN_PD_EN ((uint32_t) 0x60078)
#define TX_FE_TIMING_W7__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68078)

#define TX_FE_TIMING_W8 ((uint16_t) 0x7a)
#define TX_FE_TIMING_W8__TX_FE_DIN_PD_EN ((uint32_t) 0x6007a)
#define TX_FE_TIMING_W8__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6807a)

#define TX_FE_TIMING_W9 ((uint16_t) 0x7c)
#define TX_FE_TIMING_W9__TX_FE_DIN_PD_EN ((uint32_t) 0x6007c)
#define TX_FE_TIMING_W9__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6807c)

#define TX_FE_TIMING_W10 ((uint16_t) 0x7e)
#define TX_FE_TIMING_W10__TX_FE_DIN_PD_EN ((uint32_t) 0x6007e)
#define TX_FE_TIMING_W10__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6807e)

#define TX_FE_TIMING_W11 ((uint16_t) 0x80)
#define TX_FE_TIMING_W11__TX_FE_DIN_PD_EN ((uint32_t) 0x60080)
#define TX_FE_TIMING_W11__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68080)

#define TX_FE_TIMING_W12 ((uint16_t) 0x82)
#define TX_FE_TIMING_W12__TX_FE_DIN_PD_EN ((uint32_t) 0x60082)
#define TX_FE_TIMING_W12__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68082)

#define TX_FE_TIMING_W13 ((uint16_t) 0x84)
#define TX_FE_TIMING_W13__TX_FE_DIN_PD_EN ((uint32_t) 0x60084)
#define TX_FE_TIMING_W13__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68084)

#define TX_FE_TIMING_W14 ((uint16_t) 0x86)
#define TX_FE_TIMING_W14__TX_FE_DIN_PD_EN ((uint32_t) 0x60086)
#define TX_FE_TIMING_W14__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68086)

#define TX_FE_TIMING_W15 ((uint16_t) 0x88)
#define TX_FE_TIMING_W15__TX_FE_DIN_PD_EN ((uint32_t) 0x60088)
#define TX_FE_TIMING_W15__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68088)

#define TX_FE_TIMING_W16 ((uint16_t) 0x8a)
#define TX_FE_TIMING_W16__TX_FE_DIN_PD_EN ((uint32_t) 0x6008a)
#define TX_FE_TIMING_W16__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6808a)

#define TX_FE_TIMING_W17 ((uint16_t) 0x8c)
#define TX_FE_TIMING_W17__TX_FE_DIN_PD_EN ((uint32_t) 0x6008c)
#define TX_FE_TIMING_W17__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6808c)

#define TX_FE_TIMING_W18 ((uint16_t) 0x8e)
#define TX_FE_TIMING_W18__TX_FE_DIN_PD_EN ((uint32_t) 0x6008e)
#define TX_FE_TIMING_W18__TX_FE_DIN_PU_EN_N ((uint32_t) 0x6808e)

#define TX_FE_TIMING_W19 ((uint16_t) 0x90)
#define TX_FE_TIMING_W19__TX_FE_DIN_PD_EN ((uint32_t) 0x60090)
#define TX_FE_TIMING_W19__TX_FE_DIN_PU_EN_N ((uint32_t) 0x68090)

#define TX_FE_DRV_EN_W0 ((uint16_t) 0x92)
#define TX_FE_DRV_EN_W0__TX_FE_DRV_EN_N ((uint32_t) 0x80092)

#define TX_FE_DRV_EN_W1 ((uint16_t) 0x94)
#define TX_FE_DRV_EN_W1__TX_FE_DRV_EN_N ((uint32_t) 0x80094)

#define TX_FE_DRV_EN_W2 ((uint16_t) 0x96)
#define TX_FE_DRV_EN_W2__TX_FE_DRV_EN_N ((uint32_t) 0x80096)

#define TX_FE_DRV_EN_W3 ((uint16_t) 0x98)
#define TX_FE_DRV_EN_W3__TX_FE_DRV_EN_N ((uint32_t) 0x80098)

#define TX_FE_DRV_EN_W4 ((uint16_t) 0x9a)
#define TX_FE_DRV_EN_W4__TX_FE_DRV_EN_N ((uint32_t) 0x8009a)

#define TX_FE_DRV_EN_W5 ((uint16_t) 0x9c)
#define TX_FE_DRV_EN_W5__TX_FE_DRV_EN_N ((uint32_t) 0x8009c)

#define TX_FE_DRV_EN_W6 ((uint16_t) 0x9e)
#define TX_FE_DRV_EN_W6__TX_FE_DRV_EN_N ((uint32_t) 0x8009e)

#define TX_FE_DRV_EN_W7 ((uint16_t) 0xa0)
#define TX_FE_DRV_EN_W7__TX_FE_DRV_EN_N ((uint32_t) 0x800a0)

#define TX_FE_DRV_EN_W8 ((uint16_t) 0xa2)
#define TX_FE_DRV_EN_W8__TX_FE_DRV_EN_N ((uint32_t) 0x800a2)

#define TX_FE_DRV_EN_W9 ((uint16_t) 0xa4)
#define TX_FE_DRV_EN_W9__TX_FE_DRV_EN_N ((uint32_t) 0x800a4)

#define TX_FE_DRV_EN_W10 ((uint16_t) 0xa6)
#define TX_FE_DRV_EN_W10__TX_FE_DRV_EN_N ((uint32_t) 0x800a6)

#define TX_FE_DRV_EN_W11 ((uint16_t) 0xa8)
#define TX_FE_DRV_EN_W11__TX_FE_DRV_EN_N ((uint32_t) 0x800a8)

#define TX_FE_DRV_EN_W12 ((uint16_t) 0xaa)
#define TX_FE_DRV_EN_W12__TX_FE_DRV_EN_N ((uint32_t) 0x800aa)

#define TX_FE_DRV_EN_W13 ((uint16_t) 0xac)
#define TX_FE_DRV_EN_W13__TX_FE_DRV_EN_N ((uint32_t) 0x800ac)

#define TX_FE_DRV_EN_W14 ((uint16_t) 0xae)
#define TX_FE_DRV_EN_W14__TX_FE_DRV_EN_N ((uint32_t) 0x800ae)

#define TX_FE_DRV_EN_W15 ((uint16_t) 0xb0)
#define TX_FE_DRV_EN_W15__TX_FE_DRV_EN_N ((uint32_t) 0x800b0)

#define TX_FE_DRV_EN_W16 ((uint16_t) 0xb2)
#define TX_FE_DRV_EN_W16__TX_FE_DRV_EN_N ((uint32_t) 0x800b2)

#define TX_FE_DRV_EN_W17 ((uint16_t) 0xb4)
#define TX_FE_DRV_EN_W17__TX_FE_DRV_EN_N ((uint32_t) 0x800b4)

#define TX_FE_DRV_EN_W18 ((uint16_t) 0xb6)
#define TX_FE_DRV_EN_W18__TX_FE_DRV_EN_N ((uint32_t) 0x800b6)

#define TX_FE_DRV_EN_W19 ((uint16_t) 0xb8)
#define TX_FE_DRV_EN_W19__TX_FE_DRV_EN_N ((uint32_t) 0x800b8)

#define TX_PI_CONFIG0 ((uint16_t) 0xba)
#define TX_PI_CONFIG0__PI_CLK_DIV_EN ((uint32_t) 0xba)
#define TX_PI_CONFIG0__PI_DAC_SET_N ((uint32_t) 0x20ba)
#define TX_PI_CONFIG0__PI_INTERP_RST ((uint32_t) 0x40ba)
#define TX_PI_CONFIG0__PI_LEVEL_SHIFT_RST ((uint32_t) 0x60ba)

#define TX_PI_CONFIG1 ((uint16_t) 0xbc)
#define TX_PI_CONFIG1__SHIFT_REG_SETH_N ((uint32_t) 0xe00bc)
#define TX_PI_CONFIG1__SHIFT_REG_SETL ((uint32_t) 0xf00bc)

#define TX_TX_DATA_SPARES_W0 ((uint16_t) 0xbe)
#define TX_TX_DATA_SPARES_W0__SPARE_I ((uint32_t) 0x1e00be)

#define TX_TX_DATA_SPARES_W1 ((uint16_t) 0xc0)
#define TX_TX_DATA_SPARES_W1__SPARE_I ((uint32_t) 0x1e00c0)

#define TX_TX_DATA_SPARES_W2 ((uint16_t) 0xc2)
#define TX_TX_DATA_SPARES_W2__SPARE_I ((uint32_t) 0x1e00c2)

#define TX_TX_DATA_SPARES_W3 ((uint16_t) 0xc4)
#define TX_TX_DATA_SPARES_W3__SPARE_I ((uint32_t) 0x1e00c4)

#define TX_TX_DATA_SPARES_W4 ((uint16_t) 0xc6)
#define TX_TX_DATA_SPARES_W4__SPARE_I ((uint32_t) 0x1e00c6)

#define TX_TX_DATA_SPARES_W5 ((uint16_t) 0xc8)
#define TX_TX_DATA_SPARES_W5__SPARE_I ((uint32_t) 0x1e00c8)

#define TX_TX_DATA_SPARES_W6 ((uint16_t) 0xca)
#define TX_TX_DATA_SPARES_W6__SPARE_I ((uint32_t) 0x1e00ca)

#define TX_TX_DATA_SPARES_W7 ((uint16_t) 0xcc)
#define TX_TX_DATA_SPARES_W7__SPARE_I ((uint32_t) 0x1e00cc)

#define TX_TX_DATA_SPARES_W8 ((uint16_t) 0xce)
#define TX_TX_DATA_SPARES_W8__SPARE_I ((uint32_t) 0x1e00ce)

#define TX_TX_DATA_SPARES_W9 ((uint16_t) 0xd0)
#define TX_TX_DATA_SPARES_W9__SPARE_I ((uint32_t) 0x1e00d0)

#define TX_TX_DATA_SPARES_W10 ((uint16_t) 0xd2)
#define TX_TX_DATA_SPARES_W10__SPARE_I ((uint32_t) 0x1e00d2)

#define TX_TX_DATA_SPARES_W11 ((uint16_t) 0xd4)
#define TX_TX_DATA_SPARES_W11__SPARE_I ((uint32_t) 0x1e00d4)

#define TX_TX_DATA_SPARES_W12 ((uint16_t) 0xd6)
#define TX_TX_DATA_SPARES_W12__SPARE_I ((uint32_t) 0x1e00d6)

#define TX_TX_DATA_SPARES_W13 ((uint16_t) 0xd8)
#define TX_TX_DATA_SPARES_W13__SPARE_I ((uint32_t) 0x1e00d8)

#define TX_TX_DATA_SPARES_W14 ((uint16_t) 0xda)
#define TX_TX_DATA_SPARES_W14__SPARE_I ((uint32_t) 0x1e00da)

#define TX_TX_DATA_SPARES_W15 ((uint16_t) 0xdc)
#define TX_TX_DATA_SPARES_W15__SPARE_I ((uint32_t) 0x1e00dc)

#define TX_TX_DATA_SPARES_W16 ((uint16_t) 0xde)
#define TX_TX_DATA_SPARES_W16__SPARE_I ((uint32_t) 0x1e00de)

#define TX_TX_DATA_SPARES_W17 ((uint16_t) 0xe0)
#define TX_TX_DATA_SPARES_W17__SPARE_I ((uint32_t) 0x1e00e0)

#define TX_TX_DATA_SPARES_W18 ((uint16_t) 0xe2)
#define TX_TX_DATA_SPARES_W18__SPARE_I ((uint32_t) 0x1e00e2)

#define TX_TX_DATA_SPARES_W19 ((uint16_t) 0xe4)
#define TX_TX_DATA_SPARES_W19__SPARE_I ((uint32_t) 0x1e00e4)

#define TX_TX_SHARED_SPARES ((uint16_t) 0xe6)
#define TX_TX_SHARED_SPARES__SPARE_I ((uint32_t) 0x1e00e6)

#define TX_TX_STATUS ((uint16_t) 0xe8)
#define TX_TX_STATUS__DCC_CLK_TX_SAMPLE ((uint32_t) 0x6000e8)
#define TX_TX_STATUS__DCC_CLK_TXB_SAMPLE ((uint32_t) 0x6020e8)
#define TX_TX_STATUS__DCC_CLK_DIST_SAMPLE ((uint32_t) 0x6040e8)
#define TX_TX_STATUS__PI_FREE_SAMP_TX ((uint32_t) 0x6060e8)
#define TX_TX_STATUS__PI_FREE_SAMP_EARLY ((uint32_t) 0x6080e8)

#define TX_DATA_INVERSION_REODERING ((uint16_t) 0xea)
#define TX_DATA_INVERSION_REODERING__DEBUG_DATAPATH_EN ((uint32_t) 0xea)
#define TX_DATA_INVERSION_REODERING__INVERT_DATA_EN ((uint32_t) 0x20ea)
#define TX_DATA_INVERSION_REODERING__FULL_REVERSE_DATA_EN ((uint32_t) 0x40ea)
#define TX_DATA_INVERSION_REODERING__GROUP_BY_WORD_EN ((uint32_t) 0x60ea)
#define TX_DATA_INVERSION_REODERING__SER_REVERSE_DATA_EN ((uint32_t) 0x80ea)

#define TX_INVERSION_MASK_0 ((uint16_t) 0xec)
#define TX_INVERSION_MASK_0__MASK ((uint32_t) 0x1e00ec)

#define TX_INVERSION_MASK_1 ((uint16_t) 0xee)
#define TX_INVERSION_MASK_1__MASK ((uint32_t) 0x1e00ee)

#define TX_INVERSION_MASK_2 ((uint16_t) 0xf0)
#define TX_INVERSION_MASK_2__MASK ((uint32_t) 0x1e00f0)

#define TX_INVERSION_MASK_3 ((uint16_t) 0xf2)
#define TX_INVERSION_MASK_3__MASK ((uint32_t) 0x1e00f2)

#define TX_INVERSION_MASK_4 ((uint16_t) 0xf4)
#define TX_INVERSION_MASK_4__MASK ((uint32_t) 0x1e00f4)

#define TX_INVERSION_MASK_5 ((uint16_t) 0xf6)
#define TX_INVERSION_MASK_5__MASK ((uint32_t) 0x1e00f6)

#define TX_INVERSION_MASK_6 ((uint16_t) 0xf8)
#define TX_INVERSION_MASK_6__MASK ((uint32_t) 0x1e00f8)

#define TX_INVERSION_MASK_7 ((uint16_t) 0xfa)
#define TX_INVERSION_MASK_7__MASK ((uint32_t) 0x1e00fa)

#define TX_INVERSION_MASK_8 ((uint16_t) 0xfc)
#define TX_INVERSION_MASK_8__MASK ((uint32_t) 0x1e00fc)

#define TX_INVERSION_MASK_9 ((uint16_t) 0xfe)
#define TX_INVERSION_MASK_9__MASK ((uint32_t) 0x1e00fe)

#define TX_INVERSION_MASK_10 ((uint16_t) 0x100)
#define TX_INVERSION_MASK_10__MASK ((uint32_t) 0x1e0100)

#define TX_INVERSION_MASK_11 ((uint16_t) 0x102)
#define TX_INVERSION_MASK_11__MASK ((uint32_t) 0x1e0102)

#define TX_INVERSION_MASK_12 ((uint16_t) 0x104)
#define TX_INVERSION_MASK_12__MASK ((uint32_t) 0x1e0104)

#define TX_INVERSION_MASK_13 ((uint16_t) 0x106)
#define TX_INVERSION_MASK_13__MASK ((uint32_t) 0x1e0106)

#define TX_INVERSION_MASK_14 ((uint16_t) 0x108)
#define TX_INVERSION_MASK_14__MASK ((uint32_t) 0x1e0108)

#define TX_INVERSION_MASK_15 ((uint16_t) 0x10a)
#define TX_INVERSION_MASK_15__MASK ((uint32_t) 0x1e010a)

#define TX_BIT_REDUNDANCY_SEL_0_7 ((uint16_t) 0x10c)
#define TX_BIT_REDUNDANCY_SEL_0_7__AUX_BIT ((uint32_t) 0x10c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_0 ((uint32_t) 0x210c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_1 ((uint32_t) 0x2410c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_2 ((uint32_t) 0x2810c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_3 ((uint32_t) 0x2c10c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_4 ((uint32_t) 0x3010c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_5 ((uint32_t) 0x3410c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_6 ((uint32_t) 0x3810c)
#define TX_BIT_REDUNDANCY_SEL_0_7__BIT_7 ((uint32_t) 0x3c10c)

#define TX_BIT_REDUNDANCY_SEL_8_15 ((uint16_t) 0x10e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_8 ((uint32_t) 0x2010e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_9 ((uint32_t) 0x2410e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_10 ((uint32_t) 0x2810e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_11 ((uint32_t) 0x2c10e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_12 ((uint32_t) 0x3010e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_13 ((uint32_t) 0x3410e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_14 ((uint32_t) 0x3810e)
#define TX_BIT_REDUNDANCY_SEL_8_15__BIT_15 ((uint32_t) 0x1c10e)
#define TX_BIT_REDUNDANCY_SEL_8_15__FEC_BIT ((uint32_t) 0x1e10e)

#define TX_PATTERN_GENERATOR_EN ((uint16_t) 0x110)
#define TX_PATTERN_GENERATOR_EN__DATA_ENABLE ((uint32_t) 0x110)

#define TX_LINK_LAYER_CLOCK_SEL ((uint16_t) 0x112)
#define TX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_ASYNC_CLK_EN ((uint32_t) 0x112)
#define TX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_SYNC_CLK_EN ((uint32_t) 0x2112)
#define TX_LINK_LAYER_CLOCK_SEL__APB_CLK_EN ((uint32_t) 0x4112)

#define TX_PHYREADY_OVERRIDE ((uint16_t) 0x114)
#define TX_PHYREADY_OVERRIDE__OVRD ((uint32_t) 0x114)
#define TX_PHYREADY_OVERRIDE__OVRD_VALUE ((uint32_t) 0x2114)

#define TX_FD_FREEZE ((uint16_t) 0x116)
#define TX_FD_FREEZE__FREEZE ((uint32_t) 0x116)

#define TX_FD_RESET ((uint16_t) 0x118)
#define TX_FD_RESET__RST_N ((uint32_t) 0x118)

#define TX_FD_CLOCK_GATE ((uint16_t) 0x11a)
#define TX_FD_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x11a)

#define TX_FD_REF_PER_MULT ((uint16_t) 0x11c)
#define TX_FD_REF_PER_MULT__REF_PER_MULT ((uint32_t) 0x1e011c)

#define TX_FD_FREQ_CNT_OBSV ((uint16_t) 0x11e)
#define TX_FD_FREQ_CNT_OBSV__FREQ_CNT_OBSV ((uint32_t) 0x7e011e)

#define TX_PAT_GEN_MISC_CTRL ((uint16_t) 0x120)
#define TX_PAT_GEN_MISC_CTRL__SW_RST_N ((uint32_t) 0x120)
#define TX_PAT_GEN_MISC_CTRL__SER_RATIO ((uint32_t) 0x22120)

#define TX_PAT_GEN_CLOCK_GATE ((uint16_t) 0x122)
#define TX_PAT_GEN_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x122)

#define TX_PAT_GEN_PAT_GEN_FREEZE ((uint16_t) 0x124)
#define TX_PAT_GEN_PAT_GEN_FREEZE__FREEZE ((uint32_t) 0x124)

#define TX_PAT_GEN_MUX_CTRL_D0 ((uint16_t) 0x126)
#define TX_PAT_GEN_MUX_CTRL_D0__INV ((uint32_t) 0x126)
#define TX_PAT_GEN_MUX_CTRL_D0__PATSEL ((uint32_t) 0x2126)

#define TX_PAT_GEN_MUX_CTRL_D1 ((uint16_t) 0x128)
#define TX_PAT_GEN_MUX_CTRL_D1__INV ((uint32_t) 0x128)
#define TX_PAT_GEN_MUX_CTRL_D1__PATSEL ((uint32_t) 0x2128)

#define TX_PAT_GEN_MUX_CTRL_D2 ((uint16_t) 0x12a)
#define TX_PAT_GEN_MUX_CTRL_D2__INV ((uint32_t) 0x12a)
#define TX_PAT_GEN_MUX_CTRL_D2__PATSEL ((uint32_t) 0x212a)

#define TX_PAT_GEN_MUX_CTRL_D3 ((uint16_t) 0x12c)
#define TX_PAT_GEN_MUX_CTRL_D3__INV ((uint32_t) 0x12c)
#define TX_PAT_GEN_MUX_CTRL_D3__PATSEL ((uint32_t) 0x212c)

#define TX_PAT_GEN_MUX_CTRL_D4 ((uint16_t) 0x12e)
#define TX_PAT_GEN_MUX_CTRL_D4__INV ((uint32_t) 0x12e)
#define TX_PAT_GEN_MUX_CTRL_D4__PATSEL ((uint32_t) 0x212e)

#define TX_PAT_GEN_MUX_CTRL_D5 ((uint16_t) 0x130)
#define TX_PAT_GEN_MUX_CTRL_D5__INV ((uint32_t) 0x130)
#define TX_PAT_GEN_MUX_CTRL_D5__PATSEL ((uint32_t) 0x2130)

#define TX_PAT_GEN_MUX_CTRL_D6 ((uint16_t) 0x132)
#define TX_PAT_GEN_MUX_CTRL_D6__INV ((uint32_t) 0x132)
#define TX_PAT_GEN_MUX_CTRL_D6__PATSEL ((uint32_t) 0x2132)

#define TX_PAT_GEN_MUX_CTRL_D7 ((uint16_t) 0x134)
#define TX_PAT_GEN_MUX_CTRL_D7__INV ((uint32_t) 0x134)
#define TX_PAT_GEN_MUX_CTRL_D7__PATSEL ((uint32_t) 0x2134)

#define TX_PAT_GEN_MUX_CTRL_D8 ((uint16_t) 0x136)
#define TX_PAT_GEN_MUX_CTRL_D8__INV ((uint32_t) 0x136)
#define TX_PAT_GEN_MUX_CTRL_D8__PATSEL ((uint32_t) 0x2136)

#define TX_PAT_GEN_MUX_CTRL_D9 ((uint16_t) 0x138)
#define TX_PAT_GEN_MUX_CTRL_D9__INV ((uint32_t) 0x138)
#define TX_PAT_GEN_MUX_CTRL_D9__PATSEL ((uint32_t) 0x2138)

#define TX_PAT_GEN_MUX_CTRL_D10 ((uint16_t) 0x13a)
#define TX_PAT_GEN_MUX_CTRL_D10__INV ((uint32_t) 0x13a)
#define TX_PAT_GEN_MUX_CTRL_D10__PATSEL ((uint32_t) 0x213a)

#define TX_PAT_GEN_MUX_CTRL_D11 ((uint16_t) 0x13c)
#define TX_PAT_GEN_MUX_CTRL_D11__INV ((uint32_t) 0x13c)
#define TX_PAT_GEN_MUX_CTRL_D11__PATSEL ((uint32_t) 0x213c)

#define TX_PAT_GEN_MUX_CTRL_D12 ((uint16_t) 0x13e)
#define TX_PAT_GEN_MUX_CTRL_D12__INV ((uint32_t) 0x13e)
#define TX_PAT_GEN_MUX_CTRL_D12__PATSEL ((uint32_t) 0x213e)

#define TX_PAT_GEN_MUX_CTRL_D13 ((uint16_t) 0x140)
#define TX_PAT_GEN_MUX_CTRL_D13__INV ((uint32_t) 0x140)
#define TX_PAT_GEN_MUX_CTRL_D13__PATSEL ((uint32_t) 0x2140)

#define TX_PAT_GEN_MUX_CTRL_D14 ((uint16_t) 0x142)
#define TX_PAT_GEN_MUX_CTRL_D14__INV ((uint32_t) 0x142)
#define TX_PAT_GEN_MUX_CTRL_D14__PATSEL ((uint32_t) 0x2142)

#define TX_PAT_GEN_MUX_CTRL_D15 ((uint16_t) 0x144)
#define TX_PAT_GEN_MUX_CTRL_D15__INV ((uint32_t) 0x144)
#define TX_PAT_GEN_MUX_CTRL_D15__PATSEL ((uint32_t) 0x2144)

#define TX_PAT_GEN_MUX_CTRL_D16 ((uint16_t) 0x146)
#define TX_PAT_GEN_MUX_CTRL_D16__INV ((uint32_t) 0x146)
#define TX_PAT_GEN_MUX_CTRL_D16__PATSEL ((uint32_t) 0x2146)

#define TX_PAT_GEN_MUX_CTRL_D17 ((uint16_t) 0x148)
#define TX_PAT_GEN_MUX_CTRL_D17__INV ((uint32_t) 0x148)
#define TX_PAT_GEN_MUX_CTRL_D17__PATSEL ((uint32_t) 0x2148)

#define TX_PAT_GEN_MUX_CTRL_D18 ((uint16_t) 0x14a)
#define TX_PAT_GEN_MUX_CTRL_D18__INV ((uint32_t) 0x14a)
#define TX_PAT_GEN_MUX_CTRL_D18__PATSEL ((uint32_t) 0x214a)

#define TX_PAT_GEN_MUX_CTRL_D19 ((uint16_t) 0x14c)
#define TX_PAT_GEN_MUX_CTRL_D19__INV ((uint32_t) 0x14c)
#define TX_PAT_GEN_MUX_CTRL_D19__PATSEL ((uint32_t) 0x214c)

#define TX_PAT_GEN_PRBS_CTRL_P0 ((uint16_t) 0x14e)
#define TX_PAT_GEN_PRBS_CTRL_P0__PRBS_EN ((uint32_t) 0x14e)
#define TX_PAT_GEN_PRBS_CTRL_P0__PRBS_SEED_EN ((uint32_t) 0x214e)
#define TX_PAT_GEN_PRBS_CTRL_P0__PRBS_SIZE ((uint32_t) 0x4414e)

#define TX_PAT_GEN_PRBS_CTRL_P1 ((uint16_t) 0x150)
#define TX_PAT_GEN_PRBS_CTRL_P1__PRBS_EN ((uint32_t) 0x150)
#define TX_PAT_GEN_PRBS_CTRL_P1__PRBS_SEED_EN ((uint32_t) 0x2150)
#define TX_PAT_GEN_PRBS_CTRL_P1__PRBS_SIZE ((uint32_t) 0x44150)

#define TX_PAT_GEN_PRBS_CTRL_P2 ((uint16_t) 0x152)
#define TX_PAT_GEN_PRBS_CTRL_P2__PRBS_EN ((uint32_t) 0x152)
#define TX_PAT_GEN_PRBS_CTRL_P2__PRBS_SEED_EN ((uint32_t) 0x2152)
#define TX_PAT_GEN_PRBS_CTRL_P2__PRBS_SIZE ((uint32_t) 0x44152)

#define TX_PAT_GEN_PRBS_CTRL_P3 ((uint16_t) 0x154)
#define TX_PAT_GEN_PRBS_CTRL_P3__PRBS_EN ((uint32_t) 0x154)
#define TX_PAT_GEN_PRBS_CTRL_P3__PRBS_SEED_EN ((uint32_t) 0x2154)
#define TX_PAT_GEN_PRBS_CTRL_P3__PRBS_SIZE ((uint32_t) 0x44154)

#define TX_PAT_GEN_PRBS_CTRL_P4 ((uint16_t) 0x156)
#define TX_PAT_GEN_PRBS_CTRL_P4__PRBS_EN ((uint32_t) 0x156)
#define TX_PAT_GEN_PRBS_CTRL_P4__PRBS_SEED_EN ((uint32_t) 0x2156)
#define TX_PAT_GEN_PRBS_CTRL_P4__PRBS_SIZE ((uint32_t) 0x44156)

#define TX_PAT_GEN_PRBS_CTRL_P5 ((uint16_t) 0x158)
#define TX_PAT_GEN_PRBS_CTRL_P5__PRBS_EN ((uint32_t) 0x158)
#define TX_PAT_GEN_PRBS_CTRL_P5__PRBS_SEED_EN ((uint32_t) 0x2158)
#define TX_PAT_GEN_PRBS_CTRL_P5__PRBS_SIZE ((uint32_t) 0x44158)

#define TX_PAT_GEN_PRBS_CTRL_P6 ((uint16_t) 0x15a)
#define TX_PAT_GEN_PRBS_CTRL_P6__PRBS_EN ((uint32_t) 0x15a)
#define TX_PAT_GEN_PRBS_CTRL_P6__PRBS_SEED_EN ((uint32_t) 0x215a)
#define TX_PAT_GEN_PRBS_CTRL_P6__PRBS_SIZE ((uint32_t) 0x4415a)

#define TX_PAT_GEN_PRBS_CTRL_P7 ((uint16_t) 0x15c)
#define TX_PAT_GEN_PRBS_CTRL_P7__PRBS_EN ((uint32_t) 0x15c)
#define TX_PAT_GEN_PRBS_CTRL_P7__PRBS_SEED_EN ((uint32_t) 0x215c)
#define TX_PAT_GEN_PRBS_CTRL_P7__PRBS_SIZE ((uint32_t) 0x4415c)

#define TX_PAT_GEN_PRBS_CTRL_P8 ((uint16_t) 0x15e)
#define TX_PAT_GEN_PRBS_CTRL_P8__PRBS_EN ((uint32_t) 0x15e)
#define TX_PAT_GEN_PRBS_CTRL_P8__PRBS_SEED_EN ((uint32_t) 0x215e)
#define TX_PAT_GEN_PRBS_CTRL_P8__PRBS_SIZE ((uint32_t) 0x4415e)

#define TX_PAT_GEN_PRBS_CTRL_P9 ((uint16_t) 0x160)
#define TX_PAT_GEN_PRBS_CTRL_P9__PRBS_EN ((uint32_t) 0x160)
#define TX_PAT_GEN_PRBS_CTRL_P9__PRBS_SEED_EN ((uint32_t) 0x2160)
#define TX_PAT_GEN_PRBS_CTRL_P9__PRBS_SIZE ((uint32_t) 0x44160)

#define TX_PAT_GEN_PRBS_CTRL_P10 ((uint16_t) 0x162)
#define TX_PAT_GEN_PRBS_CTRL_P10__PRBS_EN ((uint32_t) 0x162)
#define TX_PAT_GEN_PRBS_CTRL_P10__PRBS_SEED_EN ((uint32_t) 0x2162)
#define TX_PAT_GEN_PRBS_CTRL_P10__PRBS_SIZE ((uint32_t) 0x44162)

#define TX_PAT_GEN_PRBS_CTRL_P11 ((uint16_t) 0x164)
#define TX_PAT_GEN_PRBS_CTRL_P11__PRBS_EN ((uint32_t) 0x164)
#define TX_PAT_GEN_PRBS_CTRL_P11__PRBS_SEED_EN ((uint32_t) 0x2164)
#define TX_PAT_GEN_PRBS_CTRL_P11__PRBS_SIZE ((uint32_t) 0x44164)

#define TX_PAT_GEN_PRBS_CTRL_P12 ((uint16_t) 0x166)
#define TX_PAT_GEN_PRBS_CTRL_P12__PRBS_EN ((uint32_t) 0x166)
#define TX_PAT_GEN_PRBS_CTRL_P12__PRBS_SEED_EN ((uint32_t) 0x2166)
#define TX_PAT_GEN_PRBS_CTRL_P12__PRBS_SIZE ((uint32_t) 0x44166)

#define TX_PAT_GEN_PRBS_CTRL_P13 ((uint16_t) 0x168)
#define TX_PAT_GEN_PRBS_CTRL_P13__PRBS_EN ((uint32_t) 0x168)
#define TX_PAT_GEN_PRBS_CTRL_P13__PRBS_SEED_EN ((uint32_t) 0x2168)
#define TX_PAT_GEN_PRBS_CTRL_P13__PRBS_SIZE ((uint32_t) 0x44168)

#define TX_PAT_GEN_PRBS_CTRL_P14 ((uint16_t) 0x16a)
#define TX_PAT_GEN_PRBS_CTRL_P14__PRBS_EN ((uint32_t) 0x16a)
#define TX_PAT_GEN_PRBS_CTRL_P14__PRBS_SEED_EN ((uint32_t) 0x216a)
#define TX_PAT_GEN_PRBS_CTRL_P14__PRBS_SIZE ((uint32_t) 0x4416a)

#define TX_PAT_GEN_PRBS_CTRL_P15 ((uint16_t) 0x16c)
#define TX_PAT_GEN_PRBS_CTRL_P15__PRBS_EN ((uint32_t) 0x16c)
#define TX_PAT_GEN_PRBS_CTRL_P15__PRBS_SEED_EN ((uint32_t) 0x216c)
#define TX_PAT_GEN_PRBS_CTRL_P15__PRBS_SIZE ((uint32_t) 0x4416c)

#define TX_PAT_GEN_PRBS_CTRL_P16 ((uint16_t) 0x16e)
#define TX_PAT_GEN_PRBS_CTRL_P16__PRBS_EN ((uint32_t) 0x16e)
#define TX_PAT_GEN_PRBS_CTRL_P16__PRBS_SEED_EN ((uint32_t) 0x216e)
#define TX_PAT_GEN_PRBS_CTRL_P16__PRBS_SIZE ((uint32_t) 0x4416e)

#define TX_PAT_GEN_PRBS_CTRL_P17 ((uint16_t) 0x170)
#define TX_PAT_GEN_PRBS_CTRL_P17__PRBS_EN ((uint32_t) 0x170)
#define TX_PAT_GEN_PRBS_CTRL_P17__PRBS_SEED_EN ((uint32_t) 0x2170)
#define TX_PAT_GEN_PRBS_CTRL_P17__PRBS_SIZE ((uint32_t) 0x44170)

#define TX_PAT_GEN_PRBS_SEED_LO_P0 ((uint16_t) 0x172)
#define TX_PAT_GEN_PRBS_SEED_LO_P0__SEED ((uint32_t) 0x1e0172)

#define TX_PAT_GEN_PRBS_SEED_LO_P1 ((uint16_t) 0x174)
#define TX_PAT_GEN_PRBS_SEED_LO_P1__SEED ((uint32_t) 0x1e0174)

#define TX_PAT_GEN_PRBS_SEED_LO_P2 ((uint16_t) 0x176)
#define TX_PAT_GEN_PRBS_SEED_LO_P2__SEED ((uint32_t) 0x1e0176)

#define TX_PAT_GEN_PRBS_SEED_LO_P3 ((uint16_t) 0x178)
#define TX_PAT_GEN_PRBS_SEED_LO_P3__SEED ((uint32_t) 0x1e0178)

#define TX_PAT_GEN_PRBS_SEED_LO_P4 ((uint16_t) 0x17a)
#define TX_PAT_GEN_PRBS_SEED_LO_P4__SEED ((uint32_t) 0x1e017a)

#define TX_PAT_GEN_PRBS_SEED_LO_P5 ((uint16_t) 0x17c)
#define TX_PAT_GEN_PRBS_SEED_LO_P5__SEED ((uint32_t) 0x1e017c)

#define TX_PAT_GEN_PRBS_SEED_LO_P6 ((uint16_t) 0x17e)
#define TX_PAT_GEN_PRBS_SEED_LO_P6__SEED ((uint32_t) 0x1e017e)

#define TX_PAT_GEN_PRBS_SEED_LO_P7 ((uint16_t) 0x180)
#define TX_PAT_GEN_PRBS_SEED_LO_P7__SEED ((uint32_t) 0x1e0180)

#define TX_PAT_GEN_PRBS_SEED_LO_P8 ((uint16_t) 0x182)
#define TX_PAT_GEN_PRBS_SEED_LO_P8__SEED ((uint32_t) 0x1e0182)

#define TX_PAT_GEN_PRBS_SEED_LO_P9 ((uint16_t) 0x184)
#define TX_PAT_GEN_PRBS_SEED_LO_P9__SEED ((uint32_t) 0x1e0184)

#define TX_PAT_GEN_PRBS_SEED_LO_P10 ((uint16_t) 0x186)
#define TX_PAT_GEN_PRBS_SEED_LO_P10__SEED ((uint32_t) 0x1e0186)

#define TX_PAT_GEN_PRBS_SEED_LO_P11 ((uint16_t) 0x188)
#define TX_PAT_GEN_PRBS_SEED_LO_P11__SEED ((uint32_t) 0x1e0188)

#define TX_PAT_GEN_PRBS_SEED_LO_P12 ((uint16_t) 0x18a)
#define TX_PAT_GEN_PRBS_SEED_LO_P12__SEED ((uint32_t) 0x1e018a)

#define TX_PAT_GEN_PRBS_SEED_LO_P13 ((uint16_t) 0x18c)
#define TX_PAT_GEN_PRBS_SEED_LO_P13__SEED ((uint32_t) 0x1e018c)

#define TX_PAT_GEN_PRBS_SEED_LO_P14 ((uint16_t) 0x18e)
#define TX_PAT_GEN_PRBS_SEED_LO_P14__SEED ((uint32_t) 0x1e018e)

#define TX_PAT_GEN_PRBS_SEED_LO_P15 ((uint16_t) 0x190)
#define TX_PAT_GEN_PRBS_SEED_LO_P15__SEED ((uint32_t) 0x1e0190)

#define TX_PAT_GEN_PRBS_SEED_LO_P16 ((uint16_t) 0x192)
#define TX_PAT_GEN_PRBS_SEED_LO_P16__SEED ((uint32_t) 0x1e0192)

#define TX_PAT_GEN_PRBS_SEED_LO_P17 ((uint16_t) 0x194)
#define TX_PAT_GEN_PRBS_SEED_LO_P17__SEED ((uint32_t) 0x1e0194)

#define TX_PAT_GEN_PRBS_SEED_HI_P0 ((uint16_t) 0x196)
#define TX_PAT_GEN_PRBS_SEED_HI_P0__SEED ((uint32_t) 0x1e0196)

#define TX_PAT_GEN_PRBS_SEED_HI_P1 ((uint16_t) 0x198)
#define TX_PAT_GEN_PRBS_SEED_HI_P1__SEED ((uint32_t) 0x1e0198)

#define TX_PAT_GEN_PRBS_SEED_HI_P2 ((uint16_t) 0x19a)
#define TX_PAT_GEN_PRBS_SEED_HI_P2__SEED ((uint32_t) 0x1e019a)

#define TX_PAT_GEN_PRBS_SEED_HI_P3 ((uint16_t) 0x19c)
#define TX_PAT_GEN_PRBS_SEED_HI_P3__SEED ((uint32_t) 0x1e019c)

#define TX_PAT_GEN_PRBS_SEED_HI_P4 ((uint16_t) 0x19e)
#define TX_PAT_GEN_PRBS_SEED_HI_P4__SEED ((uint32_t) 0x1e019e)

#define TX_PAT_GEN_PRBS_SEED_HI_P5 ((uint16_t) 0x1a0)
#define TX_PAT_GEN_PRBS_SEED_HI_P5__SEED ((uint32_t) 0x1e01a0)

#define TX_PAT_GEN_PRBS_SEED_HI_P6 ((uint16_t) 0x1a2)
#define TX_PAT_GEN_PRBS_SEED_HI_P6__SEED ((uint32_t) 0x1e01a2)

#define TX_PAT_GEN_PRBS_SEED_HI_P7 ((uint16_t) 0x1a4)
#define TX_PAT_GEN_PRBS_SEED_HI_P7__SEED ((uint32_t) 0x1e01a4)

#define TX_PAT_GEN_PRBS_SEED_HI_P8 ((uint16_t) 0x1a6)
#define TX_PAT_GEN_PRBS_SEED_HI_P8__SEED ((uint32_t) 0x1e01a6)

#define TX_PAT_GEN_PRBS_SEED_HI_P9 ((uint16_t) 0x1a8)
#define TX_PAT_GEN_PRBS_SEED_HI_P9__SEED ((uint32_t) 0x1e01a8)

#define TX_PAT_GEN_PRBS_SEED_HI_P10 ((uint16_t) 0x1aa)
#define TX_PAT_GEN_PRBS_SEED_HI_P10__SEED ((uint32_t) 0x1e01aa)

#define TX_PAT_GEN_PRBS_SEED_HI_P11 ((uint16_t) 0x1ac)
#define TX_PAT_GEN_PRBS_SEED_HI_P11__SEED ((uint32_t) 0x1e01ac)

#define TX_PAT_GEN_PRBS_SEED_HI_P12 ((uint16_t) 0x1ae)
#define TX_PAT_GEN_PRBS_SEED_HI_P12__SEED ((uint32_t) 0x1e01ae)

#define TX_PAT_GEN_PRBS_SEED_HI_P13 ((uint16_t) 0x1b0)
#define TX_PAT_GEN_PRBS_SEED_HI_P13__SEED ((uint32_t) 0x1e01b0)

#define TX_PAT_GEN_PRBS_SEED_HI_P14 ((uint16_t) 0x1b2)
#define TX_PAT_GEN_PRBS_SEED_HI_P14__SEED ((uint32_t) 0x1e01b2)

#define TX_PAT_GEN_PRBS_SEED_HI_P15 ((uint16_t) 0x1b4)
#define TX_PAT_GEN_PRBS_SEED_HI_P15__SEED ((uint32_t) 0x1e01b4)

#define TX_PAT_GEN_PRBS_SEED_HI_P16 ((uint16_t) 0x1b6)
#define TX_PAT_GEN_PRBS_SEED_HI_P16__SEED ((uint32_t) 0x1e01b6)

#define TX_PAT_GEN_PRBS_SEED_HI_P17 ((uint16_t) 0x1b8)
#define TX_PAT_GEN_PRBS_SEED_HI_P17__SEED ((uint32_t) 0x1e01b8)

#define TX_PAT_GEN_PRBS_STATE_LO_P0 ((uint16_t) 0x1ba)
#define TX_PAT_GEN_PRBS_STATE_LO_P0__STATE ((uint32_t) 0x7e01ba)

#define TX_PAT_GEN_PRBS_STATE_LO_P1 ((uint16_t) 0x1bc)
#define TX_PAT_GEN_PRBS_STATE_LO_P1__STATE ((uint32_t) 0x7e01bc)

#define TX_PAT_GEN_PRBS_STATE_LO_P2 ((uint16_t) 0x1be)
#define TX_PAT_GEN_PRBS_STATE_LO_P2__STATE ((uint32_t) 0x7e01be)

#define TX_PAT_GEN_PRBS_STATE_LO_P3 ((uint16_t) 0x1c0)
#define TX_PAT_GEN_PRBS_STATE_LO_P3__STATE ((uint32_t) 0x7e01c0)

#define TX_PAT_GEN_PRBS_STATE_LO_P4 ((uint16_t) 0x1c2)
#define TX_PAT_GEN_PRBS_STATE_LO_P4__STATE ((uint32_t) 0x7e01c2)

#define TX_PAT_GEN_PRBS_STATE_LO_P5 ((uint16_t) 0x1c4)
#define TX_PAT_GEN_PRBS_STATE_LO_P5__STATE ((uint32_t) 0x7e01c4)

#define TX_PAT_GEN_PRBS_STATE_LO_P6 ((uint16_t) 0x1c6)
#define TX_PAT_GEN_PRBS_STATE_LO_P6__STATE ((uint32_t) 0x7e01c6)

#define TX_PAT_GEN_PRBS_STATE_LO_P7 ((uint16_t) 0x1c8)
#define TX_PAT_GEN_PRBS_STATE_LO_P7__STATE ((uint32_t) 0x7e01c8)

#define TX_PAT_GEN_PRBS_STATE_LO_P8 ((uint16_t) 0x1ca)
#define TX_PAT_GEN_PRBS_STATE_LO_P8__STATE ((uint32_t) 0x7e01ca)

#define TX_PAT_GEN_PRBS_STATE_LO_P9 ((uint16_t) 0x1cc)
#define TX_PAT_GEN_PRBS_STATE_LO_P9__STATE ((uint32_t) 0x7e01cc)

#define TX_PAT_GEN_PRBS_STATE_LO_P10 ((uint16_t) 0x1ce)
#define TX_PAT_GEN_PRBS_STATE_LO_P10__STATE ((uint32_t) 0x7e01ce)

#define TX_PAT_GEN_PRBS_STATE_LO_P11 ((uint16_t) 0x1d0)
#define TX_PAT_GEN_PRBS_STATE_LO_P11__STATE ((uint32_t) 0x7e01d0)

#define TX_PAT_GEN_PRBS_STATE_LO_P12 ((uint16_t) 0x1d2)
#define TX_PAT_GEN_PRBS_STATE_LO_P12__STATE ((uint32_t) 0x7e01d2)

#define TX_PAT_GEN_PRBS_STATE_LO_P13 ((uint16_t) 0x1d4)
#define TX_PAT_GEN_PRBS_STATE_LO_P13__STATE ((uint32_t) 0x7e01d4)

#define TX_PAT_GEN_PRBS_STATE_LO_P14 ((uint16_t) 0x1d6)
#define TX_PAT_GEN_PRBS_STATE_LO_P14__STATE ((uint32_t) 0x7e01d6)

#define TX_PAT_GEN_PRBS_STATE_LO_P15 ((uint16_t) 0x1d8)
#define TX_PAT_GEN_PRBS_STATE_LO_P15__STATE ((uint32_t) 0x7e01d8)

#define TX_PAT_GEN_PRBS_STATE_LO_P16 ((uint16_t) 0x1da)
#define TX_PAT_GEN_PRBS_STATE_LO_P16__STATE ((uint32_t) 0x7e01da)

#define TX_PAT_GEN_PRBS_STATE_LO_P17 ((uint16_t) 0x1dc)
#define TX_PAT_GEN_PRBS_STATE_LO_P17__STATE ((uint32_t) 0x7e01dc)

#define TX_PAT_GEN_PRBS_STATE_HI_P0 ((uint16_t) 0x1de)
#define TX_PAT_GEN_PRBS_STATE_HI_P0__STATE ((uint32_t) 0x7e01de)

#define TX_PAT_GEN_PRBS_STATE_HI_P1 ((uint16_t) 0x1e0)
#define TX_PAT_GEN_PRBS_STATE_HI_P1__STATE ((uint32_t) 0x7e01e0)

#define TX_PAT_GEN_PRBS_STATE_HI_P2 ((uint16_t) 0x1e2)
#define TX_PAT_GEN_PRBS_STATE_HI_P2__STATE ((uint32_t) 0x7e01e2)

#define TX_PAT_GEN_PRBS_STATE_HI_P3 ((uint16_t) 0x1e4)
#define TX_PAT_GEN_PRBS_STATE_HI_P3__STATE ((uint32_t) 0x7e01e4)

#define TX_PAT_GEN_PRBS_STATE_HI_P4 ((uint16_t) 0x1e6)
#define TX_PAT_GEN_PRBS_STATE_HI_P4__STATE ((uint32_t) 0x7e01e6)

#define TX_PAT_GEN_PRBS_STATE_HI_P5 ((uint16_t) 0x1e8)
#define TX_PAT_GEN_PRBS_STATE_HI_P5__STATE ((uint32_t) 0x7e01e8)

#define TX_PAT_GEN_PRBS_STATE_HI_P6 ((uint16_t) 0x1ea)
#define TX_PAT_GEN_PRBS_STATE_HI_P6__STATE ((uint32_t) 0x7e01ea)

#define TX_PAT_GEN_PRBS_STATE_HI_P7 ((uint16_t) 0x1ec)
#define TX_PAT_GEN_PRBS_STATE_HI_P7__STATE ((uint32_t) 0x7e01ec)

#define TX_PAT_GEN_PRBS_STATE_HI_P8 ((uint16_t) 0x1ee)
#define TX_PAT_GEN_PRBS_STATE_HI_P8__STATE ((uint32_t) 0x7e01ee)

#define TX_PAT_GEN_PRBS_STATE_HI_P9 ((uint16_t) 0x1f0)
#define TX_PAT_GEN_PRBS_STATE_HI_P9__STATE ((uint32_t) 0x7e01f0)

#define TX_PAT_GEN_PRBS_STATE_HI_P10 ((uint16_t) 0x1f2)
#define TX_PAT_GEN_PRBS_STATE_HI_P10__STATE ((uint32_t) 0x7e01f2)

#define TX_PAT_GEN_PRBS_STATE_HI_P11 ((uint16_t) 0x1f4)
#define TX_PAT_GEN_PRBS_STATE_HI_P11__STATE ((uint32_t) 0x7e01f4)

#define TX_PAT_GEN_PRBS_STATE_HI_P12 ((uint16_t) 0x1f6)
#define TX_PAT_GEN_PRBS_STATE_HI_P12__STATE ((uint32_t) 0x7e01f6)

#define TX_PAT_GEN_PRBS_STATE_HI_P13 ((uint16_t) 0x1f8)
#define TX_PAT_GEN_PRBS_STATE_HI_P13__STATE ((uint32_t) 0x7e01f8)

#define TX_PAT_GEN_PRBS_STATE_HI_P14 ((uint16_t) 0x1fa)
#define TX_PAT_GEN_PRBS_STATE_HI_P14__STATE ((uint32_t) 0x7e01fa)

#define TX_PAT_GEN_PRBS_STATE_HI_P15 ((uint16_t) 0x1fc)
#define TX_PAT_GEN_PRBS_STATE_HI_P15__STATE ((uint32_t) 0x7e01fc)

#define TX_PAT_GEN_PRBS_STATE_HI_P16 ((uint16_t) 0x1fe)
#define TX_PAT_GEN_PRBS_STATE_HI_P16__STATE ((uint32_t) 0x7e01fe)

#define TX_PAT_GEN_PRBS_STATE_HI_P17 ((uint16_t) 0x200)
#define TX_PAT_GEN_PRBS_STATE_HI_P17__STATE ((uint32_t) 0x7e0200)

#define TX_PAT_GEN_MEM_CTRL_M0 ((uint16_t) 0x202)
#define TX_PAT_GEN_MEM_CTRL_M0__MEM_EN ((uint32_t) 0x202)

#define TX_PAT_GEN_MEM_CTRL_M1 ((uint16_t) 0x204)
#define TX_PAT_GEN_MEM_CTRL_M1__MEM_EN ((uint32_t) 0x204)

#define TX_PAT_GEN_MEM_CTRL_M2 ((uint16_t) 0x206)
#define TX_PAT_GEN_MEM_CTRL_M2__MEM_EN ((uint32_t) 0x206)

#define TX_PAT_GEN_MEM_CTRL_M3 ((uint16_t) 0x208)
#define TX_PAT_GEN_MEM_CTRL_M3__MEM_EN ((uint32_t) 0x208)

#define TX_PAT_GEN_MEM_CTRL_M4 ((uint16_t) 0x20a)
#define TX_PAT_GEN_MEM_CTRL_M4__MEM_EN ((uint32_t) 0x20a)

#define TX_PAT_GEN_MEM_CTRL_M5 ((uint16_t) 0x20c)
#define TX_PAT_GEN_MEM_CTRL_M5__MEM_EN ((uint32_t) 0x20c)

#define TX_PAT_GEN_MEM_CTRL_M6 ((uint16_t) 0x20e)
#define TX_PAT_GEN_MEM_CTRL_M6__MEM_EN ((uint32_t) 0x20e)

#define TX_PAT_GEN_MEM_CTRL_M7 ((uint16_t) 0x210)
#define TX_PAT_GEN_MEM_CTRL_M7__MEM_EN ((uint32_t) 0x210)

#define TX_PAT_GEN_MEM_CTRL_M8 ((uint16_t) 0x212)
#define TX_PAT_GEN_MEM_CTRL_M8__MEM_EN ((uint32_t) 0x212)

#define TX_PAT_GEN_MEM_CTRL_M9 ((uint16_t) 0x214)
#define TX_PAT_GEN_MEM_CTRL_M9__MEM_EN ((uint32_t) 0x214)

#define TX_PAT_GEN_MEM_CTRL_M10 ((uint16_t) 0x216)
#define TX_PAT_GEN_MEM_CTRL_M10__MEM_EN ((uint32_t) 0x216)

#define TX_PAT_GEN_MEM_CTRL_M11 ((uint16_t) 0x218)
#define TX_PAT_GEN_MEM_CTRL_M11__MEM_EN ((uint32_t) 0x218)

#define TX_PAT_GEN_MEM_CTRL_M12 ((uint16_t) 0x21a)
#define TX_PAT_GEN_MEM_CTRL_M12__MEM_EN ((uint32_t) 0x21a)

#define TX_PAT_GEN_MEM_CTRL_M13 ((uint16_t) 0x21c)
#define TX_PAT_GEN_MEM_CTRL_M13__MEM_EN ((uint32_t) 0x21c)

#define TX_PAT_GEN_MEM_CTRL_M14 ((uint16_t) 0x21e)
#define TX_PAT_GEN_MEM_CTRL_M14__MEM_EN ((uint32_t) 0x21e)

#define TX_PAT_GEN_MEM_CTRL_M15 ((uint16_t) 0x220)
#define TX_PAT_GEN_MEM_CTRL_M15__MEM_EN ((uint32_t) 0x220)

#define TX_PAT_GEN_MEM_CTRL_M16 ((uint16_t) 0x222)
#define TX_PAT_GEN_MEM_CTRL_M16__MEM_EN ((uint32_t) 0x222)

#define TX_PAT_GEN_MEM_CTRL_M17 ((uint16_t) 0x224)
#define TX_PAT_GEN_MEM_CTRL_M17__MEM_EN ((uint32_t) 0x224)

#define TX_PAT_GEN_MEM_ARRAY_M0M0 ((uint16_t) 0x226)
#define TX_PAT_GEN_MEM_ARRAY_M0M0__DATA ((uint32_t) 0x1e0226)

#define TX_PAT_GEN_MEM_ARRAY_M0M1 ((uint16_t) 0x228)
#define TX_PAT_GEN_MEM_ARRAY_M0M1__DATA ((uint32_t) 0x1e0228)

#define TX_PAT_GEN_MEM_ARRAY_M0M2 ((uint16_t) 0x22a)
#define TX_PAT_GEN_MEM_ARRAY_M0M2__DATA ((uint32_t) 0x1e022a)

#define TX_PAT_GEN_MEM_ARRAY_M0M3 ((uint16_t) 0x22c)
#define TX_PAT_GEN_MEM_ARRAY_M0M3__DATA ((uint32_t) 0x1e022c)

#define TX_PAT_GEN_MEM_ARRAY_M1M0 ((uint16_t) 0x22e)
#define TX_PAT_GEN_MEM_ARRAY_M1M0__DATA ((uint32_t) 0x1e022e)

#define TX_PAT_GEN_MEM_ARRAY_M1M1 ((uint16_t) 0x230)
#define TX_PAT_GEN_MEM_ARRAY_M1M1__DATA ((uint32_t) 0x1e0230)

#define TX_PAT_GEN_MEM_ARRAY_M1M2 ((uint16_t) 0x232)
#define TX_PAT_GEN_MEM_ARRAY_M1M2__DATA ((uint32_t) 0x1e0232)

#define TX_PAT_GEN_MEM_ARRAY_M1M3 ((uint16_t) 0x234)
#define TX_PAT_GEN_MEM_ARRAY_M1M3__DATA ((uint32_t) 0x1e0234)

#define TX_PAT_GEN_MEM_ARRAY_M2M0 ((uint16_t) 0x236)
#define TX_PAT_GEN_MEM_ARRAY_M2M0__DATA ((uint32_t) 0x1e0236)

#define TX_PAT_GEN_MEM_ARRAY_M2M1 ((uint16_t) 0x238)
#define TX_PAT_GEN_MEM_ARRAY_M2M1__DATA ((uint32_t) 0x1e0238)

#define TX_PAT_GEN_MEM_ARRAY_M2M2 ((uint16_t) 0x23a)
#define TX_PAT_GEN_MEM_ARRAY_M2M2__DATA ((uint32_t) 0x1e023a)

#define TX_PAT_GEN_MEM_ARRAY_M2M3 ((uint16_t) 0x23c)
#define TX_PAT_GEN_MEM_ARRAY_M2M3__DATA ((uint32_t) 0x1e023c)

#define TX_PAT_GEN_MEM_ARRAY_M3M0 ((uint16_t) 0x23e)
#define TX_PAT_GEN_MEM_ARRAY_M3M0__DATA ((uint32_t) 0x1e023e)

#define TX_PAT_GEN_MEM_ARRAY_M3M1 ((uint16_t) 0x240)
#define TX_PAT_GEN_MEM_ARRAY_M3M1__DATA ((uint32_t) 0x1e0240)

#define TX_PAT_GEN_MEM_ARRAY_M3M2 ((uint16_t) 0x242)
#define TX_PAT_GEN_MEM_ARRAY_M3M2__DATA ((uint32_t) 0x1e0242)

#define TX_PAT_GEN_MEM_ARRAY_M3M3 ((uint16_t) 0x244)
#define TX_PAT_GEN_MEM_ARRAY_M3M3__DATA ((uint32_t) 0x1e0244)

#define TX_PAT_GEN_MEM_ARRAY_M4M0 ((uint16_t) 0x246)
#define TX_PAT_GEN_MEM_ARRAY_M4M0__DATA ((uint32_t) 0x1e0246)

#define TX_PAT_GEN_MEM_ARRAY_M4M1 ((uint16_t) 0x248)
#define TX_PAT_GEN_MEM_ARRAY_M4M1__DATA ((uint32_t) 0x1e0248)

#define TX_PAT_GEN_MEM_ARRAY_M4M2 ((uint16_t) 0x24a)
#define TX_PAT_GEN_MEM_ARRAY_M4M2__DATA ((uint32_t) 0x1e024a)

#define TX_PAT_GEN_MEM_ARRAY_M4M3 ((uint16_t) 0x24c)
#define TX_PAT_GEN_MEM_ARRAY_M4M3__DATA ((uint32_t) 0x1e024c)

#define TX_PAT_GEN_MEM_ARRAY_M5M0 ((uint16_t) 0x24e)
#define TX_PAT_GEN_MEM_ARRAY_M5M0__DATA ((uint32_t) 0x1e024e)

#define TX_PAT_GEN_MEM_ARRAY_M5M1 ((uint16_t) 0x250)
#define TX_PAT_GEN_MEM_ARRAY_M5M1__DATA ((uint32_t) 0x1e0250)

#define TX_PAT_GEN_MEM_ARRAY_M5M2 ((uint16_t) 0x252)
#define TX_PAT_GEN_MEM_ARRAY_M5M2__DATA ((uint32_t) 0x1e0252)

#define TX_PAT_GEN_MEM_ARRAY_M5M3 ((uint16_t) 0x254)
#define TX_PAT_GEN_MEM_ARRAY_M5M3__DATA ((uint32_t) 0x1e0254)

#define TX_PAT_GEN_MEM_ARRAY_M6M0 ((uint16_t) 0x256)
#define TX_PAT_GEN_MEM_ARRAY_M6M0__DATA ((uint32_t) 0x1e0256)

#define TX_PAT_GEN_MEM_ARRAY_M6M1 ((uint16_t) 0x258)
#define TX_PAT_GEN_MEM_ARRAY_M6M1__DATA ((uint32_t) 0x1e0258)

#define TX_PAT_GEN_MEM_ARRAY_M6M2 ((uint16_t) 0x25a)
#define TX_PAT_GEN_MEM_ARRAY_M6M2__DATA ((uint32_t) 0x1e025a)

#define TX_PAT_GEN_MEM_ARRAY_M6M3 ((uint16_t) 0x25c)
#define TX_PAT_GEN_MEM_ARRAY_M6M3__DATA ((uint32_t) 0x1e025c)

#define TX_PAT_GEN_MEM_ARRAY_M7M0 ((uint16_t) 0x25e)
#define TX_PAT_GEN_MEM_ARRAY_M7M0__DATA ((uint32_t) 0x1e025e)

#define TX_PAT_GEN_MEM_ARRAY_M7M1 ((uint16_t) 0x260)
#define TX_PAT_GEN_MEM_ARRAY_M7M1__DATA ((uint32_t) 0x1e0260)

#define TX_PAT_GEN_MEM_ARRAY_M7M2 ((uint16_t) 0x262)
#define TX_PAT_GEN_MEM_ARRAY_M7M2__DATA ((uint32_t) 0x1e0262)

#define TX_PAT_GEN_MEM_ARRAY_M7M3 ((uint16_t) 0x264)
#define TX_PAT_GEN_MEM_ARRAY_M7M3__DATA ((uint32_t) 0x1e0264)

#define TX_PAT_GEN_MEM_ARRAY_M8M0 ((uint16_t) 0x266)
#define TX_PAT_GEN_MEM_ARRAY_M8M0__DATA ((uint32_t) 0x1e0266)

#define TX_PAT_GEN_MEM_ARRAY_M8M1 ((uint16_t) 0x268)
#define TX_PAT_GEN_MEM_ARRAY_M8M1__DATA ((uint32_t) 0x1e0268)

#define TX_PAT_GEN_MEM_ARRAY_M8M2 ((uint16_t) 0x26a)
#define TX_PAT_GEN_MEM_ARRAY_M8M2__DATA ((uint32_t) 0x1e026a)

#define TX_PAT_GEN_MEM_ARRAY_M8M3 ((uint16_t) 0x26c)
#define TX_PAT_GEN_MEM_ARRAY_M8M3__DATA ((uint32_t) 0x1e026c)

#define TX_PAT_GEN_MEM_ARRAY_M9M0 ((uint16_t) 0x26e)
#define TX_PAT_GEN_MEM_ARRAY_M9M0__DATA ((uint32_t) 0x1e026e)

#define TX_PAT_GEN_MEM_ARRAY_M9M1 ((uint16_t) 0x270)
#define TX_PAT_GEN_MEM_ARRAY_M9M1__DATA ((uint32_t) 0x1e0270)

#define TX_PAT_GEN_MEM_ARRAY_M9M2 ((uint16_t) 0x272)
#define TX_PAT_GEN_MEM_ARRAY_M9M2__DATA ((uint32_t) 0x1e0272)

#define TX_PAT_GEN_MEM_ARRAY_M9M3 ((uint16_t) 0x274)
#define TX_PAT_GEN_MEM_ARRAY_M9M3__DATA ((uint32_t) 0x1e0274)

#define TX_PAT_GEN_MEM_ARRAY_M10M0 ((uint16_t) 0x276)
#define TX_PAT_GEN_MEM_ARRAY_M10M0__DATA ((uint32_t) 0x1e0276)

#define TX_PAT_GEN_MEM_ARRAY_M10M1 ((uint16_t) 0x278)
#define TX_PAT_GEN_MEM_ARRAY_M10M1__DATA ((uint32_t) 0x1e0278)

#define TX_PAT_GEN_MEM_ARRAY_M10M2 ((uint16_t) 0x27a)
#define TX_PAT_GEN_MEM_ARRAY_M10M2__DATA ((uint32_t) 0x1e027a)

#define TX_PAT_GEN_MEM_ARRAY_M10M3 ((uint16_t) 0x27c)
#define TX_PAT_GEN_MEM_ARRAY_M10M3__DATA ((uint32_t) 0x1e027c)

#define TX_PAT_GEN_MEM_ARRAY_M11M0 ((uint16_t) 0x27e)
#define TX_PAT_GEN_MEM_ARRAY_M11M0__DATA ((uint32_t) 0x1e027e)

#define TX_PAT_GEN_MEM_ARRAY_M11M1 ((uint16_t) 0x280)
#define TX_PAT_GEN_MEM_ARRAY_M11M1__DATA ((uint32_t) 0x1e0280)

#define TX_PAT_GEN_MEM_ARRAY_M11M2 ((uint16_t) 0x282)
#define TX_PAT_GEN_MEM_ARRAY_M11M2__DATA ((uint32_t) 0x1e0282)

#define TX_PAT_GEN_MEM_ARRAY_M11M3 ((uint16_t) 0x284)
#define TX_PAT_GEN_MEM_ARRAY_M11M3__DATA ((uint32_t) 0x1e0284)

#define TX_PAT_GEN_MEM_ARRAY_M12M0 ((uint16_t) 0x286)
#define TX_PAT_GEN_MEM_ARRAY_M12M0__DATA ((uint32_t) 0x1e0286)

#define TX_PAT_GEN_MEM_ARRAY_M12M1 ((uint16_t) 0x288)
#define TX_PAT_GEN_MEM_ARRAY_M12M1__DATA ((uint32_t) 0x1e0288)

#define TX_PAT_GEN_MEM_ARRAY_M12M2 ((uint16_t) 0x28a)
#define TX_PAT_GEN_MEM_ARRAY_M12M2__DATA ((uint32_t) 0x1e028a)

#define TX_PAT_GEN_MEM_ARRAY_M12M3 ((uint16_t) 0x28c)
#define TX_PAT_GEN_MEM_ARRAY_M12M3__DATA ((uint32_t) 0x1e028c)

#define TX_PAT_GEN_MEM_ARRAY_M13M0 ((uint16_t) 0x28e)
#define TX_PAT_GEN_MEM_ARRAY_M13M0__DATA ((uint32_t) 0x1e028e)

#define TX_PAT_GEN_MEM_ARRAY_M13M1 ((uint16_t) 0x290)
#define TX_PAT_GEN_MEM_ARRAY_M13M1__DATA ((uint32_t) 0x1e0290)

#define TX_PAT_GEN_MEM_ARRAY_M13M2 ((uint16_t) 0x292)
#define TX_PAT_GEN_MEM_ARRAY_M13M2__DATA ((uint32_t) 0x1e0292)

#define TX_PAT_GEN_MEM_ARRAY_M13M3 ((uint16_t) 0x294)
#define TX_PAT_GEN_MEM_ARRAY_M13M3__DATA ((uint32_t) 0x1e0294)

#define TX_PAT_GEN_MEM_ARRAY_M14M0 ((uint16_t) 0x296)
#define TX_PAT_GEN_MEM_ARRAY_M14M0__DATA ((uint32_t) 0x1e0296)

#define TX_PAT_GEN_MEM_ARRAY_M14M1 ((uint16_t) 0x298)
#define TX_PAT_GEN_MEM_ARRAY_M14M1__DATA ((uint32_t) 0x1e0298)

#define TX_PAT_GEN_MEM_ARRAY_M14M2 ((uint16_t) 0x29a)
#define TX_PAT_GEN_MEM_ARRAY_M14M2__DATA ((uint32_t) 0x1e029a)

#define TX_PAT_GEN_MEM_ARRAY_M14M3 ((uint16_t) 0x29c)
#define TX_PAT_GEN_MEM_ARRAY_M14M3__DATA ((uint32_t) 0x1e029c)

#define TX_PAT_GEN_MEM_ARRAY_M15M0 ((uint16_t) 0x29e)
#define TX_PAT_GEN_MEM_ARRAY_M15M0__DATA ((uint32_t) 0x1e029e)

#define TX_PAT_GEN_MEM_ARRAY_M15M1 ((uint16_t) 0x2a0)
#define TX_PAT_GEN_MEM_ARRAY_M15M1__DATA ((uint32_t) 0x1e02a0)

#define TX_PAT_GEN_MEM_ARRAY_M15M2 ((uint16_t) 0x2a2)
#define TX_PAT_GEN_MEM_ARRAY_M15M2__DATA ((uint32_t) 0x1e02a2)

#define TX_PAT_GEN_MEM_ARRAY_M15M3 ((uint16_t) 0x2a4)
#define TX_PAT_GEN_MEM_ARRAY_M15M3__DATA ((uint32_t) 0x1e02a4)

#define TX_PAT_GEN_MEM_ARRAY_M16M0 ((uint16_t) 0x2a6)
#define TX_PAT_GEN_MEM_ARRAY_M16M0__DATA ((uint32_t) 0x1e02a6)

#define TX_PAT_GEN_MEM_ARRAY_M16M1 ((uint16_t) 0x2a8)
#define TX_PAT_GEN_MEM_ARRAY_M16M1__DATA ((uint32_t) 0x1e02a8)

#define TX_PAT_GEN_MEM_ARRAY_M16M2 ((uint16_t) 0x2aa)
#define TX_PAT_GEN_MEM_ARRAY_M16M2__DATA ((uint32_t) 0x1e02aa)

#define TX_PAT_GEN_MEM_ARRAY_M16M3 ((uint16_t) 0x2ac)
#define TX_PAT_GEN_MEM_ARRAY_M16M3__DATA ((uint32_t) 0x1e02ac)

#define TX_PAT_GEN_MEM_ARRAY_M17M0 ((uint16_t) 0x2ae)
#define TX_PAT_GEN_MEM_ARRAY_M17M0__DATA ((uint32_t) 0x1e02ae)

#define TX_PAT_GEN_MEM_ARRAY_M17M1 ((uint16_t) 0x2b0)
#define TX_PAT_GEN_MEM_ARRAY_M17M1__DATA ((uint32_t) 0x1e02b0)

#define TX_PAT_GEN_MEM_ARRAY_M17M2 ((uint16_t) 0x2b2)
#define TX_PAT_GEN_MEM_ARRAY_M17M2__DATA ((uint32_t) 0x1e02b2)

#define TX_PAT_GEN_MEM_ARRAY_M17M3 ((uint16_t) 0x2b4)
#define TX_PAT_GEN_MEM_ARRAY_M17M3__DATA ((uint32_t) 0x1e02b4)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M0 ((uint16_t) 0x2b6)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M0__BUFFER_END ((uint32_t) 0xa02b6)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M1 ((uint16_t) 0x2b8)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M1__BUFFER_END ((uint32_t) 0xa02b8)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M2 ((uint16_t) 0x2ba)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M2__BUFFER_END ((uint32_t) 0xa02ba)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M3 ((uint16_t) 0x2bc)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M3__BUFFER_END ((uint32_t) 0xa02bc)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M4 ((uint16_t) 0x2be)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M4__BUFFER_END ((uint32_t) 0xa02be)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M5 ((uint16_t) 0x2c0)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M5__BUFFER_END ((uint32_t) 0xa02c0)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M6 ((uint16_t) 0x2c2)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M6__BUFFER_END ((uint32_t) 0xa02c2)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M7 ((uint16_t) 0x2c4)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M7__BUFFER_END ((uint32_t) 0xa02c4)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M8 ((uint16_t) 0x2c6)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M8__BUFFER_END ((uint32_t) 0xa02c6)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M9 ((uint16_t) 0x2c8)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M9__BUFFER_END ((uint32_t) 0xa02c8)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M10 ((uint16_t) 0x2ca)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M10__BUFFER_END ((uint32_t) 0xa02ca)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M11 ((uint16_t) 0x2cc)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M11__BUFFER_END ((uint32_t) 0xa02cc)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M12 ((uint16_t) 0x2ce)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M12__BUFFER_END ((uint32_t) 0xa02ce)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M13 ((uint16_t) 0x2d0)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M13__BUFFER_END ((uint32_t) 0xa02d0)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M14 ((uint16_t) 0x2d2)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M14__BUFFER_END ((uint32_t) 0xa02d2)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M15 ((uint16_t) 0x2d4)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M15__BUFFER_END ((uint32_t) 0xa02d4)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M16 ((uint16_t) 0x2d6)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M16__BUFFER_END ((uint32_t) 0xa02d6)

#define TX_PAT_GEN_MEM_CNTR_CTRL_M17 ((uint16_t) 0x2d8)
#define TX_PAT_GEN_MEM_CNTR_CTRL_M17__BUFFER_END ((uint32_t) 0xa02d8)

#define TX_PAT_GEN_MEM_CNTR_M0 ((uint16_t) 0x2da)
#define TX_PAT_GEN_MEM_CNTR_M0__ADDR_CNTR ((uint32_t) 0x6c02da)

#define TX_PAT_GEN_MEM_CNTR_M1 ((uint16_t) 0x2dc)
#define TX_PAT_GEN_MEM_CNTR_M1__ADDR_CNTR ((uint32_t) 0x6c02dc)

#define TX_PAT_GEN_MEM_CNTR_M2 ((uint16_t) 0x2de)
#define TX_PAT_GEN_MEM_CNTR_M2__ADDR_CNTR ((uint32_t) 0x6c02de)

#define TX_PAT_GEN_MEM_CNTR_M3 ((uint16_t) 0x2e0)
#define TX_PAT_GEN_MEM_CNTR_M3__ADDR_CNTR ((uint32_t) 0x6c02e0)

#define TX_PAT_GEN_MEM_CNTR_M4 ((uint16_t) 0x2e2)
#define TX_PAT_GEN_MEM_CNTR_M4__ADDR_CNTR ((uint32_t) 0x6c02e2)

#define TX_PAT_GEN_MEM_CNTR_M5 ((uint16_t) 0x2e4)
#define TX_PAT_GEN_MEM_CNTR_M5__ADDR_CNTR ((uint32_t) 0x6c02e4)

#define TX_PAT_GEN_MEM_CNTR_M6 ((uint16_t) 0x2e6)
#define TX_PAT_GEN_MEM_CNTR_M6__ADDR_CNTR ((uint32_t) 0x6c02e6)

#define TX_PAT_GEN_MEM_CNTR_M7 ((uint16_t) 0x2e8)
#define TX_PAT_GEN_MEM_CNTR_M7__ADDR_CNTR ((uint32_t) 0x6c02e8)

#define TX_PAT_GEN_MEM_CNTR_M8 ((uint16_t) 0x2ea)
#define TX_PAT_GEN_MEM_CNTR_M8__ADDR_CNTR ((uint32_t) 0x6c02ea)

#define TX_PAT_GEN_MEM_CNTR_M9 ((uint16_t) 0x2ec)
#define TX_PAT_GEN_MEM_CNTR_M9__ADDR_CNTR ((uint32_t) 0x6c02ec)

#define TX_PAT_GEN_MEM_CNTR_M10 ((uint16_t) 0x2ee)
#define TX_PAT_GEN_MEM_CNTR_M10__ADDR_CNTR ((uint32_t) 0x6c02ee)

#define TX_PAT_GEN_MEM_CNTR_M11 ((uint16_t) 0x2f0)
#define TX_PAT_GEN_MEM_CNTR_M11__ADDR_CNTR ((uint32_t) 0x6c02f0)

#define TX_PAT_GEN_MEM_CNTR_M12 ((uint16_t) 0x2f2)
#define TX_PAT_GEN_MEM_CNTR_M12__ADDR_CNTR ((uint32_t) 0x6c02f2)

#define TX_PAT_GEN_MEM_CNTR_M13 ((uint16_t) 0x2f4)
#define TX_PAT_GEN_MEM_CNTR_M13__ADDR_CNTR ((uint32_t) 0x6c02f4)

#define TX_PAT_GEN_MEM_CNTR_M14 ((uint16_t) 0x2f6)
#define TX_PAT_GEN_MEM_CNTR_M14__ADDR_CNTR ((uint32_t) 0x6c02f6)

#define TX_PAT_GEN_MEM_CNTR_M15 ((uint16_t) 0x2f8)
#define TX_PAT_GEN_MEM_CNTR_M15__ADDR_CNTR ((uint32_t) 0x6c02f8)

#define TX_PAT_GEN_MEM_CNTR_M16 ((uint16_t) 0x2fa)
#define TX_PAT_GEN_MEM_CNTR_M16__ADDR_CNTR ((uint32_t) 0x6c02fa)

#define TX_PAT_GEN_MEM_CNTR_M17 ((uint16_t) 0x2fc)
#define TX_PAT_GEN_MEM_CNTR_M17__ADDR_CNTR ((uint32_t) 0x6c02fc)

#define TX_PAT_GEN_CLK_CTRL_C0 ((uint16_t) 0x2fe)
#define TX_PAT_GEN_CLK_CTRL_C0__CLK_EN ((uint32_t) 0x2fe)

#define TX_PAT_GEN_CLK_CTRL_C1 ((uint16_t) 0x300)
#define TX_PAT_GEN_CLK_CTRL_C1__CLK_EN ((uint32_t) 0x300)

#define TX_PAT_GEN_CLK_ARRAY_C0 ((uint16_t) 0x302)
#define TX_PAT_GEN_CLK_ARRAY_C0__DATA ((uint32_t) 0x1e0302)

#define TX_PAT_GEN_CLK_ARRAY_C1 ((uint16_t) 0x304)
#define TX_PAT_GEN_CLK_ARRAY_C1__DATA ((uint32_t) 0x1e0304)

#define TX_PAT_GEN_CLK_CNTR_CTRL_C0 ((uint16_t) 0x306)
#define TX_PAT_GEN_CLK_CNTR_CTRL_C0__BUFFER_END ((uint32_t) 0x60306)

#define TX_PAT_GEN_CLK_CNTR_CTRL_C1 ((uint16_t) 0x308)
#define TX_PAT_GEN_CLK_CNTR_CTRL_C1__BUFFER_END ((uint32_t) 0x60308)

#define TX_PAT_GEN_CLK_CNTR_C0 ((uint16_t) 0x30a)
#define TX_PAT_GEN_CLK_CNTR_C0__ADDR_CNTR ((uint32_t) 0x68030a)

#define TX_PAT_GEN_CLK_CNTR_C1 ((uint16_t) 0x30c)
#define TX_PAT_GEN_CLK_CNTR_C1__ADDR_CNTR ((uint32_t) 0x68030c)

#define TX_PAT_CHK_MISC_CTRL ((uint16_t) 0x30e)
#define TX_PAT_CHK_MISC_CTRL__SW_RST_N ((uint32_t) 0x30e)
#define TX_PAT_CHK_MISC_CTRL__DESER_RATIO ((uint32_t) 0x2230e)

#define TX_PAT_CHK_CLOCK_GATE ((uint16_t) 0x310)
#define TX_PAT_CHK_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x310)

#define TX_PAT_CHK_PAT_CHK_FREEZE ((uint16_t) 0x312)
#define TX_PAT_CHK_PAT_CHK_FREEZE__FREEZE ((uint32_t) 0x312)

#define TX_PAT_CHK_MEM_CTRL ((uint16_t) 0x314)
#define TX_PAT_CHK_MEM_CTRL__MEM_EN_C0 ((uint32_t) 0x314)
#define TX_PAT_CHK_MEM_CTRL__MEM_EN_C1 ((uint32_t) 0x2314)
#define TX_PAT_CHK_MEM_CTRL__MEM_EN_C2 ((uint32_t) 0x4314)
#define TX_PAT_CHK_MEM_CTRL__MEM_EN_C3 ((uint32_t) 0x6314)
#define TX_PAT_CHK_MEM_CTRL__MEM_CHECK_C0 ((uint32_t) 0x8314)
#define TX_PAT_CHK_MEM_CTRL__MEM_CHECK_C1 ((uint32_t) 0xa314)
#define TX_PAT_CHK_MEM_CTRL__MEM_CHECK_C2 ((uint32_t) 0xc314)
#define TX_PAT_CHK_MEM_CTRL__MEM_CHECK_C3 ((uint32_t) 0xe314)

#define TX_PAT_CHK_MEM_CTRL_PATREAD ((uint16_t) 0x316)
#define TX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C0 ((uint32_t) 0x40316)
#define TX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C1 ((uint32_t) 0x46316)
#define TX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C2 ((uint32_t) 0x4c316)
#define TX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C3 ((uint32_t) 0x52316)

#define TX_PAT_CHK_MEM_CNTR_CTRL_C0 ((uint16_t) 0x318)
#define TX_PAT_CHK_MEM_CNTR_CTRL_C0__BUFFER_END ((uint32_t) 0xc0318)

#define TX_PAT_CHK_MEM_CNTR_CTRL_C1 ((uint16_t) 0x31a)
#define TX_PAT_CHK_MEM_CNTR_CTRL_C1__BUFFER_END ((uint32_t) 0xc031a)

#define TX_PAT_CHK_MEM_CNTR_CTRL_C2 ((uint16_t) 0x31c)
#define TX_PAT_CHK_MEM_CNTR_CTRL_C2__BUFFER_END ((uint32_t) 0xc031c)

#define TX_PAT_CHK_MEM_CNTR_CTRL_C3 ((uint16_t) 0x31e)
#define TX_PAT_CHK_MEM_CNTR_CTRL_C3__BUFFER_END ((uint32_t) 0xc031e)

#define TX_PAT_CHK_MUX_CTRL_C0 ((uint16_t) 0x320)
#define TX_PAT_CHK_MUX_CTRL_C0__MUX ((uint32_t) 0x80320)

#define TX_PAT_CHK_MUX_CTRL_C1 ((uint16_t) 0x322)
#define TX_PAT_CHK_MUX_CTRL_C1__MUX ((uint32_t) 0x80322)

#define TX_PAT_CHK_MUX_CTRL_C2 ((uint16_t) 0x324)
#define TX_PAT_CHK_MUX_CTRL_C2__MUX ((uint32_t) 0x80324)

#define TX_PAT_CHK_MUX_CTRL_C3 ((uint16_t) 0x326)
#define TX_PAT_CHK_MUX_CTRL_C3__MUX ((uint32_t) 0x80326)

#define TX_PAT_CHK_MEM_CNTR_C0 ((uint16_t) 0x328)
#define TX_PAT_CHK_MEM_CNTR_C0__ADDR_CNTR ((uint32_t) 0x6e0328)

#define TX_PAT_CHK_MEM_CNTR_C1 ((uint16_t) 0x32a)
#define TX_PAT_CHK_MEM_CNTR_C1__ADDR_CNTR ((uint32_t) 0x6e032a)

#define TX_PAT_CHK_MEM_CNTR_C2 ((uint16_t) 0x32c)
#define TX_PAT_CHK_MEM_CNTR_C2__ADDR_CNTR ((uint32_t) 0x6e032c)

#define TX_PAT_CHK_MEM_CNTR_C3 ((uint16_t) 0x32e)
#define TX_PAT_CHK_MEM_CNTR_C3__ADDR_CNTR ((uint32_t) 0x6e032e)

#define TX_PAT_CHK_MEM_CTRL_STATES ((uint16_t) 0x330)
#define TX_PAT_CHK_MEM_CTRL_STATES__STATE_C0 ((uint32_t) 0x620330)
#define TX_PAT_CHK_MEM_CTRL_STATES__STATE_C1 ((uint32_t) 0x624330)
#define TX_PAT_CHK_MEM_CTRL_STATES__STATE_C2 ((uint32_t) 0x628330)
#define TX_PAT_CHK_MEM_CTRL_STATES__STATE_C3 ((uint32_t) 0x62c330)

#define TX_PAT_CHK_MEM_PATREAD_C0 ((uint16_t) 0x332)
#define TX_PAT_CHK_MEM_PATREAD_C0__WORD ((uint32_t) 0x7e0332)

#define TX_PAT_CHK_MEM_PATREAD_C1 ((uint16_t) 0x334)
#define TX_PAT_CHK_MEM_PATREAD_C1__WORD ((uint32_t) 0x7e0334)

#define TX_PAT_CHK_MEM_PATREAD_C2 ((uint16_t) 0x336)
#define TX_PAT_CHK_MEM_PATREAD_C2__WORD ((uint32_t) 0x7e0336)

#define TX_PAT_CHK_MEM_PATREAD_C3 ((uint16_t) 0x338)
#define TX_PAT_CHK_MEM_PATREAD_C3__WORD ((uint32_t) 0x7e0338)

#define TX_PAT_CHK_PRBS_CTRL ((uint16_t) 0x33a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_EN_C0 ((uint32_t) 0x33a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_EN_C1 ((uint32_t) 0x233a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_EN_C2 ((uint32_t) 0x433a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_EN_C3 ((uint32_t) 0x633a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C0 ((uint32_t) 0x833a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C1 ((uint32_t) 0xa33a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C2 ((uint32_t) 0xc33a)
#define TX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C3 ((uint32_t) 0xe33a)

#define TX_PAT_CHK_PRBS_SIZE ((uint16_t) 0x33c)
#define TX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C0 ((uint32_t) 0x4033c)
#define TX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C1 ((uint32_t) 0x4633c)
#define TX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C2 ((uint32_t) 0x4c33c)
#define TX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C3 ((uint32_t) 0x5233c)

#define TX_PAT_CHK_PRBS_CTRL_STATES ((uint16_t) 0x33e)
#define TX_PAT_CHK_PRBS_CTRL_STATES__STATE_C0 ((uint32_t) 0x62033e)
#define TX_PAT_CHK_PRBS_CTRL_STATES__STATE_C1 ((uint32_t) 0x62433e)
#define TX_PAT_CHK_PRBS_CTRL_STATES__STATE_C2 ((uint32_t) 0x62833e)
#define TX_PAT_CHK_PRBS_CTRL_STATES__STATE_C3 ((uint32_t) 0x62c33e)

#define TX_PAT_CHK_PRBS_STATE_LO_C0 ((uint16_t) 0x340)
#define TX_PAT_CHK_PRBS_STATE_LO_C0__STATE ((uint32_t) 0x7e0340)

#define TX_PAT_CHK_PRBS_STATE_LO_C1 ((uint16_t) 0x342)
#define TX_PAT_CHK_PRBS_STATE_LO_C1__STATE ((uint32_t) 0x7e0342)

#define TX_PAT_CHK_PRBS_STATE_LO_C2 ((uint16_t) 0x344)
#define TX_PAT_CHK_PRBS_STATE_LO_C2__STATE ((uint32_t) 0x7e0344)

#define TX_PAT_CHK_PRBS_STATE_LO_C3 ((uint16_t) 0x346)
#define TX_PAT_CHK_PRBS_STATE_LO_C3__STATE ((uint32_t) 0x7e0346)

#define TX_PAT_CHK_PRBS_STATE_HI_C0 ((uint16_t) 0x348)
#define TX_PAT_CHK_PRBS_STATE_HI_C0__STATE ((uint32_t) 0x7e0348)

#define TX_PAT_CHK_PRBS_STATE_HI_C1 ((uint16_t) 0x34a)
#define TX_PAT_CHK_PRBS_STATE_HI_C1__STATE ((uint32_t) 0x7e034a)

#define TX_PAT_CHK_PRBS_STATE_HI_C2 ((uint16_t) 0x34c)
#define TX_PAT_CHK_PRBS_STATE_HI_C2__STATE ((uint32_t) 0x7e034c)

#define TX_PAT_CHK_PRBS_STATE_HI_C3 ((uint16_t) 0x34e)
#define TX_PAT_CHK_PRBS_STATE_HI_C3__STATE ((uint32_t) 0x7e034e)

#define TX_PAT_CHK_BIT_COUNT0 ((uint16_t) 0x350)
#define TX_PAT_CHK_BIT_COUNT0__COUNT ((uint32_t) 0x7e0350)

#define TX_PAT_CHK_BIT_COUNT1 ((uint16_t) 0x352)
#define TX_PAT_CHK_BIT_COUNT1__COUNT ((uint32_t) 0x7e0352)

#define TX_PAT_CHK_BIT_COUNT2 ((uint16_t) 0x354)
#define TX_PAT_CHK_BIT_COUNT2__COUNT ((uint32_t) 0x7e0354)

#define TX_PAT_CHK_BIT_COUNT3 ((uint16_t) 0x356)
#define TX_PAT_CHK_BIT_COUNT3__COUNT ((uint32_t) 0x7e0356)

#define TX_PAT_CHK_ERROR_COUNT_LSB_C0 ((uint16_t) 0x358)
#define TX_PAT_CHK_ERROR_COUNT_LSB_C0__COUNT ((uint32_t) 0x7e0358)

#define TX_PAT_CHK_ERROR_COUNT_LSB_C1 ((uint16_t) 0x35a)
#define TX_PAT_CHK_ERROR_COUNT_LSB_C1__COUNT ((uint32_t) 0x7e035a)

#define TX_PAT_CHK_ERROR_COUNT_LSB_C2 ((uint16_t) 0x35c)
#define TX_PAT_CHK_ERROR_COUNT_LSB_C2__COUNT ((uint32_t) 0x7e035c)

#define TX_PAT_CHK_ERROR_COUNT_LSB_C3 ((uint16_t) 0x35e)
#define TX_PAT_CHK_ERROR_COUNT_LSB_C3__COUNT ((uint32_t) 0x7e035e)

#define TX_PAT_CHK_ERROR_COUNT_MSB_C0 ((uint16_t) 0x360)
#define TX_PAT_CHK_ERROR_COUNT_MSB_C0__COUNT ((uint32_t) 0x7e0360)

#define TX_PAT_CHK_ERROR_COUNT_MSB_C1 ((uint16_t) 0x362)
#define TX_PAT_CHK_ERROR_COUNT_MSB_C1__COUNT ((uint32_t) 0x7e0362)

#define TX_PAT_CHK_ERROR_COUNT_MSB_C2 ((uint16_t) 0x364)
#define TX_PAT_CHK_ERROR_COUNT_MSB_C2__COUNT ((uint32_t) 0x7e0364)

#define TX_PAT_CHK_ERROR_COUNT_MSB_C3 ((uint16_t) 0x366)
#define TX_PAT_CHK_ERROR_COUNT_MSB_C3__COUNT ((uint32_t) 0x7e0366)

#define TX_VR_FREEZE ((uint16_t) 0x368)
#define TX_VR_FREEZE__FREEZE ((uint32_t) 0x368)

#define TX_VR_CLK_GATE ((uint16_t) 0x36a)
#define TX_VR_CLK_GATE__GATE_CLK_CTRL ((uint32_t) 0x36a)
#define TX_VR_CLK_GATE__GATE_CLK_VCO ((uint32_t) 0x236a)

#define TX_VR_RESET ((uint16_t) 0x36c)
#define TX_VR_RESET__ACM_RST_N ((uint32_t) 0x36c)
#define TX_VR_RESET__DSM_RST_N ((uint32_t) 0x236c)
#define TX_VR_RESET__DSM_OUT_RST_N ((uint32_t) 0x436c)
#define TX_VR_RESET__LD_RST_N ((uint32_t) 0x636c)
#define TX_VR_RESET__FD_RST_N ((uint32_t) 0x836c)

#define TX_VR_ACM_CTRL ((uint16_t) 0x36e)
#define TX_VR_ACM_CTRL__BYP_RST_SYNC ((uint32_t) 0x36e)
#define TX_VR_ACM_CTRL__ACM_OVRD ((uint32_t) 0x236e)
#define TX_VR_ACM_CTRL__ACM_PRLD ((uint32_t) 0x436e)
#define TX_VR_ACM_CTRL__ACM_HOLD ((uint32_t) 0x636e)
#define TX_VR_ACM_CTRL__ACM_BYP_SAT ((uint32_t) 0x836e)

#define TX_VR_ACM_ADJ_POS_LO ((uint16_t) 0x370)
#define TX_VR_ACM_ADJ_POS_LO__ACM_ADJ_POS_LO ((uint32_t) 0x1e0370)

#define TX_VR_ACM_ADJ_POS_HI ((uint16_t) 0x372)
#define TX_VR_ACM_ADJ_POS_HI__ACM_ADJ_POS_HI ((uint32_t) 0xe0372)

#define TX_VR_ACM_ADJ_NEG_LO ((uint16_t) 0x374)
#define TX_VR_ACM_ADJ_NEG_LO__ACM_ADJ_NEG_LO ((uint32_t) 0x1e0374)

#define TX_VR_ACM_ADJ_NEG_HI ((uint16_t) 0x376)
#define TX_VR_ACM_ADJ_NEG_HI__ACM_ADJ_NEG_HI ((uint32_t) 0xe0376)

#define TX_VR_ACM_OVRD_VAL_LO ((uint16_t) 0x378)
#define TX_VR_ACM_OVRD_VAL_LO__ACM_OVRD_VAL_LO ((uint32_t) 0x1e0378)

#define TX_VR_ACM_OVRD_VAL_HI ((uint16_t) 0x37a)
#define TX_VR_ACM_OVRD_VAL_HI__ACM_OVRD_VAL_HI ((uint32_t) 0xe037a)

#define TX_VR_ACM_PRLD_VAL_LO ((uint16_t) 0x37c)
#define TX_VR_ACM_PRLD_VAL_LO__ACM_PRLD_VAL_LO ((uint32_t) 0x1e037c)

#define TX_VR_ACM_PRLD_VAL_HI ((uint16_t) 0x37e)
#define TX_VR_ACM_PRLD_VAL_HI__ACM_PRLD_VAL_HI ((uint32_t) 0xe037e)

#define TX_VR_ACM_ACCUM_OBSV_LO ((uint16_t) 0x380)
#define TX_VR_ACM_ACCUM_OBSV_LO__ACM_ACCUM_OBSV_LO ((uint32_t) 0x7e0380)

#define TX_VR_ACM_ACCUM_OBSV_HI ((uint16_t) 0x382)
#define TX_VR_ACM_ACCUM_OBSV_HI__ACM_ACCUM_OBSV_HI ((uint32_t) 0x6e0382)

#define TX_VR_DSM_CTRL ((uint16_t) 0x384)
#define TX_VR_DSM_CTRL__BYP_RST_SYNC ((uint32_t) 0x384)
#define TX_VR_DSM_CTRL__DSM_OVRD ((uint32_t) 0x2384)
#define TX_VR_DSM_CTRL__DSM_PRLD ((uint32_t) 0x4384)
#define TX_VR_DSM_CTRL__DSM_HOLD ((uint32_t) 0x6384)
#define TX_VR_DSM_CTRL__DSM_INV ((uint32_t) 0x8384)

#define TX_VR_DSM_OVRD_VAL ((uint16_t) 0x386)
#define TX_VR_DSM_OVRD_VAL__DSM_OVRD_VAL ((uint32_t) 0x1e0386)

#define TX_VR_DSM_PRLD_VAL ((uint16_t) 0x388)
#define TX_VR_DSM_PRLD_VAL__DSM_PRLD_VAL ((uint32_t) 0x1e0388)

#define TX_VR_DSM_ACCUM_OBSV ((uint16_t) 0x38a)
#define TX_VR_DSM_ACCUM_OBSV__DSM_ACCUM_OBSV ((uint32_t) 0x7e038a)

#define TX_VR_LD_CTRL ((uint16_t) 0x38c)
#define TX_VR_LD_CTRL__LD_FORCE_LOCK ((uint32_t) 0x38c)
#define TX_VR_LD_CTRL__LOCK_SEL ((uint32_t) 0x238c)

#define TX_VR_LD_MEAS_PER ((uint16_t) 0x38e)
#define TX_VR_LD_MEAS_PER__LD_MEAS_PER ((uint32_t) 0x1e038e)

#define TX_VR_LD_LOCK_THRESH ((uint16_t) 0x390)
#define TX_VR_LD_LOCK_THRESH__LD_LOCK_THRESH ((uint32_t) 0x160390)

#define TX_VR_LD_LOCK_CNT ((uint16_t) 0x392)
#define TX_VR_LD_LOCK_CNT__LD_LOCK_CNT ((uint32_t) 0xe0392)

#define TX_VR_LD_STAT ((uint16_t) 0x394)
#define TX_VR_LD_STAT__LD_LOCKED ((uint32_t) 0x600394)

#define TX_VR_LD_LOW_CNT ((uint16_t) 0x396)
#define TX_VR_LD_LOW_CNT__LD_LOW_CNT ((uint32_t) 0x7e0396)

#define TX_VR_FD_CTRL ((uint16_t) 0x398)
#define TX_VR_FD_CTRL__SEL_FLTRD_FREQ ((uint32_t) 0x398)

#define TX_VR_FD_PER_MULT ((uint16_t) 0x39a)
#define TX_VR_FD_PER_MULT__PER_MULT ((uint32_t) 0x1e039a)

#define TX_VR_FD_FREQ_CNT_TRGT_MAX ((uint16_t) 0x39c)
#define TX_VR_FD_FREQ_CNT_TRGT_MAX__FREQ_CNT_TRGT_MAX ((uint32_t) 0x1e039c)

#define TX_VR_FD_FREQ_CNT_TRGT_MIN ((uint16_t) 0x39e)
#define TX_VR_FD_FREQ_CNT_TRGT_MIN__FREQ_CNT_TRGT_MIN ((uint32_t) 0x1e039e)

#define TX_VR_FD_STAT ((uint16_t) 0x3a0)
#define TX_VR_FD_STAT__FREQ_FAST ((uint32_t) 0x6003a0)
#define TX_VR_FD_STAT__FREQ_SLOW ((uint32_t) 0x6023a0)

#define TX_VR_FD_FREQ_CNT_OBSV ((uint16_t) 0x3a2)
#define TX_VR_FD_FREQ_CNT_OBSV__FREQ_CNT_OBSV ((uint32_t) 0x7e03a2)

#define TX_DCC_DCC_FREEZE ((uint16_t) 0x3a4)
#define TX_DCC_DCC_FREEZE__FREEZE ((uint32_t) 0x3a4)

#define TX_DCC_MISC_CTRL ((uint16_t) 0x3a6)
#define TX_DCC_MISC_CTRL__SW_RST_N ((uint32_t) 0x3a6)
#define TX_DCC_MISC_CTRL__DISABLE_WCLK ((uint32_t) 0x23a6)
#define TX_DCC_MISC_CTRL__SAMPLER_CYCLE_LATENCY ((uint32_t) 0x243a6)
#define TX_DCC_MISC_CTRL__COMP_SEL_INP_OVERRIDE_EN ((uint32_t) 0x83a6)
#define TX_DCC_MISC_CTRL__COMP_SEL_INM_OVERRIDE_EN ((uint32_t) 0xa3a6)
#define TX_DCC_MISC_CTRL__ACC_INPUT_OVERRIDE_EN ((uint32_t) 0xc3a6)
#define TX_DCC_MISC_CTRL__BYP_RST_SYNC ((uint32_t) 0xe3a6)

#define TX_DCC_CONTROL_CODE_SEQUENCE_0_0_TO_15 ((uint16_t) 0x3a8)
#define TX_DCC_CONTROL_CODE_SEQUENCE_0_0_TO_15__CONTROL_CODE_STATE ((uint32_t) 0x1e03a8)

#define TX_DCC_CONTROL_CODE_SEQUENCE_0_16_TO_31 ((uint16_t) 0x3aa)
#define TX_DCC_CONTROL_CODE_SEQUENCE_0_16_TO_31__CONTROL_CODE_STATE ((uint32_t) 0x1e03aa)

#define TX_DCC_CONTROL_CODE_SEQUENCE_1_0_TO_15 ((uint16_t) 0x3ac)
#define TX_DCC_CONTROL_CODE_SEQUENCE_1_0_TO_15__CONTROL_CODE_STATE ((uint32_t) 0x1e03ac)

#define TX_DCC_CONTROL_CODE_SEQUENCE_1_16_TO_31 ((uint16_t) 0x3ae)
#define TX_DCC_CONTROL_CODE_SEQUENCE_1_16_TO_31__CONTROL_CODE_STATE ((uint32_t) 0x1e03ae)

#define TX_DCC_COMP_SEL_OVERRIDES ((uint16_t) 0x3b0)
#define TX_DCC_COMP_SEL_OVERRIDES__COMP_SEL_INP_OVERRIDE_VAL ((uint32_t) 0x403b0)
#define TX_DCC_COMP_SEL_OVERRIDES__COMP_SEL_INM_OVERRIDE_VAL ((uint32_t) 0x463b0)
#define TX_DCC_COMP_SEL_OVERRIDES__ACC_INPUT_OVERRIDE_VAL ((uint32_t) 0x2c3b0)

#define TX_DCC_CLKTX_CTRL_P_MISC_CTRL ((uint16_t) 0x3b2)
#define TX_DCC_CLKTX_CTRL_P_MISC_CTRL__DSM_INVERT_EN ((uint32_t) 0x3b2)
#define TX_DCC_CLKTX_CTRL_P_MISC_CTRL__DSM_OVERRIDE_EN ((uint32_t) 0x23b2)
#define TX_DCC_CLKTX_CTRL_P_MISC_CTRL__DSM_PRELOAD_EN ((uint32_t) 0x43b2)
#define TX_DCC_CLKTX_CTRL_P_MISC_CTRL__DSM_HOLD_EN ((uint32_t) 0x63b2)

#define TX_DCC_CLKTX_CTRL_P_DSM_V_FIXED_VAL ((uint16_t) 0x3b4)
#define TX_DCC_CLKTX_CTRL_P_DSM_V_FIXED_VAL__VAL ((uint32_t) 0x1403b4)

#define TX_DCC_CLKTX_CTRL_P_DSM_OVERRIDE_VAL ((uint16_t) 0x3b6)
#define TX_DCC_CLKTX_CTRL_P_DSM_OVERRIDE_VAL__VAL ((uint32_t) 0x1803b6)

#define TX_DCC_CLKTX_CTRL_P_DSM_VAL ((uint16_t) 0x3b8)
#define TX_DCC_CLKTX_CTRL_P_DSM_VAL__VAL ((uint32_t) 0x7803b8)

#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL ((uint16_t) 0x3ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_EN ((uint32_t) 0x3ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN ((uint32_t) 0x23ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_BYPASS_SAT_EN ((uint32_t) 0x43ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__ACC_INVERT_EN ((uint32_t) 0x63ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__DSM_INVERT_EN ((uint32_t) 0x83ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__DSM_OVERRIDE_EN ((uint32_t) 0xa3ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__DSM_PRELOAD_EN ((uint32_t) 0xc3ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__DSM_HOLD_EN ((uint32_t) 0xe3ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCKDET_RST_N ((uint32_t) 0x103ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCKDET_OVERRIDE_EN ((uint32_t) 0x123ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCKDET_FORCE_EN ((uint32_t) 0x143ba)
#define TX_DCC_CLKTX_CTRL_N_MISC_CTRL__LOCK_SEL ((uint32_t) 0x163ba)

#define TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_L ((uint16_t) 0x3bc)
#define TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_L__LSB ((uint32_t) 0x1e03bc)

#define TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_M ((uint16_t) 0x3be)
#define TX_DCC_CLKTX_CTRL_N_ACC_POS_ADJ_M__MSB ((uint32_t) 0xe03be)

#define TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_L ((uint16_t) 0x3c0)
#define TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_L__LSB ((uint32_t) 0x1e03c0)

#define TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_M ((uint16_t) 0x3c2)
#define TX_DCC_CLKTX_CTRL_N_ACC_NEG_ADJ_M__MSB ((uint32_t) 0xe03c2)

#define TX_DCC_CLKTX_CTRL_N_ACC_OVERRIDE_VAL ((uint16_t) 0x3c4)
#define TX_DCC_CLKTX_CTRL_N_ACC_OVERRIDE_VAL__VAL ((uint32_t) 0x1403c4)

#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_UPPER_VAL_L ((uint16_t) 0x3c6)
#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_UPPER_VAL_L__LSB ((uint32_t) 0x1e03c6)

#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_UPPER_VAL_M ((uint16_t) 0x3c8)
#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_UPPER_VAL_M__MSB ((uint32_t) 0xe03c8)

#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_LOWER_VAL_L ((uint16_t) 0x3ca)
#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_LOWER_VAL_L__LSB ((uint32_t) 0x1e03ca)

#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_LOWER_VAL_M ((uint16_t) 0x3cc)
#define TX_DCC_CLKTX_CTRL_N_ACC_SAT_LOWER_VAL_M__MSB ((uint32_t) 0xe03cc)

#define TX_DCC_CLKTX_CTRL_N_ACC_VAL_L ((uint16_t) 0x3ce)
#define TX_DCC_CLKTX_CTRL_N_ACC_VAL_L__LSB ((uint32_t) 0x7e03ce)

#define TX_DCC_CLKTX_CTRL_N_ACC_VAL_M ((uint16_t) 0x3d0)
#define TX_DCC_CLKTX_CTRL_N_ACC_VAL_M__MSB ((uint32_t) 0x6e03d0)

#define TX_DCC_CLKTX_CTRL_N_DSM_OVERRIDE_VAL ((uint16_t) 0x3d2)
#define TX_DCC_CLKTX_CTRL_N_DSM_OVERRIDE_VAL__VAL ((uint32_t) 0x1803d2)

#define TX_DCC_CLKTX_CTRL_N_DSM_VAL ((uint16_t) 0x3d4)
#define TX_DCC_CLKTX_CTRL_N_DSM_VAL__VAL ((uint32_t) 0x7803d4)

#define TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_L ((uint16_t) 0x3d6)
#define TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_L__LSB ((uint32_t) 0x1e03d6)

#define TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_M ((uint16_t) 0x3d8)
#define TX_DCC_CLKTX_CTRL_N_LOCKDET_THRESH_M__MSB ((uint32_t) 0xe03d8)

#define TX_DCC_CLKTX_CTRL_N_LOCKDET_PERIOD ((uint16_t) 0x3da)
#define TX_DCC_CLKTX_CTRL_N_LOCKDET_PERIOD__VAL ((uint32_t) 0x1e03da)

#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL ((uint16_t) 0x3dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_EN ((uint32_t) 0x3dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_OVERRIDE_EN ((uint32_t) 0x23dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_BYPASS_SAT_EN ((uint32_t) 0x43dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__ACC_INVERT_EN ((uint32_t) 0x63dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__DSM_INVERT_EN ((uint32_t) 0x83dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__DSM_OVERRIDE_EN ((uint32_t) 0xa3dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__DSM_PRELOAD_EN ((uint32_t) 0xc3dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__DSM_HOLD_EN ((uint32_t) 0xe3dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCKDET_RST_N ((uint32_t) 0x103dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCKDET_OVERRIDE_EN ((uint32_t) 0x123dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCKDET_FORCE_EN ((uint32_t) 0x143dc)
#define TX_DCC_CLKTXB_CTRL_P_MISC_CTRL__LOCK_SEL ((uint32_t) 0x163dc)

#define TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_L ((uint16_t) 0x3de)
#define TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_L__LSB ((uint32_t) 0x1e03de)

#define TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_M ((uint16_t) 0x3e0)
#define TX_DCC_CLKTXB_CTRL_P_ACC_POS_ADJ_M__MSB ((uint32_t) 0xe03e0)

#define TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_L ((uint16_t) 0x3e2)
#define TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_L__LSB ((uint32_t) 0x1e03e2)

#define TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_M ((uint16_t) 0x3e4)
#define TX_DCC_CLKTXB_CTRL_P_ACC_NEG_ADJ_M__MSB ((uint32_t) 0xe03e4)

#define TX_DCC_CLKTXB_CTRL_P_ACC_OVERRIDE_VAL ((uint16_t) 0x3e6)
#define TX_DCC_CLKTXB_CTRL_P_ACC_OVERRIDE_VAL__VAL ((uint32_t) 0x1403e6)

#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_UPPER_VAL_L ((uint16_t) 0x3e8)
#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_UPPER_VAL_L__LSB ((uint32_t) 0x1e03e8)

#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_UPPER_VAL_M ((uint16_t) 0x3ea)
#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_UPPER_VAL_M__MSB ((uint32_t) 0xe03ea)

#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_LOWER_VAL_L ((uint16_t) 0x3ec)
#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_LOWER_VAL_L__LSB ((uint32_t) 0x1e03ec)

#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_LOWER_VAL_M ((uint16_t) 0x3ee)
#define TX_DCC_CLKTXB_CTRL_P_ACC_SAT_LOWER_VAL_M__MSB ((uint32_t) 0xe03ee)

#define TX_DCC_CLKTXB_CTRL_P_ACC_VAL_L ((uint16_t) 0x3f0)
#define TX_DCC_CLKTXB_CTRL_P_ACC_VAL_L__LSB ((uint32_t) 0x7e03f0)

#define TX_DCC_CLKTXB_CTRL_P_ACC_VAL_M ((uint16_t) 0x3f2)
#define TX_DCC_CLKTXB_CTRL_P_ACC_VAL_M__MSB ((uint32_t) 0x6e03f2)

#define TX_DCC_CLKTXB_CTRL_P_DSM_OVERRIDE_VAL ((uint16_t) 0x3f4)
#define TX_DCC_CLKTXB_CTRL_P_DSM_OVERRIDE_VAL__VAL ((uint32_t) 0x1803f4)

#define TX_DCC_CLKTXB_CTRL_P_DSM_VAL ((uint16_t) 0x3f6)
#define TX_DCC_CLKTXB_CTRL_P_DSM_VAL__VAL ((uint32_t) 0x7803f6)

#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_L ((uint16_t) 0x3f8)
#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_L__LSB ((uint32_t) 0x1e03f8)

#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_M ((uint16_t) 0x3fa)
#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_THRESH_M__MSB ((uint32_t) 0xe03fa)

#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_PERIOD ((uint16_t) 0x3fc)
#define TX_DCC_CLKTXB_CTRL_P_LOCKDET_PERIOD__VAL ((uint32_t) 0x1e03fc)

#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL ((uint16_t) 0x3fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_EN ((uint32_t) 0x3fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_OVERRIDE_EN ((uint32_t) 0x23fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_BYPASS_SAT_EN ((uint32_t) 0x43fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__ACC_INVERT_EN ((uint32_t) 0x63fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__DSM_INVERT_EN ((uint32_t) 0x83fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__DSM_OVERRIDE_EN ((uint32_t) 0xa3fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__DSM_PRELOAD_EN ((uint32_t) 0xc3fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__DSM_HOLD_EN ((uint32_t) 0xe3fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCKDET_RST_N ((uint32_t) 0x103fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCKDET_OVERRIDE_EN ((uint32_t) 0x123fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCKDET_FORCE_EN ((uint32_t) 0x143fe)
#define TX_DCC_CLKTXB_CTRL_N_MISC_CTRL__LOCK_SEL ((uint32_t) 0x163fe)

#define TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_L ((uint16_t) 0x400)
#define TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_L__LSB ((uint32_t) 0x1e0400)

#define TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_M ((uint16_t) 0x402)
#define TX_DCC_CLKTXB_CTRL_N_ACC_POS_ADJ_M__MSB ((uint32_t) 0xe0402)

#define TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_L ((uint16_t) 0x404)
#define TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_L__LSB ((uint32_t) 0x1e0404)

#define TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_M ((uint16_t) 0x406)
#define TX_DCC_CLKTXB_CTRL_N_ACC_NEG_ADJ_M__MSB ((uint32_t) 0xe0406)

#define TX_DCC_CLKTXB_CTRL_N_ACC_OVERRIDE_VAL ((uint16_t) 0x408)
#define TX_DCC_CLKTXB_CTRL_N_ACC_OVERRIDE_VAL__VAL ((uint32_t) 0x140408)

#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_UPPER_VAL_L ((uint16_t) 0x40a)
#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_UPPER_VAL_L__LSB ((uint32_t) 0x1e040a)

#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_UPPER_VAL_M ((uint16_t) 0x40c)
#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_UPPER_VAL_M__MSB ((uint32_t) 0xe040c)

#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_LOWER_VAL_L ((uint16_t) 0x40e)
#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_LOWER_VAL_L__LSB ((uint32_t) 0x1e040e)

#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_LOWER_VAL_M ((uint16_t) 0x410)
#define TX_DCC_CLKTXB_CTRL_N_ACC_SAT_LOWER_VAL_M__MSB ((uint32_t) 0xe0410)

#define TX_DCC_CLKTXB_CTRL_N_ACC_VAL_L ((uint16_t) 0x412)
#define TX_DCC_CLKTXB_CTRL_N_ACC_VAL_L__LSB ((uint32_t) 0x7e0412)

#define TX_DCC_CLKTXB_CTRL_N_ACC_VAL_M ((uint16_t) 0x414)
#define TX_DCC_CLKTXB_CTRL_N_ACC_VAL_M__MSB ((uint32_t) 0x6e0414)

#define TX_DCC_CLKTXB_CTRL_N_DSM_OVERRIDE_VAL ((uint16_t) 0x416)
#define TX_DCC_CLKTXB_CTRL_N_DSM_OVERRIDE_VAL__VAL ((uint32_t) 0x180416)

#define TX_DCC_CLKTXB_CTRL_N_DSM_VAL ((uint16_t) 0x418)
#define TX_DCC_CLKTXB_CTRL_N_DSM_VAL__VAL ((uint32_t) 0x780418)

#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_L ((uint16_t) 0x41a)
#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_L__LSB ((uint32_t) 0x1e041a)

#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_M ((uint16_t) 0x41c)
#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_THRESH_M__MSB ((uint32_t) 0xe041c)

#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_PERIOD ((uint16_t) 0x41e)
#define TX_DCC_CLKTXB_CTRL_N_LOCKDET_PERIOD__VAL ((uint32_t) 0x1e041e)

#define TX_DCC_CLKTXB_CTRL_N_LUT ((uint16_t) 0x420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SROOT_INCREMENT_VAL ((uint32_t) 0x420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SCLKP_INCREMENT_VAL ((uint32_t) 0x2420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SCLKM_INCREMENT_VAL ((uint32_t) 0x4420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SROOT_DECREMENT_VAL ((uint32_t) 0x6420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SCLKP_DECREMENT_VAL ((uint32_t) 0x8420)
#define TX_DCC_CLKTXB_CTRL_N_LUT__SCLKM_DECREMENT_VAL ((uint32_t) 0xa420)

#define TX_DCC_LOCKDET_STAT ((uint16_t) 0x422)
#define TX_DCC_LOCKDET_STAT__CLKTX_CTRL_N_LOCKED ((uint32_t) 0x600422)
#define TX_DCC_LOCKDET_STAT__CLKTXB_CTRL_P_LOCKED ((uint32_t) 0x602422)
#define TX_DCC_LOCKDET_STAT__CLKTXB_CTRL_N_LOCKED ((uint32_t) 0x604422)

#define TX_DCC_VREF_CTRL ((uint16_t) 0x424)
#define TX_DCC_VREF_CTRL__VREF_EN ((uint32_t) 0x424)
#define TX_DCC_VREF_CTRL__VREF_VAL ((uint32_t) 0x142424)
#define TX_DCC_VREF_CTRL__INV_DSM_VREF ((uint32_t) 0x18424)

#define TX_LPBK_FREEZE ((uint16_t) 0x426)
#define TX_LPBK_FREEZE__FREEZE ((uint32_t) 0x426)

#define TX_LPBK_CLK_GATE ((uint16_t) 0x428)
#define TX_LPBK_CLK_GATE__GATE_CLK ((uint32_t) 0x428)

#define TX_LPBK_RESET ((uint16_t) 0x42a)
#define TX_LPBK_RESET__RST_N ((uint32_t) 0x42a)

#define TX_LPBK_ACCUM ((uint16_t) 0x42c)
#define TX_LPBK_ACCUM__LPBK_ACCUM ((uint32_t) 0x1a042c)

#define TX_LPBK_CTRL ((uint16_t) 0x42e)
#define TX_LPBK_CTRL__LPBK_SHIFT_AMT ((uint32_t) 0x2042e)
#define TX_LPBK_CTRL__LPBK_SAT_VAL_HIGH ((uint32_t) 0x14442e)
#define TX_LPBK_CTRL__LPBK_INV_DSM_OUT ((uint32_t) 0x1a42e)

#define TX_LPBK_DSM_CTRL ((uint16_t) 0x430)
#define TX_LPBK_DSM_CTRL__DSM_BYP_RST_SYNC ((uint32_t) 0x430)
#define TX_LPBK_DSM_CTRL__DSM_OVRD ((uint32_t) 0x2430)

#define TX_LPBK_DSM_OVRD_VAL_0 ((uint16_t) 0x432)
#define TX_LPBK_DSM_OVRD_VAL_0__DSM_OVRD_VAL ((uint32_t) 0x1e0432)

#define TX_LPBK_DSM_OVRD_VAL_1 ((uint16_t) 0x434)
#define TX_LPBK_DSM_OVRD_VAL_1__DSM_OVRD_VAL ((uint32_t) 0x1e0434)

#define TX_LPBK_DSM_ACCUM_E_OBSV ((uint16_t) 0x436)
#define TX_LPBK_DSM_ACCUM_E_OBSV__DSM_ACCUM_E_OBSV ((uint32_t) 0x780436)

#define TX_LPBK_DSM_ACCUM_O_OBSV ((uint16_t) 0x438)
#define TX_LPBK_DSM_ACCUM_O_OBSV__DSM_ACCUM_O_OBSV_LO ((uint32_t) 0x780438)

#define RX_CLKRX_CONFIG ((uint16_t) 0x0)
#define RX_CLKRX_CONFIG__CLKRX_EN ((uint32_t) 0x0)
#define RX_CLKRX_CONFIG__CLKRX_DISABLE_VAL ((uint32_t) 0x2000)
#define RX_CLKRX_CONFIG__CLKRX_FE_BIAS_TRIM ((uint32_t) 0x44000)
#define RX_CLKRX_CONFIG__CLKRX_TIA_SEL_LF_RES ((uint32_t) 0xa000)
#define RX_CLKRX_CONFIG__CLKRX_STG1_SEL_LF_RES ((uint32_t) 0xc000)

#define RX_DESER_RATIO_CTRL ((uint16_t) 0x2)
#define RX_DESER_RATIO_CTRL__MPCG_DESER_RATIO_CTRL ((uint32_t) 0x20002)

#define RX_DESER_LAT_TRANS_W0 ((uint16_t) 0x4)
#define RX_DESER_LAT_TRANS_W0__DESER_LAT_TRANS_O ((uint32_t) 0x4)

#define RX_DESER_LAT_TRANS_W1 ((uint16_t) 0x6)
#define RX_DESER_LAT_TRANS_W1__DESER_LAT_TRANS_O ((uint32_t) 0x6)

#define RX_DESER_LAT_TRANS_W2 ((uint16_t) 0x8)
#define RX_DESER_LAT_TRANS_W2__DESER_LAT_TRANS_O ((uint32_t) 0x8)

#define RX_DESER_LAT_TRANS_W3 ((uint16_t) 0xa)
#define RX_DESER_LAT_TRANS_W3__DESER_LAT_TRANS_O ((uint32_t) 0xa)

#define RX_DESER_LAT_TRANS_W4 ((uint16_t) 0xc)
#define RX_DESER_LAT_TRANS_W4__DESER_LAT_TRANS_O ((uint32_t) 0xc)

#define RX_DESER_LAT_TRANS_W5 ((uint16_t) 0xe)
#define RX_DESER_LAT_TRANS_W5__DESER_LAT_TRANS_O ((uint32_t) 0xe)

#define RX_DESER_LAT_TRANS_W6 ((uint16_t) 0x10)
#define RX_DESER_LAT_TRANS_W6__DESER_LAT_TRANS_O ((uint32_t) 0x10)

#define RX_DESER_LAT_TRANS_W7 ((uint16_t) 0x12)
#define RX_DESER_LAT_TRANS_W7__DESER_LAT_TRANS_O ((uint32_t) 0x12)

#define RX_DESER_LAT_TRANS_W8 ((uint16_t) 0x14)
#define RX_DESER_LAT_TRANS_W8__DESER_LAT_TRANS_O ((uint32_t) 0x14)

#define RX_DESER_LAT_TRANS_W9 ((uint16_t) 0x16)
#define RX_DESER_LAT_TRANS_W9__DESER_LAT_TRANS_O ((uint32_t) 0x16)

#define RX_DESER_LAT_TRANS_W10 ((uint16_t) 0x18)
#define RX_DESER_LAT_TRANS_W10__DESER_LAT_TRANS_O ((uint32_t) 0x18)

#define RX_DESER_LAT_TRANS_W11 ((uint16_t) 0x1a)
#define RX_DESER_LAT_TRANS_W11__DESER_LAT_TRANS_O ((uint32_t) 0x1a)

#define RX_DESER_LAT_TRANS_W12 ((uint16_t) 0x1c)
#define RX_DESER_LAT_TRANS_W12__DESER_LAT_TRANS_O ((uint32_t) 0x1c)

#define RX_DESER_LAT_TRANS_W13 ((uint16_t) 0x1e)
#define RX_DESER_LAT_TRANS_W13__DESER_LAT_TRANS_O ((uint32_t) 0x1e)

#define RX_DESER_LAT_TRANS_W14 ((uint16_t) 0x20)
#define RX_DESER_LAT_TRANS_W14__DESER_LAT_TRANS_O ((uint32_t) 0x20)

#define RX_DESER_LAT_TRANS_W15 ((uint16_t) 0x22)
#define RX_DESER_LAT_TRANS_W15__DESER_LAT_TRANS_O ((uint32_t) 0x22)

#define RX_DESER_LAT_TRANS_W16 ((uint16_t) 0x24)
#define RX_DESER_LAT_TRANS_W16__DESER_LAT_TRANS_O ((uint32_t) 0x24)

#define RX_DESER_LAT_TRANS_W17 ((uint16_t) 0x26)
#define RX_DESER_LAT_TRANS_W17__DESER_LAT_TRANS_O ((uint32_t) 0x26)

#define RX_SHIFT_REG_OUT_SETH_N ((uint16_t) 0x28)
#define RX_SHIFT_REG_OUT_SETH_N__MPCG_SHIFT_REG_OUT_SETH_N ((uint32_t) 0x1e0028)

#define RX_SHIFT_REG_OUT_SETL ((uint16_t) 0x2a)
#define RX_SHIFT_REG_OUT_SETL__MPCG_SHIFT_REG_OUT_SETL ((uint32_t) 0x1e002a)

#define RX_SHIFT_REG_MUX_SEL_SETH_N ((uint16_t) 0x2c)
#define RX_SHIFT_REG_MUX_SEL_SETH_N__MPCG_SHIFT_REG_MUX_SEL_SETH_N ((uint32_t) 0x1e002c)

#define RX_SHIFT_REG_MUX_SEL_SETL ((uint16_t) 0x2e)
#define RX_SHIFT_REG_MUX_SEL_SETL__MPCG_SHIFT_REG_MUX_SEL_SETL ((uint32_t) 0x1e002e)

#define RX_CLK_SEL ((uint16_t) 0x30)
#define RX_CLK_SEL__MPCG_SEL_DES ((uint32_t) 0x60030)
#define RX_CLK_SEL__MPCG_SEL_REG ((uint32_t) 0x68030)
#define RX_CLK_SEL__MPCG_SEL_RTL ((uint32_t) 0x70030)
#define RX_CLK_SEL__MPCG_SEL_LINK_LAYER ((uint32_t) 0x78030)

#define RX_SEL_DESER_MUX ((uint16_t) 0x32)
#define RX_SEL_DESER_MUX__MPCG_SEL_DESER_MUX ((uint32_t) 0x60032)

#define RX_CLK_EN ((uint16_t) 0x34)
#define RX_CLK_EN__MPCG_CLK_DES_EN ((uint32_t) 0x34)
#define RX_CLK_EN__MPCG_CLK_REG_EN ((uint32_t) 0x2034)
#define RX_CLK_EN__MPCG_CLK_RTL_EN ((uint32_t) 0x4034)
#define RX_CLK_EN__MPCG_CLK_LINK_LAYER_EN ((uint32_t) 0x6034)

#define RX_DATA_LPBK_EN ((uint16_t) 0x36)
#define RX_DATA_LPBK_EN__DATA_LPBK_EN ((uint32_t) 0x1e0036)

#define RX_CLK_AUX_FEC_LPBK_EN ((uint16_t) 0x38)
#define RX_CLK_AUX_FEC_LPBK_EN__CLK_LPBK_EN ((uint32_t) 0x20038)
#define RX_CLK_AUX_FEC_LPBK_EN__AUX_LPBK_EN ((uint32_t) 0x4038)
#define RX_CLK_AUX_FEC_LPBK_EN__FEC_LPBK_EN ((uint32_t) 0x6038)

#define RX_WILD_CLK_CONFIG0 ((uint16_t) 0x3a)
#define RX_WILD_CLK_CONFIG0__MPCG_WILD_SLOW ((uint32_t) 0x3a)
#define RX_WILD_CLK_CONFIG0__MPCG_WILD_HCOUNT ((uint32_t) 0xa203a)
#define RX_WILD_CLK_CONFIG0__MPCG_WILD_LCOUNT ((uint32_t) 0xae03a)
#define RX_WILD_CLK_CONFIG0__MPCG_WILD_DIV_MODE ((uint32_t) 0x5a03a)

#define RX_WILD_CLK_CONFIG1 ((uint16_t) 0x3c)
#define RX_WILD_CLK_CONFIG1__MPCG_WILD_EN ((uint32_t) 0x3c)
#define RX_WILD_CLK_CONFIG1__MPCG_WILD_RST_N ((uint32_t) 0x203c)

#define RX_RX_QPUMP_VREG_CONFIG ((uint16_t) 0x3e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_DIV_EN_FROM_RTL ((uint32_t) 0x3e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_OSC_SLOW ((uint32_t) 0x203e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV1_RTL ((uint32_t) 0x403e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV4_RTL ((uint32_t) 0x603e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_SEL_DIV8_RTL ((uint32_t) 0x803e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_START ((uint32_t) 0xa03e)
#define RX_RX_QPUMP_VREG_CONFIG__QPUMP_VREG_EN_FROM_RTL ((uint32_t) 0xc03e)

#define RX_FE_VREF_CONFIG ((uint16_t) 0x40)
#define RX_FE_VREF_CONFIG__RX_VREF_DAC_EN_N ((uint32_t) 0x40)
#define RX_FE_VREF_CONFIG__RX_VREF_DAC_POS ((uint32_t) 0x2040)

#define RX_RX_TERM_CONFIG_0 ((uint16_t) 0x42)
#define RX_RX_TERM_CONFIG_0__RX_TERM_ZCTRL ((uint32_t) 0x80042)

#define RX_RX_TERM_CONFIG_1 ((uint16_t) 0x44)
#define RX_RX_TERM_CONFIG_1__RX_TERM_ZCTRL ((uint32_t) 0x80044)

#define RX_RX_TERM_CONFIG_2 ((uint16_t) 0x46)
#define RX_RX_TERM_CONFIG_2__RX_TERM_ZCTRL ((uint32_t) 0x80046)

#define RX_RX_TERM_CONFIG_3 ((uint16_t) 0x48)
#define RX_RX_TERM_CONFIG_3__RX_TERM_ZCTRL ((uint32_t) 0x80048)

#define RX_RX_TERM_CONFIG_4 ((uint16_t) 0x4a)
#define RX_RX_TERM_CONFIG_4__RX_TERM_ZCTRL ((uint32_t) 0x8004a)

#define RX_RX_TERM_CONFIG_5 ((uint16_t) 0x4c)
#define RX_RX_TERM_CONFIG_5__RX_TERM_ZCTRL ((uint32_t) 0x8004c)

#define RX_RX_TERM_CONFIG_6 ((uint16_t) 0x4e)
#define RX_RX_TERM_CONFIG_6__RX_TERM_ZCTRL ((uint32_t) 0x8004e)

#define RX_RX_TERM_CONFIG_7 ((uint16_t) 0x50)
#define RX_RX_TERM_CONFIG_7__RX_TERM_ZCTRL ((uint32_t) 0x80050)

#define RX_RX_TERM_CONFIG_8 ((uint16_t) 0x52)
#define RX_RX_TERM_CONFIG_8__RX_TERM_ZCTRL ((uint32_t) 0x80052)

#define RX_RX_TERM_CONFIG_9 ((uint16_t) 0x54)
#define RX_RX_TERM_CONFIG_9__RX_TERM_ZCTRL ((uint32_t) 0x80054)

#define RX_RX_TERM_CONFIG_10 ((uint16_t) 0x56)
#define RX_RX_TERM_CONFIG_10__RX_TERM_ZCTRL ((uint32_t) 0x80056)

#define RX_RX_TERM_CONFIG_11 ((uint16_t) 0x58)
#define RX_RX_TERM_CONFIG_11__RX_TERM_ZCTRL ((uint32_t) 0x80058)

#define RX_RX_TERM_CONFIG_12 ((uint16_t) 0x5a)
#define RX_RX_TERM_CONFIG_12__RX_TERM_ZCTRL ((uint32_t) 0x8005a)

#define RX_RX_TERM_CONFIG_13 ((uint16_t) 0x5c)
#define RX_RX_TERM_CONFIG_13__RX_TERM_ZCTRL ((uint32_t) 0x8005c)

#define RX_RX_TERM_CONFIG_14 ((uint16_t) 0x5e)
#define RX_RX_TERM_CONFIG_14__RX_TERM_ZCTRL ((uint32_t) 0x8005e)

#define RX_RX_TERM_CONFIG_15 ((uint16_t) 0x60)
#define RX_RX_TERM_CONFIG_15__RX_TERM_ZCTRL ((uint32_t) 0x80060)

#define RX_RX_TERM_CONFIG_16 ((uint16_t) 0x62)
#define RX_RX_TERM_CONFIG_16__RX_TERM_ZCTRL ((uint32_t) 0x80062)

#define RX_RX_TERM_CONFIG_17 ((uint16_t) 0x64)
#define RX_RX_TERM_CONFIG_17__RX_TERM_ZCTRL ((uint32_t) 0x80064)

#define RX_RX_TERM_CONFIG_18 ((uint16_t) 0x66)
#define RX_RX_TERM_CONFIG_18__RX_TERM_ZCTRL ((uint32_t) 0x80066)

#define RX_RX_TERM_CONFIG_19 ((uint16_t) 0x68)
#define RX_RX_TERM_CONFIG_19__RX_TERM_ZCTRL ((uint32_t) 0x80068)

#define RX_FE_OFFSET_CANCEL_PBD_W0S0 ((uint16_t) 0x6a)
#define RX_FE_OFFSET_CANCEL_PBD_W0S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4006a)
#define RX_FE_OFFSET_CANCEL_PBD_W0S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4606a)
#define RX_FE_OFFSET_CANCEL_PBD_W0S0__RX_FE_PBD ((uint32_t) 0x6c06a)

#define RX_FE_OFFSET_CANCEL_PBD_W0S1 ((uint16_t) 0x6c)
#define RX_FE_OFFSET_CANCEL_PBD_W0S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4006c)
#define RX_FE_OFFSET_CANCEL_PBD_W0S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4606c)
#define RX_FE_OFFSET_CANCEL_PBD_W0S1__RX_FE_PBD ((uint32_t) 0x6c06c)

#define RX_FE_OFFSET_CANCEL_PBD_W0S2 ((uint16_t) 0x6e)
#define RX_FE_OFFSET_CANCEL_PBD_W0S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4006e)
#define RX_FE_OFFSET_CANCEL_PBD_W0S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4606e)
#define RX_FE_OFFSET_CANCEL_PBD_W0S2__RX_FE_PBD ((uint32_t) 0x6c06e)

#define RX_FE_OFFSET_CANCEL_PBD_W0S3 ((uint16_t) 0x70)
#define RX_FE_OFFSET_CANCEL_PBD_W0S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40070)
#define RX_FE_OFFSET_CANCEL_PBD_W0S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46070)
#define RX_FE_OFFSET_CANCEL_PBD_W0S3__RX_FE_PBD ((uint32_t) 0x6c070)

#define RX_FE_OFFSET_CANCEL_PBD_W0S4 ((uint16_t) 0x72)
#define RX_FE_OFFSET_CANCEL_PBD_W0S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40072)
#define RX_FE_OFFSET_CANCEL_PBD_W0S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46072)
#define RX_FE_OFFSET_CANCEL_PBD_W0S4__RX_FE_PBD ((uint32_t) 0x6c072)

#define RX_FE_OFFSET_CANCEL_PBD_W0S5 ((uint16_t) 0x74)
#define RX_FE_OFFSET_CANCEL_PBD_W0S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40074)
#define RX_FE_OFFSET_CANCEL_PBD_W0S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46074)
#define RX_FE_OFFSET_CANCEL_PBD_W0S5__RX_FE_PBD ((uint32_t) 0x6c074)

#define RX_FE_OFFSET_CANCEL_PBD_W0S6 ((uint16_t) 0x76)
#define RX_FE_OFFSET_CANCEL_PBD_W0S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40076)
#define RX_FE_OFFSET_CANCEL_PBD_W0S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46076)
#define RX_FE_OFFSET_CANCEL_PBD_W0S6__RX_FE_PBD ((uint32_t) 0x6c076)

#define RX_FE_OFFSET_CANCEL_PBD_W0S7 ((uint16_t) 0x78)
#define RX_FE_OFFSET_CANCEL_PBD_W0S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40078)
#define RX_FE_OFFSET_CANCEL_PBD_W0S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46078)
#define RX_FE_OFFSET_CANCEL_PBD_W0S7__RX_FE_PBD ((uint32_t) 0x6c078)

#define RX_FE_OFFSET_CANCEL_PBD_W1S0 ((uint16_t) 0x7a)
#define RX_FE_OFFSET_CANCEL_PBD_W1S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4007a)
#define RX_FE_OFFSET_CANCEL_PBD_W1S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4607a)
#define RX_FE_OFFSET_CANCEL_PBD_W1S0__RX_FE_PBD ((uint32_t) 0x6c07a)

#define RX_FE_OFFSET_CANCEL_PBD_W1S1 ((uint16_t) 0x7c)
#define RX_FE_OFFSET_CANCEL_PBD_W1S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4007c)
#define RX_FE_OFFSET_CANCEL_PBD_W1S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4607c)
#define RX_FE_OFFSET_CANCEL_PBD_W1S1__RX_FE_PBD ((uint32_t) 0x6c07c)

#define RX_FE_OFFSET_CANCEL_PBD_W1S2 ((uint16_t) 0x7e)
#define RX_FE_OFFSET_CANCEL_PBD_W1S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4007e)
#define RX_FE_OFFSET_CANCEL_PBD_W1S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4607e)
#define RX_FE_OFFSET_CANCEL_PBD_W1S2__RX_FE_PBD ((uint32_t) 0x6c07e)

#define RX_FE_OFFSET_CANCEL_PBD_W1S3 ((uint16_t) 0x80)
#define RX_FE_OFFSET_CANCEL_PBD_W1S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40080)
#define RX_FE_OFFSET_CANCEL_PBD_W1S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46080)
#define RX_FE_OFFSET_CANCEL_PBD_W1S3__RX_FE_PBD ((uint32_t) 0x6c080)

#define RX_FE_OFFSET_CANCEL_PBD_W1S4 ((uint16_t) 0x82)
#define RX_FE_OFFSET_CANCEL_PBD_W1S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40082)
#define RX_FE_OFFSET_CANCEL_PBD_W1S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46082)
#define RX_FE_OFFSET_CANCEL_PBD_W1S4__RX_FE_PBD ((uint32_t) 0x6c082)

#define RX_FE_OFFSET_CANCEL_PBD_W1S5 ((uint16_t) 0x84)
#define RX_FE_OFFSET_CANCEL_PBD_W1S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40084)
#define RX_FE_OFFSET_CANCEL_PBD_W1S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46084)
#define RX_FE_OFFSET_CANCEL_PBD_W1S5__RX_FE_PBD ((uint32_t) 0x6c084)

#define RX_FE_OFFSET_CANCEL_PBD_W1S6 ((uint16_t) 0x86)
#define RX_FE_OFFSET_CANCEL_PBD_W1S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40086)
#define RX_FE_OFFSET_CANCEL_PBD_W1S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46086)
#define RX_FE_OFFSET_CANCEL_PBD_W1S6__RX_FE_PBD ((uint32_t) 0x6c086)

#define RX_FE_OFFSET_CANCEL_PBD_W1S7 ((uint16_t) 0x88)
#define RX_FE_OFFSET_CANCEL_PBD_W1S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40088)
#define RX_FE_OFFSET_CANCEL_PBD_W1S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46088)
#define RX_FE_OFFSET_CANCEL_PBD_W1S7__RX_FE_PBD ((uint32_t) 0x6c088)

#define RX_FE_OFFSET_CANCEL_PBD_W2S0 ((uint16_t) 0x8a)
#define RX_FE_OFFSET_CANCEL_PBD_W2S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4008a)
#define RX_FE_OFFSET_CANCEL_PBD_W2S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4608a)
#define RX_FE_OFFSET_CANCEL_PBD_W2S0__RX_FE_PBD ((uint32_t) 0x6c08a)

#define RX_FE_OFFSET_CANCEL_PBD_W2S1 ((uint16_t) 0x8c)
#define RX_FE_OFFSET_CANCEL_PBD_W2S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4008c)
#define RX_FE_OFFSET_CANCEL_PBD_W2S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4608c)
#define RX_FE_OFFSET_CANCEL_PBD_W2S1__RX_FE_PBD ((uint32_t) 0x6c08c)

#define RX_FE_OFFSET_CANCEL_PBD_W2S2 ((uint16_t) 0x8e)
#define RX_FE_OFFSET_CANCEL_PBD_W2S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4008e)
#define RX_FE_OFFSET_CANCEL_PBD_W2S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4608e)
#define RX_FE_OFFSET_CANCEL_PBD_W2S2__RX_FE_PBD ((uint32_t) 0x6c08e)

#define RX_FE_OFFSET_CANCEL_PBD_W2S3 ((uint16_t) 0x90)
#define RX_FE_OFFSET_CANCEL_PBD_W2S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40090)
#define RX_FE_OFFSET_CANCEL_PBD_W2S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46090)
#define RX_FE_OFFSET_CANCEL_PBD_W2S3__RX_FE_PBD ((uint32_t) 0x6c090)

#define RX_FE_OFFSET_CANCEL_PBD_W2S4 ((uint16_t) 0x92)
#define RX_FE_OFFSET_CANCEL_PBD_W2S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40092)
#define RX_FE_OFFSET_CANCEL_PBD_W2S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46092)
#define RX_FE_OFFSET_CANCEL_PBD_W2S4__RX_FE_PBD ((uint32_t) 0x6c092)

#define RX_FE_OFFSET_CANCEL_PBD_W2S5 ((uint16_t) 0x94)
#define RX_FE_OFFSET_CANCEL_PBD_W2S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40094)
#define RX_FE_OFFSET_CANCEL_PBD_W2S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46094)
#define RX_FE_OFFSET_CANCEL_PBD_W2S5__RX_FE_PBD ((uint32_t) 0x6c094)

#define RX_FE_OFFSET_CANCEL_PBD_W2S6 ((uint16_t) 0x96)
#define RX_FE_OFFSET_CANCEL_PBD_W2S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40096)
#define RX_FE_OFFSET_CANCEL_PBD_W2S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46096)
#define RX_FE_OFFSET_CANCEL_PBD_W2S6__RX_FE_PBD ((uint32_t) 0x6c096)

#define RX_FE_OFFSET_CANCEL_PBD_W2S7 ((uint16_t) 0x98)
#define RX_FE_OFFSET_CANCEL_PBD_W2S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40098)
#define RX_FE_OFFSET_CANCEL_PBD_W2S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46098)
#define RX_FE_OFFSET_CANCEL_PBD_W2S7__RX_FE_PBD ((uint32_t) 0x6c098)

#define RX_FE_OFFSET_CANCEL_PBD_W3S0 ((uint16_t) 0x9a)
#define RX_FE_OFFSET_CANCEL_PBD_W3S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4009a)
#define RX_FE_OFFSET_CANCEL_PBD_W3S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4609a)
#define RX_FE_OFFSET_CANCEL_PBD_W3S0__RX_FE_PBD ((uint32_t) 0x6c09a)

#define RX_FE_OFFSET_CANCEL_PBD_W3S1 ((uint16_t) 0x9c)
#define RX_FE_OFFSET_CANCEL_PBD_W3S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4009c)
#define RX_FE_OFFSET_CANCEL_PBD_W3S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4609c)
#define RX_FE_OFFSET_CANCEL_PBD_W3S1__RX_FE_PBD ((uint32_t) 0x6c09c)

#define RX_FE_OFFSET_CANCEL_PBD_W3S2 ((uint16_t) 0x9e)
#define RX_FE_OFFSET_CANCEL_PBD_W3S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4009e)
#define RX_FE_OFFSET_CANCEL_PBD_W3S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4609e)
#define RX_FE_OFFSET_CANCEL_PBD_W3S2__RX_FE_PBD ((uint32_t) 0x6c09e)

#define RX_FE_OFFSET_CANCEL_PBD_W3S3 ((uint16_t) 0xa0)
#define RX_FE_OFFSET_CANCEL_PBD_W3S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400a0)
#define RX_FE_OFFSET_CANCEL_PBD_W3S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460a0)
#define RX_FE_OFFSET_CANCEL_PBD_W3S3__RX_FE_PBD ((uint32_t) 0x6c0a0)

#define RX_FE_OFFSET_CANCEL_PBD_W3S4 ((uint16_t) 0xa2)
#define RX_FE_OFFSET_CANCEL_PBD_W3S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400a2)
#define RX_FE_OFFSET_CANCEL_PBD_W3S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460a2)
#define RX_FE_OFFSET_CANCEL_PBD_W3S4__RX_FE_PBD ((uint32_t) 0x6c0a2)

#define RX_FE_OFFSET_CANCEL_PBD_W3S5 ((uint16_t) 0xa4)
#define RX_FE_OFFSET_CANCEL_PBD_W3S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400a4)
#define RX_FE_OFFSET_CANCEL_PBD_W3S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460a4)
#define RX_FE_OFFSET_CANCEL_PBD_W3S5__RX_FE_PBD ((uint32_t) 0x6c0a4)

#define RX_FE_OFFSET_CANCEL_PBD_W3S6 ((uint16_t) 0xa6)
#define RX_FE_OFFSET_CANCEL_PBD_W3S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400a6)
#define RX_FE_OFFSET_CANCEL_PBD_W3S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460a6)
#define RX_FE_OFFSET_CANCEL_PBD_W3S6__RX_FE_PBD ((uint32_t) 0x6c0a6)

#define RX_FE_OFFSET_CANCEL_PBD_W3S7 ((uint16_t) 0xa8)
#define RX_FE_OFFSET_CANCEL_PBD_W3S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400a8)
#define RX_FE_OFFSET_CANCEL_PBD_W3S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460a8)
#define RX_FE_OFFSET_CANCEL_PBD_W3S7__RX_FE_PBD ((uint32_t) 0x6c0a8)

#define RX_FE_OFFSET_CANCEL_PBD_W4S0 ((uint16_t) 0xaa)
#define RX_FE_OFFSET_CANCEL_PBD_W4S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400aa)
#define RX_FE_OFFSET_CANCEL_PBD_W4S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460aa)
#define RX_FE_OFFSET_CANCEL_PBD_W4S0__RX_FE_PBD ((uint32_t) 0x6c0aa)

#define RX_FE_OFFSET_CANCEL_PBD_W4S1 ((uint16_t) 0xac)
#define RX_FE_OFFSET_CANCEL_PBD_W4S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ac)
#define RX_FE_OFFSET_CANCEL_PBD_W4S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ac)
#define RX_FE_OFFSET_CANCEL_PBD_W4S1__RX_FE_PBD ((uint32_t) 0x6c0ac)

#define RX_FE_OFFSET_CANCEL_PBD_W4S2 ((uint16_t) 0xae)
#define RX_FE_OFFSET_CANCEL_PBD_W4S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ae)
#define RX_FE_OFFSET_CANCEL_PBD_W4S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ae)
#define RX_FE_OFFSET_CANCEL_PBD_W4S2__RX_FE_PBD ((uint32_t) 0x6c0ae)

#define RX_FE_OFFSET_CANCEL_PBD_W4S3 ((uint16_t) 0xb0)
#define RX_FE_OFFSET_CANCEL_PBD_W4S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400b0)
#define RX_FE_OFFSET_CANCEL_PBD_W4S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460b0)
#define RX_FE_OFFSET_CANCEL_PBD_W4S3__RX_FE_PBD ((uint32_t) 0x6c0b0)

#define RX_FE_OFFSET_CANCEL_PBD_W4S4 ((uint16_t) 0xb2)
#define RX_FE_OFFSET_CANCEL_PBD_W4S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400b2)
#define RX_FE_OFFSET_CANCEL_PBD_W4S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460b2)
#define RX_FE_OFFSET_CANCEL_PBD_W4S4__RX_FE_PBD ((uint32_t) 0x6c0b2)

#define RX_FE_OFFSET_CANCEL_PBD_W4S5 ((uint16_t) 0xb4)
#define RX_FE_OFFSET_CANCEL_PBD_W4S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400b4)
#define RX_FE_OFFSET_CANCEL_PBD_W4S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460b4)
#define RX_FE_OFFSET_CANCEL_PBD_W4S5__RX_FE_PBD ((uint32_t) 0x6c0b4)

#define RX_FE_OFFSET_CANCEL_PBD_W4S6 ((uint16_t) 0xb6)
#define RX_FE_OFFSET_CANCEL_PBD_W4S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400b6)
#define RX_FE_OFFSET_CANCEL_PBD_W4S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460b6)
#define RX_FE_OFFSET_CANCEL_PBD_W4S6__RX_FE_PBD ((uint32_t) 0x6c0b6)

#define RX_FE_OFFSET_CANCEL_PBD_W4S7 ((uint16_t) 0xb8)
#define RX_FE_OFFSET_CANCEL_PBD_W4S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400b8)
#define RX_FE_OFFSET_CANCEL_PBD_W4S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460b8)
#define RX_FE_OFFSET_CANCEL_PBD_W4S7__RX_FE_PBD ((uint32_t) 0x6c0b8)

#define RX_FE_OFFSET_CANCEL_PBD_W5S0 ((uint16_t) 0xba)
#define RX_FE_OFFSET_CANCEL_PBD_W5S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ba)
#define RX_FE_OFFSET_CANCEL_PBD_W5S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ba)
#define RX_FE_OFFSET_CANCEL_PBD_W5S0__RX_FE_PBD ((uint32_t) 0x6c0ba)

#define RX_FE_OFFSET_CANCEL_PBD_W5S1 ((uint16_t) 0xbc)
#define RX_FE_OFFSET_CANCEL_PBD_W5S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400bc)
#define RX_FE_OFFSET_CANCEL_PBD_W5S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460bc)
#define RX_FE_OFFSET_CANCEL_PBD_W5S1__RX_FE_PBD ((uint32_t) 0x6c0bc)

#define RX_FE_OFFSET_CANCEL_PBD_W5S2 ((uint16_t) 0xbe)
#define RX_FE_OFFSET_CANCEL_PBD_W5S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400be)
#define RX_FE_OFFSET_CANCEL_PBD_W5S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460be)
#define RX_FE_OFFSET_CANCEL_PBD_W5S2__RX_FE_PBD ((uint32_t) 0x6c0be)

#define RX_FE_OFFSET_CANCEL_PBD_W5S3 ((uint16_t) 0xc0)
#define RX_FE_OFFSET_CANCEL_PBD_W5S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400c0)
#define RX_FE_OFFSET_CANCEL_PBD_W5S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460c0)
#define RX_FE_OFFSET_CANCEL_PBD_W5S3__RX_FE_PBD ((uint32_t) 0x6c0c0)

#define RX_FE_OFFSET_CANCEL_PBD_W5S4 ((uint16_t) 0xc2)
#define RX_FE_OFFSET_CANCEL_PBD_W5S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400c2)
#define RX_FE_OFFSET_CANCEL_PBD_W5S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460c2)
#define RX_FE_OFFSET_CANCEL_PBD_W5S4__RX_FE_PBD ((uint32_t) 0x6c0c2)

#define RX_FE_OFFSET_CANCEL_PBD_W5S5 ((uint16_t) 0xc4)
#define RX_FE_OFFSET_CANCEL_PBD_W5S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400c4)
#define RX_FE_OFFSET_CANCEL_PBD_W5S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460c4)
#define RX_FE_OFFSET_CANCEL_PBD_W5S5__RX_FE_PBD ((uint32_t) 0x6c0c4)

#define RX_FE_OFFSET_CANCEL_PBD_W5S6 ((uint16_t) 0xc6)
#define RX_FE_OFFSET_CANCEL_PBD_W5S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400c6)
#define RX_FE_OFFSET_CANCEL_PBD_W5S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460c6)
#define RX_FE_OFFSET_CANCEL_PBD_W5S6__RX_FE_PBD ((uint32_t) 0x6c0c6)

#define RX_FE_OFFSET_CANCEL_PBD_W5S7 ((uint16_t) 0xc8)
#define RX_FE_OFFSET_CANCEL_PBD_W5S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400c8)
#define RX_FE_OFFSET_CANCEL_PBD_W5S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460c8)
#define RX_FE_OFFSET_CANCEL_PBD_W5S7__RX_FE_PBD ((uint32_t) 0x6c0c8)

#define RX_FE_OFFSET_CANCEL_PBD_W6S0 ((uint16_t) 0xca)
#define RX_FE_OFFSET_CANCEL_PBD_W6S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ca)
#define RX_FE_OFFSET_CANCEL_PBD_W6S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ca)
#define RX_FE_OFFSET_CANCEL_PBD_W6S0__RX_FE_PBD ((uint32_t) 0x6c0ca)

#define RX_FE_OFFSET_CANCEL_PBD_W6S1 ((uint16_t) 0xcc)
#define RX_FE_OFFSET_CANCEL_PBD_W6S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400cc)
#define RX_FE_OFFSET_CANCEL_PBD_W6S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460cc)
#define RX_FE_OFFSET_CANCEL_PBD_W6S1__RX_FE_PBD ((uint32_t) 0x6c0cc)

#define RX_FE_OFFSET_CANCEL_PBD_W6S2 ((uint16_t) 0xce)
#define RX_FE_OFFSET_CANCEL_PBD_W6S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ce)
#define RX_FE_OFFSET_CANCEL_PBD_W6S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ce)
#define RX_FE_OFFSET_CANCEL_PBD_W6S2__RX_FE_PBD ((uint32_t) 0x6c0ce)

#define RX_FE_OFFSET_CANCEL_PBD_W6S3 ((uint16_t) 0xd0)
#define RX_FE_OFFSET_CANCEL_PBD_W6S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400d0)
#define RX_FE_OFFSET_CANCEL_PBD_W6S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460d0)
#define RX_FE_OFFSET_CANCEL_PBD_W6S3__RX_FE_PBD ((uint32_t) 0x6c0d0)

#define RX_FE_OFFSET_CANCEL_PBD_W6S4 ((uint16_t) 0xd2)
#define RX_FE_OFFSET_CANCEL_PBD_W6S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400d2)
#define RX_FE_OFFSET_CANCEL_PBD_W6S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460d2)
#define RX_FE_OFFSET_CANCEL_PBD_W6S4__RX_FE_PBD ((uint32_t) 0x6c0d2)

#define RX_FE_OFFSET_CANCEL_PBD_W6S5 ((uint16_t) 0xd4)
#define RX_FE_OFFSET_CANCEL_PBD_W6S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400d4)
#define RX_FE_OFFSET_CANCEL_PBD_W6S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460d4)
#define RX_FE_OFFSET_CANCEL_PBD_W6S5__RX_FE_PBD ((uint32_t) 0x6c0d4)

#define RX_FE_OFFSET_CANCEL_PBD_W6S6 ((uint16_t) 0xd6)
#define RX_FE_OFFSET_CANCEL_PBD_W6S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400d6)
#define RX_FE_OFFSET_CANCEL_PBD_W6S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460d6)
#define RX_FE_OFFSET_CANCEL_PBD_W6S6__RX_FE_PBD ((uint32_t) 0x6c0d6)

#define RX_FE_OFFSET_CANCEL_PBD_W6S7 ((uint16_t) 0xd8)
#define RX_FE_OFFSET_CANCEL_PBD_W6S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400d8)
#define RX_FE_OFFSET_CANCEL_PBD_W6S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460d8)
#define RX_FE_OFFSET_CANCEL_PBD_W6S7__RX_FE_PBD ((uint32_t) 0x6c0d8)

#define RX_FE_OFFSET_CANCEL_PBD_W7S0 ((uint16_t) 0xda)
#define RX_FE_OFFSET_CANCEL_PBD_W7S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400da)
#define RX_FE_OFFSET_CANCEL_PBD_W7S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460da)
#define RX_FE_OFFSET_CANCEL_PBD_W7S0__RX_FE_PBD ((uint32_t) 0x6c0da)

#define RX_FE_OFFSET_CANCEL_PBD_W7S1 ((uint16_t) 0xdc)
#define RX_FE_OFFSET_CANCEL_PBD_W7S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400dc)
#define RX_FE_OFFSET_CANCEL_PBD_W7S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460dc)
#define RX_FE_OFFSET_CANCEL_PBD_W7S1__RX_FE_PBD ((uint32_t) 0x6c0dc)

#define RX_FE_OFFSET_CANCEL_PBD_W7S2 ((uint16_t) 0xde)
#define RX_FE_OFFSET_CANCEL_PBD_W7S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400de)
#define RX_FE_OFFSET_CANCEL_PBD_W7S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460de)
#define RX_FE_OFFSET_CANCEL_PBD_W7S2__RX_FE_PBD ((uint32_t) 0x6c0de)

#define RX_FE_OFFSET_CANCEL_PBD_W7S3 ((uint16_t) 0xe0)
#define RX_FE_OFFSET_CANCEL_PBD_W7S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400e0)
#define RX_FE_OFFSET_CANCEL_PBD_W7S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460e0)
#define RX_FE_OFFSET_CANCEL_PBD_W7S3__RX_FE_PBD ((uint32_t) 0x6c0e0)

#define RX_FE_OFFSET_CANCEL_PBD_W7S4 ((uint16_t) 0xe2)
#define RX_FE_OFFSET_CANCEL_PBD_W7S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400e2)
#define RX_FE_OFFSET_CANCEL_PBD_W7S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460e2)
#define RX_FE_OFFSET_CANCEL_PBD_W7S4__RX_FE_PBD ((uint32_t) 0x6c0e2)

#define RX_FE_OFFSET_CANCEL_PBD_W7S5 ((uint16_t) 0xe4)
#define RX_FE_OFFSET_CANCEL_PBD_W7S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400e4)
#define RX_FE_OFFSET_CANCEL_PBD_W7S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460e4)
#define RX_FE_OFFSET_CANCEL_PBD_W7S5__RX_FE_PBD ((uint32_t) 0x6c0e4)

#define RX_FE_OFFSET_CANCEL_PBD_W7S6 ((uint16_t) 0xe6)
#define RX_FE_OFFSET_CANCEL_PBD_W7S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400e6)
#define RX_FE_OFFSET_CANCEL_PBD_W7S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460e6)
#define RX_FE_OFFSET_CANCEL_PBD_W7S6__RX_FE_PBD ((uint32_t) 0x6c0e6)

#define RX_FE_OFFSET_CANCEL_PBD_W7S7 ((uint16_t) 0xe8)
#define RX_FE_OFFSET_CANCEL_PBD_W7S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400e8)
#define RX_FE_OFFSET_CANCEL_PBD_W7S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460e8)
#define RX_FE_OFFSET_CANCEL_PBD_W7S7__RX_FE_PBD ((uint32_t) 0x6c0e8)

#define RX_FE_OFFSET_CANCEL_PBD_W8S0 ((uint16_t) 0xea)
#define RX_FE_OFFSET_CANCEL_PBD_W8S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ea)
#define RX_FE_OFFSET_CANCEL_PBD_W8S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ea)
#define RX_FE_OFFSET_CANCEL_PBD_W8S0__RX_FE_PBD ((uint32_t) 0x6c0ea)

#define RX_FE_OFFSET_CANCEL_PBD_W8S1 ((uint16_t) 0xec)
#define RX_FE_OFFSET_CANCEL_PBD_W8S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ec)
#define RX_FE_OFFSET_CANCEL_PBD_W8S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ec)
#define RX_FE_OFFSET_CANCEL_PBD_W8S1__RX_FE_PBD ((uint32_t) 0x6c0ec)

#define RX_FE_OFFSET_CANCEL_PBD_W8S2 ((uint16_t) 0xee)
#define RX_FE_OFFSET_CANCEL_PBD_W8S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400ee)
#define RX_FE_OFFSET_CANCEL_PBD_W8S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460ee)
#define RX_FE_OFFSET_CANCEL_PBD_W8S2__RX_FE_PBD ((uint32_t) 0x6c0ee)

#define RX_FE_OFFSET_CANCEL_PBD_W8S3 ((uint16_t) 0xf0)
#define RX_FE_OFFSET_CANCEL_PBD_W8S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400f0)
#define RX_FE_OFFSET_CANCEL_PBD_W8S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460f0)
#define RX_FE_OFFSET_CANCEL_PBD_W8S3__RX_FE_PBD ((uint32_t) 0x6c0f0)

#define RX_FE_OFFSET_CANCEL_PBD_W8S4 ((uint16_t) 0xf2)
#define RX_FE_OFFSET_CANCEL_PBD_W8S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400f2)
#define RX_FE_OFFSET_CANCEL_PBD_W8S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460f2)
#define RX_FE_OFFSET_CANCEL_PBD_W8S4__RX_FE_PBD ((uint32_t) 0x6c0f2)

#define RX_FE_OFFSET_CANCEL_PBD_W8S5 ((uint16_t) 0xf4)
#define RX_FE_OFFSET_CANCEL_PBD_W8S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400f4)
#define RX_FE_OFFSET_CANCEL_PBD_W8S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460f4)
#define RX_FE_OFFSET_CANCEL_PBD_W8S5__RX_FE_PBD ((uint32_t) 0x6c0f4)

#define RX_FE_OFFSET_CANCEL_PBD_W8S6 ((uint16_t) 0xf6)
#define RX_FE_OFFSET_CANCEL_PBD_W8S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400f6)
#define RX_FE_OFFSET_CANCEL_PBD_W8S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460f6)
#define RX_FE_OFFSET_CANCEL_PBD_W8S6__RX_FE_PBD ((uint32_t) 0x6c0f6)

#define RX_FE_OFFSET_CANCEL_PBD_W8S7 ((uint16_t) 0xf8)
#define RX_FE_OFFSET_CANCEL_PBD_W8S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400f8)
#define RX_FE_OFFSET_CANCEL_PBD_W8S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460f8)
#define RX_FE_OFFSET_CANCEL_PBD_W8S7__RX_FE_PBD ((uint32_t) 0x6c0f8)

#define RX_FE_OFFSET_CANCEL_PBD_W9S0 ((uint16_t) 0xfa)
#define RX_FE_OFFSET_CANCEL_PBD_W9S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400fa)
#define RX_FE_OFFSET_CANCEL_PBD_W9S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460fa)
#define RX_FE_OFFSET_CANCEL_PBD_W9S0__RX_FE_PBD ((uint32_t) 0x6c0fa)

#define RX_FE_OFFSET_CANCEL_PBD_W9S1 ((uint16_t) 0xfc)
#define RX_FE_OFFSET_CANCEL_PBD_W9S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400fc)
#define RX_FE_OFFSET_CANCEL_PBD_W9S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460fc)
#define RX_FE_OFFSET_CANCEL_PBD_W9S1__RX_FE_PBD ((uint32_t) 0x6c0fc)

#define RX_FE_OFFSET_CANCEL_PBD_W9S2 ((uint16_t) 0xfe)
#define RX_FE_OFFSET_CANCEL_PBD_W9S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x400fe)
#define RX_FE_OFFSET_CANCEL_PBD_W9S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x460fe)
#define RX_FE_OFFSET_CANCEL_PBD_W9S2__RX_FE_PBD ((uint32_t) 0x6c0fe)

#define RX_FE_OFFSET_CANCEL_PBD_W9S3 ((uint16_t) 0x100)
#define RX_FE_OFFSET_CANCEL_PBD_W9S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40100)
#define RX_FE_OFFSET_CANCEL_PBD_W9S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46100)
#define RX_FE_OFFSET_CANCEL_PBD_W9S3__RX_FE_PBD ((uint32_t) 0x6c100)

#define RX_FE_OFFSET_CANCEL_PBD_W9S4 ((uint16_t) 0x102)
#define RX_FE_OFFSET_CANCEL_PBD_W9S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40102)
#define RX_FE_OFFSET_CANCEL_PBD_W9S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46102)
#define RX_FE_OFFSET_CANCEL_PBD_W9S4__RX_FE_PBD ((uint32_t) 0x6c102)

#define RX_FE_OFFSET_CANCEL_PBD_W9S5 ((uint16_t) 0x104)
#define RX_FE_OFFSET_CANCEL_PBD_W9S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40104)
#define RX_FE_OFFSET_CANCEL_PBD_W9S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46104)
#define RX_FE_OFFSET_CANCEL_PBD_W9S5__RX_FE_PBD ((uint32_t) 0x6c104)

#define RX_FE_OFFSET_CANCEL_PBD_W9S6 ((uint16_t) 0x106)
#define RX_FE_OFFSET_CANCEL_PBD_W9S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40106)
#define RX_FE_OFFSET_CANCEL_PBD_W9S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46106)
#define RX_FE_OFFSET_CANCEL_PBD_W9S6__RX_FE_PBD ((uint32_t) 0x6c106)

#define RX_FE_OFFSET_CANCEL_PBD_W9S7 ((uint16_t) 0x108)
#define RX_FE_OFFSET_CANCEL_PBD_W9S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40108)
#define RX_FE_OFFSET_CANCEL_PBD_W9S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46108)
#define RX_FE_OFFSET_CANCEL_PBD_W9S7__RX_FE_PBD ((uint32_t) 0x6c108)

#define RX_FE_OFFSET_CANCEL_PBD_W10S0 ((uint16_t) 0x10a)
#define RX_FE_OFFSET_CANCEL_PBD_W10S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4010a)
#define RX_FE_OFFSET_CANCEL_PBD_W10S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4610a)
#define RX_FE_OFFSET_CANCEL_PBD_W10S0__RX_FE_PBD ((uint32_t) 0x6c10a)

#define RX_FE_OFFSET_CANCEL_PBD_W10S1 ((uint16_t) 0x10c)
#define RX_FE_OFFSET_CANCEL_PBD_W10S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4010c)
#define RX_FE_OFFSET_CANCEL_PBD_W10S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4610c)
#define RX_FE_OFFSET_CANCEL_PBD_W10S1__RX_FE_PBD ((uint32_t) 0x6c10c)

#define RX_FE_OFFSET_CANCEL_PBD_W10S2 ((uint16_t) 0x10e)
#define RX_FE_OFFSET_CANCEL_PBD_W10S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4010e)
#define RX_FE_OFFSET_CANCEL_PBD_W10S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4610e)
#define RX_FE_OFFSET_CANCEL_PBD_W10S2__RX_FE_PBD ((uint32_t) 0x6c10e)

#define RX_FE_OFFSET_CANCEL_PBD_W10S3 ((uint16_t) 0x110)
#define RX_FE_OFFSET_CANCEL_PBD_W10S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40110)
#define RX_FE_OFFSET_CANCEL_PBD_W10S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46110)
#define RX_FE_OFFSET_CANCEL_PBD_W10S3__RX_FE_PBD ((uint32_t) 0x6c110)

#define RX_FE_OFFSET_CANCEL_PBD_W10S4 ((uint16_t) 0x112)
#define RX_FE_OFFSET_CANCEL_PBD_W10S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40112)
#define RX_FE_OFFSET_CANCEL_PBD_W10S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46112)
#define RX_FE_OFFSET_CANCEL_PBD_W10S4__RX_FE_PBD ((uint32_t) 0x6c112)

#define RX_FE_OFFSET_CANCEL_PBD_W10S5 ((uint16_t) 0x114)
#define RX_FE_OFFSET_CANCEL_PBD_W10S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40114)
#define RX_FE_OFFSET_CANCEL_PBD_W10S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46114)
#define RX_FE_OFFSET_CANCEL_PBD_W10S5__RX_FE_PBD ((uint32_t) 0x6c114)

#define RX_FE_OFFSET_CANCEL_PBD_W10S6 ((uint16_t) 0x116)
#define RX_FE_OFFSET_CANCEL_PBD_W10S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40116)
#define RX_FE_OFFSET_CANCEL_PBD_W10S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46116)
#define RX_FE_OFFSET_CANCEL_PBD_W10S6__RX_FE_PBD ((uint32_t) 0x6c116)

#define RX_FE_OFFSET_CANCEL_PBD_W10S7 ((uint16_t) 0x118)
#define RX_FE_OFFSET_CANCEL_PBD_W10S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40118)
#define RX_FE_OFFSET_CANCEL_PBD_W10S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46118)
#define RX_FE_OFFSET_CANCEL_PBD_W10S7__RX_FE_PBD ((uint32_t) 0x6c118)

#define RX_FE_OFFSET_CANCEL_PBD_W11S0 ((uint16_t) 0x11a)
#define RX_FE_OFFSET_CANCEL_PBD_W11S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4011a)
#define RX_FE_OFFSET_CANCEL_PBD_W11S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4611a)
#define RX_FE_OFFSET_CANCEL_PBD_W11S0__RX_FE_PBD ((uint32_t) 0x6c11a)

#define RX_FE_OFFSET_CANCEL_PBD_W11S1 ((uint16_t) 0x11c)
#define RX_FE_OFFSET_CANCEL_PBD_W11S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4011c)
#define RX_FE_OFFSET_CANCEL_PBD_W11S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4611c)
#define RX_FE_OFFSET_CANCEL_PBD_W11S1__RX_FE_PBD ((uint32_t) 0x6c11c)

#define RX_FE_OFFSET_CANCEL_PBD_W11S2 ((uint16_t) 0x11e)
#define RX_FE_OFFSET_CANCEL_PBD_W11S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4011e)
#define RX_FE_OFFSET_CANCEL_PBD_W11S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4611e)
#define RX_FE_OFFSET_CANCEL_PBD_W11S2__RX_FE_PBD ((uint32_t) 0x6c11e)

#define RX_FE_OFFSET_CANCEL_PBD_W11S3 ((uint16_t) 0x120)
#define RX_FE_OFFSET_CANCEL_PBD_W11S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40120)
#define RX_FE_OFFSET_CANCEL_PBD_W11S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46120)
#define RX_FE_OFFSET_CANCEL_PBD_W11S3__RX_FE_PBD ((uint32_t) 0x6c120)

#define RX_FE_OFFSET_CANCEL_PBD_W11S4 ((uint16_t) 0x122)
#define RX_FE_OFFSET_CANCEL_PBD_W11S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40122)
#define RX_FE_OFFSET_CANCEL_PBD_W11S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46122)
#define RX_FE_OFFSET_CANCEL_PBD_W11S4__RX_FE_PBD ((uint32_t) 0x6c122)

#define RX_FE_OFFSET_CANCEL_PBD_W11S5 ((uint16_t) 0x124)
#define RX_FE_OFFSET_CANCEL_PBD_W11S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40124)
#define RX_FE_OFFSET_CANCEL_PBD_W11S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46124)
#define RX_FE_OFFSET_CANCEL_PBD_W11S5__RX_FE_PBD ((uint32_t) 0x6c124)

#define RX_FE_OFFSET_CANCEL_PBD_W11S6 ((uint16_t) 0x126)
#define RX_FE_OFFSET_CANCEL_PBD_W11S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40126)
#define RX_FE_OFFSET_CANCEL_PBD_W11S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46126)
#define RX_FE_OFFSET_CANCEL_PBD_W11S6__RX_FE_PBD ((uint32_t) 0x6c126)

#define RX_FE_OFFSET_CANCEL_PBD_W11S7 ((uint16_t) 0x128)
#define RX_FE_OFFSET_CANCEL_PBD_W11S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40128)
#define RX_FE_OFFSET_CANCEL_PBD_W11S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46128)
#define RX_FE_OFFSET_CANCEL_PBD_W11S7__RX_FE_PBD ((uint32_t) 0x6c128)

#define RX_FE_OFFSET_CANCEL_PBD_W12S0 ((uint16_t) 0x12a)
#define RX_FE_OFFSET_CANCEL_PBD_W12S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4012a)
#define RX_FE_OFFSET_CANCEL_PBD_W12S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4612a)
#define RX_FE_OFFSET_CANCEL_PBD_W12S0__RX_FE_PBD ((uint32_t) 0x6c12a)

#define RX_FE_OFFSET_CANCEL_PBD_W12S1 ((uint16_t) 0x12c)
#define RX_FE_OFFSET_CANCEL_PBD_W12S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4012c)
#define RX_FE_OFFSET_CANCEL_PBD_W12S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4612c)
#define RX_FE_OFFSET_CANCEL_PBD_W12S1__RX_FE_PBD ((uint32_t) 0x6c12c)

#define RX_FE_OFFSET_CANCEL_PBD_W12S2 ((uint16_t) 0x12e)
#define RX_FE_OFFSET_CANCEL_PBD_W12S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4012e)
#define RX_FE_OFFSET_CANCEL_PBD_W12S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4612e)
#define RX_FE_OFFSET_CANCEL_PBD_W12S2__RX_FE_PBD ((uint32_t) 0x6c12e)

#define RX_FE_OFFSET_CANCEL_PBD_W12S3 ((uint16_t) 0x130)
#define RX_FE_OFFSET_CANCEL_PBD_W12S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40130)
#define RX_FE_OFFSET_CANCEL_PBD_W12S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46130)
#define RX_FE_OFFSET_CANCEL_PBD_W12S3__RX_FE_PBD ((uint32_t) 0x6c130)

#define RX_FE_OFFSET_CANCEL_PBD_W12S4 ((uint16_t) 0x132)
#define RX_FE_OFFSET_CANCEL_PBD_W12S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40132)
#define RX_FE_OFFSET_CANCEL_PBD_W12S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46132)
#define RX_FE_OFFSET_CANCEL_PBD_W12S4__RX_FE_PBD ((uint32_t) 0x6c132)

#define RX_FE_OFFSET_CANCEL_PBD_W12S5 ((uint16_t) 0x134)
#define RX_FE_OFFSET_CANCEL_PBD_W12S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40134)
#define RX_FE_OFFSET_CANCEL_PBD_W12S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46134)
#define RX_FE_OFFSET_CANCEL_PBD_W12S5__RX_FE_PBD ((uint32_t) 0x6c134)

#define RX_FE_OFFSET_CANCEL_PBD_W12S6 ((uint16_t) 0x136)
#define RX_FE_OFFSET_CANCEL_PBD_W12S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40136)
#define RX_FE_OFFSET_CANCEL_PBD_W12S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46136)
#define RX_FE_OFFSET_CANCEL_PBD_W12S6__RX_FE_PBD ((uint32_t) 0x6c136)

#define RX_FE_OFFSET_CANCEL_PBD_W12S7 ((uint16_t) 0x138)
#define RX_FE_OFFSET_CANCEL_PBD_W12S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40138)
#define RX_FE_OFFSET_CANCEL_PBD_W12S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46138)
#define RX_FE_OFFSET_CANCEL_PBD_W12S7__RX_FE_PBD ((uint32_t) 0x6c138)

#define RX_FE_OFFSET_CANCEL_PBD_W13S0 ((uint16_t) 0x13a)
#define RX_FE_OFFSET_CANCEL_PBD_W13S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4013a)
#define RX_FE_OFFSET_CANCEL_PBD_W13S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4613a)
#define RX_FE_OFFSET_CANCEL_PBD_W13S0__RX_FE_PBD ((uint32_t) 0x6c13a)

#define RX_FE_OFFSET_CANCEL_PBD_W13S1 ((uint16_t) 0x13c)
#define RX_FE_OFFSET_CANCEL_PBD_W13S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4013c)
#define RX_FE_OFFSET_CANCEL_PBD_W13S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4613c)
#define RX_FE_OFFSET_CANCEL_PBD_W13S1__RX_FE_PBD ((uint32_t) 0x6c13c)

#define RX_FE_OFFSET_CANCEL_PBD_W13S2 ((uint16_t) 0x13e)
#define RX_FE_OFFSET_CANCEL_PBD_W13S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4013e)
#define RX_FE_OFFSET_CANCEL_PBD_W13S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4613e)
#define RX_FE_OFFSET_CANCEL_PBD_W13S2__RX_FE_PBD ((uint32_t) 0x6c13e)

#define RX_FE_OFFSET_CANCEL_PBD_W13S3 ((uint16_t) 0x140)
#define RX_FE_OFFSET_CANCEL_PBD_W13S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40140)
#define RX_FE_OFFSET_CANCEL_PBD_W13S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46140)
#define RX_FE_OFFSET_CANCEL_PBD_W13S3__RX_FE_PBD ((uint32_t) 0x6c140)

#define RX_FE_OFFSET_CANCEL_PBD_W13S4 ((uint16_t) 0x142)
#define RX_FE_OFFSET_CANCEL_PBD_W13S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40142)
#define RX_FE_OFFSET_CANCEL_PBD_W13S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46142)
#define RX_FE_OFFSET_CANCEL_PBD_W13S4__RX_FE_PBD ((uint32_t) 0x6c142)

#define RX_FE_OFFSET_CANCEL_PBD_W13S5 ((uint16_t) 0x144)
#define RX_FE_OFFSET_CANCEL_PBD_W13S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40144)
#define RX_FE_OFFSET_CANCEL_PBD_W13S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46144)
#define RX_FE_OFFSET_CANCEL_PBD_W13S5__RX_FE_PBD ((uint32_t) 0x6c144)

#define RX_FE_OFFSET_CANCEL_PBD_W13S6 ((uint16_t) 0x146)
#define RX_FE_OFFSET_CANCEL_PBD_W13S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40146)
#define RX_FE_OFFSET_CANCEL_PBD_W13S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46146)
#define RX_FE_OFFSET_CANCEL_PBD_W13S6__RX_FE_PBD ((uint32_t) 0x6c146)

#define RX_FE_OFFSET_CANCEL_PBD_W13S7 ((uint16_t) 0x148)
#define RX_FE_OFFSET_CANCEL_PBD_W13S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40148)
#define RX_FE_OFFSET_CANCEL_PBD_W13S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46148)
#define RX_FE_OFFSET_CANCEL_PBD_W13S7__RX_FE_PBD ((uint32_t) 0x6c148)

#define RX_FE_OFFSET_CANCEL_PBD_W14S0 ((uint16_t) 0x14a)
#define RX_FE_OFFSET_CANCEL_PBD_W14S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4014a)
#define RX_FE_OFFSET_CANCEL_PBD_W14S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4614a)
#define RX_FE_OFFSET_CANCEL_PBD_W14S0__RX_FE_PBD ((uint32_t) 0x6c14a)

#define RX_FE_OFFSET_CANCEL_PBD_W14S1 ((uint16_t) 0x14c)
#define RX_FE_OFFSET_CANCEL_PBD_W14S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4014c)
#define RX_FE_OFFSET_CANCEL_PBD_W14S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4614c)
#define RX_FE_OFFSET_CANCEL_PBD_W14S1__RX_FE_PBD ((uint32_t) 0x6c14c)

#define RX_FE_OFFSET_CANCEL_PBD_W14S2 ((uint16_t) 0x14e)
#define RX_FE_OFFSET_CANCEL_PBD_W14S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4014e)
#define RX_FE_OFFSET_CANCEL_PBD_W14S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4614e)
#define RX_FE_OFFSET_CANCEL_PBD_W14S2__RX_FE_PBD ((uint32_t) 0x6c14e)

#define RX_FE_OFFSET_CANCEL_PBD_W14S3 ((uint16_t) 0x150)
#define RX_FE_OFFSET_CANCEL_PBD_W14S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40150)
#define RX_FE_OFFSET_CANCEL_PBD_W14S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46150)
#define RX_FE_OFFSET_CANCEL_PBD_W14S3__RX_FE_PBD ((uint32_t) 0x6c150)

#define RX_FE_OFFSET_CANCEL_PBD_W14S4 ((uint16_t) 0x152)
#define RX_FE_OFFSET_CANCEL_PBD_W14S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40152)
#define RX_FE_OFFSET_CANCEL_PBD_W14S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46152)
#define RX_FE_OFFSET_CANCEL_PBD_W14S4__RX_FE_PBD ((uint32_t) 0x6c152)

#define RX_FE_OFFSET_CANCEL_PBD_W14S5 ((uint16_t) 0x154)
#define RX_FE_OFFSET_CANCEL_PBD_W14S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40154)
#define RX_FE_OFFSET_CANCEL_PBD_W14S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46154)
#define RX_FE_OFFSET_CANCEL_PBD_W14S5__RX_FE_PBD ((uint32_t) 0x6c154)

#define RX_FE_OFFSET_CANCEL_PBD_W14S6 ((uint16_t) 0x156)
#define RX_FE_OFFSET_CANCEL_PBD_W14S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40156)
#define RX_FE_OFFSET_CANCEL_PBD_W14S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46156)
#define RX_FE_OFFSET_CANCEL_PBD_W14S6__RX_FE_PBD ((uint32_t) 0x6c156)

#define RX_FE_OFFSET_CANCEL_PBD_W14S7 ((uint16_t) 0x158)
#define RX_FE_OFFSET_CANCEL_PBD_W14S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40158)
#define RX_FE_OFFSET_CANCEL_PBD_W14S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46158)
#define RX_FE_OFFSET_CANCEL_PBD_W14S7__RX_FE_PBD ((uint32_t) 0x6c158)

#define RX_FE_OFFSET_CANCEL_PBD_W15S0 ((uint16_t) 0x15a)
#define RX_FE_OFFSET_CANCEL_PBD_W15S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4015a)
#define RX_FE_OFFSET_CANCEL_PBD_W15S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4615a)
#define RX_FE_OFFSET_CANCEL_PBD_W15S0__RX_FE_PBD ((uint32_t) 0x6c15a)

#define RX_FE_OFFSET_CANCEL_PBD_W15S1 ((uint16_t) 0x15c)
#define RX_FE_OFFSET_CANCEL_PBD_W15S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4015c)
#define RX_FE_OFFSET_CANCEL_PBD_W15S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4615c)
#define RX_FE_OFFSET_CANCEL_PBD_W15S1__RX_FE_PBD ((uint32_t) 0x6c15c)

#define RX_FE_OFFSET_CANCEL_PBD_W15S2 ((uint16_t) 0x15e)
#define RX_FE_OFFSET_CANCEL_PBD_W15S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4015e)
#define RX_FE_OFFSET_CANCEL_PBD_W15S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4615e)
#define RX_FE_OFFSET_CANCEL_PBD_W15S2__RX_FE_PBD ((uint32_t) 0x6c15e)

#define RX_FE_OFFSET_CANCEL_PBD_W15S3 ((uint16_t) 0x160)
#define RX_FE_OFFSET_CANCEL_PBD_W15S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40160)
#define RX_FE_OFFSET_CANCEL_PBD_W15S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46160)
#define RX_FE_OFFSET_CANCEL_PBD_W15S3__RX_FE_PBD ((uint32_t) 0x6c160)

#define RX_FE_OFFSET_CANCEL_PBD_W15S4 ((uint16_t) 0x162)
#define RX_FE_OFFSET_CANCEL_PBD_W15S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40162)
#define RX_FE_OFFSET_CANCEL_PBD_W15S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46162)
#define RX_FE_OFFSET_CANCEL_PBD_W15S4__RX_FE_PBD ((uint32_t) 0x6c162)

#define RX_FE_OFFSET_CANCEL_PBD_W15S5 ((uint16_t) 0x164)
#define RX_FE_OFFSET_CANCEL_PBD_W15S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40164)
#define RX_FE_OFFSET_CANCEL_PBD_W15S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46164)
#define RX_FE_OFFSET_CANCEL_PBD_W15S5__RX_FE_PBD ((uint32_t) 0x6c164)

#define RX_FE_OFFSET_CANCEL_PBD_W15S6 ((uint16_t) 0x166)
#define RX_FE_OFFSET_CANCEL_PBD_W15S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40166)
#define RX_FE_OFFSET_CANCEL_PBD_W15S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46166)
#define RX_FE_OFFSET_CANCEL_PBD_W15S6__RX_FE_PBD ((uint32_t) 0x6c166)

#define RX_FE_OFFSET_CANCEL_PBD_W15S7 ((uint16_t) 0x168)
#define RX_FE_OFFSET_CANCEL_PBD_W15S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40168)
#define RX_FE_OFFSET_CANCEL_PBD_W15S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46168)
#define RX_FE_OFFSET_CANCEL_PBD_W15S7__RX_FE_PBD ((uint32_t) 0x6c168)

#define RX_FE_OFFSET_CANCEL_PBD_W16S0 ((uint16_t) 0x16a)
#define RX_FE_OFFSET_CANCEL_PBD_W16S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4016a)
#define RX_FE_OFFSET_CANCEL_PBD_W16S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4616a)
#define RX_FE_OFFSET_CANCEL_PBD_W16S0__RX_FE_PBD ((uint32_t) 0x6c16a)

#define RX_FE_OFFSET_CANCEL_PBD_W16S1 ((uint16_t) 0x16c)
#define RX_FE_OFFSET_CANCEL_PBD_W16S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4016c)
#define RX_FE_OFFSET_CANCEL_PBD_W16S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4616c)
#define RX_FE_OFFSET_CANCEL_PBD_W16S1__RX_FE_PBD ((uint32_t) 0x6c16c)

#define RX_FE_OFFSET_CANCEL_PBD_W16S2 ((uint16_t) 0x16e)
#define RX_FE_OFFSET_CANCEL_PBD_W16S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4016e)
#define RX_FE_OFFSET_CANCEL_PBD_W16S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4616e)
#define RX_FE_OFFSET_CANCEL_PBD_W16S2__RX_FE_PBD ((uint32_t) 0x6c16e)

#define RX_FE_OFFSET_CANCEL_PBD_W16S3 ((uint16_t) 0x170)
#define RX_FE_OFFSET_CANCEL_PBD_W16S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40170)
#define RX_FE_OFFSET_CANCEL_PBD_W16S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46170)
#define RX_FE_OFFSET_CANCEL_PBD_W16S3__RX_FE_PBD ((uint32_t) 0x6c170)

#define RX_FE_OFFSET_CANCEL_PBD_W16S4 ((uint16_t) 0x172)
#define RX_FE_OFFSET_CANCEL_PBD_W16S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40172)
#define RX_FE_OFFSET_CANCEL_PBD_W16S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46172)
#define RX_FE_OFFSET_CANCEL_PBD_W16S4__RX_FE_PBD ((uint32_t) 0x6c172)

#define RX_FE_OFFSET_CANCEL_PBD_W16S5 ((uint16_t) 0x174)
#define RX_FE_OFFSET_CANCEL_PBD_W16S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40174)
#define RX_FE_OFFSET_CANCEL_PBD_W16S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46174)
#define RX_FE_OFFSET_CANCEL_PBD_W16S5__RX_FE_PBD ((uint32_t) 0x6c174)

#define RX_FE_OFFSET_CANCEL_PBD_W16S6 ((uint16_t) 0x176)
#define RX_FE_OFFSET_CANCEL_PBD_W16S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40176)
#define RX_FE_OFFSET_CANCEL_PBD_W16S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46176)
#define RX_FE_OFFSET_CANCEL_PBD_W16S6__RX_FE_PBD ((uint32_t) 0x6c176)

#define RX_FE_OFFSET_CANCEL_PBD_W16S7 ((uint16_t) 0x178)
#define RX_FE_OFFSET_CANCEL_PBD_W16S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40178)
#define RX_FE_OFFSET_CANCEL_PBD_W16S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46178)
#define RX_FE_OFFSET_CANCEL_PBD_W16S7__RX_FE_PBD ((uint32_t) 0x6c178)

#define RX_FE_OFFSET_CANCEL_PBD_W17S0 ((uint16_t) 0x17a)
#define RX_FE_OFFSET_CANCEL_PBD_W17S0__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4017a)
#define RX_FE_OFFSET_CANCEL_PBD_W17S0__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4617a)
#define RX_FE_OFFSET_CANCEL_PBD_W17S0__RX_FE_PBD ((uint32_t) 0x6c17a)

#define RX_FE_OFFSET_CANCEL_PBD_W17S1 ((uint16_t) 0x17c)
#define RX_FE_OFFSET_CANCEL_PBD_W17S1__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4017c)
#define RX_FE_OFFSET_CANCEL_PBD_W17S1__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4617c)
#define RX_FE_OFFSET_CANCEL_PBD_W17S1__RX_FE_PBD ((uint32_t) 0x6c17c)

#define RX_FE_OFFSET_CANCEL_PBD_W17S2 ((uint16_t) 0x17e)
#define RX_FE_OFFSET_CANCEL_PBD_W17S2__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x4017e)
#define RX_FE_OFFSET_CANCEL_PBD_W17S2__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x4617e)
#define RX_FE_OFFSET_CANCEL_PBD_W17S2__RX_FE_PBD ((uint32_t) 0x6c17e)

#define RX_FE_OFFSET_CANCEL_PBD_W17S3 ((uint16_t) 0x180)
#define RX_FE_OFFSET_CANCEL_PBD_W17S3__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40180)
#define RX_FE_OFFSET_CANCEL_PBD_W17S3__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46180)
#define RX_FE_OFFSET_CANCEL_PBD_W17S3__RX_FE_PBD ((uint32_t) 0x6c180)

#define RX_FE_OFFSET_CANCEL_PBD_W17S4 ((uint16_t) 0x182)
#define RX_FE_OFFSET_CANCEL_PBD_W17S4__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40182)
#define RX_FE_OFFSET_CANCEL_PBD_W17S4__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46182)
#define RX_FE_OFFSET_CANCEL_PBD_W17S4__RX_FE_PBD ((uint32_t) 0x6c182)

#define RX_FE_OFFSET_CANCEL_PBD_W17S5 ((uint16_t) 0x184)
#define RX_FE_OFFSET_CANCEL_PBD_W17S5__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40184)
#define RX_FE_OFFSET_CANCEL_PBD_W17S5__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46184)
#define RX_FE_OFFSET_CANCEL_PBD_W17S5__RX_FE_PBD ((uint32_t) 0x6c184)

#define RX_FE_OFFSET_CANCEL_PBD_W17S6 ((uint16_t) 0x186)
#define RX_FE_OFFSET_CANCEL_PBD_W17S6__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40186)
#define RX_FE_OFFSET_CANCEL_PBD_W17S6__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46186)
#define RX_FE_OFFSET_CANCEL_PBD_W17S6__RX_FE_PBD ((uint32_t) 0x6c186)

#define RX_FE_OFFSET_CANCEL_PBD_W17S7 ((uint16_t) 0x188)
#define RX_FE_OFFSET_CANCEL_PBD_W17S7__RX_FE_OFFSET_CANCEL_SIG ((uint32_t) 0x40188)
#define RX_FE_OFFSET_CANCEL_PBD_W17S7__RX_FE_OFFSET_CANCEL_REF ((uint32_t) 0x46188)
#define RX_FE_OFFSET_CANCEL_PBD_W17S7__RX_FE_PBD ((uint32_t) 0x6c188)

#define RX_FE_CONFIG_W0 ((uint16_t) 0x18a)
#define RX_FE_CONFIG_W0__RX_FE_PRE_VSS ((uint32_t) 0x18a)
#define RX_FE_CONFIG_W0__RX_FE_KICK_EN ((uint32_t) 0x218a)
#define RX_FE_CONFIG_W0__RX_FE_IN_P_RST_EN ((uint32_t) 0x418a)
#define RX_FE_CONFIG_W0__RX_FE_IN_N_RST_EN ((uint32_t) 0x618a)

#define RX_FE_CONFIG_W1 ((uint16_t) 0x18c)
#define RX_FE_CONFIG_W1__RX_FE_PRE_VSS ((uint32_t) 0x18c)
#define RX_FE_CONFIG_W1__RX_FE_KICK_EN ((uint32_t) 0x218c)
#define RX_FE_CONFIG_W1__RX_FE_IN_P_RST_EN ((uint32_t) 0x418c)
#define RX_FE_CONFIG_W1__RX_FE_IN_N_RST_EN ((uint32_t) 0x618c)

#define RX_FE_CONFIG_W2 ((uint16_t) 0x18e)
#define RX_FE_CONFIG_W2__RX_FE_PRE_VSS ((uint32_t) 0x18e)
#define RX_FE_CONFIG_W2__RX_FE_KICK_EN ((uint32_t) 0x218e)
#define RX_FE_CONFIG_W2__RX_FE_IN_P_RST_EN ((uint32_t) 0x418e)
#define RX_FE_CONFIG_W2__RX_FE_IN_N_RST_EN ((uint32_t) 0x618e)

#define RX_FE_CONFIG_W3 ((uint16_t) 0x190)
#define RX_FE_CONFIG_W3__RX_FE_PRE_VSS ((uint32_t) 0x190)
#define RX_FE_CONFIG_W3__RX_FE_KICK_EN ((uint32_t) 0x2190)
#define RX_FE_CONFIG_W3__RX_FE_IN_P_RST_EN ((uint32_t) 0x4190)
#define RX_FE_CONFIG_W3__RX_FE_IN_N_RST_EN ((uint32_t) 0x6190)

#define RX_FE_CONFIG_W4 ((uint16_t) 0x192)
#define RX_FE_CONFIG_W4__RX_FE_PRE_VSS ((uint32_t) 0x192)
#define RX_FE_CONFIG_W4__RX_FE_KICK_EN ((uint32_t) 0x2192)
#define RX_FE_CONFIG_W4__RX_FE_IN_P_RST_EN ((uint32_t) 0x4192)
#define RX_FE_CONFIG_W4__RX_FE_IN_N_RST_EN ((uint32_t) 0x6192)

#define RX_FE_CONFIG_W5 ((uint16_t) 0x194)
#define RX_FE_CONFIG_W5__RX_FE_PRE_VSS ((uint32_t) 0x194)
#define RX_FE_CONFIG_W5__RX_FE_KICK_EN ((uint32_t) 0x2194)
#define RX_FE_CONFIG_W5__RX_FE_IN_P_RST_EN ((uint32_t) 0x4194)
#define RX_FE_CONFIG_W5__RX_FE_IN_N_RST_EN ((uint32_t) 0x6194)

#define RX_FE_CONFIG_W6 ((uint16_t) 0x196)
#define RX_FE_CONFIG_W6__RX_FE_PRE_VSS ((uint32_t) 0x196)
#define RX_FE_CONFIG_W6__RX_FE_KICK_EN ((uint32_t) 0x2196)
#define RX_FE_CONFIG_W6__RX_FE_IN_P_RST_EN ((uint32_t) 0x4196)
#define RX_FE_CONFIG_W6__RX_FE_IN_N_RST_EN ((uint32_t) 0x6196)

#define RX_FE_CONFIG_W7 ((uint16_t) 0x198)
#define RX_FE_CONFIG_W7__RX_FE_PRE_VSS ((uint32_t) 0x198)
#define RX_FE_CONFIG_W7__RX_FE_KICK_EN ((uint32_t) 0x2198)
#define RX_FE_CONFIG_W7__RX_FE_IN_P_RST_EN ((uint32_t) 0x4198)
#define RX_FE_CONFIG_W7__RX_FE_IN_N_RST_EN ((uint32_t) 0x6198)

#define RX_FE_CONFIG_W8 ((uint16_t) 0x19a)
#define RX_FE_CONFIG_W8__RX_FE_PRE_VSS ((uint32_t) 0x19a)
#define RX_FE_CONFIG_W8__RX_FE_KICK_EN ((uint32_t) 0x219a)
#define RX_FE_CONFIG_W8__RX_FE_IN_P_RST_EN ((uint32_t) 0x419a)
#define RX_FE_CONFIG_W8__RX_FE_IN_N_RST_EN ((uint32_t) 0x619a)

#define RX_FE_CONFIG_W9 ((uint16_t) 0x19c)
#define RX_FE_CONFIG_W9__RX_FE_PRE_VSS ((uint32_t) 0x19c)
#define RX_FE_CONFIG_W9__RX_FE_KICK_EN ((uint32_t) 0x219c)
#define RX_FE_CONFIG_W9__RX_FE_IN_P_RST_EN ((uint32_t) 0x419c)
#define RX_FE_CONFIG_W9__RX_FE_IN_N_RST_EN ((uint32_t) 0x619c)

#define RX_FE_CONFIG_W10 ((uint16_t) 0x19e)
#define RX_FE_CONFIG_W10__RX_FE_PRE_VSS ((uint32_t) 0x19e)
#define RX_FE_CONFIG_W10__RX_FE_KICK_EN ((uint32_t) 0x219e)
#define RX_FE_CONFIG_W10__RX_FE_IN_P_RST_EN ((uint32_t) 0x419e)
#define RX_FE_CONFIG_W10__RX_FE_IN_N_RST_EN ((uint32_t) 0x619e)

#define RX_FE_CONFIG_W11 ((uint16_t) 0x1a0)
#define RX_FE_CONFIG_W11__RX_FE_PRE_VSS ((uint32_t) 0x1a0)
#define RX_FE_CONFIG_W11__RX_FE_KICK_EN ((uint32_t) 0x21a0)
#define RX_FE_CONFIG_W11__RX_FE_IN_P_RST_EN ((uint32_t) 0x41a0)
#define RX_FE_CONFIG_W11__RX_FE_IN_N_RST_EN ((uint32_t) 0x61a0)

#define RX_FE_CONFIG_W12 ((uint16_t) 0x1a2)
#define RX_FE_CONFIG_W12__RX_FE_PRE_VSS ((uint32_t) 0x1a2)
#define RX_FE_CONFIG_W12__RX_FE_KICK_EN ((uint32_t) 0x21a2)
#define RX_FE_CONFIG_W12__RX_FE_IN_P_RST_EN ((uint32_t) 0x41a2)
#define RX_FE_CONFIG_W12__RX_FE_IN_N_RST_EN ((uint32_t) 0x61a2)

#define RX_FE_CONFIG_W13 ((uint16_t) 0x1a4)
#define RX_FE_CONFIG_W13__RX_FE_PRE_VSS ((uint32_t) 0x1a4)
#define RX_FE_CONFIG_W13__RX_FE_KICK_EN ((uint32_t) 0x21a4)
#define RX_FE_CONFIG_W13__RX_FE_IN_P_RST_EN ((uint32_t) 0x41a4)
#define RX_FE_CONFIG_W13__RX_FE_IN_N_RST_EN ((uint32_t) 0x61a4)

#define RX_FE_CONFIG_W14 ((uint16_t) 0x1a6)
#define RX_FE_CONFIG_W14__RX_FE_PRE_VSS ((uint32_t) 0x1a6)
#define RX_FE_CONFIG_W14__RX_FE_KICK_EN ((uint32_t) 0x21a6)
#define RX_FE_CONFIG_W14__RX_FE_IN_P_RST_EN ((uint32_t) 0x41a6)
#define RX_FE_CONFIG_W14__RX_FE_IN_N_RST_EN ((uint32_t) 0x61a6)

#define RX_FE_CONFIG_W15 ((uint16_t) 0x1a8)
#define RX_FE_CONFIG_W15__RX_FE_PRE_VSS ((uint32_t) 0x1a8)
#define RX_FE_CONFIG_W15__RX_FE_KICK_EN ((uint32_t) 0x21a8)
#define RX_FE_CONFIG_W15__RX_FE_IN_P_RST_EN ((uint32_t) 0x41a8)
#define RX_FE_CONFIG_W15__RX_FE_IN_N_RST_EN ((uint32_t) 0x61a8)

#define RX_FE_CONFIG_W16 ((uint16_t) 0x1aa)
#define RX_FE_CONFIG_W16__RX_FE_PRE_VSS ((uint32_t) 0x1aa)
#define RX_FE_CONFIG_W16__RX_FE_KICK_EN ((uint32_t) 0x21aa)
#define RX_FE_CONFIG_W16__RX_FE_IN_P_RST_EN ((uint32_t) 0x41aa)
#define RX_FE_CONFIG_W16__RX_FE_IN_N_RST_EN ((uint32_t) 0x61aa)

#define RX_FE_CONFIG_W17 ((uint16_t) 0x1ac)
#define RX_FE_CONFIG_W17__RX_FE_PRE_VSS ((uint32_t) 0x1ac)
#define RX_FE_CONFIG_W17__RX_FE_KICK_EN ((uint32_t) 0x21ac)
#define RX_FE_CONFIG_W17__RX_FE_IN_P_RST_EN ((uint32_t) 0x41ac)
#define RX_FE_CONFIG_W17__RX_FE_IN_N_RST_EN ((uint32_t) 0x61ac)

#define RX_DLL_CONFIG ((uint16_t) 0x1ae)
#define RX_DLL_CONFIG__DLL_CLK_DIV_EN ((uint32_t) 0x1ae)
#define RX_DLL_CONFIG__DLL_DAC_INT_SET_N ((uint32_t) 0x21ae)
#define RX_DLL_CONFIG__DLL_PPHD_DAC_RST ((uint32_t) 0x41ae)
#define RX_DLL_CONFIG__DLL_PPHD_DAC_BIAS_RST ((uint32_t) 0x61ae)
#define RX_DLL_CONFIG__DLL_INT_RST ((uint32_t) 0x81ae)
#define RX_DLL_CONFIG__DLL_LVL_RST ((uint32_t) 0xa1ae)
#define RX_DLL_CONFIG__DLL_CLK_SAMP_CAL_EN ((uint32_t) 0xc1ae)
#define RX_DLL_CONFIG__DLL_WILD_CLK_CAL_EN ((uint32_t) 0xe1ae)
#define RX_DLL_CONFIG__DLL_PBD_SREF ((uint32_t) 0x701ae)

#define RX_DLL_CLK_DIV_STATE ((uint16_t) 0x1b0)
#define RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETH_N ((uint32_t) 0xe01b0)
#define RX_DLL_CLK_DIV_STATE__DLL_SHIFT_REG_SETL ((uint32_t) 0xf01b0)

#define RX_DLL_SREF_SAMP_CONFIG ((uint16_t) 0x1b2)
#define RX_DLL_SREF_SAMP_CONFIG__DLL_PRE_VSS ((uint32_t) 0x1b2)
#define RX_DLL_SREF_SAMP_CONFIG__DLL_KICK_EN ((uint32_t) 0x21b2)
#define RX_DLL_SREF_SAMP_CONFIG__DLL_IN_RST_EN ((uint32_t) 0x41b2)

#define RX_RX_DATA_SPARES_W0 ((uint16_t) 0x1b4)
#define RX_RX_DATA_SPARES_W0__SPARE_I ((uint32_t) 0x1e01b4)

#define RX_RX_DATA_SPARES_W1 ((uint16_t) 0x1b6)
#define RX_RX_DATA_SPARES_W1__SPARE_I ((uint32_t) 0x1e01b6)

#define RX_RX_DATA_SPARES_W2 ((uint16_t) 0x1b8)
#define RX_RX_DATA_SPARES_W2__SPARE_I ((uint32_t) 0x1e01b8)

#define RX_RX_DATA_SPARES_W3 ((uint16_t) 0x1ba)
#define RX_RX_DATA_SPARES_W3__SPARE_I ((uint32_t) 0x1e01ba)

#define RX_RX_DATA_SPARES_W4 ((uint16_t) 0x1bc)
#define RX_RX_DATA_SPARES_W4__SPARE_I ((uint32_t) 0x1e01bc)

#define RX_RX_DATA_SPARES_W5 ((uint16_t) 0x1be)
#define RX_RX_DATA_SPARES_W5__SPARE_I ((uint32_t) 0x1e01be)

#define RX_RX_DATA_SPARES_W6 ((uint16_t) 0x1c0)
#define RX_RX_DATA_SPARES_W6__SPARE_I ((uint32_t) 0x1e01c0)

#define RX_RX_DATA_SPARES_W7 ((uint16_t) 0x1c2)
#define RX_RX_DATA_SPARES_W7__SPARE_I ((uint32_t) 0x1e01c2)

#define RX_RX_DATA_SPARES_W8 ((uint16_t) 0x1c4)
#define RX_RX_DATA_SPARES_W8__SPARE_I ((uint32_t) 0x1e01c4)

#define RX_RX_DATA_SPARES_W9 ((uint16_t) 0x1c6)
#define RX_RX_DATA_SPARES_W9__SPARE_I ((uint32_t) 0x1e01c6)

#define RX_RX_DATA_SPARES_W10 ((uint16_t) 0x1c8)
#define RX_RX_DATA_SPARES_W10__SPARE_I ((uint32_t) 0x1e01c8)

#define RX_RX_DATA_SPARES_W11 ((uint16_t) 0x1ca)
#define RX_RX_DATA_SPARES_W11__SPARE_I ((uint32_t) 0x1e01ca)

#define RX_RX_DATA_SPARES_W12 ((uint16_t) 0x1cc)
#define RX_RX_DATA_SPARES_W12__SPARE_I ((uint32_t) 0x1e01cc)

#define RX_RX_DATA_SPARES_W13 ((uint16_t) 0x1ce)
#define RX_RX_DATA_SPARES_W13__SPARE_I ((uint32_t) 0x1e01ce)

#define RX_RX_DATA_SPARES_W14 ((uint16_t) 0x1d0)
#define RX_RX_DATA_SPARES_W14__SPARE_I ((uint32_t) 0x1e01d0)

#define RX_RX_DATA_SPARES_W15 ((uint16_t) 0x1d2)
#define RX_RX_DATA_SPARES_W15__SPARE_I ((uint32_t) 0x1e01d2)

#define RX_RX_DATA_SPARES_W16 ((uint16_t) 0x1d4)
#define RX_RX_DATA_SPARES_W16__SPARE_I ((uint32_t) 0x1e01d4)

#define RX_RX_DATA_SPARES_W17 ((uint16_t) 0x1d6)
#define RX_RX_DATA_SPARES_W17__SPARE_I ((uint32_t) 0x1e01d6)

#define RX_RX_SHARED_SPARES ((uint16_t) 0x1d8)
#define RX_RX_SHARED_SPARES__SPARE_I ((uint32_t) 0x1e01d8)

#define RX_CLKRX_SPARES ((uint16_t) 0x1da)
#define RX_CLKRX_SPARES__SPARE_I ((uint32_t) 0x1e01da)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S0 ((uint16_t) 0x1dc)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S0__DLL_SREF_POS_OFF_N ((uint32_t) 0x401dc)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S0__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461dc)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S1 ((uint16_t) 0x1de)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S1__DLL_SREF_POS_OFF_N ((uint32_t) 0x401de)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S1__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461de)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S2 ((uint16_t) 0x1e0)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S2__DLL_SREF_POS_OFF_N ((uint32_t) 0x401e0)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S2__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461e0)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S3 ((uint16_t) 0x1e2)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S3__DLL_SREF_POS_OFF_N ((uint32_t) 0x401e2)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S3__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461e2)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S4 ((uint16_t) 0x1e4)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S4__DLL_SREF_POS_OFF_N ((uint32_t) 0x401e4)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S4__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461e4)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S5 ((uint16_t) 0x1e6)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S5__DLL_SREF_POS_OFF_N ((uint32_t) 0x401e6)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S5__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461e6)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S6 ((uint16_t) 0x1e8)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S6__DLL_SREF_POS_OFF_N ((uint32_t) 0x401e8)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S6__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461e8)

#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S7 ((uint16_t) 0x1ea)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S7__DLL_SREF_POS_OFF_N ((uint32_t) 0x401ea)
#define RX_DLL_SREF_SAMP_OFFSET_CANCEL_S7__DLL_SREF_NEG_OFF_N ((uint32_t) 0x461ea)

#define RX_DATA_INVERSION_REODERING ((uint16_t) 0x1ec)
#define RX_DATA_INVERSION_REODERING__DEBUG_DATAPATH_EN ((uint32_t) 0x1ec)
#define RX_DATA_INVERSION_REODERING__INVERT_DATA_EN ((uint32_t) 0x21ec)
#define RX_DATA_INVERSION_REODERING__FULL_REVERSE_DATA_EN ((uint32_t) 0x41ec)
#define RX_DATA_INVERSION_REODERING__GROUP_BY_CHANNEL_EN ((uint32_t) 0x61ec)
#define RX_DATA_INVERSION_REODERING__SER_REVERSE_DATA_EN ((uint32_t) 0x81ec)

#define RX_INVERSION_MASK_0 ((uint16_t) 0x1ee)
#define RX_INVERSION_MASK_0__MASK ((uint32_t) 0x1e01ee)

#define RX_INVERSION_MASK_1 ((uint16_t) 0x1f0)
#define RX_INVERSION_MASK_1__MASK ((uint32_t) 0x1e01f0)

#define RX_INVERSION_MASK_2 ((uint16_t) 0x1f2)
#define RX_INVERSION_MASK_2__MASK ((uint32_t) 0x1e01f2)

#define RX_INVERSION_MASK_3 ((uint16_t) 0x1f4)
#define RX_INVERSION_MASK_3__MASK ((uint32_t) 0x1e01f4)

#define RX_INVERSION_MASK_4 ((uint16_t) 0x1f6)
#define RX_INVERSION_MASK_4__MASK ((uint32_t) 0x1e01f6)

#define RX_INVERSION_MASK_5 ((uint16_t) 0x1f8)
#define RX_INVERSION_MASK_5__MASK ((uint32_t) 0x1e01f8)

#define RX_INVERSION_MASK_6 ((uint16_t) 0x1fa)
#define RX_INVERSION_MASK_6__MASK ((uint32_t) 0x1e01fa)

#define RX_INVERSION_MASK_7 ((uint16_t) 0x1fc)
#define RX_INVERSION_MASK_7__MASK ((uint32_t) 0x1e01fc)

#define RX_INVERSION_MASK_8 ((uint16_t) 0x1fe)
#define RX_INVERSION_MASK_8__MASK ((uint32_t) 0x1e01fe)

#define RX_INVERSION_MASK_9 ((uint16_t) 0x200)
#define RX_INVERSION_MASK_9__MASK ((uint32_t) 0x1e0200)

#define RX_INVERSION_MASK_10 ((uint16_t) 0x202)
#define RX_INVERSION_MASK_10__MASK ((uint32_t) 0x1e0202)

#define RX_INVERSION_MASK_11 ((uint16_t) 0x204)
#define RX_INVERSION_MASK_11__MASK ((uint32_t) 0x1e0204)

#define RX_INVERSION_MASK_12 ((uint16_t) 0x206)
#define RX_INVERSION_MASK_12__MASK ((uint32_t) 0x1e0206)

#define RX_INVERSION_MASK_13 ((uint16_t) 0x208)
#define RX_INVERSION_MASK_13__MASK ((uint32_t) 0x1e0208)

#define RX_INVERSION_MASK_14 ((uint16_t) 0x20a)
#define RX_INVERSION_MASK_14__MASK ((uint32_t) 0x1e020a)

#define RX_INVERSION_MASK_15 ((uint16_t) 0x20c)
#define RX_INVERSION_MASK_15__MASK ((uint32_t) 0x1e020c)

#define RX_BIT_REDUNDANCY_SEL_0_7 ((uint16_t) 0x20e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_0 ((uint32_t) 0x2020e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_1 ((uint32_t) 0x2420e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_2 ((uint32_t) 0x2820e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_3 ((uint32_t) 0x2c20e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_4 ((uint32_t) 0x3020e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_5 ((uint32_t) 0x3420e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_6 ((uint32_t) 0x3820e)
#define RX_BIT_REDUNDANCY_SEL_0_7__BIT_7 ((uint32_t) 0x3c20e)

#define RX_BIT_REDUNDANCY_SEL_8_15 ((uint16_t) 0x210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_8 ((uint32_t) 0x20210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_9 ((uint32_t) 0x24210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_10 ((uint32_t) 0x28210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_11 ((uint32_t) 0x2c210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_12 ((uint32_t) 0x30210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_13 ((uint32_t) 0x34210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_14 ((uint32_t) 0x38210)
#define RX_BIT_REDUNDANCY_SEL_8_15__BIT_15 ((uint32_t) 0x3c210)

#define RX_LINK_LAYER_CLOCK_SEL ((uint16_t) 0x212)
#define RX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_ASYNC_CLK_EN ((uint32_t) 0x212)
#define RX_LINK_LAYER_CLOCK_SEL__PHY_LINK_LAYER_SYNC_CLK_EN ((uint32_t) 0x2212)
#define RX_LINK_LAYER_CLOCK_SEL__APB_CLK_EN ((uint32_t) 0x4212)

#define RX_PHYREADY_OVERRIDE ((uint16_t) 0x214)
#define RX_PHYREADY_OVERRIDE__OVRD ((uint32_t) 0x214)
#define RX_PHYREADY_OVERRIDE__OVRD_VALUE ((uint32_t) 0x2214)

#define RX_FD_FREEZE ((uint16_t) 0x216)
#define RX_FD_FREEZE__FREEZE ((uint32_t) 0x216)

#define RX_FD_RESET ((uint16_t) 0x218)
#define RX_FD_RESET__RST_N ((uint32_t) 0x218)

#define RX_FD_CLOCK_GATE ((uint16_t) 0x21a)
#define RX_FD_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x21a)

#define RX_FD_REF_PER_MULT ((uint16_t) 0x21c)
#define RX_FD_REF_PER_MULT__REF_PER_MULT ((uint32_t) 0x1e021c)

#define RX_FD_FREQ_CNT_OBSV ((uint16_t) 0x21e)
#define RX_FD_FREQ_CNT_OBSV__FREQ_CNT_OBSV ((uint32_t) 0x7e021e)

#define RX_PAT_GEN_MISC_CTRL ((uint16_t) 0x220)
#define RX_PAT_GEN_MISC_CTRL__SW_RST_N ((uint32_t) 0x220)
#define RX_PAT_GEN_MISC_CTRL__SER_RATIO ((uint32_t) 0x22220)

#define RX_PAT_GEN_CLOCK_GATE ((uint16_t) 0x222)
#define RX_PAT_GEN_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x222)

#define RX_PAT_GEN_PAT_GEN_FREEZE ((uint16_t) 0x224)
#define RX_PAT_GEN_PAT_GEN_FREEZE__FREEZE ((uint32_t) 0x224)

#define RX_PAT_GEN_MUX_CTRL_D0 ((uint16_t) 0x226)
#define RX_PAT_GEN_MUX_CTRL_D0__INV ((uint32_t) 0x226)
#define RX_PAT_GEN_MUX_CTRL_D0__PATSEL ((uint32_t) 0x2226)

#define RX_PAT_GEN_MUX_CTRL_D1 ((uint16_t) 0x228)
#define RX_PAT_GEN_MUX_CTRL_D1__INV ((uint32_t) 0x228)
#define RX_PAT_GEN_MUX_CTRL_D1__PATSEL ((uint32_t) 0x2228)

#define RX_PAT_GEN_MUX_CTRL_D2 ((uint16_t) 0x22a)
#define RX_PAT_GEN_MUX_CTRL_D2__INV ((uint32_t) 0x22a)
#define RX_PAT_GEN_MUX_CTRL_D2__PATSEL ((uint32_t) 0x222a)

#define RX_PAT_GEN_MUX_CTRL_D3 ((uint16_t) 0x22c)
#define RX_PAT_GEN_MUX_CTRL_D3__INV ((uint32_t) 0x22c)
#define RX_PAT_GEN_MUX_CTRL_D3__PATSEL ((uint32_t) 0x222c)

#define RX_PAT_GEN_MUX_CTRL_D4 ((uint16_t) 0x22e)
#define RX_PAT_GEN_MUX_CTRL_D4__INV ((uint32_t) 0x22e)
#define RX_PAT_GEN_MUX_CTRL_D4__PATSEL ((uint32_t) 0x222e)

#define RX_PAT_GEN_MUX_CTRL_D5 ((uint16_t) 0x230)
#define RX_PAT_GEN_MUX_CTRL_D5__INV ((uint32_t) 0x230)
#define RX_PAT_GEN_MUX_CTRL_D5__PATSEL ((uint32_t) 0x2230)

#define RX_PAT_GEN_MUX_CTRL_D6 ((uint16_t) 0x232)
#define RX_PAT_GEN_MUX_CTRL_D6__INV ((uint32_t) 0x232)
#define RX_PAT_GEN_MUX_CTRL_D6__PATSEL ((uint32_t) 0x2232)

#define RX_PAT_GEN_MUX_CTRL_D7 ((uint16_t) 0x234)
#define RX_PAT_GEN_MUX_CTRL_D7__INV ((uint32_t) 0x234)
#define RX_PAT_GEN_MUX_CTRL_D7__PATSEL ((uint32_t) 0x2234)

#define RX_PAT_GEN_MUX_CTRL_D8 ((uint16_t) 0x236)
#define RX_PAT_GEN_MUX_CTRL_D8__INV ((uint32_t) 0x236)
#define RX_PAT_GEN_MUX_CTRL_D8__PATSEL ((uint32_t) 0x2236)

#define RX_PAT_GEN_MUX_CTRL_D9 ((uint16_t) 0x238)
#define RX_PAT_GEN_MUX_CTRL_D9__INV ((uint32_t) 0x238)
#define RX_PAT_GEN_MUX_CTRL_D9__PATSEL ((uint32_t) 0x2238)

#define RX_PAT_GEN_MUX_CTRL_D10 ((uint16_t) 0x23a)
#define RX_PAT_GEN_MUX_CTRL_D10__INV ((uint32_t) 0x23a)
#define RX_PAT_GEN_MUX_CTRL_D10__PATSEL ((uint32_t) 0x223a)

#define RX_PAT_GEN_MUX_CTRL_D11 ((uint16_t) 0x23c)
#define RX_PAT_GEN_MUX_CTRL_D11__INV ((uint32_t) 0x23c)
#define RX_PAT_GEN_MUX_CTRL_D11__PATSEL ((uint32_t) 0x223c)

#define RX_PAT_GEN_MUX_CTRL_D12 ((uint16_t) 0x23e)
#define RX_PAT_GEN_MUX_CTRL_D12__INV ((uint32_t) 0x23e)
#define RX_PAT_GEN_MUX_CTRL_D12__PATSEL ((uint32_t) 0x223e)

#define RX_PAT_GEN_MUX_CTRL_D13 ((uint16_t) 0x240)
#define RX_PAT_GEN_MUX_CTRL_D13__INV ((uint32_t) 0x240)
#define RX_PAT_GEN_MUX_CTRL_D13__PATSEL ((uint32_t) 0x2240)

#define RX_PAT_GEN_MUX_CTRL_D14 ((uint16_t) 0x242)
#define RX_PAT_GEN_MUX_CTRL_D14__INV ((uint32_t) 0x242)
#define RX_PAT_GEN_MUX_CTRL_D14__PATSEL ((uint32_t) 0x2242)

#define RX_PAT_GEN_MUX_CTRL_D15 ((uint16_t) 0x244)
#define RX_PAT_GEN_MUX_CTRL_D15__INV ((uint32_t) 0x244)
#define RX_PAT_GEN_MUX_CTRL_D15__PATSEL ((uint32_t) 0x2244)

#define RX_PAT_GEN_MUX_CTRL_D16 ((uint16_t) 0x246)
#define RX_PAT_GEN_MUX_CTRL_D16__INV ((uint32_t) 0x246)
#define RX_PAT_GEN_MUX_CTRL_D16__PATSEL ((uint32_t) 0x2246)

#define RX_PAT_GEN_MUX_CTRL_D17 ((uint16_t) 0x248)
#define RX_PAT_GEN_MUX_CTRL_D17__INV ((uint32_t) 0x248)
#define RX_PAT_GEN_MUX_CTRL_D17__PATSEL ((uint32_t) 0x2248)

#define RX_PAT_GEN_MUX_CTRL_D18 ((uint16_t) 0x24a)
#define RX_PAT_GEN_MUX_CTRL_D18__INV ((uint32_t) 0x24a)
#define RX_PAT_GEN_MUX_CTRL_D18__PATSEL ((uint32_t) 0x224a)

#define RX_PAT_GEN_MUX_CTRL_D19 ((uint16_t) 0x24c)
#define RX_PAT_GEN_MUX_CTRL_D19__INV ((uint32_t) 0x24c)
#define RX_PAT_GEN_MUX_CTRL_D19__PATSEL ((uint32_t) 0x224c)

#define RX_PAT_GEN_PRBS_CTRL_P0 ((uint16_t) 0x24e)
#define RX_PAT_GEN_PRBS_CTRL_P0__PRBS_EN ((uint32_t) 0x24e)
#define RX_PAT_GEN_PRBS_CTRL_P0__PRBS_SEED_EN ((uint32_t) 0x224e)
#define RX_PAT_GEN_PRBS_CTRL_P0__PRBS_SIZE ((uint32_t) 0x4424e)

#define RX_PAT_GEN_PRBS_CTRL_P1 ((uint16_t) 0x250)
#define RX_PAT_GEN_PRBS_CTRL_P1__PRBS_EN ((uint32_t) 0x250)
#define RX_PAT_GEN_PRBS_CTRL_P1__PRBS_SEED_EN ((uint32_t) 0x2250)
#define RX_PAT_GEN_PRBS_CTRL_P1__PRBS_SIZE ((uint32_t) 0x44250)

#define RX_PAT_GEN_PRBS_CTRL_P2 ((uint16_t) 0x252)
#define RX_PAT_GEN_PRBS_CTRL_P2__PRBS_EN ((uint32_t) 0x252)
#define RX_PAT_GEN_PRBS_CTRL_P2__PRBS_SEED_EN ((uint32_t) 0x2252)
#define RX_PAT_GEN_PRBS_CTRL_P2__PRBS_SIZE ((uint32_t) 0x44252)

#define RX_PAT_GEN_PRBS_CTRL_P3 ((uint16_t) 0x254)
#define RX_PAT_GEN_PRBS_CTRL_P3__PRBS_EN ((uint32_t) 0x254)
#define RX_PAT_GEN_PRBS_CTRL_P3__PRBS_SEED_EN ((uint32_t) 0x2254)
#define RX_PAT_GEN_PRBS_CTRL_P3__PRBS_SIZE ((uint32_t) 0x44254)

#define RX_PAT_GEN_PRBS_CTRL_P4 ((uint16_t) 0x256)
#define RX_PAT_GEN_PRBS_CTRL_P4__PRBS_EN ((uint32_t) 0x256)
#define RX_PAT_GEN_PRBS_CTRL_P4__PRBS_SEED_EN ((uint32_t) 0x2256)
#define RX_PAT_GEN_PRBS_CTRL_P4__PRBS_SIZE ((uint32_t) 0x44256)

#define RX_PAT_GEN_PRBS_CTRL_P5 ((uint16_t) 0x258)
#define RX_PAT_GEN_PRBS_CTRL_P5__PRBS_EN ((uint32_t) 0x258)
#define RX_PAT_GEN_PRBS_CTRL_P5__PRBS_SEED_EN ((uint32_t) 0x2258)
#define RX_PAT_GEN_PRBS_CTRL_P5__PRBS_SIZE ((uint32_t) 0x44258)

#define RX_PAT_GEN_PRBS_CTRL_P6 ((uint16_t) 0x25a)
#define RX_PAT_GEN_PRBS_CTRL_P6__PRBS_EN ((uint32_t) 0x25a)
#define RX_PAT_GEN_PRBS_CTRL_P6__PRBS_SEED_EN ((uint32_t) 0x225a)
#define RX_PAT_GEN_PRBS_CTRL_P6__PRBS_SIZE ((uint32_t) 0x4425a)

#define RX_PAT_GEN_PRBS_CTRL_P7 ((uint16_t) 0x25c)
#define RX_PAT_GEN_PRBS_CTRL_P7__PRBS_EN ((uint32_t) 0x25c)
#define RX_PAT_GEN_PRBS_CTRL_P7__PRBS_SEED_EN ((uint32_t) 0x225c)
#define RX_PAT_GEN_PRBS_CTRL_P7__PRBS_SIZE ((uint32_t) 0x4425c)

#define RX_PAT_GEN_PRBS_CTRL_P8 ((uint16_t) 0x25e)
#define RX_PAT_GEN_PRBS_CTRL_P8__PRBS_EN ((uint32_t) 0x25e)
#define RX_PAT_GEN_PRBS_CTRL_P8__PRBS_SEED_EN ((uint32_t) 0x225e)
#define RX_PAT_GEN_PRBS_CTRL_P8__PRBS_SIZE ((uint32_t) 0x4425e)

#define RX_PAT_GEN_PRBS_CTRL_P9 ((uint16_t) 0x260)
#define RX_PAT_GEN_PRBS_CTRL_P9__PRBS_EN ((uint32_t) 0x260)
#define RX_PAT_GEN_PRBS_CTRL_P9__PRBS_SEED_EN ((uint32_t) 0x2260)
#define RX_PAT_GEN_PRBS_CTRL_P9__PRBS_SIZE ((uint32_t) 0x44260)

#define RX_PAT_GEN_PRBS_CTRL_P10 ((uint16_t) 0x262)
#define RX_PAT_GEN_PRBS_CTRL_P10__PRBS_EN ((uint32_t) 0x262)
#define RX_PAT_GEN_PRBS_CTRL_P10__PRBS_SEED_EN ((uint32_t) 0x2262)
#define RX_PAT_GEN_PRBS_CTRL_P10__PRBS_SIZE ((uint32_t) 0x44262)

#define RX_PAT_GEN_PRBS_CTRL_P11 ((uint16_t) 0x264)
#define RX_PAT_GEN_PRBS_CTRL_P11__PRBS_EN ((uint32_t) 0x264)
#define RX_PAT_GEN_PRBS_CTRL_P11__PRBS_SEED_EN ((uint32_t) 0x2264)
#define RX_PAT_GEN_PRBS_CTRL_P11__PRBS_SIZE ((uint32_t) 0x44264)

#define RX_PAT_GEN_PRBS_CTRL_P12 ((uint16_t) 0x266)
#define RX_PAT_GEN_PRBS_CTRL_P12__PRBS_EN ((uint32_t) 0x266)
#define RX_PAT_GEN_PRBS_CTRL_P12__PRBS_SEED_EN ((uint32_t) 0x2266)
#define RX_PAT_GEN_PRBS_CTRL_P12__PRBS_SIZE ((uint32_t) 0x44266)

#define RX_PAT_GEN_PRBS_CTRL_P13 ((uint16_t) 0x268)
#define RX_PAT_GEN_PRBS_CTRL_P13__PRBS_EN ((uint32_t) 0x268)
#define RX_PAT_GEN_PRBS_CTRL_P13__PRBS_SEED_EN ((uint32_t) 0x2268)
#define RX_PAT_GEN_PRBS_CTRL_P13__PRBS_SIZE ((uint32_t) 0x44268)

#define RX_PAT_GEN_PRBS_CTRL_P14 ((uint16_t) 0x26a)
#define RX_PAT_GEN_PRBS_CTRL_P14__PRBS_EN ((uint32_t) 0x26a)
#define RX_PAT_GEN_PRBS_CTRL_P14__PRBS_SEED_EN ((uint32_t) 0x226a)
#define RX_PAT_GEN_PRBS_CTRL_P14__PRBS_SIZE ((uint32_t) 0x4426a)

#define RX_PAT_GEN_PRBS_CTRL_P15 ((uint16_t) 0x26c)
#define RX_PAT_GEN_PRBS_CTRL_P15__PRBS_EN ((uint32_t) 0x26c)
#define RX_PAT_GEN_PRBS_CTRL_P15__PRBS_SEED_EN ((uint32_t) 0x226c)
#define RX_PAT_GEN_PRBS_CTRL_P15__PRBS_SIZE ((uint32_t) 0x4426c)

#define RX_PAT_GEN_PRBS_CTRL_P16 ((uint16_t) 0x26e)
#define RX_PAT_GEN_PRBS_CTRL_P16__PRBS_EN ((uint32_t) 0x26e)
#define RX_PAT_GEN_PRBS_CTRL_P16__PRBS_SEED_EN ((uint32_t) 0x226e)
#define RX_PAT_GEN_PRBS_CTRL_P16__PRBS_SIZE ((uint32_t) 0x4426e)

#define RX_PAT_GEN_PRBS_CTRL_P17 ((uint16_t) 0x270)
#define RX_PAT_GEN_PRBS_CTRL_P17__PRBS_EN ((uint32_t) 0x270)
#define RX_PAT_GEN_PRBS_CTRL_P17__PRBS_SEED_EN ((uint32_t) 0x2270)
#define RX_PAT_GEN_PRBS_CTRL_P17__PRBS_SIZE ((uint32_t) 0x44270)

#define RX_PAT_GEN_PRBS_SEED_LO_P0 ((uint16_t) 0x272)
#define RX_PAT_GEN_PRBS_SEED_LO_P0__SEED ((uint32_t) 0x1e0272)

#define RX_PAT_GEN_PRBS_SEED_LO_P1 ((uint16_t) 0x274)
#define RX_PAT_GEN_PRBS_SEED_LO_P1__SEED ((uint32_t) 0x1e0274)

#define RX_PAT_GEN_PRBS_SEED_LO_P2 ((uint16_t) 0x276)
#define RX_PAT_GEN_PRBS_SEED_LO_P2__SEED ((uint32_t) 0x1e0276)

#define RX_PAT_GEN_PRBS_SEED_LO_P3 ((uint16_t) 0x278)
#define RX_PAT_GEN_PRBS_SEED_LO_P3__SEED ((uint32_t) 0x1e0278)

#define RX_PAT_GEN_PRBS_SEED_LO_P4 ((uint16_t) 0x27a)
#define RX_PAT_GEN_PRBS_SEED_LO_P4__SEED ((uint32_t) 0x1e027a)

#define RX_PAT_GEN_PRBS_SEED_LO_P5 ((uint16_t) 0x27c)
#define RX_PAT_GEN_PRBS_SEED_LO_P5__SEED ((uint32_t) 0x1e027c)

#define RX_PAT_GEN_PRBS_SEED_LO_P6 ((uint16_t) 0x27e)
#define RX_PAT_GEN_PRBS_SEED_LO_P6__SEED ((uint32_t) 0x1e027e)

#define RX_PAT_GEN_PRBS_SEED_LO_P7 ((uint16_t) 0x280)
#define RX_PAT_GEN_PRBS_SEED_LO_P7__SEED ((uint32_t) 0x1e0280)

#define RX_PAT_GEN_PRBS_SEED_LO_P8 ((uint16_t) 0x282)
#define RX_PAT_GEN_PRBS_SEED_LO_P8__SEED ((uint32_t) 0x1e0282)

#define RX_PAT_GEN_PRBS_SEED_LO_P9 ((uint16_t) 0x284)
#define RX_PAT_GEN_PRBS_SEED_LO_P9__SEED ((uint32_t) 0x1e0284)

#define RX_PAT_GEN_PRBS_SEED_LO_P10 ((uint16_t) 0x286)
#define RX_PAT_GEN_PRBS_SEED_LO_P10__SEED ((uint32_t) 0x1e0286)

#define RX_PAT_GEN_PRBS_SEED_LO_P11 ((uint16_t) 0x288)
#define RX_PAT_GEN_PRBS_SEED_LO_P11__SEED ((uint32_t) 0x1e0288)

#define RX_PAT_GEN_PRBS_SEED_LO_P12 ((uint16_t) 0x28a)
#define RX_PAT_GEN_PRBS_SEED_LO_P12__SEED ((uint32_t) 0x1e028a)

#define RX_PAT_GEN_PRBS_SEED_LO_P13 ((uint16_t) 0x28c)
#define RX_PAT_GEN_PRBS_SEED_LO_P13__SEED ((uint32_t) 0x1e028c)

#define RX_PAT_GEN_PRBS_SEED_LO_P14 ((uint16_t) 0x28e)
#define RX_PAT_GEN_PRBS_SEED_LO_P14__SEED ((uint32_t) 0x1e028e)

#define RX_PAT_GEN_PRBS_SEED_LO_P15 ((uint16_t) 0x290)
#define RX_PAT_GEN_PRBS_SEED_LO_P15__SEED ((uint32_t) 0x1e0290)

#define RX_PAT_GEN_PRBS_SEED_LO_P16 ((uint16_t) 0x292)
#define RX_PAT_GEN_PRBS_SEED_LO_P16__SEED ((uint32_t) 0x1e0292)

#define RX_PAT_GEN_PRBS_SEED_LO_P17 ((uint16_t) 0x294)
#define RX_PAT_GEN_PRBS_SEED_LO_P17__SEED ((uint32_t) 0x1e0294)

#define RX_PAT_GEN_PRBS_SEED_HI_P0 ((uint16_t) 0x296)
#define RX_PAT_GEN_PRBS_SEED_HI_P0__SEED ((uint32_t) 0x1e0296)

#define RX_PAT_GEN_PRBS_SEED_HI_P1 ((uint16_t) 0x298)
#define RX_PAT_GEN_PRBS_SEED_HI_P1__SEED ((uint32_t) 0x1e0298)

#define RX_PAT_GEN_PRBS_SEED_HI_P2 ((uint16_t) 0x29a)
#define RX_PAT_GEN_PRBS_SEED_HI_P2__SEED ((uint32_t) 0x1e029a)

#define RX_PAT_GEN_PRBS_SEED_HI_P3 ((uint16_t) 0x29c)
#define RX_PAT_GEN_PRBS_SEED_HI_P3__SEED ((uint32_t) 0x1e029c)

#define RX_PAT_GEN_PRBS_SEED_HI_P4 ((uint16_t) 0x29e)
#define RX_PAT_GEN_PRBS_SEED_HI_P4__SEED ((uint32_t) 0x1e029e)

#define RX_PAT_GEN_PRBS_SEED_HI_P5 ((uint16_t) 0x2a0)
#define RX_PAT_GEN_PRBS_SEED_HI_P5__SEED ((uint32_t) 0x1e02a0)

#define RX_PAT_GEN_PRBS_SEED_HI_P6 ((uint16_t) 0x2a2)
#define RX_PAT_GEN_PRBS_SEED_HI_P6__SEED ((uint32_t) 0x1e02a2)

#define RX_PAT_GEN_PRBS_SEED_HI_P7 ((uint16_t) 0x2a4)
#define RX_PAT_GEN_PRBS_SEED_HI_P7__SEED ((uint32_t) 0x1e02a4)

#define RX_PAT_GEN_PRBS_SEED_HI_P8 ((uint16_t) 0x2a6)
#define RX_PAT_GEN_PRBS_SEED_HI_P8__SEED ((uint32_t) 0x1e02a6)

#define RX_PAT_GEN_PRBS_SEED_HI_P9 ((uint16_t) 0x2a8)
#define RX_PAT_GEN_PRBS_SEED_HI_P9__SEED ((uint32_t) 0x1e02a8)

#define RX_PAT_GEN_PRBS_SEED_HI_P10 ((uint16_t) 0x2aa)
#define RX_PAT_GEN_PRBS_SEED_HI_P10__SEED ((uint32_t) 0x1e02aa)

#define RX_PAT_GEN_PRBS_SEED_HI_P11 ((uint16_t) 0x2ac)
#define RX_PAT_GEN_PRBS_SEED_HI_P11__SEED ((uint32_t) 0x1e02ac)

#define RX_PAT_GEN_PRBS_SEED_HI_P12 ((uint16_t) 0x2ae)
#define RX_PAT_GEN_PRBS_SEED_HI_P12__SEED ((uint32_t) 0x1e02ae)

#define RX_PAT_GEN_PRBS_SEED_HI_P13 ((uint16_t) 0x2b0)
#define RX_PAT_GEN_PRBS_SEED_HI_P13__SEED ((uint32_t) 0x1e02b0)

#define RX_PAT_GEN_PRBS_SEED_HI_P14 ((uint16_t) 0x2b2)
#define RX_PAT_GEN_PRBS_SEED_HI_P14__SEED ((uint32_t) 0x1e02b2)

#define RX_PAT_GEN_PRBS_SEED_HI_P15 ((uint16_t) 0x2b4)
#define RX_PAT_GEN_PRBS_SEED_HI_P15__SEED ((uint32_t) 0x1e02b4)

#define RX_PAT_GEN_PRBS_SEED_HI_P16 ((uint16_t) 0x2b6)
#define RX_PAT_GEN_PRBS_SEED_HI_P16__SEED ((uint32_t) 0x1e02b6)

#define RX_PAT_GEN_PRBS_SEED_HI_P17 ((uint16_t) 0x2b8)
#define RX_PAT_GEN_PRBS_SEED_HI_P17__SEED ((uint32_t) 0x1e02b8)

#define RX_PAT_GEN_PRBS_STATE_LO_P0 ((uint16_t) 0x2ba)
#define RX_PAT_GEN_PRBS_STATE_LO_P0__STATE ((uint32_t) 0x7e02ba)

#define RX_PAT_GEN_PRBS_STATE_LO_P1 ((uint16_t) 0x2bc)
#define RX_PAT_GEN_PRBS_STATE_LO_P1__STATE ((uint32_t) 0x7e02bc)

#define RX_PAT_GEN_PRBS_STATE_LO_P2 ((uint16_t) 0x2be)
#define RX_PAT_GEN_PRBS_STATE_LO_P2__STATE ((uint32_t) 0x7e02be)

#define RX_PAT_GEN_PRBS_STATE_LO_P3 ((uint16_t) 0x2c0)
#define RX_PAT_GEN_PRBS_STATE_LO_P3__STATE ((uint32_t) 0x7e02c0)

#define RX_PAT_GEN_PRBS_STATE_LO_P4 ((uint16_t) 0x2c2)
#define RX_PAT_GEN_PRBS_STATE_LO_P4__STATE ((uint32_t) 0x7e02c2)

#define RX_PAT_GEN_PRBS_STATE_LO_P5 ((uint16_t) 0x2c4)
#define RX_PAT_GEN_PRBS_STATE_LO_P5__STATE ((uint32_t) 0x7e02c4)

#define RX_PAT_GEN_PRBS_STATE_LO_P6 ((uint16_t) 0x2c6)
#define RX_PAT_GEN_PRBS_STATE_LO_P6__STATE ((uint32_t) 0x7e02c6)

#define RX_PAT_GEN_PRBS_STATE_LO_P7 ((uint16_t) 0x2c8)
#define RX_PAT_GEN_PRBS_STATE_LO_P7__STATE ((uint32_t) 0x7e02c8)

#define RX_PAT_GEN_PRBS_STATE_LO_P8 ((uint16_t) 0x2ca)
#define RX_PAT_GEN_PRBS_STATE_LO_P8__STATE ((uint32_t) 0x7e02ca)

#define RX_PAT_GEN_PRBS_STATE_LO_P9 ((uint16_t) 0x2cc)
#define RX_PAT_GEN_PRBS_STATE_LO_P9__STATE ((uint32_t) 0x7e02cc)

#define RX_PAT_GEN_PRBS_STATE_LO_P10 ((uint16_t) 0x2ce)
#define RX_PAT_GEN_PRBS_STATE_LO_P10__STATE ((uint32_t) 0x7e02ce)

#define RX_PAT_GEN_PRBS_STATE_LO_P11 ((uint16_t) 0x2d0)
#define RX_PAT_GEN_PRBS_STATE_LO_P11__STATE ((uint32_t) 0x7e02d0)

#define RX_PAT_GEN_PRBS_STATE_LO_P12 ((uint16_t) 0x2d2)
#define RX_PAT_GEN_PRBS_STATE_LO_P12__STATE ((uint32_t) 0x7e02d2)

#define RX_PAT_GEN_PRBS_STATE_LO_P13 ((uint16_t) 0x2d4)
#define RX_PAT_GEN_PRBS_STATE_LO_P13__STATE ((uint32_t) 0x7e02d4)

#define RX_PAT_GEN_PRBS_STATE_LO_P14 ((uint16_t) 0x2d6)
#define RX_PAT_GEN_PRBS_STATE_LO_P14__STATE ((uint32_t) 0x7e02d6)

#define RX_PAT_GEN_PRBS_STATE_LO_P15 ((uint16_t) 0x2d8)
#define RX_PAT_GEN_PRBS_STATE_LO_P15__STATE ((uint32_t) 0x7e02d8)

#define RX_PAT_GEN_PRBS_STATE_LO_P16 ((uint16_t) 0x2da)
#define RX_PAT_GEN_PRBS_STATE_LO_P16__STATE ((uint32_t) 0x7e02da)

#define RX_PAT_GEN_PRBS_STATE_LO_P17 ((uint16_t) 0x2dc)
#define RX_PAT_GEN_PRBS_STATE_LO_P17__STATE ((uint32_t) 0x7e02dc)

#define RX_PAT_GEN_PRBS_STATE_HI_P0 ((uint16_t) 0x2de)
#define RX_PAT_GEN_PRBS_STATE_HI_P0__STATE ((uint32_t) 0x7e02de)

#define RX_PAT_GEN_PRBS_STATE_HI_P1 ((uint16_t) 0x2e0)
#define RX_PAT_GEN_PRBS_STATE_HI_P1__STATE ((uint32_t) 0x7e02e0)

#define RX_PAT_GEN_PRBS_STATE_HI_P2 ((uint16_t) 0x2e2)
#define RX_PAT_GEN_PRBS_STATE_HI_P2__STATE ((uint32_t) 0x7e02e2)

#define RX_PAT_GEN_PRBS_STATE_HI_P3 ((uint16_t) 0x2e4)
#define RX_PAT_GEN_PRBS_STATE_HI_P3__STATE ((uint32_t) 0x7e02e4)

#define RX_PAT_GEN_PRBS_STATE_HI_P4 ((uint16_t) 0x2e6)
#define RX_PAT_GEN_PRBS_STATE_HI_P4__STATE ((uint32_t) 0x7e02e6)

#define RX_PAT_GEN_PRBS_STATE_HI_P5 ((uint16_t) 0x2e8)
#define RX_PAT_GEN_PRBS_STATE_HI_P5__STATE ((uint32_t) 0x7e02e8)

#define RX_PAT_GEN_PRBS_STATE_HI_P6 ((uint16_t) 0x2ea)
#define RX_PAT_GEN_PRBS_STATE_HI_P6__STATE ((uint32_t) 0x7e02ea)

#define RX_PAT_GEN_PRBS_STATE_HI_P7 ((uint16_t) 0x2ec)
#define RX_PAT_GEN_PRBS_STATE_HI_P7__STATE ((uint32_t) 0x7e02ec)

#define RX_PAT_GEN_PRBS_STATE_HI_P8 ((uint16_t) 0x2ee)
#define RX_PAT_GEN_PRBS_STATE_HI_P8__STATE ((uint32_t) 0x7e02ee)

#define RX_PAT_GEN_PRBS_STATE_HI_P9 ((uint16_t) 0x2f0)
#define RX_PAT_GEN_PRBS_STATE_HI_P9__STATE ((uint32_t) 0x7e02f0)

#define RX_PAT_GEN_PRBS_STATE_HI_P10 ((uint16_t) 0x2f2)
#define RX_PAT_GEN_PRBS_STATE_HI_P10__STATE ((uint32_t) 0x7e02f2)

#define RX_PAT_GEN_PRBS_STATE_HI_P11 ((uint16_t) 0x2f4)
#define RX_PAT_GEN_PRBS_STATE_HI_P11__STATE ((uint32_t) 0x7e02f4)

#define RX_PAT_GEN_PRBS_STATE_HI_P12 ((uint16_t) 0x2f6)
#define RX_PAT_GEN_PRBS_STATE_HI_P12__STATE ((uint32_t) 0x7e02f6)

#define RX_PAT_GEN_PRBS_STATE_HI_P13 ((uint16_t) 0x2f8)
#define RX_PAT_GEN_PRBS_STATE_HI_P13__STATE ((uint32_t) 0x7e02f8)

#define RX_PAT_GEN_PRBS_STATE_HI_P14 ((uint16_t) 0x2fa)
#define RX_PAT_GEN_PRBS_STATE_HI_P14__STATE ((uint32_t) 0x7e02fa)

#define RX_PAT_GEN_PRBS_STATE_HI_P15 ((uint16_t) 0x2fc)
#define RX_PAT_GEN_PRBS_STATE_HI_P15__STATE ((uint32_t) 0x7e02fc)

#define RX_PAT_GEN_PRBS_STATE_HI_P16 ((uint16_t) 0x2fe)
#define RX_PAT_GEN_PRBS_STATE_HI_P16__STATE ((uint32_t) 0x7e02fe)

#define RX_PAT_GEN_PRBS_STATE_HI_P17 ((uint16_t) 0x300)
#define RX_PAT_GEN_PRBS_STATE_HI_P17__STATE ((uint32_t) 0x7e0300)

#define RX_PAT_GEN_MEM_CTRL_M0 ((uint16_t) 0x302)
#define RX_PAT_GEN_MEM_CTRL_M0__MEM_EN ((uint32_t) 0x302)

#define RX_PAT_GEN_MEM_CTRL_M1 ((uint16_t) 0x304)
#define RX_PAT_GEN_MEM_CTRL_M1__MEM_EN ((uint32_t) 0x304)

#define RX_PAT_GEN_MEM_CTRL_M2 ((uint16_t) 0x306)
#define RX_PAT_GEN_MEM_CTRL_M2__MEM_EN ((uint32_t) 0x306)

#define RX_PAT_GEN_MEM_CTRL_M3 ((uint16_t) 0x308)
#define RX_PAT_GEN_MEM_CTRL_M3__MEM_EN ((uint32_t) 0x308)

#define RX_PAT_GEN_MEM_CTRL_M4 ((uint16_t) 0x30a)
#define RX_PAT_GEN_MEM_CTRL_M4__MEM_EN ((uint32_t) 0x30a)

#define RX_PAT_GEN_MEM_CTRL_M5 ((uint16_t) 0x30c)
#define RX_PAT_GEN_MEM_CTRL_M5__MEM_EN ((uint32_t) 0x30c)

#define RX_PAT_GEN_MEM_CTRL_M6 ((uint16_t) 0x30e)
#define RX_PAT_GEN_MEM_CTRL_M6__MEM_EN ((uint32_t) 0x30e)

#define RX_PAT_GEN_MEM_CTRL_M7 ((uint16_t) 0x310)
#define RX_PAT_GEN_MEM_CTRL_M7__MEM_EN ((uint32_t) 0x310)

#define RX_PAT_GEN_MEM_CTRL_M8 ((uint16_t) 0x312)
#define RX_PAT_GEN_MEM_CTRL_M8__MEM_EN ((uint32_t) 0x312)

#define RX_PAT_GEN_MEM_CTRL_M9 ((uint16_t) 0x314)
#define RX_PAT_GEN_MEM_CTRL_M9__MEM_EN ((uint32_t) 0x314)

#define RX_PAT_GEN_MEM_CTRL_M10 ((uint16_t) 0x316)
#define RX_PAT_GEN_MEM_CTRL_M10__MEM_EN ((uint32_t) 0x316)

#define RX_PAT_GEN_MEM_CTRL_M11 ((uint16_t) 0x318)
#define RX_PAT_GEN_MEM_CTRL_M11__MEM_EN ((uint32_t) 0x318)

#define RX_PAT_GEN_MEM_CTRL_M12 ((uint16_t) 0x31a)
#define RX_PAT_GEN_MEM_CTRL_M12__MEM_EN ((uint32_t) 0x31a)

#define RX_PAT_GEN_MEM_CTRL_M13 ((uint16_t) 0x31c)
#define RX_PAT_GEN_MEM_CTRL_M13__MEM_EN ((uint32_t) 0x31c)

#define RX_PAT_GEN_MEM_CTRL_M14 ((uint16_t) 0x31e)
#define RX_PAT_GEN_MEM_CTRL_M14__MEM_EN ((uint32_t) 0x31e)

#define RX_PAT_GEN_MEM_CTRL_M15 ((uint16_t) 0x320)
#define RX_PAT_GEN_MEM_CTRL_M15__MEM_EN ((uint32_t) 0x320)

#define RX_PAT_GEN_MEM_CTRL_M16 ((uint16_t) 0x322)
#define RX_PAT_GEN_MEM_CTRL_M16__MEM_EN ((uint32_t) 0x322)

#define RX_PAT_GEN_MEM_CTRL_M17 ((uint16_t) 0x324)
#define RX_PAT_GEN_MEM_CTRL_M17__MEM_EN ((uint32_t) 0x324)

#define RX_PAT_GEN_MEM_ARRAY_M0M0 ((uint16_t) 0x326)
#define RX_PAT_GEN_MEM_ARRAY_M0M0__DATA ((uint32_t) 0x1e0326)

#define RX_PAT_GEN_MEM_ARRAY_M0M1 ((uint16_t) 0x328)
#define RX_PAT_GEN_MEM_ARRAY_M0M1__DATA ((uint32_t) 0x1e0328)

#define RX_PAT_GEN_MEM_ARRAY_M0M2 ((uint16_t) 0x32a)
#define RX_PAT_GEN_MEM_ARRAY_M0M2__DATA ((uint32_t) 0x1e032a)

#define RX_PAT_GEN_MEM_ARRAY_M0M3 ((uint16_t) 0x32c)
#define RX_PAT_GEN_MEM_ARRAY_M0M3__DATA ((uint32_t) 0x1e032c)

#define RX_PAT_GEN_MEM_ARRAY_M1M0 ((uint16_t) 0x32e)
#define RX_PAT_GEN_MEM_ARRAY_M1M0__DATA ((uint32_t) 0x1e032e)

#define RX_PAT_GEN_MEM_ARRAY_M1M1 ((uint16_t) 0x330)
#define RX_PAT_GEN_MEM_ARRAY_M1M1__DATA ((uint32_t) 0x1e0330)

#define RX_PAT_GEN_MEM_ARRAY_M1M2 ((uint16_t) 0x332)
#define RX_PAT_GEN_MEM_ARRAY_M1M2__DATA ((uint32_t) 0x1e0332)

#define RX_PAT_GEN_MEM_ARRAY_M1M3 ((uint16_t) 0x334)
#define RX_PAT_GEN_MEM_ARRAY_M1M3__DATA ((uint32_t) 0x1e0334)

#define RX_PAT_GEN_MEM_ARRAY_M2M0 ((uint16_t) 0x336)
#define RX_PAT_GEN_MEM_ARRAY_M2M0__DATA ((uint32_t) 0x1e0336)

#define RX_PAT_GEN_MEM_ARRAY_M2M1 ((uint16_t) 0x338)
#define RX_PAT_GEN_MEM_ARRAY_M2M1__DATA ((uint32_t) 0x1e0338)

#define RX_PAT_GEN_MEM_ARRAY_M2M2 ((uint16_t) 0x33a)
#define RX_PAT_GEN_MEM_ARRAY_M2M2__DATA ((uint32_t) 0x1e033a)

#define RX_PAT_GEN_MEM_ARRAY_M2M3 ((uint16_t) 0x33c)
#define RX_PAT_GEN_MEM_ARRAY_M2M3__DATA ((uint32_t) 0x1e033c)

#define RX_PAT_GEN_MEM_ARRAY_M3M0 ((uint16_t) 0x33e)
#define RX_PAT_GEN_MEM_ARRAY_M3M0__DATA ((uint32_t) 0x1e033e)

#define RX_PAT_GEN_MEM_ARRAY_M3M1 ((uint16_t) 0x340)
#define RX_PAT_GEN_MEM_ARRAY_M3M1__DATA ((uint32_t) 0x1e0340)

#define RX_PAT_GEN_MEM_ARRAY_M3M2 ((uint16_t) 0x342)
#define RX_PAT_GEN_MEM_ARRAY_M3M2__DATA ((uint32_t) 0x1e0342)

#define RX_PAT_GEN_MEM_ARRAY_M3M3 ((uint16_t) 0x344)
#define RX_PAT_GEN_MEM_ARRAY_M3M3__DATA ((uint32_t) 0x1e0344)

#define RX_PAT_GEN_MEM_ARRAY_M4M0 ((uint16_t) 0x346)
#define RX_PAT_GEN_MEM_ARRAY_M4M0__DATA ((uint32_t) 0x1e0346)

#define RX_PAT_GEN_MEM_ARRAY_M4M1 ((uint16_t) 0x348)
#define RX_PAT_GEN_MEM_ARRAY_M4M1__DATA ((uint32_t) 0x1e0348)

#define RX_PAT_GEN_MEM_ARRAY_M4M2 ((uint16_t) 0x34a)
#define RX_PAT_GEN_MEM_ARRAY_M4M2__DATA ((uint32_t) 0x1e034a)

#define RX_PAT_GEN_MEM_ARRAY_M4M3 ((uint16_t) 0x34c)
#define RX_PAT_GEN_MEM_ARRAY_M4M3__DATA ((uint32_t) 0x1e034c)

#define RX_PAT_GEN_MEM_ARRAY_M5M0 ((uint16_t) 0x34e)
#define RX_PAT_GEN_MEM_ARRAY_M5M0__DATA ((uint32_t) 0x1e034e)

#define RX_PAT_GEN_MEM_ARRAY_M5M1 ((uint16_t) 0x350)
#define RX_PAT_GEN_MEM_ARRAY_M5M1__DATA ((uint32_t) 0x1e0350)

#define RX_PAT_GEN_MEM_ARRAY_M5M2 ((uint16_t) 0x352)
#define RX_PAT_GEN_MEM_ARRAY_M5M2__DATA ((uint32_t) 0x1e0352)

#define RX_PAT_GEN_MEM_ARRAY_M5M3 ((uint16_t) 0x354)
#define RX_PAT_GEN_MEM_ARRAY_M5M3__DATA ((uint32_t) 0x1e0354)

#define RX_PAT_GEN_MEM_ARRAY_M6M0 ((uint16_t) 0x356)
#define RX_PAT_GEN_MEM_ARRAY_M6M0__DATA ((uint32_t) 0x1e0356)

#define RX_PAT_GEN_MEM_ARRAY_M6M1 ((uint16_t) 0x358)
#define RX_PAT_GEN_MEM_ARRAY_M6M1__DATA ((uint32_t) 0x1e0358)

#define RX_PAT_GEN_MEM_ARRAY_M6M2 ((uint16_t) 0x35a)
#define RX_PAT_GEN_MEM_ARRAY_M6M2__DATA ((uint32_t) 0x1e035a)

#define RX_PAT_GEN_MEM_ARRAY_M6M3 ((uint16_t) 0x35c)
#define RX_PAT_GEN_MEM_ARRAY_M6M3__DATA ((uint32_t) 0x1e035c)

#define RX_PAT_GEN_MEM_ARRAY_M7M0 ((uint16_t) 0x35e)
#define RX_PAT_GEN_MEM_ARRAY_M7M0__DATA ((uint32_t) 0x1e035e)

#define RX_PAT_GEN_MEM_ARRAY_M7M1 ((uint16_t) 0x360)
#define RX_PAT_GEN_MEM_ARRAY_M7M1__DATA ((uint32_t) 0x1e0360)

#define RX_PAT_GEN_MEM_ARRAY_M7M2 ((uint16_t) 0x362)
#define RX_PAT_GEN_MEM_ARRAY_M7M2__DATA ((uint32_t) 0x1e0362)

#define RX_PAT_GEN_MEM_ARRAY_M7M3 ((uint16_t) 0x364)
#define RX_PAT_GEN_MEM_ARRAY_M7M3__DATA ((uint32_t) 0x1e0364)

#define RX_PAT_GEN_MEM_ARRAY_M8M0 ((uint16_t) 0x366)
#define RX_PAT_GEN_MEM_ARRAY_M8M0__DATA ((uint32_t) 0x1e0366)

#define RX_PAT_GEN_MEM_ARRAY_M8M1 ((uint16_t) 0x368)
#define RX_PAT_GEN_MEM_ARRAY_M8M1__DATA ((uint32_t) 0x1e0368)

#define RX_PAT_GEN_MEM_ARRAY_M8M2 ((uint16_t) 0x36a)
#define RX_PAT_GEN_MEM_ARRAY_M8M2__DATA ((uint32_t) 0x1e036a)

#define RX_PAT_GEN_MEM_ARRAY_M8M3 ((uint16_t) 0x36c)
#define RX_PAT_GEN_MEM_ARRAY_M8M3__DATA ((uint32_t) 0x1e036c)

#define RX_PAT_GEN_MEM_ARRAY_M9M0 ((uint16_t) 0x36e)
#define RX_PAT_GEN_MEM_ARRAY_M9M0__DATA ((uint32_t) 0x1e036e)

#define RX_PAT_GEN_MEM_ARRAY_M9M1 ((uint16_t) 0x370)
#define RX_PAT_GEN_MEM_ARRAY_M9M1__DATA ((uint32_t) 0x1e0370)

#define RX_PAT_GEN_MEM_ARRAY_M9M2 ((uint16_t) 0x372)
#define RX_PAT_GEN_MEM_ARRAY_M9M2__DATA ((uint32_t) 0x1e0372)

#define RX_PAT_GEN_MEM_ARRAY_M9M3 ((uint16_t) 0x374)
#define RX_PAT_GEN_MEM_ARRAY_M9M3__DATA ((uint32_t) 0x1e0374)

#define RX_PAT_GEN_MEM_ARRAY_M10M0 ((uint16_t) 0x376)
#define RX_PAT_GEN_MEM_ARRAY_M10M0__DATA ((uint32_t) 0x1e0376)

#define RX_PAT_GEN_MEM_ARRAY_M10M1 ((uint16_t) 0x378)
#define RX_PAT_GEN_MEM_ARRAY_M10M1__DATA ((uint32_t) 0x1e0378)

#define RX_PAT_GEN_MEM_ARRAY_M10M2 ((uint16_t) 0x37a)
#define RX_PAT_GEN_MEM_ARRAY_M10M2__DATA ((uint32_t) 0x1e037a)

#define RX_PAT_GEN_MEM_ARRAY_M10M3 ((uint16_t) 0x37c)
#define RX_PAT_GEN_MEM_ARRAY_M10M3__DATA ((uint32_t) 0x1e037c)

#define RX_PAT_GEN_MEM_ARRAY_M11M0 ((uint16_t) 0x37e)
#define RX_PAT_GEN_MEM_ARRAY_M11M0__DATA ((uint32_t) 0x1e037e)

#define RX_PAT_GEN_MEM_ARRAY_M11M1 ((uint16_t) 0x380)
#define RX_PAT_GEN_MEM_ARRAY_M11M1__DATA ((uint32_t) 0x1e0380)

#define RX_PAT_GEN_MEM_ARRAY_M11M2 ((uint16_t) 0x382)
#define RX_PAT_GEN_MEM_ARRAY_M11M2__DATA ((uint32_t) 0x1e0382)

#define RX_PAT_GEN_MEM_ARRAY_M11M3 ((uint16_t) 0x384)
#define RX_PAT_GEN_MEM_ARRAY_M11M3__DATA ((uint32_t) 0x1e0384)

#define RX_PAT_GEN_MEM_ARRAY_M12M0 ((uint16_t) 0x386)
#define RX_PAT_GEN_MEM_ARRAY_M12M0__DATA ((uint32_t) 0x1e0386)

#define RX_PAT_GEN_MEM_ARRAY_M12M1 ((uint16_t) 0x388)
#define RX_PAT_GEN_MEM_ARRAY_M12M1__DATA ((uint32_t) 0x1e0388)

#define RX_PAT_GEN_MEM_ARRAY_M12M2 ((uint16_t) 0x38a)
#define RX_PAT_GEN_MEM_ARRAY_M12M2__DATA ((uint32_t) 0x1e038a)

#define RX_PAT_GEN_MEM_ARRAY_M12M3 ((uint16_t) 0x38c)
#define RX_PAT_GEN_MEM_ARRAY_M12M3__DATA ((uint32_t) 0x1e038c)

#define RX_PAT_GEN_MEM_ARRAY_M13M0 ((uint16_t) 0x38e)
#define RX_PAT_GEN_MEM_ARRAY_M13M0__DATA ((uint32_t) 0x1e038e)

#define RX_PAT_GEN_MEM_ARRAY_M13M1 ((uint16_t) 0x390)
#define RX_PAT_GEN_MEM_ARRAY_M13M1__DATA ((uint32_t) 0x1e0390)

#define RX_PAT_GEN_MEM_ARRAY_M13M2 ((uint16_t) 0x392)
#define RX_PAT_GEN_MEM_ARRAY_M13M2__DATA ((uint32_t) 0x1e0392)

#define RX_PAT_GEN_MEM_ARRAY_M13M3 ((uint16_t) 0x394)
#define RX_PAT_GEN_MEM_ARRAY_M13M3__DATA ((uint32_t) 0x1e0394)

#define RX_PAT_GEN_MEM_ARRAY_M14M0 ((uint16_t) 0x396)
#define RX_PAT_GEN_MEM_ARRAY_M14M0__DATA ((uint32_t) 0x1e0396)

#define RX_PAT_GEN_MEM_ARRAY_M14M1 ((uint16_t) 0x398)
#define RX_PAT_GEN_MEM_ARRAY_M14M1__DATA ((uint32_t) 0x1e0398)

#define RX_PAT_GEN_MEM_ARRAY_M14M2 ((uint16_t) 0x39a)
#define RX_PAT_GEN_MEM_ARRAY_M14M2__DATA ((uint32_t) 0x1e039a)

#define RX_PAT_GEN_MEM_ARRAY_M14M3 ((uint16_t) 0x39c)
#define RX_PAT_GEN_MEM_ARRAY_M14M3__DATA ((uint32_t) 0x1e039c)

#define RX_PAT_GEN_MEM_ARRAY_M15M0 ((uint16_t) 0x39e)
#define RX_PAT_GEN_MEM_ARRAY_M15M0__DATA ((uint32_t) 0x1e039e)

#define RX_PAT_GEN_MEM_ARRAY_M15M1 ((uint16_t) 0x3a0)
#define RX_PAT_GEN_MEM_ARRAY_M15M1__DATA ((uint32_t) 0x1e03a0)

#define RX_PAT_GEN_MEM_ARRAY_M15M2 ((uint16_t) 0x3a2)
#define RX_PAT_GEN_MEM_ARRAY_M15M2__DATA ((uint32_t) 0x1e03a2)

#define RX_PAT_GEN_MEM_ARRAY_M15M3 ((uint16_t) 0x3a4)
#define RX_PAT_GEN_MEM_ARRAY_M15M3__DATA ((uint32_t) 0x1e03a4)

#define RX_PAT_GEN_MEM_ARRAY_M16M0 ((uint16_t) 0x3a6)
#define RX_PAT_GEN_MEM_ARRAY_M16M0__DATA ((uint32_t) 0x1e03a6)

#define RX_PAT_GEN_MEM_ARRAY_M16M1 ((uint16_t) 0x3a8)
#define RX_PAT_GEN_MEM_ARRAY_M16M1__DATA ((uint32_t) 0x1e03a8)

#define RX_PAT_GEN_MEM_ARRAY_M16M2 ((uint16_t) 0x3aa)
#define RX_PAT_GEN_MEM_ARRAY_M16M2__DATA ((uint32_t) 0x1e03aa)

#define RX_PAT_GEN_MEM_ARRAY_M16M3 ((uint16_t) 0x3ac)
#define RX_PAT_GEN_MEM_ARRAY_M16M3__DATA ((uint32_t) 0x1e03ac)

#define RX_PAT_GEN_MEM_ARRAY_M17M0 ((uint16_t) 0x3ae)
#define RX_PAT_GEN_MEM_ARRAY_M17M0__DATA ((uint32_t) 0x1e03ae)

#define RX_PAT_GEN_MEM_ARRAY_M17M1 ((uint16_t) 0x3b0)
#define RX_PAT_GEN_MEM_ARRAY_M17M1__DATA ((uint32_t) 0x1e03b0)

#define RX_PAT_GEN_MEM_ARRAY_M17M2 ((uint16_t) 0x3b2)
#define RX_PAT_GEN_MEM_ARRAY_M17M2__DATA ((uint32_t) 0x1e03b2)

#define RX_PAT_GEN_MEM_ARRAY_M17M3 ((uint16_t) 0x3b4)
#define RX_PAT_GEN_MEM_ARRAY_M17M3__DATA ((uint32_t) 0x1e03b4)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M0 ((uint16_t) 0x3b6)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M0__BUFFER_END ((uint32_t) 0xa03b6)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M1 ((uint16_t) 0x3b8)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M1__BUFFER_END ((uint32_t) 0xa03b8)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M2 ((uint16_t) 0x3ba)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M2__BUFFER_END ((uint32_t) 0xa03ba)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M3 ((uint16_t) 0x3bc)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M3__BUFFER_END ((uint32_t) 0xa03bc)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M4 ((uint16_t) 0x3be)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M4__BUFFER_END ((uint32_t) 0xa03be)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M5 ((uint16_t) 0x3c0)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M5__BUFFER_END ((uint32_t) 0xa03c0)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M6 ((uint16_t) 0x3c2)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M6__BUFFER_END ((uint32_t) 0xa03c2)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M7 ((uint16_t) 0x3c4)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M7__BUFFER_END ((uint32_t) 0xa03c4)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M8 ((uint16_t) 0x3c6)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M8__BUFFER_END ((uint32_t) 0xa03c6)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M9 ((uint16_t) 0x3c8)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M9__BUFFER_END ((uint32_t) 0xa03c8)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M10 ((uint16_t) 0x3ca)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M10__BUFFER_END ((uint32_t) 0xa03ca)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M11 ((uint16_t) 0x3cc)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M11__BUFFER_END ((uint32_t) 0xa03cc)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M12 ((uint16_t) 0x3ce)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M12__BUFFER_END ((uint32_t) 0xa03ce)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M13 ((uint16_t) 0x3d0)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M13__BUFFER_END ((uint32_t) 0xa03d0)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M14 ((uint16_t) 0x3d2)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M14__BUFFER_END ((uint32_t) 0xa03d2)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M15 ((uint16_t) 0x3d4)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M15__BUFFER_END ((uint32_t) 0xa03d4)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M16 ((uint16_t) 0x3d6)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M16__BUFFER_END ((uint32_t) 0xa03d6)

#define RX_PAT_GEN_MEM_CNTR_CTRL_M17 ((uint16_t) 0x3d8)
#define RX_PAT_GEN_MEM_CNTR_CTRL_M17__BUFFER_END ((uint32_t) 0xa03d8)

#define RX_PAT_GEN_MEM_CNTR_M0 ((uint16_t) 0x3da)
#define RX_PAT_GEN_MEM_CNTR_M0__ADDR_CNTR ((uint32_t) 0x6c03da)

#define RX_PAT_GEN_MEM_CNTR_M1 ((uint16_t) 0x3dc)
#define RX_PAT_GEN_MEM_CNTR_M1__ADDR_CNTR ((uint32_t) 0x6c03dc)

#define RX_PAT_GEN_MEM_CNTR_M2 ((uint16_t) 0x3de)
#define RX_PAT_GEN_MEM_CNTR_M2__ADDR_CNTR ((uint32_t) 0x6c03de)

#define RX_PAT_GEN_MEM_CNTR_M3 ((uint16_t) 0x3e0)
#define RX_PAT_GEN_MEM_CNTR_M3__ADDR_CNTR ((uint32_t) 0x6c03e0)

#define RX_PAT_GEN_MEM_CNTR_M4 ((uint16_t) 0x3e2)
#define RX_PAT_GEN_MEM_CNTR_M4__ADDR_CNTR ((uint32_t) 0x6c03e2)

#define RX_PAT_GEN_MEM_CNTR_M5 ((uint16_t) 0x3e4)
#define RX_PAT_GEN_MEM_CNTR_M5__ADDR_CNTR ((uint32_t) 0x6c03e4)

#define RX_PAT_GEN_MEM_CNTR_M6 ((uint16_t) 0x3e6)
#define RX_PAT_GEN_MEM_CNTR_M6__ADDR_CNTR ((uint32_t) 0x6c03e6)

#define RX_PAT_GEN_MEM_CNTR_M7 ((uint16_t) 0x3e8)
#define RX_PAT_GEN_MEM_CNTR_M7__ADDR_CNTR ((uint32_t) 0x6c03e8)

#define RX_PAT_GEN_MEM_CNTR_M8 ((uint16_t) 0x3ea)
#define RX_PAT_GEN_MEM_CNTR_M8__ADDR_CNTR ((uint32_t) 0x6c03ea)

#define RX_PAT_GEN_MEM_CNTR_M9 ((uint16_t) 0x3ec)
#define RX_PAT_GEN_MEM_CNTR_M9__ADDR_CNTR ((uint32_t) 0x6c03ec)

#define RX_PAT_GEN_MEM_CNTR_M10 ((uint16_t) 0x3ee)
#define RX_PAT_GEN_MEM_CNTR_M10__ADDR_CNTR ((uint32_t) 0x6c03ee)

#define RX_PAT_GEN_MEM_CNTR_M11 ((uint16_t) 0x3f0)
#define RX_PAT_GEN_MEM_CNTR_M11__ADDR_CNTR ((uint32_t) 0x6c03f0)

#define RX_PAT_GEN_MEM_CNTR_M12 ((uint16_t) 0x3f2)
#define RX_PAT_GEN_MEM_CNTR_M12__ADDR_CNTR ((uint32_t) 0x6c03f2)

#define RX_PAT_GEN_MEM_CNTR_M13 ((uint16_t) 0x3f4)
#define RX_PAT_GEN_MEM_CNTR_M13__ADDR_CNTR ((uint32_t) 0x6c03f4)

#define RX_PAT_GEN_MEM_CNTR_M14 ((uint16_t) 0x3f6)
#define RX_PAT_GEN_MEM_CNTR_M14__ADDR_CNTR ((uint32_t) 0x6c03f6)

#define RX_PAT_GEN_MEM_CNTR_M15 ((uint16_t) 0x3f8)
#define RX_PAT_GEN_MEM_CNTR_M15__ADDR_CNTR ((uint32_t) 0x6c03f8)

#define RX_PAT_GEN_MEM_CNTR_M16 ((uint16_t) 0x3fa)
#define RX_PAT_GEN_MEM_CNTR_M16__ADDR_CNTR ((uint32_t) 0x6c03fa)

#define RX_PAT_GEN_MEM_CNTR_M17 ((uint16_t) 0x3fc)
#define RX_PAT_GEN_MEM_CNTR_M17__ADDR_CNTR ((uint32_t) 0x6c03fc)

#define RX_PAT_GEN_CLK_CTRL_C0 ((uint16_t) 0x3fe)
#define RX_PAT_GEN_CLK_CTRL_C0__CLK_EN ((uint32_t) 0x3fe)

#define RX_PAT_GEN_CLK_CTRL_C1 ((uint16_t) 0x400)
#define RX_PAT_GEN_CLK_CTRL_C1__CLK_EN ((uint32_t) 0x400)

#define RX_PAT_GEN_CLK_ARRAY_C0 ((uint16_t) 0x402)
#define RX_PAT_GEN_CLK_ARRAY_C0__DATA ((uint32_t) 0x1e0402)

#define RX_PAT_GEN_CLK_ARRAY_C1 ((uint16_t) 0x404)
#define RX_PAT_GEN_CLK_ARRAY_C1__DATA ((uint32_t) 0x1e0404)

#define RX_PAT_GEN_CLK_CNTR_CTRL_C0 ((uint16_t) 0x406)
#define RX_PAT_GEN_CLK_CNTR_CTRL_C0__BUFFER_END ((uint32_t) 0x60406)

#define RX_PAT_GEN_CLK_CNTR_CTRL_C1 ((uint16_t) 0x408)
#define RX_PAT_GEN_CLK_CNTR_CTRL_C1__BUFFER_END ((uint32_t) 0x60408)

#define RX_PAT_GEN_CLK_CNTR_C0 ((uint16_t) 0x40a)
#define RX_PAT_GEN_CLK_CNTR_C0__ADDR_CNTR ((uint32_t) 0x68040a)

#define RX_PAT_GEN_CLK_CNTR_C1 ((uint16_t) 0x40c)
#define RX_PAT_GEN_CLK_CNTR_C1__ADDR_CNTR ((uint32_t) 0x68040c)

#define RX_PAT_CHK_MISC_CTRL ((uint16_t) 0x40e)
#define RX_PAT_CHK_MISC_CTRL__SW_RST_N ((uint32_t) 0x40e)
#define RX_PAT_CHK_MISC_CTRL__DESER_RATIO ((uint32_t) 0x2240e)

#define RX_PAT_CHK_CLOCK_GATE ((uint16_t) 0x410)
#define RX_PAT_CHK_CLOCK_GATE__CLOCK_ENABLE ((uint32_t) 0x410)

#define RX_PAT_CHK_PAT_CHK_FREEZE ((uint16_t) 0x412)
#define RX_PAT_CHK_PAT_CHK_FREEZE__FREEZE ((uint32_t) 0x412)

#define RX_PAT_CHK_MEM_CTRL ((uint16_t) 0x414)
#define RX_PAT_CHK_MEM_CTRL__MEM_EN_C0 ((uint32_t) 0x414)
#define RX_PAT_CHK_MEM_CTRL__MEM_EN_C1 ((uint32_t) 0x2414)
#define RX_PAT_CHK_MEM_CTRL__MEM_EN_C2 ((uint32_t) 0x4414)
#define RX_PAT_CHK_MEM_CTRL__MEM_EN_C3 ((uint32_t) 0x6414)
#define RX_PAT_CHK_MEM_CTRL__MEM_CHECK_C0 ((uint32_t) 0x8414)
#define RX_PAT_CHK_MEM_CTRL__MEM_CHECK_C1 ((uint32_t) 0xa414)
#define RX_PAT_CHK_MEM_CTRL__MEM_CHECK_C2 ((uint32_t) 0xc414)
#define RX_PAT_CHK_MEM_CTRL__MEM_CHECK_C3 ((uint32_t) 0xe414)

#define RX_PAT_CHK_MEM_CTRL_PATREAD ((uint16_t) 0x416)
#define RX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C0 ((uint32_t) 0x40416)
#define RX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C1 ((uint32_t) 0x46416)
#define RX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C2 ((uint32_t) 0x4c416)
#define RX_PAT_CHK_MEM_CTRL_PATREAD__MEM_ROWID_C3 ((uint32_t) 0x52416)

#define RX_PAT_CHK_MEM_CNTR_CTRL_C0 ((uint16_t) 0x418)
#define RX_PAT_CHK_MEM_CNTR_CTRL_C0__BUFFER_END ((uint32_t) 0xc0418)

#define RX_PAT_CHK_MEM_CNTR_CTRL_C1 ((uint16_t) 0x41a)
#define RX_PAT_CHK_MEM_CNTR_CTRL_C1__BUFFER_END ((uint32_t) 0xc041a)

#define RX_PAT_CHK_MEM_CNTR_CTRL_C2 ((uint16_t) 0x41c)
#define RX_PAT_CHK_MEM_CNTR_CTRL_C2__BUFFER_END ((uint32_t) 0xc041c)

#define RX_PAT_CHK_MEM_CNTR_CTRL_C3 ((uint16_t) 0x41e)
#define RX_PAT_CHK_MEM_CNTR_CTRL_C3__BUFFER_END ((uint32_t) 0xc041e)

#define RX_PAT_CHK_MUX_CTRL_C0 ((uint16_t) 0x420)
#define RX_PAT_CHK_MUX_CTRL_C0__MUX ((uint32_t) 0x80420)

#define RX_PAT_CHK_MUX_CTRL_C1 ((uint16_t) 0x422)
#define RX_PAT_CHK_MUX_CTRL_C1__MUX ((uint32_t) 0x80422)

#define RX_PAT_CHK_MUX_CTRL_C2 ((uint16_t) 0x424)
#define RX_PAT_CHK_MUX_CTRL_C2__MUX ((uint32_t) 0x80424)

#define RX_PAT_CHK_MUX_CTRL_C3 ((uint16_t) 0x426)
#define RX_PAT_CHK_MUX_CTRL_C3__MUX ((uint32_t) 0x80426)

#define RX_PAT_CHK_MEM_CNTR_C0 ((uint16_t) 0x428)
#define RX_PAT_CHK_MEM_CNTR_C0__ADDR_CNTR ((uint32_t) 0x6e0428)

#define RX_PAT_CHK_MEM_CNTR_C1 ((uint16_t) 0x42a)
#define RX_PAT_CHK_MEM_CNTR_C1__ADDR_CNTR ((uint32_t) 0x6e042a)

#define RX_PAT_CHK_MEM_CNTR_C2 ((uint16_t) 0x42c)
#define RX_PAT_CHK_MEM_CNTR_C2__ADDR_CNTR ((uint32_t) 0x6e042c)

#define RX_PAT_CHK_MEM_CNTR_C3 ((uint16_t) 0x42e)
#define RX_PAT_CHK_MEM_CNTR_C3__ADDR_CNTR ((uint32_t) 0x6e042e)

#define RX_PAT_CHK_MEM_CTRL_STATES ((uint16_t) 0x430)
#define RX_PAT_CHK_MEM_CTRL_STATES__STATE_C0 ((uint32_t) 0x620430)
#define RX_PAT_CHK_MEM_CTRL_STATES__STATE_C1 ((uint32_t) 0x624430)
#define RX_PAT_CHK_MEM_CTRL_STATES__STATE_C2 ((uint32_t) 0x628430)
#define RX_PAT_CHK_MEM_CTRL_STATES__STATE_C3 ((uint32_t) 0x62c430)

#define RX_PAT_CHK_MEM_PATREAD_C0 ((uint16_t) 0x432)
#define RX_PAT_CHK_MEM_PATREAD_C0__WORD ((uint32_t) 0x7e0432)

#define RX_PAT_CHK_MEM_PATREAD_C1 ((uint16_t) 0x434)
#define RX_PAT_CHK_MEM_PATREAD_C1__WORD ((uint32_t) 0x7e0434)

#define RX_PAT_CHK_MEM_PATREAD_C2 ((uint16_t) 0x436)
#define RX_PAT_CHK_MEM_PATREAD_C2__WORD ((uint32_t) 0x7e0436)

#define RX_PAT_CHK_MEM_PATREAD_C3 ((uint16_t) 0x438)
#define RX_PAT_CHK_MEM_PATREAD_C3__WORD ((uint32_t) 0x7e0438)

#define RX_PAT_CHK_PRBS_CTRL ((uint16_t) 0x43a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_EN_C0 ((uint32_t) 0x43a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_EN_C1 ((uint32_t) 0x243a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_EN_C2 ((uint32_t) 0x443a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_EN_C3 ((uint32_t) 0x643a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C0 ((uint32_t) 0x843a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C1 ((uint32_t) 0xa43a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C2 ((uint32_t) 0xc43a)
#define RX_PAT_CHK_PRBS_CTRL__PRBS_CHECK_C3 ((uint32_t) 0xe43a)

#define RX_PAT_CHK_PRBS_SIZE ((uint16_t) 0x43c)
#define RX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C0 ((uint32_t) 0x4043c)
#define RX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C1 ((uint32_t) 0x4643c)
#define RX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C2 ((uint32_t) 0x4c43c)
#define RX_PAT_CHK_PRBS_SIZE__PRBS_SIZE_C3 ((uint32_t) 0x5243c)

#define RX_PAT_CHK_PRBS_CTRL_STATES ((uint16_t) 0x43e)
#define RX_PAT_CHK_PRBS_CTRL_STATES__STATE_C0 ((uint32_t) 0x62043e)
#define RX_PAT_CHK_PRBS_CTRL_STATES__STATE_C1 ((uint32_t) 0x62443e)
#define RX_PAT_CHK_PRBS_CTRL_STATES__STATE_C2 ((uint32_t) 0x62843e)
#define RX_PAT_CHK_PRBS_CTRL_STATES__STATE_C3 ((uint32_t) 0x62c43e)

#define RX_PAT_CHK_PRBS_STATE_LO_C0 ((uint16_t) 0x440)
#define RX_PAT_CHK_PRBS_STATE_LO_C0__STATE ((uint32_t) 0x7e0440)

#define RX_PAT_CHK_PRBS_STATE_LO_C1 ((uint16_t) 0x442)
#define RX_PAT_CHK_PRBS_STATE_LO_C1__STATE ((uint32_t) 0x7e0442)

#define RX_PAT_CHK_PRBS_STATE_LO_C2 ((uint16_t) 0x444)
#define RX_PAT_CHK_PRBS_STATE_LO_C2__STATE ((uint32_t) 0x7e0444)

#define RX_PAT_CHK_PRBS_STATE_LO_C3 ((uint16_t) 0x446)
#define RX_PAT_CHK_PRBS_STATE_LO_C3__STATE ((uint32_t) 0x7e0446)

#define RX_PAT_CHK_PRBS_STATE_HI_C0 ((uint16_t) 0x448)
#define RX_PAT_CHK_PRBS_STATE_HI_C0__STATE ((uint32_t) 0x7e0448)

#define RX_PAT_CHK_PRBS_STATE_HI_C1 ((uint16_t) 0x44a)
#define RX_PAT_CHK_PRBS_STATE_HI_C1__STATE ((uint32_t) 0x7e044a)

#define RX_PAT_CHK_PRBS_STATE_HI_C2 ((uint16_t) 0x44c)
#define RX_PAT_CHK_PRBS_STATE_HI_C2__STATE ((uint32_t) 0x7e044c)

#define RX_PAT_CHK_PRBS_STATE_HI_C3 ((uint16_t) 0x44e)
#define RX_PAT_CHK_PRBS_STATE_HI_C3__STATE ((uint32_t) 0x7e044e)

#define RX_PAT_CHK_BIT_COUNT0 ((uint16_t) 0x450)
#define RX_PAT_CHK_BIT_COUNT0__COUNT ((uint32_t) 0x7e0450)

#define RX_PAT_CHK_BIT_COUNT1 ((uint16_t) 0x452)
#define RX_PAT_CHK_BIT_COUNT1__COUNT ((uint32_t) 0x7e0452)

#define RX_PAT_CHK_BIT_COUNT2 ((uint16_t) 0x454)
#define RX_PAT_CHK_BIT_COUNT2__COUNT ((uint32_t) 0x7e0454)

#define RX_PAT_CHK_BIT_COUNT3 ((uint16_t) 0x456)
#define RX_PAT_CHK_BIT_COUNT3__COUNT ((uint32_t) 0x7e0456)

#define RX_PAT_CHK_ERROR_COUNT_LSB_C0 ((uint16_t) 0x458)
#define RX_PAT_CHK_ERROR_COUNT_LSB_C0__COUNT ((uint32_t) 0x7e0458)

#define RX_PAT_CHK_ERROR_COUNT_LSB_C1 ((uint16_t) 0x45a)
#define RX_PAT_CHK_ERROR_COUNT_LSB_C1__COUNT ((uint32_t) 0x7e045a)

#define RX_PAT_CHK_ERROR_COUNT_LSB_C2 ((uint16_t) 0x45c)
#define RX_PAT_CHK_ERROR_COUNT_LSB_C2__COUNT ((uint32_t) 0x7e045c)

#define RX_PAT_CHK_ERROR_COUNT_LSB_C3 ((uint16_t) 0x45e)
#define RX_PAT_CHK_ERROR_COUNT_LSB_C3__COUNT ((uint32_t) 0x7e045e)

#define RX_PAT_CHK_ERROR_COUNT_MSB_C0 ((uint16_t) 0x460)
#define RX_PAT_CHK_ERROR_COUNT_MSB_C0__COUNT ((uint32_t) 0x7e0460)

#define RX_PAT_CHK_ERROR_COUNT_MSB_C1 ((uint16_t) 0x462)
#define RX_PAT_CHK_ERROR_COUNT_MSB_C1__COUNT ((uint32_t) 0x7e0462)

#define RX_PAT_CHK_ERROR_COUNT_MSB_C2 ((uint16_t) 0x464)
#define RX_PAT_CHK_ERROR_COUNT_MSB_C2__COUNT ((uint32_t) 0x7e0464)

#define RX_PAT_CHK_ERROR_COUNT_MSB_C3 ((uint16_t) 0x466)
#define RX_PAT_CHK_ERROR_COUNT_MSB_C3__COUNT ((uint32_t) 0x7e0466)

#define RX_VR_FREEZE ((uint16_t) 0x468)
#define RX_VR_FREEZE__FREEZE ((uint32_t) 0x468)

#define RX_VR_CLK_GATE ((uint16_t) 0x46a)
#define RX_VR_CLK_GATE__GATE_CLK_CTRL ((uint32_t) 0x46a)
#define RX_VR_CLK_GATE__GATE_CLK_VCO ((uint32_t) 0x246a)

#define RX_VR_RESET ((uint16_t) 0x46c)
#define RX_VR_RESET__ACM_RST_N ((uint32_t) 0x46c)
#define RX_VR_RESET__DSM_RST_N ((uint32_t) 0x246c)
#define RX_VR_RESET__DSM_OUT_RST_N ((uint32_t) 0x446c)
#define RX_VR_RESET__LD_RST_N ((uint32_t) 0x646c)
#define RX_VR_RESET__FD_RST_N ((uint32_t) 0x846c)

#define RX_VR_ACM_CTRL ((uint16_t) 0x46e)
#define RX_VR_ACM_CTRL__BYP_RST_SYNC ((uint32_t) 0x46e)
#define RX_VR_ACM_CTRL__ACM_OVRD ((uint32_t) 0x246e)
#define RX_VR_ACM_CTRL__ACM_PRLD ((uint32_t) 0x446e)
#define RX_VR_ACM_CTRL__ACM_HOLD ((uint32_t) 0x646e)
#define RX_VR_ACM_CTRL__ACM_BYP_SAT ((uint32_t) 0x846e)

#define RX_VR_ACM_ADJ_POS_LO ((uint16_t) 0x470)
#define RX_VR_ACM_ADJ_POS_LO__ACM_ADJ_POS_LO ((uint32_t) 0x1e0470)

#define RX_VR_ACM_ADJ_POS_HI ((uint16_t) 0x472)
#define RX_VR_ACM_ADJ_POS_HI__ACM_ADJ_POS_HI ((uint32_t) 0xe0472)

#define RX_VR_ACM_ADJ_NEG_LO ((uint16_t) 0x474)
#define RX_VR_ACM_ADJ_NEG_LO__ACM_ADJ_NEG_LO ((uint32_t) 0x1e0474)

#define RX_VR_ACM_ADJ_NEG_HI ((uint16_t) 0x476)
#define RX_VR_ACM_ADJ_NEG_HI__ACM_ADJ_NEG_HI ((uint32_t) 0xe0476)

#define RX_VR_ACM_OVRD_VAL_LO ((uint16_t) 0x478)
#define RX_VR_ACM_OVRD_VAL_LO__ACM_OVRD_VAL_LO ((uint32_t) 0x1e0478)

#define RX_VR_ACM_OVRD_VAL_HI ((uint16_t) 0x47a)
#define RX_VR_ACM_OVRD_VAL_HI__ACM_OVRD_VAL_HI ((uint32_t) 0xe047a)

#define RX_VR_ACM_PRLD_VAL_LO ((uint16_t) 0x47c)
#define RX_VR_ACM_PRLD_VAL_LO__ACM_PRLD_VAL_LO ((uint32_t) 0x1e047c)

#define RX_VR_ACM_PRLD_VAL_HI ((uint16_t) 0x47e)
#define RX_VR_ACM_PRLD_VAL_HI__ACM_PRLD_VAL_HI ((uint32_t) 0xe047e)

#define RX_VR_ACM_ACCUM_OBSV_LO ((uint16_t) 0x480)
#define RX_VR_ACM_ACCUM_OBSV_LO__ACM_ACCUM_OBSV_LO ((uint32_t) 0x7e0480)

#define RX_VR_ACM_ACCUM_OBSV_HI ((uint16_t) 0x482)
#define RX_VR_ACM_ACCUM_OBSV_HI__ACM_ACCUM_OBSV_HI ((uint32_t) 0x6e0482)

#define RX_VR_DSM_CTRL ((uint16_t) 0x484)
#define RX_VR_DSM_CTRL__BYP_RST_SYNC ((uint32_t) 0x484)
#define RX_VR_DSM_CTRL__DSM_OVRD ((uint32_t) 0x2484)
#define RX_VR_DSM_CTRL__DSM_PRLD ((uint32_t) 0x4484)
#define RX_VR_DSM_CTRL__DSM_HOLD ((uint32_t) 0x6484)
#define RX_VR_DSM_CTRL__DSM_INV ((uint32_t) 0x8484)

#define RX_VR_DSM_OVRD_VAL ((uint16_t) 0x486)
#define RX_VR_DSM_OVRD_VAL__DSM_OVRD_VAL ((uint32_t) 0x1e0486)

#define RX_VR_DSM_PRLD_VAL ((uint16_t) 0x488)
#define RX_VR_DSM_PRLD_VAL__DSM_PRLD_VAL ((uint32_t) 0x1e0488)

#define RX_VR_DSM_ACCUM_OBSV ((uint16_t) 0x48a)
#define RX_VR_DSM_ACCUM_OBSV__DSM_ACCUM_OBSV ((uint32_t) 0x7e048a)

#define RX_VR_LD_CTRL ((uint16_t) 0x48c)
#define RX_VR_LD_CTRL__LD_FORCE_LOCK ((uint32_t) 0x48c)
#define RX_VR_LD_CTRL__LOCK_SEL ((uint32_t) 0x248c)

#define RX_VR_LD_MEAS_PER ((uint16_t) 0x48e)
#define RX_VR_LD_MEAS_PER__LD_MEAS_PER ((uint32_t) 0x1e048e)

#define RX_VR_LD_LOCK_THRESH ((uint16_t) 0x490)
#define RX_VR_LD_LOCK_THRESH__LD_LOCK_THRESH ((uint32_t) 0x160490)

#define RX_VR_LD_LOCK_CNT ((uint16_t) 0x492)
#define RX_VR_LD_LOCK_CNT__LD_LOCK_CNT ((uint32_t) 0xe0492)

#define RX_VR_LD_STAT ((uint16_t) 0x494)
#define RX_VR_LD_STAT__LD_LOCKED ((uint32_t) 0x600494)

#define RX_VR_LD_LOW_CNT ((uint16_t) 0x496)
#define RX_VR_LD_LOW_CNT__LD_LOW_CNT ((uint32_t) 0x7e0496)

#define RX_VR_FD_CTRL ((uint16_t) 0x498)
#define RX_VR_FD_CTRL__SEL_FLTRD_FREQ ((uint32_t) 0x498)

#define RX_VR_FD_PER_MULT ((uint16_t) 0x49a)
#define RX_VR_FD_PER_MULT__PER_MULT ((uint32_t) 0x1e049a)

#define RX_VR_FD_FREQ_CNT_TRGT_MAX ((uint16_t) 0x49c)
#define RX_VR_FD_FREQ_CNT_TRGT_MAX__FREQ_CNT_TRGT_MAX ((uint32_t) 0x1e049c)

#define RX_VR_FD_FREQ_CNT_TRGT_MIN ((uint16_t) 0x49e)
#define RX_VR_FD_FREQ_CNT_TRGT_MIN__FREQ_CNT_TRGT_MIN ((uint32_t) 0x1e049e)

#define RX_VR_FD_STAT ((uint16_t) 0x4a0)
#define RX_VR_FD_STAT__FREQ_FAST ((uint32_t) 0x6004a0)
#define RX_VR_FD_STAT__FREQ_SLOW ((uint32_t) 0x6024a0)

#define RX_VR_FD_FREQ_CNT_OBSV ((uint16_t) 0x4a2)
#define RX_VR_FD_FREQ_CNT_OBSV__FREQ_CNT_OBSV ((uint32_t) 0x7e04a2)

#define RX_DLL_DLL_FREEZE ((uint16_t) 0x4a4)
#define RX_DLL_DLL_FREEZE__FREEZE ((uint32_t) 0x4a4)

#define RX_DLL_MISC_CTRL ((uint16_t) 0x4a6)
#define RX_DLL_MISC_CTRL__GATE_CLK ((uint32_t) 0x4a6)
#define RX_DLL_MISC_CTRL__RST_N ((uint32_t) 0x24a6)
#define RX_DLL_MISC_CTRL__BYP_RST_SYNC ((uint32_t) 0x44a6)
#define RX_DLL_MISC_CTRL__DSM_SHIFT_AMT ((uint32_t) 0x264a6)

#define RX_DLL_SREF_LOOP_CTRL ((uint16_t) 0x4a8)
#define RX_DLL_SREF_LOOP_CTRL__AXC_MULT ((uint32_t) 0x604a8)

#define RX_DLL_TR_WINDOW ((uint16_t) 0x4aa)
#define RX_DLL_TR_WINDOW__SEL_NARROW ((uint32_t) 0xe04aa)

#define RX_DLL_OVRD_ACCUM_CTRL_R ((uint16_t) 0x4ac)
#define RX_DLL_OVRD_ACCUM_CTRL_R__PPHD ((uint32_t) 0xe04ac)
#define RX_DLL_OVRD_ACCUM_CTRL_R__INT_EV ((uint32_t) 0x104ac)
#define RX_DLL_OVRD_ACCUM_CTRL_R__INT_OD ((uint32_t) 0x124ac)

#define RX_DLL_OVRD_ACCUM_CTRL_D ((uint16_t) 0x4ae)
#define RX_DLL_OVRD_ACCUM_CTRL_D__PPHD ((uint32_t) 0xe04ae)
#define RX_DLL_OVRD_ACCUM_CTRL_D__CTRL_D_INT ((uint32_t) 0x104ae)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_0 ((uint16_t) 0x4b0)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_0__VAL ((uint32_t) 0x1004b0)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_1 ((uint16_t) 0x4b2)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_1__VAL ((uint32_t) 0x1004b2)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_2 ((uint16_t) 0x4b4)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_2__VAL ((uint32_t) 0x1004b4)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_3 ((uint16_t) 0x4b6)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_3__VAL ((uint32_t) 0x1004b6)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_4 ((uint16_t) 0x4b8)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_4__VAL ((uint32_t) 0x1004b8)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_5 ((uint16_t) 0x4ba)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_5__VAL ((uint32_t) 0x1004ba)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_6 ((uint16_t) 0x4bc)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_6__VAL ((uint32_t) 0x1004bc)

#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_7 ((uint16_t) 0x4be)
#define RX_DLL_OVRD_VAL_CTRL_R_PPHD_7__VAL ((uint32_t) 0x1004be)

#define RX_DLL_OVRD_VAL_CTRL_R_INT_EV ((uint16_t) 0x4c0)
#define RX_DLL_OVRD_VAL_CTRL_R_INT_EV__VAL ((uint32_t) 0x1a04c0)

#define RX_DLL_OVRD_VAL_CTRL_R_INT_OD ((uint16_t) 0x4c2)
#define RX_DLL_OVRD_VAL_CTRL_R_INT_OD__VAL ((uint32_t) 0x1a04c2)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_0 ((uint16_t) 0x4c4)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_0__VAL ((uint32_t) 0x1004c4)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_1 ((uint16_t) 0x4c6)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_1__VAL ((uint32_t) 0x1004c6)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_2 ((uint16_t) 0x4c8)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_2__VAL ((uint32_t) 0x1004c8)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_3 ((uint16_t) 0x4ca)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_3__VAL ((uint32_t) 0x1004ca)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_4 ((uint16_t) 0x4cc)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_4__VAL ((uint32_t) 0x1004cc)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_5 ((uint16_t) 0x4ce)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_5__VAL ((uint32_t) 0x1004ce)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_6 ((uint16_t) 0x4d0)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_6__VAL ((uint32_t) 0x1004d0)

#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_7 ((uint16_t) 0x4d2)
#define RX_DLL_OVRD_VAL_CTRL_D_PPHD_7__VAL ((uint32_t) 0x1004d2)

#define RX_DLL_OVRD_VAL_CTRL_D_INT ((uint16_t) 0x4d4)
#define RX_DLL_OVRD_VAL_CTRL_D_INT__VAL ((uint32_t) 0x1a04d4)

#define RX_DLL_HOLD_ACCUM_CTRL_R ((uint16_t) 0x4d6)
#define RX_DLL_HOLD_ACCUM_CTRL_R__PPHD ((uint32_t) 0xe04d6)
#define RX_DLL_HOLD_ACCUM_CTRL_R__INT_EV ((uint32_t) 0x104d6)
#define RX_DLL_HOLD_ACCUM_CTRL_R__INT_OD ((uint32_t) 0x124d6)

#define RX_DLL_HOLD_ACCUM_CTRL_D ((uint16_t) 0x4d8)
#define RX_DLL_HOLD_ACCUM_CTRL_D__PPHD ((uint32_t) 0xe04d8)
#define RX_DLL_HOLD_ACCUM_CTRL_D__CTRL_D_INT ((uint32_t) 0x104d8)

#define RX_DLL_INV_ACCUM_IN_CTRL_R ((uint16_t) 0x4da)
#define RX_DLL_INV_ACCUM_IN_CTRL_R__PPHD ((uint32_t) 0xe04da)
#define RX_DLL_INV_ACCUM_IN_CTRL_R__INT_EV ((uint32_t) 0x104da)
#define RX_DLL_INV_ACCUM_IN_CTRL_R__INT_OD ((uint32_t) 0x124da)

#define RX_DLL_INV_ACCUM_IN_CTRL_D ((uint16_t) 0x4dc)
#define RX_DLL_INV_ACCUM_IN_CTRL_D__PPHD ((uint32_t) 0xe04dc)
#define RX_DLL_INV_ACCUM_IN_CTRL_D__CTRL_D_INT ((uint32_t) 0x104dc)

#define RX_DLL_BYP_SAT_LOGIC ((uint16_t) 0x4de)
#define RX_DLL_BYP_SAT_LOGIC__CTRL_R_PPHD ((uint32_t) 0x4de)
#define RX_DLL_BYP_SAT_LOGIC__CTRL_R_INT_EV ((uint32_t) 0x24de)
#define RX_DLL_BYP_SAT_LOGIC__CTRL_R_INT_OD ((uint32_t) 0x44de)
#define RX_DLL_BYP_SAT_LOGIC__CTRL_D_PPHD ((uint32_t) 0x64de)
#define RX_DLL_BYP_SAT_LOGIC__CTRL_D_INT ((uint32_t) 0x84de)

#define RX_DLL_ADJ_POS_CTRL_R_PPHD_LO ((uint16_t) 0x4e0)
#define RX_DLL_ADJ_POS_CTRL_R_PPHD_LO__LSW ((uint32_t) 0x1e04e0)

#define RX_DLL_ADJ_POS_CTRL_R_PPHD_HI ((uint16_t) 0x4e2)
#define RX_DLL_ADJ_POS_CTRL_R_PPHD_HI__MSW ((uint32_t) 0xe04e2)

#define RX_DLL_ADJ_NEG_CTRL_R_PPHD_LO ((uint16_t) 0x4e4)
#define RX_DLL_ADJ_NEG_CTRL_R_PPHD_LO__LSW ((uint32_t) 0x1e04e4)

#define RX_DLL_ADJ_NEG_CTRL_R_PPHD_HI ((uint16_t) 0x4e6)
#define RX_DLL_ADJ_NEG_CTRL_R_PPHD_HI__MSW ((uint32_t) 0xe04e6)

#define RX_DLL_ADJ_POS_CTRL_R_INT_EV_LO ((uint16_t) 0x4e8)
#define RX_DLL_ADJ_POS_CTRL_R_INT_EV_LO__LSW ((uint32_t) 0x1e04e8)

#define RX_DLL_ADJ_POS_CTRL_R_INT_EV_HI ((uint16_t) 0x4ea)
#define RX_DLL_ADJ_POS_CTRL_R_INT_EV_HI__MSW ((uint32_t) 0xe04ea)

#define RX_DLL_ADJ_NEG_CTRL_R_INT_EV_LO ((uint16_t) 0x4ec)
#define RX_DLL_ADJ_NEG_CTRL_R_INT_EV_LO__LSW ((uint32_t) 0x1e04ec)

#define RX_DLL_ADJ_NEG_CTRL_R_INT_EV_HI ((uint16_t) 0x4ee)
#define RX_DLL_ADJ_NEG_CTRL_R_INT_EV_HI__MSW ((uint32_t) 0xe04ee)

#define RX_DLL_ADJ_POS_CTRL_R_INT_OD_LO ((uint16_t) 0x4f0)
#define RX_DLL_ADJ_POS_CTRL_R_INT_OD_LO__LSW ((uint32_t) 0x1e04f0)

#define RX_DLL_ADJ_POS_CTRL_R_INT_OD_HI ((uint16_t) 0x4f2)
#define RX_DLL_ADJ_POS_CTRL_R_INT_OD_HI__MSW ((uint32_t) 0xe04f2)

#define RX_DLL_ADJ_NEG_CTRL_R_INT_OD_LO ((uint16_t) 0x4f4)
#define RX_DLL_ADJ_NEG_CTRL_R_INT_OD_LO__LSW ((uint32_t) 0x1e04f4)

#define RX_DLL_ADJ_NEG_CTRL_R_INT_OD_HI ((uint16_t) 0x4f6)
#define RX_DLL_ADJ_NEG_CTRL_R_INT_OD_HI__MSW ((uint32_t) 0xe04f6)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_0 ((uint16_t) 0x4f8)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_0__LSW ((uint32_t) 0x1e04f8)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_1 ((uint16_t) 0x4fa)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_1__LSW ((uint32_t) 0x1e04fa)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_2 ((uint16_t) 0x4fc)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_2__LSW ((uint32_t) 0x1e04fc)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_3 ((uint16_t) 0x4fe)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_3__LSW ((uint32_t) 0x1e04fe)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_4 ((uint16_t) 0x500)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_4__LSW ((uint32_t) 0x1e0500)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_5 ((uint16_t) 0x502)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_5__LSW ((uint32_t) 0x1e0502)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_6 ((uint16_t) 0x504)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_6__LSW ((uint32_t) 0x1e0504)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_7 ((uint16_t) 0x506)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_LO_7__LSW ((uint32_t) 0x1e0506)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_0 ((uint16_t) 0x508)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_0__MSW ((uint32_t) 0xe0508)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_1 ((uint16_t) 0x50a)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_1__MSW ((uint32_t) 0xe050a)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_2 ((uint16_t) 0x50c)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_2__MSW ((uint32_t) 0xe050c)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_3 ((uint16_t) 0x50e)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_3__MSW ((uint32_t) 0xe050e)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_4 ((uint16_t) 0x510)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_4__MSW ((uint32_t) 0xe0510)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_5 ((uint16_t) 0x512)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_5__MSW ((uint32_t) 0xe0512)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_6 ((uint16_t) 0x514)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_6__MSW ((uint32_t) 0xe0514)

#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_7 ((uint16_t) 0x516)
#define RX_DLL_ADJ_POS_CTRL_D_PPHD_HI_7__MSW ((uint32_t) 0xe0516)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_0 ((uint16_t) 0x518)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_0__LSW ((uint32_t) 0x1e0518)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_1 ((uint16_t) 0x51a)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_1__LSW ((uint32_t) 0x1e051a)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_2 ((uint16_t) 0x51c)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_2__LSW ((uint32_t) 0x1e051c)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_3 ((uint16_t) 0x51e)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_3__LSW ((uint32_t) 0x1e051e)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_4 ((uint16_t) 0x520)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_4__LSW ((uint32_t) 0x1e0520)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_5 ((uint16_t) 0x522)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_5__LSW ((uint32_t) 0x1e0522)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_6 ((uint16_t) 0x524)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_6__LSW ((uint32_t) 0x1e0524)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_7 ((uint16_t) 0x526)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_LO_7__LSW ((uint32_t) 0x1e0526)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_0 ((uint16_t) 0x528)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_0__MSW ((uint32_t) 0xe0528)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_1 ((uint16_t) 0x52a)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_1__MSW ((uint32_t) 0xe052a)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_2 ((uint16_t) 0x52c)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_2__MSW ((uint32_t) 0xe052c)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_3 ((uint16_t) 0x52e)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_3__MSW ((uint32_t) 0xe052e)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_4 ((uint16_t) 0x530)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_4__MSW ((uint32_t) 0xe0530)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_5 ((uint16_t) 0x532)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_5__MSW ((uint32_t) 0xe0532)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_6 ((uint16_t) 0x534)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_6__MSW ((uint32_t) 0xe0534)

#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_7 ((uint16_t) 0x536)
#define RX_DLL_ADJ_NEG_CTRL_D_PPHD_HI_7__MSW ((uint32_t) 0xe0536)

#define RX_DLL_ADJ_POS_CTRL_D_INT_LO ((uint16_t) 0x538)
#define RX_DLL_ADJ_POS_CTRL_D_INT_LO__LSW ((uint32_t) 0x1e0538)

#define RX_DLL_ADJ_POS_CTRL_D_INT_HI ((uint16_t) 0x53a)
#define RX_DLL_ADJ_POS_CTRL_D_INT_HI__MSW ((uint32_t) 0xe053a)

#define RX_DLL_ADJ_NEG_CTRL_D_INT_LO ((uint16_t) 0x53c)
#define RX_DLL_ADJ_NEG_CTRL_D_INT_LO__LSW ((uint32_t) 0x1e053c)

#define RX_DLL_ADJ_NEG_CTRL_D_INT_HI ((uint16_t) 0x53e)
#define RX_DLL_ADJ_NEG_CTRL_D_INT_HI__MSW ((uint32_t) 0xe053e)

#define RX_DLL_SAT_MAX_CTRL_R_PPHD_LO ((uint16_t) 0x540)
#define RX_DLL_SAT_MAX_CTRL_R_PPHD_LO__LSW ((uint32_t) 0x1e0540)

#define RX_DLL_SAT_MAX_CTRL_R_PPHD_HI ((uint16_t) 0x542)
#define RX_DLL_SAT_MAX_CTRL_R_PPHD_HI__MSW ((uint32_t) 0xe0542)

#define RX_DLL_SAT_MIN_CTRL_R_PPHD_LO ((uint16_t) 0x544)
#define RX_DLL_SAT_MIN_CTRL_R_PPHD_LO__LSW ((uint32_t) 0x1e0544)

#define RX_DLL_SAT_MIN_CTRL_R_PPHD_HI ((uint16_t) 0x546)
#define RX_DLL_SAT_MIN_CTRL_R_PPHD_HI__MSW ((uint32_t) 0xe0546)

#define RX_DLL_SAT_MAX_CTRL_R_INT_EV_LO ((uint16_t) 0x548)
#define RX_DLL_SAT_MAX_CTRL_R_INT_EV_LO__LSW ((uint32_t) 0x1e0548)

#define RX_DLL_SAT_MAX_CTRL_R_INT_EV_HI ((uint16_t) 0x54a)
#define RX_DLL_SAT_MAX_CTRL_R_INT_EV_HI__MSW ((uint32_t) 0xe054a)

#define RX_DLL_SAT_MIN_CTRL_R_INT_EV_LO ((uint16_t) 0x54c)
#define RX_DLL_SAT_MIN_CTRL_R_INT_EV_LO__LSW ((uint32_t) 0x1e054c)

#define RX_DLL_SAT_MIN_CTRL_R_INT_EV_HI ((uint16_t) 0x54e)
#define RX_DLL_SAT_MIN_CTRL_R_INT_EV_HI__MSW ((uint32_t) 0xe054e)

#define RX_DLL_SAT_MAX_CTRL_R_INT_OD_LO ((uint16_t) 0x550)
#define RX_DLL_SAT_MAX_CTRL_R_INT_OD_LO__LSW ((uint32_t) 0x1e0550)

#define RX_DLL_SAT_MAX_CTRL_R_INT_OD_HI ((uint16_t) 0x552)
#define RX_DLL_SAT_MAX_CTRL_R_INT_OD_HI__MSW ((uint32_t) 0xe0552)

#define RX_DLL_SAT_MIN_CTRL_R_INT_OD_LO ((uint16_t) 0x554)
#define RX_DLL_SAT_MIN_CTRL_R_INT_OD_LO__LSW ((uint32_t) 0x1e0554)

#define RX_DLL_SAT_MIN_CTRL_R_INT_OD_HI ((uint16_t) 0x556)
#define RX_DLL_SAT_MIN_CTRL_R_INT_OD_HI__MSW ((uint32_t) 0xe0556)

#define RX_DLL_SAT_MAX_CTRL_D_PPHD_LO ((uint16_t) 0x558)
#define RX_DLL_SAT_MAX_CTRL_D_PPHD_LO__LSW ((uint32_t) 0x1e0558)

#define RX_DLL_SAT_MAX_CTRL_D_PPHD_HI ((uint16_t) 0x55a)
#define RX_DLL_SAT_MAX_CTRL_D_PPHD_HI__MSW ((uint32_t) 0xe055a)

#define RX_DLL_SAT_MIN_CTRL_D_PPHD_LO ((uint16_t) 0x55c)
#define RX_DLL_SAT_MIN_CTRL_D_PPHD_LO__LSW ((uint32_t) 0x1e055c)

#define RX_DLL_SAT_MIN_CTRL_D_PPHD_HI ((uint16_t) 0x55e)
#define RX_DLL_SAT_MIN_CTRL_D_PPHD_HI__MSW ((uint32_t) 0xe055e)

#define RX_DLL_SAT_MAX_CTRL_D_INT_LO ((uint16_t) 0x560)
#define RX_DLL_SAT_MAX_CTRL_D_INT_LO__LSW ((uint32_t) 0x1e0560)

#define RX_DLL_SAT_MAX_CTRL_D_INT_HI ((uint16_t) 0x562)
#define RX_DLL_SAT_MAX_CTRL_D_INT_HI__MSW ((uint32_t) 0xe0562)

#define RX_DLL_SAT_MIN_CTRL_D_INT_LO ((uint16_t) 0x564)
#define RX_DLL_SAT_MIN_CTRL_D_INT_LO__LSW ((uint32_t) 0x1e0564)

#define RX_DLL_SAT_MIN_CTRL_D_INT_HI ((uint16_t) 0x566)
#define RX_DLL_SAT_MIN_CTRL_D_INT_HI__MSW ((uint32_t) 0xe0566)

#define RX_DLL_THRESH_MAX_CTRL_R_PPHD ((uint16_t) 0x568)
#define RX_DLL_THRESH_MAX_CTRL_R_PPHD__THRESH ((uint32_t) 0x100568)

#define RX_DLL_THRESH_MIN_CTRL_R_PPHD ((uint16_t) 0x56a)
#define RX_DLL_THRESH_MIN_CTRL_R_PPHD__THRESH ((uint32_t) 0x10056a)

#define RX_DLL_THRESH_MAX_CTRL_D_PPHD ((uint16_t) 0x56c)
#define RX_DLL_THRESH_MAX_CTRL_D_PPHD__THRESH ((uint32_t) 0x10056c)

#define RX_DLL_THRESH_MIN_CTRL_D_PPHD ((uint16_t) 0x56e)
#define RX_DLL_THRESH_MIN_CTRL_D_PPHD__THRESH ((uint32_t) 0x10056e)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_0 ((uint16_t) 0x570)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_0__LSW ((uint32_t) 0x7e0570)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_1 ((uint16_t) 0x572)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_1__LSW ((uint32_t) 0x7e0572)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_2 ((uint16_t) 0x574)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_2__LSW ((uint32_t) 0x7e0574)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_3 ((uint16_t) 0x576)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_3__LSW ((uint32_t) 0x7e0576)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_4 ((uint16_t) 0x578)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_4__LSW ((uint32_t) 0x7e0578)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_5 ((uint16_t) 0x57a)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_5__LSW ((uint32_t) 0x7e057a)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_6 ((uint16_t) 0x57c)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_6__LSW ((uint32_t) 0x7e057c)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_7 ((uint16_t) 0x57e)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_LO_7__LSW ((uint32_t) 0x7e057e)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_0 ((uint16_t) 0x580)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_0__MSW ((uint32_t) 0x6e0580)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_1 ((uint16_t) 0x582)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_1__MSW ((uint32_t) 0x6e0582)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_2 ((uint16_t) 0x584)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_2__MSW ((uint32_t) 0x6e0584)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_3 ((uint16_t) 0x586)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_3__MSW ((uint32_t) 0x6e0586)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_4 ((uint16_t) 0x588)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_4__MSW ((uint32_t) 0x6e0588)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_5 ((uint16_t) 0x58a)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_5__MSW ((uint32_t) 0x6e058a)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_6 ((uint16_t) 0x58c)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_6__MSW ((uint32_t) 0x6e058c)

#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_7 ((uint16_t) 0x58e)
#define RX_DLL_ACCUM_OBSV_CTRL_R_PPHD_HI_7__MSW ((uint32_t) 0x6e058e)

#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_LO ((uint16_t) 0x590)
#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_LO__LSW ((uint32_t) 0x7e0590)

#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_HI ((uint16_t) 0x592)
#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_EV_HI__MSW ((uint32_t) 0x6e0592)

#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_LO ((uint16_t) 0x594)
#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_LO__LSW ((uint32_t) 0x7e0594)

#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_HI ((uint16_t) 0x596)
#define RX_DLL_ACCUM_OBSV_CTRL_R_INT_OD_HI__MSW ((uint32_t) 0x6e0596)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_0 ((uint16_t) 0x598)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_0__LSW ((uint32_t) 0x7e0598)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_1 ((uint16_t) 0x59a)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_1__LSW ((uint32_t) 0x7e059a)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_2 ((uint16_t) 0x59c)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_2__LSW ((uint32_t) 0x7e059c)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_3 ((uint16_t) 0x59e)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_3__LSW ((uint32_t) 0x7e059e)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_4 ((uint16_t) 0x5a0)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_4__LSW ((uint32_t) 0x7e05a0)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_5 ((uint16_t) 0x5a2)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_5__LSW ((uint32_t) 0x7e05a2)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_6 ((uint16_t) 0x5a4)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_6__LSW ((uint32_t) 0x7e05a4)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_7 ((uint16_t) 0x5a6)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_LO_7__LSW ((uint32_t) 0x7e05a6)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_0 ((uint16_t) 0x5a8)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_0__MSW ((uint32_t) 0x6e05a8)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_1 ((uint16_t) 0x5aa)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_1__MSW ((uint32_t) 0x6e05aa)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_2 ((uint16_t) 0x5ac)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_2__MSW ((uint32_t) 0x6e05ac)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_3 ((uint16_t) 0x5ae)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_3__MSW ((uint32_t) 0x6e05ae)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_4 ((uint16_t) 0x5b0)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_4__MSW ((uint32_t) 0x6e05b0)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_5 ((uint16_t) 0x5b2)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_5__MSW ((uint32_t) 0x6e05b2)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_6 ((uint16_t) 0x5b4)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_6__MSW ((uint32_t) 0x6e05b4)

#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_7 ((uint16_t) 0x5b6)
#define RX_DLL_ACCUM_OBSV_CTRL_D_PPHD_HI_7__MSW ((uint32_t) 0x6e05b6)

#define RX_DLL_ACCUM_OBSV_CTRL_D_INT_LO ((uint16_t) 0x5b8)
#define RX_DLL_ACCUM_OBSV_CTRL_D_INT_LO__LSW ((uint32_t) 0x7e05b8)

#define RX_DLL_ACCUM_OBSV_CTRL_D_INT_HI ((uint16_t) 0x5ba)
#define RX_DLL_ACCUM_OBSV_CTRL_D_INT_HI__MSW ((uint32_t) 0x6e05ba)

#define RX_DLL_CLKSMP ((uint16_t) 0x5bc)
#define RX_DLL_CLKSMP__CLKSMP ((uint32_t) 0x6e05bc)

#define RX_DLL_WSMPR ((uint16_t) 0x5be)
#define RX_DLL_WSMPR__WSMPR ((uint32_t) 0x6e05be)
#define RX_DLL_WSMPR__WSMPR_P ((uint32_t) 0x6f05be)

#define RX_DLL_WSMPD ((uint16_t) 0x5c0)
#define RX_DLL_WSMPD__WSMPD ((uint32_t) 0x6e05c0)
#define RX_DLL_WSMPD__WSMPD_P ((uint32_t) 0x6f05c0)

#define RX_DLL_TPPHD_SAT ((uint16_t) 0x5c2)
#define RX_DLL_TPPHD_SAT__MIN_VAL ((uint32_t) 0xe05c2)

#define RX_DLL_TINT_SAT ((uint16_t) 0x5c4)
#define RX_DLL_TINT_SAT__MAX_VAL ((uint32_t) 0x1405c4)

#define RX_DLL_DSM_OVRD_ACCUM_CTRL_R ((uint16_t) 0x5c6)
#define RX_DLL_DSM_OVRD_ACCUM_CTRL_R__PPHD ((uint32_t) 0xe05c6)
#define RX_DLL_DSM_OVRD_ACCUM_CTRL_R__INT_EV ((uint32_t) 0x105c6)
#define RX_DLL_DSM_OVRD_ACCUM_CTRL_R__INT_OD ((uint32_t) 0x125c6)

#define RX_DLL_DSM_OVRD_ACCUM_CTRL_D ((uint16_t) 0x5c8)
#define RX_DLL_DSM_OVRD_ACCUM_CTRL_D__PPHD ((uint32_t) 0xe05c8)
#define RX_DLL_DSM_OVRD_ACCUM_CTRL_D__CTRL_D_INT ((uint32_t) 0x105c8)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_0 ((uint16_t) 0x5ca)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_0__VAL ((uint32_t) 0x1e05ca)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_1 ((uint16_t) 0x5cc)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_1__VAL ((uint32_t) 0x1e05cc)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_2 ((uint16_t) 0x5ce)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_2__VAL ((uint32_t) 0x1e05ce)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_3 ((uint16_t) 0x5d0)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_3__VAL ((uint32_t) 0x1e05d0)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_4 ((uint16_t) 0x5d2)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_4__VAL ((uint32_t) 0x1e05d2)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_5 ((uint16_t) 0x5d4)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_5__VAL ((uint32_t) 0x1e05d4)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_6 ((uint16_t) 0x5d6)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_6__VAL ((uint32_t) 0x1e05d6)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_7 ((uint16_t) 0x5d8)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_7__VAL ((uint32_t) 0x1e05d8)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_8 ((uint16_t) 0x5da)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_8__VAL ((uint32_t) 0x1e05da)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_9 ((uint16_t) 0x5dc)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_9__VAL ((uint32_t) 0x1e05dc)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_10 ((uint16_t) 0x5de)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_10__VAL ((uint32_t) 0x1e05de)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_11 ((uint16_t) 0x5e0)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_11__VAL ((uint32_t) 0x1e05e0)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_12 ((uint16_t) 0x5e2)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_12__VAL ((uint32_t) 0x1e05e2)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_13 ((uint16_t) 0x5e4)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_13__VAL ((uint32_t) 0x1e05e4)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_14 ((uint16_t) 0x5e6)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_14__VAL ((uint32_t) 0x1e05e6)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_15 ((uint16_t) 0x5e8)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_PPHD_15__VAL ((uint32_t) 0x1e05e8)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_EV_0 ((uint16_t) 0x5ea)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_EV_0__VAL ((uint32_t) 0x1e05ea)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_EV_1 ((uint16_t) 0x5ec)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_EV_1__VAL ((uint32_t) 0x1e05ec)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_OD_0 ((uint16_t) 0x5ee)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_OD_0__VAL ((uint32_t) 0x1e05ee)

#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_OD_1 ((uint16_t) 0x5f0)
#define RX_DLL_DSM_OVRD_VAL_CTRL_R_INT_OD_1__VAL ((uint32_t) 0x1e05f0)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_0 ((uint16_t) 0x5f2)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_0__VAL ((uint32_t) 0x1e05f2)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_1 ((uint16_t) 0x5f4)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_1__VAL ((uint32_t) 0x1e05f4)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_2 ((uint16_t) 0x5f6)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_2__VAL ((uint32_t) 0x1e05f6)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_3 ((uint16_t) 0x5f8)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_3__VAL ((uint32_t) 0x1e05f8)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_4 ((uint16_t) 0x5fa)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_4__VAL ((uint32_t) 0x1e05fa)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_5 ((uint16_t) 0x5fc)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_5__VAL ((uint32_t) 0x1e05fc)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_6 ((uint16_t) 0x5fe)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_6__VAL ((uint32_t) 0x1e05fe)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_7 ((uint16_t) 0x600)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_7__VAL ((uint32_t) 0x1e0600)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_8 ((uint16_t) 0x602)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_8__VAL ((uint32_t) 0x1e0602)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_9 ((uint16_t) 0x604)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_9__VAL ((uint32_t) 0x1e0604)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_10 ((uint16_t) 0x606)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_10__VAL ((uint32_t) 0x1e0606)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_11 ((uint16_t) 0x608)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_11__VAL ((uint32_t) 0x1e0608)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_12 ((uint16_t) 0x60a)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_12__VAL ((uint32_t) 0x1e060a)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_13 ((uint16_t) 0x60c)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_13__VAL ((uint32_t) 0x1e060c)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_14 ((uint16_t) 0x60e)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_14__VAL ((uint32_t) 0x1e060e)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_15 ((uint16_t) 0x610)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_PPHD_15__VAL ((uint32_t) 0x1e0610)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_INT_0 ((uint16_t) 0x612)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_INT_0__VAL ((uint32_t) 0x1e0612)

#define RX_DLL_DSM_OVRD_VAL_CTRL_D_INT_1 ((uint16_t) 0x614)
#define RX_DLL_DSM_OVRD_VAL_CTRL_D_INT_1__VAL ((uint32_t) 0x1e0614)

#define RX_DLL_INV_DSM_OUT_CTRL_R ((uint16_t) 0x616)
#define RX_DLL_INV_DSM_OUT_CTRL_R__PPHD ((uint32_t) 0xe0616)
#define RX_DLL_INV_DSM_OUT_CTRL_R__INT_EV ((uint32_t) 0x10616)
#define RX_DLL_INV_DSM_OUT_CTRL_R__INT_OD ((uint32_t) 0x12616)

#define RX_DLL_INV_DSM_OUT_CTRL_D ((uint16_t) 0x618)
#define RX_DLL_INV_DSM_OUT_CTRL_D__PPHD ((uint32_t) 0xe0618)
#define RX_DLL_INV_DSM_OUT_CTRL_D__CTRL_D_INT ((uint32_t) 0x10618)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_0 ((uint16_t) 0x61a)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_0__VAL ((uint32_t) 0x72061a)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_1 ((uint16_t) 0x61c)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_1__VAL ((uint32_t) 0x72061c)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_2 ((uint16_t) 0x61e)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_2__VAL ((uint32_t) 0x72061e)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_3 ((uint16_t) 0x620)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_3__VAL ((uint32_t) 0x720620)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_4 ((uint16_t) 0x622)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_4__VAL ((uint32_t) 0x720622)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_5 ((uint16_t) 0x624)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_5__VAL ((uint32_t) 0x720624)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_6 ((uint16_t) 0x626)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_6__VAL ((uint32_t) 0x720626)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_7 ((uint16_t) 0x628)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_PPHD_7__VAL ((uint32_t) 0x720628)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_0 ((uint16_t) 0x62a)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_0__VAL ((uint32_t) 0x72062a)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_1 ((uint16_t) 0x62c)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_1__VAL ((uint32_t) 0x72062c)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_2 ((uint16_t) 0x62e)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_2__VAL ((uint32_t) 0x72062e)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_3 ((uint16_t) 0x630)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_3__VAL ((uint32_t) 0x720630)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_4 ((uint16_t) 0x632)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_4__VAL ((uint32_t) 0x720632)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_5 ((uint16_t) 0x634)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_5__VAL ((uint32_t) 0x720634)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_6 ((uint16_t) 0x636)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_6__VAL ((uint32_t) 0x720636)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_7 ((uint16_t) 0x638)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_R_PPHD_7__VAL ((uint32_t) 0x720638)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_INT_EV ((uint16_t) 0x63a)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_INT_EV__VAL ((uint32_t) 0x78063a)

#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_R_INT_EV ((uint16_t) 0x63c)
#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_R_INT_EV__VAL ((uint32_t) 0x78063c)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_INT_OD ((uint16_t) 0x63e)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_R_INT_OD__VAL ((uint32_t) 0x78063e)

#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_R_INT_OD ((uint16_t) 0x640)
#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_R_INT_OD__VAL ((uint32_t) 0x780640)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_0 ((uint16_t) 0x642)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_0__VAL ((uint32_t) 0x720642)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_1 ((uint16_t) 0x644)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_1__VAL ((uint32_t) 0x720644)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_2 ((uint16_t) 0x646)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_2__VAL ((uint32_t) 0x720646)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_3 ((uint16_t) 0x648)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_3__VAL ((uint32_t) 0x720648)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_4 ((uint16_t) 0x64a)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_4__VAL ((uint32_t) 0x72064a)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_5 ((uint16_t) 0x64c)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_5__VAL ((uint32_t) 0x72064c)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_6 ((uint16_t) 0x64e)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_6__VAL ((uint32_t) 0x72064e)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_7 ((uint16_t) 0x650)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_PPHD_7__VAL ((uint32_t) 0x720650)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_0 ((uint16_t) 0x652)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_0__VAL ((uint32_t) 0x720652)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_1 ((uint16_t) 0x654)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_1__VAL ((uint32_t) 0x720654)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_2 ((uint16_t) 0x656)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_2__VAL ((uint32_t) 0x720656)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_3 ((uint16_t) 0x658)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_3__VAL ((uint32_t) 0x720658)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_4 ((uint16_t) 0x65a)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_4__VAL ((uint32_t) 0x72065a)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_5 ((uint16_t) 0x65c)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_5__VAL ((uint32_t) 0x72065c)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_6 ((uint16_t) 0x65e)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_6__VAL ((uint32_t) 0x72065e)

#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_7 ((uint16_t) 0x660)
#define RX_DLL_DSM_L_ACCUM_OBSV_CTRL_D_PPHD_7__VAL ((uint32_t) 0x720660)

#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_INT ((uint16_t) 0x662)
#define RX_DLL_DSM_E_ACCUM_OBSV_CTRL_D_INT__VAL ((uint32_t) 0x780662)

#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_D_INT ((uint16_t) 0x664)
#define RX_DLL_DSM_O_ACCUM_OBSV_CTRL_D_INT__VAL ((uint32_t) 0x780664)

#define RX_DLL_BIAS_CTRL ((uint16_t) 0x666)
#define RX_DLL_BIAS_CTRL__BIAS_LOW_N ((uint32_t) 0x666)
#define RX_DLL_BIAS_CTRL__DSM_OVRD_BIAS ((uint32_t) 0x2666)
#define RX_DLL_BIAS_CTRL__INV_DSM_BIAS ((uint32_t) 0x4666)

#define RX_DLL_DSM_OVRD_BIAS_VAL_0 ((uint16_t) 0x668)
#define RX_DLL_DSM_OVRD_BIAS_VAL_0__VAL ((uint32_t) 0x1e0668)

#define RX_DLL_DSM_OVRD_BIAS_VAL_1 ((uint16_t) 0x66a)
#define RX_DLL_DSM_OVRD_BIAS_VAL_1__VAL ((uint32_t) 0x1e066a)

#define RX_DLL_VREF_CTRL ((uint16_t) 0x66c)
#define RX_DLL_VREF_CTRL__VREF_EN ((uint32_t) 0x66c)
#define RX_DLL_VREF_CTRL__VREF_VAL ((uint32_t) 0x14266c)
#define RX_DLL_VREF_CTRL__INV_DSM_VREF ((uint32_t) 0x1866c)

#define RX_DLL_LD_CTRL ((uint16_t) 0x66e)
#define RX_DLL_LD_CTRL__LOCK_DET_RST_N ((uint32_t) 0x66e)
#define RX_DLL_LD_CTRL__OVRD_CTRL_R_INT_EV ((uint32_t) 0x266e)
#define RX_DLL_LD_CTRL__OVRD_CTRL_R_INT_OD ((uint32_t) 0x466e)
#define RX_DLL_LD_CTRL__OVRD_CTRL_D_INT ((uint32_t) 0x666e)
#define RX_DLL_LD_CTRL__FORCE_CTRL_R_INT_EV ((uint32_t) 0x866e)
#define RX_DLL_LD_CTRL__FORCE_CTRL_R_INT_OD ((uint32_t) 0xa66e)
#define RX_DLL_LD_CTRL__FORCE_CTRL_D_INT ((uint32_t) 0xc66e)
#define RX_DLL_LD_CTRL__SEL_LIVE_CTRL_R_INT_EV ((uint32_t) 0xe66e)
#define RX_DLL_LD_CTRL__SEL_LIVE_CTRL_R_INT_OD ((uint32_t) 0x1066e)
#define RX_DLL_LD_CTRL__SEL_LIVE_CTRL_D_INT ((uint32_t) 0x1266e)

#define RX_DLL_LD_THRESH_CTRL_R_INT_LO ((uint16_t) 0x670)
#define RX_DLL_LD_THRESH_CTRL_R_INT_LO__LSW ((uint32_t) 0x1e0670)

#define RX_DLL_LD_THRESH_CTRL_R_INT_HI ((uint16_t) 0x672)
#define RX_DLL_LD_THRESH_CTRL_R_INT_HI__MSW ((uint32_t) 0xe0672)

#define RX_DLL_LD_THRESH_CTRL_D_INT_LO ((uint16_t) 0x674)
#define RX_DLL_LD_THRESH_CTRL_D_INT_LO__LSW ((uint32_t) 0x1e0674)

#define RX_DLL_LD_THRESH_CTRL_D_INT_HI ((uint16_t) 0x676)
#define RX_DLL_LD_THRESH_CTRL_D_INT_HI__MSW ((uint32_t) 0xe0676)

#define RX_DLL_LD_LOCKING_PERIOD_CTRL_R_INT ((uint16_t) 0x678)
#define RX_DLL_LD_LOCKING_PERIOD_CTRL_R_INT__PER ((uint32_t) 0x1e0678)

#define RX_DLL_LD_LOCKING_PERIOD_CTRL_D_INT ((uint16_t) 0x67a)
#define RX_DLL_LD_LOCKING_PERIOD_CTRL_D_INT__PER ((uint32_t) 0x1e067a)

#define RX_DLL_LD_STAT ((uint16_t) 0x67c)
#define RX_DLL_LD_STAT__LOCKED_CTRL_R_INT_EV ((uint32_t) 0x60067c)
#define RX_DLL_LD_STAT__LOCKED_CTRL_R_INT_OD ((uint32_t) 0x60267c)
#define RX_DLL_LD_STAT__LOCKED_CTRL_D_INT ((uint32_t) 0x60467c)

#endif /* BLYNX_BOW_CSR_MAP_H */
