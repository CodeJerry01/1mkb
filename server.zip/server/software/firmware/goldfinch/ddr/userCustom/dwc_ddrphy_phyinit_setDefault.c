
/** \file 
 * \brief used to set PhyInit inputs statically by the user
 */
#include <string.h>
#include "dwc_ddrphy_phyinit.h"

/**  
 * 1D Message Block 
 */
extern PMU_SMB_DDR4R_1D_t    mb_DDR4R_1D[4];
/**  
 * 2D Message Block 
 */
extern PMU_SMB_DDR4R_2D_t    mb_DDR4R_2D[4];

/**
 *  \addtogroup CustFunc
 *  @{
 */

/** @brief  This function provides a default configuration of PHY.
 * 
 * This function provides a default configuration of PHY. To change the default
 * configuration, the user can edit this file directly or use the 
 * dwc_ddrphy_phyinit_userCustom_overrideUserInput() function. The default
 * values selected below only represent a general case and may not be correct 
 * for every use case.  
 * 
 * @return Void
 */
void dwc_ddrphy_phyinit_setDefault (int Train2D /**< Train2D 1=1D & 2D training enabled, 0=only 1D training. */) {
    
    char *printf_header;
    printf_header = "// [dwc_ddrphy_phyinit_setDefault]";

    dwc_ddrphy_phyinit_print ("%s Start of dwc_ddrphy_phyinit_setDefault()\n", printf_header);


    // ##############################################################
    // userInputBasic - Basic Inputs the user must provide values
    // for detailed descriptions of each field see src/dwc_ddrphy_phyinit_struct.h
    // ##############################################################
    userInputBasic.DramType                 = DDR4;
    userInputBasic.DimmType                 = RDIMM;
    userInputBasic.HardMacroVer             = 3; //default: HardMacro family D 

    userInputBasic.NumDbyte                 = 0x0008;
    userInputBasic.NumActiveDbyteDfi0       = 0x0008;
    userInputBasic.NumAnib                  = 0x000a;
    userInputBasic.NumRank_dfi0             = 0x0001; // 1 rank
    userInputBasic.NumPStates               = 0x0001; // 1 Pstate
    userInputBasic.Frequency[3]             = 800; 
    userInputBasic.Frequency[2]             = 933; 
    userInputBasic.Frequency[1]             = 1067; 
    userInputBasic.Frequency[0]             = 1600; // 3200Mbps
    userInputBasic.PllBypass[0]             = 0x0000;
    userInputBasic.PllBypass[1]             = 0x0000;
    userInputBasic.PllBypass[2]             = 0x0000;
    userInputBasic.PllBypass[3]             = 0x0000;
    userInputBasic.DfiFreqRatio[0]          = 0x0001;
    userInputBasic.DfiFreqRatio[1]          = 0x0001;
    userInputBasic.DfiFreqRatio[2]          = 0x0001;
    userInputBasic.DfiFreqRatio[3]          = 0x0001;
    userInputBasic.Dfi1Exists               = 0x0000;
    userInputBasic.DramDataWidth            = 0x0010; //x16

    // ##############################################################
    // userInputAdvnaced (Optional)  
    // Default values will be used if no input provided
    // ##############################################################

    userInputAdvanced.DramByteSwap             = 0x0000; 
    userInputAdvanced.ExtCalResVal             = 0x0000;
    userInputAdvanced.TxSlewRiseDQ[0]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[1]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[2]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[3]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[0]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[1]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[2]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[3]          = 0x000f; 
    userInputAdvanced.TxSlewRiseAC             = 0x000f; 
    userInputAdvanced.TxSlewFallAC             = 0x000f; 
    userInputAdvanced.ODTImpedance[0]          = 60;      
    userInputAdvanced.ODTImpedance[1]          = 60; 
    userInputAdvanced.ODTImpedance[2]          = 60; 
    userInputAdvanced.ODTImpedance[3]          = 60; 
    userInputAdvanced.TxImpedance[0]           = 60; 
    userInputAdvanced.TxImpedance[1]           = 60; 
    userInputAdvanced.TxImpedance[2]           = 60; 
    userInputAdvanced.TxImpedance[3]           = 60;     
    userInputAdvanced.ATxImpedance             = 20;      //with HardMacro family E, ATxImpedance will default to 40 Ohm instead       
    userInputAdvanced.MemAlertEn               = 0x0000;
    userInputAdvanced.MemAlertPUImp            = 0x0005;
    userInputAdvanced.MemAlertVrefLevel        = 0x0029;
    userInputAdvanced.MemAlertSyncBypass       = 0x0000;
    userInputAdvanced.CalInterval              = 0x0009;
    userInputAdvanced.CalOnce                  = 0x0000;

    userInputAdvanced.DisDynAdrTri[0]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[1]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[2]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[3]          = 0x0000;
    userInputAdvanced.Is2Ttiming[0]            = 0x0000;
    userInputAdvanced.Is2Ttiming[1]            = 0x0000;
    userInputAdvanced.Is2Ttiming[2]            = 0x0000;
    userInputAdvanced.Is2Ttiming[3]            = 0x0000;


    userInputAdvanced.D4RxPreambleLength[0]    = 0x0001;
    userInputAdvanced.D4RxPreambleLength[1]    = 0x0001;
    userInputAdvanced.D4RxPreambleLength[2]    = 0x0001;
    userInputAdvanced.D4RxPreambleLength[3]    = 0x0001;
    userInputAdvanced.D4TxPreambleLength[0]    = 0x0000;
    userInputAdvanced.D4TxPreambleLength[1]    = 0x0000;
    userInputAdvanced.D4TxPreambleLength[2]    = 0x0000;
    userInputAdvanced.D4TxPreambleLength[3]    = 0x0000;
    userInputAdvanced.CsMode                   = 0; 
    userInputAdvanced.CastCsToCID              = 0; 
    userInputAdvanced.Context[0]               = 0; 
    userInputAdvanced.Context[1]               = 0; 
    userInputAdvanced.Context[2]               = 0; 
    userInputAdvanced.Context[3]               = 0; 


    // ##############################################################
    // Basic Message Block Variables
    // ##############################################################
    
    uint8_t myps;

    // ##############################################################
    // These are typically invariant across Pstate
    // ##############################################################
    uint8_t MsgMisc              = 0x06; //For fast simulation
    uint8_t Reserved00           = 0x0;  // Set Reserved00[7]   = 1 (If using T28 attenuated receivers)
                                         // Set Reserved00[6:0] = 0 (Reserved; must be programmed to 0)
                                          
    uint8_t HdtCtrl              = 0xff;
    uint8_t CsPresent            = 0x01; // Indicates presence of DRAM at each chip select for PHY. 
                                         // 
                                         // If the bit is set to 1, the CS is connected to DRAM. 
                                         // If the bit is set to 0, the CS is not connected to DRAM.
                                         // 
                                         // Set CsPresent[0]   = 1 (if CS0 is populated with DRAM)
                                         // Set CsPresent[1]   = 1 (if CS1 is populated with DRAM)
                                         // Set CsPresent[2]   = 1 (if CS2 is populated with DRAM)
                                         // Set CsPresent[3]   = 1 (if CS3 is populated with DRAM)
                                         // Set CsPresent[7:4] = 0 (Reserved; must be programmed to 0)
 
    uint8_t PhyVref              = 0x56; //Use Analytical VREF and Compensate for T28 Attenuator, see PHY databook
    uint8_t DFIMRLMargin         = 0x01; //1 is typically good in DDR3
 
    uint8_t AddrMirror           = 0xaa; // Set AddrMirror[pstate] if CS[pstate] is mirrored. (typically odd CS are mirroed in DIMMs)
    uint8_t WRODTPAT_RANK0       = 0x01; //When Writing Rank0 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK1       = 0x02; //When Writing Rank1 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK2       = 0x00; //When Writing Rank2 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK3       = 0x00; //When Writing Rank3 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
      		  
    uint8_t RDODTPAT_RANK0       = 0x20; //When Reading Rank0 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK1       = 0x10; //When Reading Rank1 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK2       = 0x00; //When Reading Rank2 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK3       = 0x00; //When Reading Rank3 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM

    uint8_t D4Misc               = 0x1;  // Protect memory reset:
                                         // 0x1 = dfi_reset_n cannot control BP_MEMRESERT_L to devices after training.
                                         // 0x0 = dfi_resert_n can control BP_MEMRESERT_L to devices after training

    uint8_t Share2DVrefResult    = 0x1;  // Bitmap that controls which vref generator the phy will use per pstate
                                         //     If Share2DVrefResult[x] = 1, pstate x will use the per-lane VrefDAC0/1 CSRs which can be trained by 2d training.    
                                         //                                  If 2D has not run yet, VrefDAC0/1 will default to pstate 0's 1D phyVref messageBlock setting.
                                         //     If Share2DVrefResult[x] = 0, pstate x will use the per-phy VrefInGlobal CSR, which are set to pstate x's 1D phyVref messageBlock setting. 

    // ##############################################################
    // These typically change across Pstate
    // ##############################################################
    
    uint16_t SequenceCtrl[4];
  
    SequenceCtrl[0] = 0x031f; 
    SequenceCtrl[1] = 0x021f; 
    SequenceCtrl[2] = 0x021f;
    SequenceCtrl[3] = 0x021f;
    
    uint16_t mr0[4];	 
    uint16_t mr1[4];	 
    uint16_t mr2[4];	 
    uint16_t mr3[4];	 
    uint16_t mr4[4];	 
    uint16_t mr5[4];	 
    uint16_t mr6[4];	 
 
    uint16_t ALT_CAS_L[4];  //Need to set if using RDDBI
    uint16_t ALT_WCAS_L[4]; //Need to set if using 2tck Write Preambles
 
    mr0[0] = 0x0630;
    mr1[0] = 0x0201;				 
    mr2[0] = 0x0020;
    mr3[0] = 0x0400;				 
    mr4[0] = 0x0000;				 
    mr5[0] = 0x0480;				 
    mr6[0] = 0x0800 | 0x0018; // Example Vref : 0x18=907mV = 0.75*VDDQ
 
    ALT_CAS_L[0]  = 0x0000;
    ALT_WCAS_L[0] = 0x0000;
 
    mr0[1] = 0x0000;
    mr1[1] = 0x0000;
    mr2[1] = 0x0000;
    mr3[1] = 0x0000;
    mr4[1] = 0x0000;
    mr5[1] = 0x0000;
    mr6[1] = 0x0000;
 
    ALT_CAS_L[1]  = 0x0000;
    ALT_WCAS_L[1] = 0x0000;
 
    mr0[2] = 0x0000;
    mr1[2] = 0x0000;
    mr2[2] = 0x0000;
    mr3[2] = 0x0000;
    mr4[2] = 0x0000;
    mr5[2] = 0x0000;
    mr6[2] = 0x0000;
 
    ALT_CAS_L[2]  = 0x0000;
    ALT_WCAS_L[2] = 0x0000;
 
    mr0[3] = 0x0000;
    mr1[3] = 0x0000;
    mr2[3] = 0x0000;
    mr3[3] = 0x0000;
    mr4[3] = 0x0000;
    mr5[3] = 0x0000;
    mr6[3] = 0x0000;
 
    ALT_CAS_L[3]  = 0x0000;
    ALT_WCAS_L[3] = 0x0000;

    
    
    // 2D Training firmware Variables
    uint8_t  SequenceCtrl2D[4];
    SequenceCtrl2D[0] = 0x0061; // 2D Training Sequince. 2DTX, 2DRX, DevInit
    SequenceCtrl2D[1] = 0x0000; 
    SequenceCtrl2D[2] = 0x0000;
    SequenceCtrl2D[3] = 0x0000;

    // ##############################################################
    // These are per-pstate Control Words for RCD
    // Please enter the correct values for your configuration
    // ##############################################################
      
    // NOTE: The following fields are purposedly omitted here - they are
    //       programmed in dwc_ddrphy_phyinit_calcMb()
    //       F0RC0A_D0
    //       F0RC0A_D1
    //       F0RC0D_D0
    //       F0RC0D_D1
    //       F0RC3x_D0
    //       F0RC3x_D1
    //       F0BC6x_D0
    //       F0BC6x_D1
    uint8_t F0RC00_D0 = 0x0;
    uint8_t F0RC00_D1 = 0x0;
    uint8_t F0RC01_D0 = 0x0;
    uint8_t F0RC01_D1 = 0x0;
    uint8_t F0RC02_D0 = 0x0;
    uint8_t F0RC02_D1 = 0x0;
    uint8_t F0RC03_D0 = 0x0;
    uint8_t F0RC03_D1 = 0x0;
    uint8_t F0RC04_D0 = 0x0;
    uint8_t F0RC04_D1 = 0x0;
    uint8_t F0RC05_D0 = 0x0;
    uint8_t F0RC05_D1 = 0x0;
    uint8_t F0RC06_D0 = 0x0;
    uint8_t F0RC06_D1 = 0x0;
    uint8_t F0RC07_D0 = 0x0;
    uint8_t F0RC07_D1 = 0x0;
    uint8_t F0RC08_D0 = 0x0;
    uint8_t F0RC08_D1 = 0x0;
    uint8_t F0RC09_D0 = 0x0;
    uint8_t F0RC09_D1 = 0x0;
    uint8_t F0RC0B_D0 = 0x0;
    uint8_t F0RC0B_D1 = 0x0;
    uint8_t F0RC0C_D0 = 0x0;
    uint8_t F0RC0C_D1 = 0x0;
    uint8_t F0RC0E_D0 = 0x0;
    uint8_t F0RC0E_D1 = 0x0;
    uint8_t F0RC0F_D0 = 0x0;
    uint8_t F0RC0F_D1 = 0x0;
    uint8_t F0RC1x_D0 = 0x0;
    uint8_t F0RC1x_D1 = 0x0;
    uint8_t F0RC2x_D0 = 0x0;
    uint8_t F0RC2x_D1 = 0x0;
    uint8_t F0RC4x_D0 = 0x0;
    uint8_t F0RC4x_D1 = 0x0;
    uint8_t F0RC5x_D0 = 0x0;
    uint8_t F0RC5x_D1 = 0x0;
    uint8_t F0RC6x_D0 = 0x0;
    uint8_t F0RC6x_D1 = 0x0;
    uint8_t F0RC7x_D0 = 0x0;
    uint8_t F0RC7x_D1 = 0x0;
    uint8_t F0RC8x_D0 = 0x0;
    uint8_t F0RC8x_D1 = 0x0;
    uint8_t F0RC9x_D0 = 0x0;
    uint8_t F0RC9x_D1 = 0x0;
    uint8_t F0RCAx_D0 = 0x0;
    uint8_t F0RCAx_D1 = 0x0;
    uint8_t F0RCBx_D0 = 0x0;
    uint8_t F0RCBx_D1 = 0x0;
    uint8_t F1RC00_D0 = 0x0;
    uint8_t F1RC00_D1 = 0x0;
    uint8_t F1RC01_D0 = 0x0;
    uint8_t F1RC01_D1 = 0x0;
    uint8_t F1RC02_D0 = 0x0;
    uint8_t F1RC02_D1 = 0x0;
    uint8_t F1RC03_D0 = 0x0;
    uint8_t F1RC03_D1 = 0x0;
    uint8_t F1RC04_D0 = 0x0;
    uint8_t F1RC04_D1 = 0x0;
    uint8_t F1RC05_D0 = 0x0;
    uint8_t F1RC05_D1 = 0x0;
    uint8_t F1RC06_D0 = 0x0;
    uint8_t F1RC06_D1 = 0x0;
    uint8_t F1RC07_D0 = 0x0;
    uint8_t F1RC07_D1 = 0x0;
    uint8_t F1RC08_D0 = 0x0;
    uint8_t F1RC08_D1 = 0x0;
    uint8_t F1RC09_D0 = 0x0;
    uint8_t F1RC09_D1 = 0x0;
    uint8_t F1RC0A_D0 = 0x0;
    uint8_t F1RC0A_D1 = 0x0;
    uint8_t F1RC0B_D0 = 0x0;
    uint8_t F1RC0B_D1 = 0x0;
    uint8_t F1RC0C_D0 = 0x0;
    uint8_t F1RC0C_D1 = 0x0;
    uint8_t F1RC0D_D0 = 0x0;
    uint8_t F1RC0D_D1 = 0x0;
    uint8_t F1RC0E_D0 = 0x0;
    uint8_t F1RC0E_D1 = 0x0;
    uint8_t F1RC0F_D0 = 0x0;
    uint8_t F1RC0F_D1 = 0x0;
    uint8_t F1RC1x_D0 = 0x0;
    uint8_t F1RC1x_D1 = 0x0;
    uint8_t F1RC2x_D0 = 0x0;
    uint8_t F1RC2x_D1 = 0x0;
    uint8_t F1RC3x_D0 = 0x0;
    uint8_t F1RC3x_D1 = 0x0;
    uint8_t F1RC4x_D0 = 0x0;
    uint8_t F1RC4x_D1 = 0x0;
    uint8_t F1RC5x_D0 = 0x0;
    uint8_t F1RC5x_D1 = 0x0;
    uint8_t F1RC6x_D0 = 0x0;
    uint8_t F1RC6x_D1 = 0x0;
    uint8_t F1RC7x_D0 = 0x0;
    uint8_t F1RC7x_D1 = 0x0;
    uint8_t F1RC8x_D0 = 0x0;
    uint8_t F1RC8x_D1 = 0x0;
    uint8_t F1RC9x_D0 = 0x0;
    uint8_t F1RC9x_D1 = 0x0;
    uint8_t F1RCAx_D0 = 0x0;
    uint8_t F1RCAx_D1 = 0x0;
    uint8_t F1RCBx_D0 = 0x0;
    uint8_t F1RCBx_D1 = 0x0;



    // ##############################################################
    // 95% of users will not need to edit below
    // ##############################################################

    // Per Rank MR seeting for RTT_NOM, RTT_WR, RTT_PARK per rank. Options unlikely need to be used.
    // See MB details on how to program if required.
    uint16_t RTT_NOM_WR_PARK0[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK1[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK2[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK3[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK4[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK5[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK6[4]  = {0x0,0x0,0x0,0x0};
    uint16_t RTT_NOM_WR_PARK7[4]  = {0x0,0x0,0x0,0x0};


    // 1D message block defaults
    for (myps=0; myps<4; myps++) {
      mb_DDR4R_1D[myps].Pstate               = myps;
      mb_DDR4R_1D[myps].SequenceCtrl         = SequenceCtrl[myps];
      mb_DDR4R_1D[myps].PhyConfigOverride    = 0x0;
      mb_DDR4R_1D[myps].HdtCtrl              = HdtCtrl;
      mb_DDR4R_1D[myps].MsgMisc              = MsgMisc;
      mb_DDR4R_1D[myps].Reserved00           = Reserved00;
      mb_DDR4R_1D[myps].DFIMRLMargin         = DFIMRLMargin;
      mb_DDR4R_1D[myps].PhyVref              = PhyVref;
  
      mb_DDR4R_1D[myps].CsPresent            = CsPresent;
      mb_DDR4R_1D[myps].CsPresentD0          = CsPresent;
      mb_DDR4R_1D[myps].CsPresentD1          = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR4R_1D[myps].AddrMirror           = AddrMirror;
                                                   
      mb_DDR4R_1D[myps].AcsmOdtCtrl0         = WRODTPAT_RANK0 | RDODTPAT_RANK0;
      mb_DDR4R_1D[myps].AcsmOdtCtrl1         = WRODTPAT_RANK1 | RDODTPAT_RANK1;
      mb_DDR4R_1D[myps].AcsmOdtCtrl2         = WRODTPAT_RANK2 | RDODTPAT_RANK2;
      mb_DDR4R_1D[myps].AcsmOdtCtrl3         = WRODTPAT_RANK3 | RDODTPAT_RANK3;
      				                               
      mb_DDR4R_1D[myps].AcsmOdtCtrl4         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR4R_1D[myps].AcsmOdtCtrl5         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR4R_1D[myps].AcsmOdtCtrl6         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR4R_1D[myps].AcsmOdtCtrl7         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR4R_1D[myps].EnabledDQs           = (userInputBasic.NumActiveDbyteDfi0+userInputBasic.NumActiveDbyteDfi1)*8;
      mb_DDR4R_1D[myps].PhyCfg               = (mr3[myps]&0x8) ? 0 : userInputAdvanced.Is2Ttiming[myps];
      mb_DDR4R_1D[myps].X16Present           = (0x10==userInputBasic.DramDataWidth) ? mb_DDR4R_1D[myps].CsPresent : 0x0;
      mb_DDR4R_1D[myps].D4Misc               = D4Misc;
      mb_DDR4R_1D[myps].CsSetupGDDec         = 0x1; //If Geardown is chosen, dynamically modify CS timing
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK0     = RTT_NOM_WR_PARK0[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK1     = RTT_NOM_WR_PARK1[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK2     = RTT_NOM_WR_PARK2[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK3     = RTT_NOM_WR_PARK3[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK4     = RTT_NOM_WR_PARK4[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK5     = RTT_NOM_WR_PARK5[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK6     = RTT_NOM_WR_PARK6[myps];
      mb_DDR4R_1D[myps].RTT_NOM_WR_PARK7     = RTT_NOM_WR_PARK7[myps];
      mb_DDR4R_1D[myps].MR0                  = mr0[myps];
      mb_DDR4R_1D[myps].MR1                  = mr1[myps];
      mb_DDR4R_1D[myps].MR2                  = mr2[myps];
      mb_DDR4R_1D[myps].MR3                  = mr3[myps];
      mb_DDR4R_1D[myps].MR4                  = mr4[myps];
      mb_DDR4R_1D[myps].MR5                  = mr5[myps];
      mb_DDR4R_1D[myps].MR6                  = mr6[myps];
  
      mb_DDR4R_1D[myps].ALT_CAS_L            = ALT_CAS_L[myps];
      mb_DDR4R_1D[myps].ALT_WCAS_L           = ALT_WCAS_L[myps];

      mb_DDR4R_1D[myps].VrefDqR0Nib0      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib1      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib2      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib3      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib4      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib5      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib6      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib7      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib8      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib9      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib10      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib11      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib12      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib13      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib14      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib15      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib16      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib17      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib18      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR0Nib19      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib0      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib1      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib2      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib3      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib4      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib5      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib6      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib7      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib8      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib9      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib10      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib11      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib12      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib13      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib14      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib15      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib16      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib17      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib18      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR1Nib19      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib0      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib1      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib2      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib3      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib4      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib5      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib6      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib7      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib8      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib9      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib10      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib11      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib12      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib13      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib14      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib15      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib16      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib17      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib18      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR2Nib19      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib0      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib1      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib2      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib3      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib4      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib5      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib6      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib7      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib8      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib9      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib10      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib11      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib12      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib13      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib14      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib15      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib16      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib17      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib18      = 0x0000; //Outputs - just initialize these to zero
      mb_DDR4R_1D[myps].VrefDqR3Nib19      = 0x0000; //Outputs - just initialize these to zero

      mb_DDR4R_1D[myps].F0RC00_D0         = F0RC00_D0;
      mb_DDR4R_1D[myps].F0RC00_D1         = F0RC00_D1;
      mb_DDR4R_1D[myps].F0RC01_D0         = F0RC01_D0;
      mb_DDR4R_1D[myps].F0RC01_D1         = F0RC01_D1;
      mb_DDR4R_1D[myps].F0RC02_D0         = F0RC02_D0;
      mb_DDR4R_1D[myps].F0RC02_D1         = F0RC02_D1;
      mb_DDR4R_1D[myps].F0RC03_D0         = F0RC03_D0;
      mb_DDR4R_1D[myps].F0RC03_D1         = F0RC03_D1;
      mb_DDR4R_1D[myps].F0RC04_D0         = F0RC04_D0;
      mb_DDR4R_1D[myps].F0RC04_D1         = F0RC04_D1;
      mb_DDR4R_1D[myps].F0RC05_D0         = F0RC05_D0;
      mb_DDR4R_1D[myps].F0RC05_D1         = F0RC05_D1;
      mb_DDR4R_1D[myps].F0RC06_D0         = F0RC06_D0;
      mb_DDR4R_1D[myps].F0RC06_D1         = F0RC06_D1;
      mb_DDR4R_1D[myps].F0RC07_D0         = F0RC07_D0;
      mb_DDR4R_1D[myps].F0RC07_D1         = F0RC07_D1;
      mb_DDR4R_1D[myps].F0RC08_D0         = F0RC08_D0;
      mb_DDR4R_1D[myps].F0RC08_D1         = F0RC08_D1;
      mb_DDR4R_1D[myps].F0RC09_D0         = F0RC09_D0;
      mb_DDR4R_1D[myps].F0RC09_D1         = F0RC09_D1;
      mb_DDR4R_1D[myps].F0RC0B_D0         = F0RC0B_D0;
      mb_DDR4R_1D[myps].F0RC0B_D1         = F0RC0B_D1;
      mb_DDR4R_1D[myps].F0RC0C_D0         = F0RC0C_D0;
      mb_DDR4R_1D[myps].F0RC0C_D1         = F0RC0C_D1;
      mb_DDR4R_1D[myps].F0RC0E_D0         = F0RC0E_D0;
      mb_DDR4R_1D[myps].F0RC0E_D1         = F0RC0E_D1;
      mb_DDR4R_1D[myps].F0RC0F_D0         = F0RC0F_D0;
      mb_DDR4R_1D[myps].F0RC0F_D1         = F0RC0F_D1;
      mb_DDR4R_1D[myps].F0RC1x_D0         = F0RC1x_D0;
      mb_DDR4R_1D[myps].F0RC1x_D1         = F0RC1x_D1;
      mb_DDR4R_1D[myps].F0RC2x_D0         = F0RC2x_D0;
      mb_DDR4R_1D[myps].F0RC2x_D1         = F0RC2x_D1;
      mb_DDR4R_1D[myps].F0RC4x_D0         = F0RC4x_D0;
      mb_DDR4R_1D[myps].F0RC4x_D1         = F0RC4x_D1;
      mb_DDR4R_1D[myps].F0RC5x_D0         = F0RC5x_D0;
      mb_DDR4R_1D[myps].F0RC5x_D1         = F0RC5x_D1;
      mb_DDR4R_1D[myps].F0RC6x_D0         = F0RC6x_D0;
      mb_DDR4R_1D[myps].F0RC6x_D1         = F0RC6x_D1;
      mb_DDR4R_1D[myps].F0RC7x_D0         = F0RC7x_D0;
      mb_DDR4R_1D[myps].F0RC7x_D1         = F0RC7x_D1;
      mb_DDR4R_1D[myps].F0RC8x_D0         = F0RC8x_D0;
      mb_DDR4R_1D[myps].F0RC8x_D1         = F0RC8x_D1;
      mb_DDR4R_1D[myps].F0RC9x_D0         = F0RC9x_D0;
      mb_DDR4R_1D[myps].F0RC9x_D1         = F0RC9x_D1;
      mb_DDR4R_1D[myps].F0RCAx_D0         = F0RCAx_D0;
      mb_DDR4R_1D[myps].F0RCAx_D1         = F0RCAx_D1;
      mb_DDR4R_1D[myps].F0RCBx_D0         = F0RCBx_D0;
      mb_DDR4R_1D[myps].F0RCBx_D1         = F0RCBx_D1;
      mb_DDR4R_1D[myps].F1RC00_D0         = F1RC00_D0;
      mb_DDR4R_1D[myps].F1RC00_D1         = F1RC00_D1;
      mb_DDR4R_1D[myps].F1RC01_D0         = F1RC01_D0;
      mb_DDR4R_1D[myps].F1RC01_D1         = F1RC01_D1;
      mb_DDR4R_1D[myps].F1RC02_D0         = F1RC02_D0;
      mb_DDR4R_1D[myps].F1RC02_D1         = F1RC02_D1;
      mb_DDR4R_1D[myps].F1RC03_D0         = F1RC03_D0;
      mb_DDR4R_1D[myps].F1RC03_D1         = F1RC03_D1;
      mb_DDR4R_1D[myps].F1RC04_D0         = F1RC04_D0;
      mb_DDR4R_1D[myps].F1RC04_D1         = F1RC04_D1;
      mb_DDR4R_1D[myps].F1RC05_D0         = F1RC05_D0;
      mb_DDR4R_1D[myps].F1RC05_D1         = F1RC05_D1;
      mb_DDR4R_1D[myps].F1RC06_D0         = F1RC06_D0;
      mb_DDR4R_1D[myps].F1RC06_D1         = F1RC06_D1;
      mb_DDR4R_1D[myps].F1RC07_D0         = F1RC07_D0;
      mb_DDR4R_1D[myps].F1RC07_D1         = F1RC07_D1;
      mb_DDR4R_1D[myps].F1RC08_D0         = F1RC08_D0;
      mb_DDR4R_1D[myps].F1RC08_D1         = F1RC08_D1;
      mb_DDR4R_1D[myps].F1RC09_D0         = F1RC09_D0;
      mb_DDR4R_1D[myps].F1RC09_D1         = F1RC09_D1;
      mb_DDR4R_1D[myps].F1RC0A_D0         = F1RC0A_D0;
      mb_DDR4R_1D[myps].F1RC0A_D1         = F1RC0A_D1;
      mb_DDR4R_1D[myps].F1RC0B_D0         = F1RC0B_D0;
      mb_DDR4R_1D[myps].F1RC0B_D1         = F1RC0B_D1;
      mb_DDR4R_1D[myps].F1RC0C_D0         = F1RC0C_D0;
      mb_DDR4R_1D[myps].F1RC0C_D1         = F1RC0C_D1;
      mb_DDR4R_1D[myps].F1RC0D_D0         = F1RC0D_D0;
      mb_DDR4R_1D[myps].F1RC0D_D1         = F1RC0D_D1;
      mb_DDR4R_1D[myps].F1RC0E_D0         = F1RC0E_D0;
      mb_DDR4R_1D[myps].F1RC0E_D1         = F1RC0E_D1;
      mb_DDR4R_1D[myps].F1RC0F_D0         = F1RC0F_D0;
      mb_DDR4R_1D[myps].F1RC0F_D1         = F1RC0F_D1;
      mb_DDR4R_1D[myps].F1RC1x_D0         = F1RC1x_D0;
      mb_DDR4R_1D[myps].F1RC1x_D1         = F1RC1x_D1;
      mb_DDR4R_1D[myps].F1RC2x_D0         = F1RC2x_D0;
      mb_DDR4R_1D[myps].F1RC2x_D1         = F1RC2x_D1;
      mb_DDR4R_1D[myps].F1RC3x_D0         = F1RC3x_D0;
      mb_DDR4R_1D[myps].F1RC3x_D1         = F1RC3x_D1;
      mb_DDR4R_1D[myps].F1RC4x_D0         = F1RC4x_D0;
      mb_DDR4R_1D[myps].F1RC4x_D1         = F1RC4x_D1;
      mb_DDR4R_1D[myps].F1RC5x_D0         = F1RC5x_D0;
      mb_DDR4R_1D[myps].F1RC5x_D1         = F1RC5x_D1;
      mb_DDR4R_1D[myps].F1RC6x_D0         = F1RC6x_D0;
      mb_DDR4R_1D[myps].F1RC6x_D1         = F1RC6x_D1;
      mb_DDR4R_1D[myps].F1RC7x_D0         = F1RC7x_D0;
      mb_DDR4R_1D[myps].F1RC7x_D1         = F1RC7x_D1;
      mb_DDR4R_1D[myps].F1RC8x_D0         = F1RC8x_D0;
      mb_DDR4R_1D[myps].F1RC8x_D1         = F1RC8x_D1;
      mb_DDR4R_1D[myps].F1RC9x_D0         = F1RC9x_D0;
      mb_DDR4R_1D[myps].F1RC9x_D1         = F1RC9x_D1;
      mb_DDR4R_1D[myps].F1RCAx_D0         = F1RCAx_D0;
      mb_DDR4R_1D[myps].F1RCAx_D1         = F1RCAx_D1;
      mb_DDR4R_1D[myps].F1RCBx_D0         = F1RCBx_D0;
      mb_DDR4R_1D[myps].F1RCBx_D1         = F1RCBx_D1;
      
      mb_DDR4R_1D[myps].Share2DVrefResult    = Share2DVrefResult;


      } // myps

    // 2D message block defaults
    if (Train2D) {
    for (myps=0; myps<1; myps++) {
        mb_DDR4R_2D[myps].Pstate               = myps;
        mb_DDR4R_2D[myps].SequenceCtrl         = SequenceCtrl2D[myps];
        mb_DDR4R_2D[myps].PhyConfigOverride    = 0x0;
        mb_DDR4R_2D[myps].HdtCtrl              = HdtCtrl;
        mb_DDR4R_2D[myps].MsgMisc              = MsgMisc;
        mb_DDR4R_2D[myps].Reserved00           = Reserved00;
        mb_DDR4R_2D[myps].DFIMRLMargin         = DFIMRLMargin;
        mb_DDR4R_2D[myps].PhyVref              = PhyVref;
  
        mb_DDR4R_2D[myps].CsPresent            = CsPresent;
        mb_DDR4R_2D[myps].CsPresentD0          = CsPresent;
        mb_DDR4R_2D[myps].CsPresentD1          = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
        mb_DDR4R_2D[myps].AddrMirror           = AddrMirror;
                                                   
        mb_DDR4R_2D[myps].AcsmOdtCtrl0         = WRODTPAT_RANK0 | RDODTPAT_RANK0;
        mb_DDR4R_2D[myps].AcsmOdtCtrl1         = WRODTPAT_RANK1 | RDODTPAT_RANK1;
        mb_DDR4R_2D[myps].AcsmOdtCtrl2         = WRODTPAT_RANK2 | RDODTPAT_RANK2;
        mb_DDR4R_2D[myps].AcsmOdtCtrl3         = WRODTPAT_RANK3 | RDODTPAT_RANK3;
      				                               
        mb_DDR4R_2D[myps].AcsmOdtCtrl4         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
        mb_DDR4R_2D[myps].AcsmOdtCtrl5         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
        mb_DDR4R_2D[myps].AcsmOdtCtrl6         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
        mb_DDR4R_2D[myps].AcsmOdtCtrl7         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
        mb_DDR4R_2D[myps].EnabledDQs           = (userInputBasic.NumActiveDbyteDfi0+userInputBasic.NumActiveDbyteDfi1)*8;
        mb_DDR4R_2D[myps].PhyCfg               = (mr3[myps]&0x8) ? 0 : userInputAdvanced.Is2Ttiming[myps];
        mb_DDR4R_2D[myps].X16Present           = (0x10==userInputBasic.DramDataWidth) ? mb_DDR4R_2D[myps].CsPresent : 0x0;
        mb_DDR4R_2D[myps].D4Misc               = D4Misc;
        mb_DDR4R_2D[myps].CsSetupGDDec         = 0x1; //If Geardown is chosen, dynamically modify CS timing
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK0     = RTT_NOM_WR_PARK0[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK1     = RTT_NOM_WR_PARK1[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK2     = RTT_NOM_WR_PARK2[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK3     = RTT_NOM_WR_PARK3[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK4     = RTT_NOM_WR_PARK4[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK5     = RTT_NOM_WR_PARK5[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK6     = RTT_NOM_WR_PARK6[myps];
        mb_DDR4R_2D[myps].RTT_NOM_WR_PARK7     = RTT_NOM_WR_PARK7[myps];
        mb_DDR4R_2D[myps].MR0                  = mr0[myps];
        mb_DDR4R_2D[myps].MR1                  = mr1[myps];
        mb_DDR4R_2D[myps].MR2                  = mr2[myps];
        mb_DDR4R_2D[myps].MR3                  = mr3[myps];
        mb_DDR4R_2D[myps].MR4                  = mr4[myps];
        mb_DDR4R_2D[myps].MR5                  = mr5[myps];
        mb_DDR4R_2D[myps].MR6                  = mr6[myps];
  
        mb_DDR4R_2D[myps].ALT_CAS_L            = ALT_CAS_L[myps];
        mb_DDR4R_2D[myps].ALT_WCAS_L           = ALT_WCAS_L[myps];

        mb_DDR4R_2D[myps].VrefDqR0Nib0      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib1      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib2      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib3      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib4      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib5      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib6      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib7      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib8      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib9      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib10      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib11      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib12      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib13      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib14      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib15      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib16      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib17      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib18      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR0Nib19      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib0      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib1      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib2      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib3      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib4      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib5      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib6      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib7      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib8      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib9      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib10      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib11      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib12      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib13      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib14      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib15      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib16      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib17      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib18      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR1Nib19      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib0      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib1      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib2      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib3      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib4      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib5      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib6      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib7      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib8      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib9      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib10      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib11      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib12      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib13      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib14      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib15      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib16      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib17      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib18      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR2Nib19      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib0      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib1      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib2      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib3      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib4      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib5      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib6      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib7      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib8      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib9      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib10      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib11      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib12      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib13      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib14      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib15      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib16      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib17      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib18      = 0x0000; //Outputs - just initialize these to zero
        mb_DDR4R_2D[myps].VrefDqR3Nib19      = 0x0000; //Outputs - just initialize these to zero

        mb_DDR4R_2D[myps].F0RC00_D0         = F0RC00_D0;
        mb_DDR4R_2D[myps].F0RC00_D1         = F0RC00_D1;
        mb_DDR4R_2D[myps].F0RC01_D0         = F0RC01_D0;
        mb_DDR4R_2D[myps].F0RC01_D1         = F0RC01_D1;
        mb_DDR4R_2D[myps].F0RC02_D0         = F0RC02_D0;
        mb_DDR4R_2D[myps].F0RC02_D1         = F0RC02_D1;
        mb_DDR4R_2D[myps].F0RC03_D0         = F0RC03_D0;
        mb_DDR4R_2D[myps].F0RC03_D1         = F0RC03_D1;
        mb_DDR4R_2D[myps].F0RC04_D0         = F0RC04_D0;
        mb_DDR4R_2D[myps].F0RC04_D1         = F0RC04_D1;
        mb_DDR4R_2D[myps].F0RC05_D0         = F0RC05_D0;
        mb_DDR4R_2D[myps].F0RC05_D1         = F0RC05_D1;
        mb_DDR4R_2D[myps].F0RC06_D0         = F0RC06_D0;
        mb_DDR4R_2D[myps].F0RC06_D1         = F0RC06_D1;
        mb_DDR4R_2D[myps].F0RC07_D0         = F0RC07_D0;
        mb_DDR4R_2D[myps].F0RC07_D1         = F0RC07_D1;
        mb_DDR4R_2D[myps].F0RC08_D0         = F0RC08_D0;
        mb_DDR4R_2D[myps].F0RC08_D1         = F0RC08_D1;
        mb_DDR4R_2D[myps].F0RC09_D0         = F0RC09_D0;
        mb_DDR4R_2D[myps].F0RC09_D1         = F0RC09_D1;
        mb_DDR4R_2D[myps].F0RC0B_D0         = F0RC0B_D0;
        mb_DDR4R_2D[myps].F0RC0B_D1         = F0RC0B_D1;
        mb_DDR4R_2D[myps].F0RC0C_D0         = F0RC0C_D0;
        mb_DDR4R_2D[myps].F0RC0C_D1         = F0RC0C_D1;
        mb_DDR4R_2D[myps].F0RC0E_D0         = F0RC0E_D0;
        mb_DDR4R_2D[myps].F0RC0E_D1         = F0RC0E_D1;
        mb_DDR4R_2D[myps].F0RC0F_D0         = F0RC0F_D0;
        mb_DDR4R_2D[myps].F0RC0F_D1         = F0RC0F_D1;
        mb_DDR4R_2D[myps].F0RC1x_D0         = F0RC1x_D0;
        mb_DDR4R_2D[myps].F0RC1x_D1         = F0RC1x_D1;
        mb_DDR4R_2D[myps].F0RC2x_D0         = F0RC2x_D0;
        mb_DDR4R_2D[myps].F0RC2x_D1         = F0RC2x_D1;
        mb_DDR4R_2D[myps].F0RC4x_D0         = F0RC4x_D0;
        mb_DDR4R_2D[myps].F0RC4x_D1         = F0RC4x_D1;
        mb_DDR4R_2D[myps].F0RC5x_D0         = F0RC5x_D0;
        mb_DDR4R_2D[myps].F0RC5x_D1         = F0RC5x_D1;
        mb_DDR4R_2D[myps].F0RC6x_D0         = F0RC6x_D0;
        mb_DDR4R_2D[myps].F0RC6x_D1         = F0RC6x_D1;
        mb_DDR4R_2D[myps].F0RC7x_D0         = F0RC7x_D0;
        mb_DDR4R_2D[myps].F0RC7x_D1         = F0RC7x_D1;
        mb_DDR4R_2D[myps].F0RC8x_D0         = F0RC8x_D0;
        mb_DDR4R_2D[myps].F0RC8x_D1         = F0RC8x_D1;
        mb_DDR4R_2D[myps].F0RC9x_D0         = F0RC9x_D0;
        mb_DDR4R_2D[myps].F0RC9x_D1         = F0RC9x_D1;
        mb_DDR4R_2D[myps].F0RCAx_D0         = F0RCAx_D0;
        mb_DDR4R_2D[myps].F0RCAx_D1         = F0RCAx_D1;
        mb_DDR4R_2D[myps].F0RCBx_D0         = F0RCBx_D0;
        mb_DDR4R_2D[myps].F0RCBx_D1         = F0RCBx_D1;
        mb_DDR4R_2D[myps].F1RC00_D0         = F1RC00_D0;
        mb_DDR4R_2D[myps].F1RC00_D1         = F1RC00_D1;
        mb_DDR4R_2D[myps].F1RC01_D0         = F1RC01_D0;
        mb_DDR4R_2D[myps].F1RC01_D1         = F1RC01_D1;
        mb_DDR4R_2D[myps].F1RC02_D0         = F1RC02_D0;
        mb_DDR4R_2D[myps].F1RC02_D1         = F1RC02_D1;
        mb_DDR4R_2D[myps].F1RC03_D0         = F1RC03_D0;
        mb_DDR4R_2D[myps].F1RC03_D1         = F1RC03_D1;
        mb_DDR4R_2D[myps].F1RC04_D0         = F1RC04_D0;
        mb_DDR4R_2D[myps].F1RC04_D1         = F1RC04_D1;
        mb_DDR4R_2D[myps].F1RC05_D0         = F1RC05_D0;
        mb_DDR4R_2D[myps].F1RC05_D1         = F1RC05_D1;
        mb_DDR4R_2D[myps].F1RC06_D0         = F1RC06_D0;
        mb_DDR4R_2D[myps].F1RC06_D1         = F1RC06_D1;
        mb_DDR4R_2D[myps].F1RC07_D0         = F1RC07_D0;
        mb_DDR4R_2D[myps].F1RC07_D1         = F1RC07_D1;
        mb_DDR4R_2D[myps].F1RC08_D0         = F1RC08_D0;
        mb_DDR4R_2D[myps].F1RC08_D1         = F1RC08_D1;
        mb_DDR4R_2D[myps].F1RC09_D0         = F1RC09_D0;
        mb_DDR4R_2D[myps].F1RC09_D1         = F1RC09_D1;
        mb_DDR4R_2D[myps].F1RC0A_D0         = F1RC0A_D0;
        mb_DDR4R_2D[myps].F1RC0A_D1         = F1RC0A_D1;
        mb_DDR4R_2D[myps].F1RC0B_D0         = F1RC0B_D0;
        mb_DDR4R_2D[myps].F1RC0B_D1         = F1RC0B_D1;
        mb_DDR4R_2D[myps].F1RC0C_D0         = F1RC0C_D0;
        mb_DDR4R_2D[myps].F1RC0C_D1         = F1RC0C_D1;
        mb_DDR4R_2D[myps].F1RC0D_D0         = F1RC0D_D0;
        mb_DDR4R_2D[myps].F1RC0D_D1         = F1RC0D_D1;
        mb_DDR4R_2D[myps].F1RC0E_D0         = F1RC0E_D0;
        mb_DDR4R_2D[myps].F1RC0E_D1         = F1RC0E_D1;
        mb_DDR4R_2D[myps].F1RC0F_D0         = F1RC0F_D0;
        mb_DDR4R_2D[myps].F1RC0F_D1         = F1RC0F_D1;
        mb_DDR4R_2D[myps].F1RC1x_D0         = F1RC1x_D0;
        mb_DDR4R_2D[myps].F1RC1x_D1         = F1RC1x_D1;
        mb_DDR4R_2D[myps].F1RC2x_D0         = F1RC2x_D0;
        mb_DDR4R_2D[myps].F1RC2x_D1         = F1RC2x_D1;
        mb_DDR4R_2D[myps].F1RC3x_D0         = F1RC3x_D0;
        mb_DDR4R_2D[myps].F1RC3x_D1         = F1RC3x_D1;
        mb_DDR4R_2D[myps].F1RC4x_D0         = F1RC4x_D0;
        mb_DDR4R_2D[myps].F1RC4x_D1         = F1RC4x_D1;
        mb_DDR4R_2D[myps].F1RC5x_D0         = F1RC5x_D0;
        mb_DDR4R_2D[myps].F1RC5x_D1         = F1RC5x_D1;
        mb_DDR4R_2D[myps].F1RC6x_D0         = F1RC6x_D0;
        mb_DDR4R_2D[myps].F1RC6x_D1         = F1RC6x_D1;
        mb_DDR4R_2D[myps].F1RC7x_D0         = F1RC7x_D0;
        mb_DDR4R_2D[myps].F1RC7x_D1         = F1RC7x_D1;
        mb_DDR4R_2D[myps].F1RC8x_D0         = F1RC8x_D0;
        mb_DDR4R_2D[myps].F1RC8x_D1         = F1RC8x_D1;
        mb_DDR4R_2D[myps].F1RC9x_D0         = F1RC9x_D0;
        mb_DDR4R_2D[myps].F1RC9x_D1         = F1RC9x_D1;
        mb_DDR4R_2D[myps].F1RCAx_D0         = F1RCAx_D0;
        mb_DDR4R_2D[myps].F1RCAx_D1         = F1RCAx_D1;
        mb_DDR4R_2D[myps].F1RCBx_D0         = F1RCBx_D0;
        mb_DDR4R_2D[myps].F1RCBx_D1         = F1RCBx_D1;
      
        mb_DDR4R_2D[myps].Share2DVrefResult    = Share2DVrefResult; 
        mb_DDR4R_2D[myps].RX2D_TrainOpt        = 0x00; // DFE off, Voltage Step Size=1 DAC setting, LCDL Delay Step Size=1 LCDL delay between checked values.
        mb_DDR4R_2D[myps].TX2D_TrainOpt        = 0x00; // FFE off, Voltage Step Size=1 DAC setting, LCDL Delay Step Size=1 LCDL delay between checked values.
        mb_DDR4R_2D[myps].Delay_Weight2D       = 0x20; // Evenly weigh Delay vs Voltage
        mb_DDR4R_2D[myps].Voltage_Weight2D     = 0x80; 


      } // myps
    } // Train2D

    // ##############################################################
    // userInputSim - Dram/Dimm Timing Parameters the user must p
    // provide value if applicable
    // ##############################################################
    userInputSim.tDQS2DQ                    = 0;  
    userInputSim.tDQSCK                     = 0;  
    userInputSim.tSTAOFF[0]                 = 0;
    userInputSim.tSTAOFF[1]                 = 0;
    userInputSim.tSTAOFF[2]                 = 0;
    userInputSim.tSTAOFF[3]                 = 0;
    userInputSim.tPDM[0]                    = 0;
    userInputSim.tPDM[1]                    = 0;
    userInputSim.tPDM[2]                    = 0;
    userInputSim.tPDM[3]                    = 0;

    
    dwc_ddrphy_phyinit_print ("%s End of dwc_ddrphy_phyinit_setDefault()\n", printf_header);
}
/** @} */
