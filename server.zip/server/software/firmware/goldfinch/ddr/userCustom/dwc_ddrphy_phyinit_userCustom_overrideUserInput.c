/** \file 
 *  \brief used for overriding setDefault assignments
 *  \addtogroup CustFunc
 *  @{
 */
#include "dwc_ddrphy_phyinit.h"
#include <stdlib.h>

extern int CurrentPhyInst;

/** @brief overrides any field in PhyInit data structure dynamically.
 *
 * This function can be used to dynamically change PhyInit Data structures set
 * by dwc_ddrphy_setDefault(). 
 * 
 * To override user_input_basic, user_input_advanced and user_input_sim the user
 * can:
 * -# call dwc_ddrphy_phyinit_setUserInput(char *field, int value) 
 * -# directly assigning structure instances userInputBasic or userInputAdvanced.
 *
 * To override settings in the message block, users must use
 * dwc_ddrphy_phyinit_setMb().
 *
 * \warning some message bloc fields are set by dwc_ddrphy_phyinit_calcMb(). If
 * these fields are set directly in this function, the override will not take
 * effect. dwc_ddrphy_phyinit_setMb() must be used to keep the override message
 * block values.
 * 
 * @return Void
 */ 

void dwc_ddrphy_phyinit_userCustom_overrideUserInput () {
    char *printf_header;
    printf_header = " [dwc_ddrphy_phyinit_userCustom_overrideUserInput]";

    dwc_ddrphy_phyinit_print ("\n");
    dwc_ddrphy_phyinit_print ("\n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("// dwc_ddrphy_phyinit_userCustom_overrideUserInput is a user-editable function.\n");
    dwc_ddrphy_phyinit_cmnt ("//\n");
    dwc_ddrphy_phyinit_cmnt ("// See PhyInit App Note for detailed description and function usage\n");
    dwc_ddrphy_phyinit_print ("//\n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_print ("\n");
    dwc_ddrphy_phyinit_print ("//dwc_ddrphy_phyinit_userCustom_overrideUserInput ();\n");	// Bill edit
    dwc_ddrphy_phyinit_cmnt ("\n");

    // == Definitions for overriding a single PHY system 
    // Example Values for testing

    // === Example to override frequency for P-State 0,1,2,3
    // === using dwc_ddrphy_phyinit_setUserInput()
    // dwc_ddrphy_phyinit_setUserInput ("Frequency[0]", 1600); // 3200Mbps 
    // dwc_ddrphy_phyinit_setUserInput ("Frequency[1]", 1200); // 2400Mbps
    // dwc_ddrphy_phyinit_setUserInput ("Frequency[2]", 933);  // 1866Mbps
    // dwc_ddrphy_phyinit_setUserInput ("Frequency[3]", 50);   // 100Mbps
    
    
    // === Example to override MemAlert related inputs using dwc_ddrphy_phyinit_setUserInput()
    // dwc_ddrphy_phyinit_setUserInput ("MemAlertEn", 0x1);
    // dwc_ddrphy_phyinit_setUserInput ("MemAlertPUImp", 0x8);
    // dwc_ddrphy_phyinit_setUserInput ("MemAlertVrefLevel", 32);
    // dwc_ddrphy_phyinit_setUserInput ("MemAlertSyncBypass", 0x1);

    
    // === Example to override frequency by setting the data structure
    // === directly
    // userInputBasic.Frequency[3]  = 1600;  // 3200Mbps 
    // userInputBasic.Frequency[2]  = 1200;  // 2400Mbps
    // userInputBasic.Frequency[1]  = 933;   // 1866Mbps
    // userInputBasic.Frequency[0]  = 50;    // 100Mbps
    
    
    // === Example to override MemAlert related inputs by setting the data
    // === structure directly
    // userInputAdvanced.MemAlertEn               = 0x0000;
    // userInputAdvanced.MemAlertPUImp            = 0x0005;
    // userInputAdvanced.MemAlertVrefLevel        = 0x0029;
    // userInputAdvanced.MemAlertSyncBypass       = 0x0000;

    // === Example to set HdtCtrl to 0x8 for 1D for pstates 0,1,2,3
    // === using dwc_ddrphy_phyinit_setMb()
    //dwc_ddrphy_phyinit_setMb (0, "HdtCtrl", 0x8, 0);
    //dwc_ddrphy_phyinit_setMb (1, "HdtCtrl", 0x8, 0);
    //dwc_ddrphy_phyinit_setMb (2, "HdtCtrl", 0x8, 0);
    //dwc_ddrphy_phyinit_setMb (3, "HdtCtrl", 0x8, 0);


    userInputBasic.DramType                 = DDR4;
    userInputBasic.DimmType                 = RDIMM;
    userInputBasic.NumDbyte                 = 0x0009;
    userInputBasic.NumActiveDbyteDfi0       = 0x0009;
    userInputBasic.NumAnib                  = 0x000c;
    userInputBasic.NumRank_dfi0             = 0x0002;
    userInputBasic.DramDataWidth            = 8;
    userInputBasic.NumPStates               = 0x0001;
    userInputBasic.Dfi1Exists               = 0x0000;
    userInputBasic.HardMacroVer             = 0x0000;
    userInputBasic.Frequency[0]             = 1600;
    userInputBasic.PllBypass[0]             = 0x0000;
    userInputBasic.DfiFreqRatio[0]          = 0x0001;
    userInputBasic.Frequency[1]             = 1066;
    userInputBasic.PllBypass[1]             = 0x0000;
    userInputBasic.DfiFreqRatio[1]          = 0x0001;
    userInputBasic.Frequency[2]             = 667;
    userInputBasic.PllBypass[2]             = 0x0000;
    userInputBasic.DfiFreqRatio[2]          = 0x0001;
    userInputAdvanced.MemAlertEn            = 0x0001;
    userInputAdvanced.MemAlertSyncBypass    = 0x0000;
    userInputAdvanced.DramByteSwap          = 0x0000;
    userInputAdvanced.CalInterval           = 0x0003;
    userInputAdvanced.ExtCalResVal          = 0;
    userInputAdvanced.ATxImpedance          = 20;
    userInputAdvanced.CsMode                = 0x0000;
    userInputAdvanced.Is2Ttiming[0]         = 0x0000;
    userInputAdvanced.DisDynAdrTri[0]       = 0x0000;
    userInputAdvanced.ODTImpedance[0]       = 60;
    userInputAdvanced.TxImpedance[0]        = 60;
    userInputAdvanced.D4RxPreambleLength[0] = 0x0000;
    userInputAdvanced.D4TxPreambleLength[0] = 0x0000;
    userInputAdvanced.Is2Ttiming[1]         = 0x0000;
    userInputAdvanced.DisDynAdrTri[1]       = 0x0000;
    userInputAdvanced.ODTImpedance[1]       = 60;
    userInputAdvanced.TxImpedance[1]        = 60;
    userInputAdvanced.D4RxPreambleLength[1] = 0x0000;
    userInputAdvanced.D4TxPreambleLength[1] = 0x0000;
    userInputAdvanced.Is2Ttiming[2]         = 0x0000;
    userInputAdvanced.DisDynAdrTri[2]       = 0x0000;
    userInputAdvanced.ODTImpedance[2]       = 60;
    userInputAdvanced.TxImpedance[2]        = 60;
    userInputAdvanced.D4RxPreambleLength[2] = 0x0000;
    userInputAdvanced.D4TxPreambleLength[2] = 0x0000;
    userInputSim.tSTAOFF[0]                 = 1612;
    userInputSim.tPDM[0]                    = 1651;
    userInputSim.tSTAOFF[1]                 = 1769;
    userInputSim.tPDM[1]                    = 1729;
    userInputSim.tSTAOFF[2]                 = 2049;
    userInputSim.tPDM[2]                    = 1869;
    userInputSim.tDQSCK                     = 0;
    
    mb_DDR4R_1D[0].MsgMisc                  = 0x0006;
    mb_DDR4R_1D[0].SequenceCtrl             = 0x0007;	// Bill edit
    mb_DDR4R_1D[0].HdtCtrl                  = 0x00ff;
    mb_DDR4R_1D[0].PhyVref                  = 0x0055;
    mb_DDR4R_1D[0].DFIMRLMargin             = 0x0002;
    mb_DDR4R_1D[0].EnabledDQs               = 0x0048;
    mb_DDR4R_1D[0].CsPresent                = 0x0003;
    mb_DDR4R_1D[0].CsPresentD0              = 0x0003;
    mb_DDR4R_1D[0].CsPresentD1              = 0x0000;
    mb_DDR4R_1D[0].AddrMirror               = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl0             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl1             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl2             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl3             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl4             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl5             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl6             = 0x0000;
    mb_DDR4R_1D[0].AcsmOdtCtrl7             = 0x0000;
    mb_DDR4R_1D[0].X16Present               = 0x0000;
    mb_DDR4R_1D[0].PhyCfg                   = 0x0000;
    mb_DDR4R_1D[0].CsSetupGDDec             = 0x0001;	// Bill edit
    mb_DDR4R_1D[0].MR0                      = 0x0d54;	// Bill edit, For 3200AC RL
    mb_DDR4R_1D[0].MR1                      = 0x0001;
    mb_DDR4R_1D[0].MR2                      = 0x0228;
    mb_DDR4R_1D[0].MR3                      = 0x0000;
    mb_DDR4R_1D[0].MR4                      = 0x0000;
    mb_DDR4R_1D[0].MR5                      = 0x0440;	// Bill edit
    mb_DDR4R_1D[0].MR6                      = 0x104f;
    mb_DDR4R_1D[0].ALT_CAS_L                = 0x0000;
    mb_DDR4R_1D[0].ALT_WCAS_L               = 0x0000;
    mb_DDR4R_1D[0].VrefDqR0Nib0             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib1             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib2             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib3             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib4             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib5             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib6             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib7             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib8             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib9             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib10            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib11            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib12            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib13            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib14            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib15            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib16            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib17            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib18            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR0Nib19            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib0             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib1             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib2             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib3             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib4             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib5             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib6             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib7             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib8             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib9             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib10            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib11            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib12            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib13            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib14            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib15            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib16            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib17            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib18            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR1Nib19            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib0             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib1             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib2             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib3             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib4             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib5             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib6             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib7             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib8             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib9             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib10            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib11            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib12            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib13            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib14            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib15            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib16            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib17            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib18            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR2Nib19            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib0             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib1             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib2             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib3             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib4             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib5             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib6             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib7             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib8             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib9             = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib10            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib11            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib12            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib13            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib14            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib15            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib16            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib17            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib18            = 0x004f;
    mb_DDR4R_1D[0].VrefDqR3Nib19            = 0x004f;
    mb_DDR4R_1D[0].F0RC00_D0                = 0x0000;
    mb_DDR4R_1D[0].F0RC01_D0                = 0x0000;
    mb_DDR4R_1D[0].F0RC08_D0                = 0x0000;
    mb_DDR4R_1D[0].F0RC0A_D0                = 0x0006;
    mb_DDR4R_1D[0].F0RC0D_D0                = 0x0004;
    mb_DDR4R_1D[0].F0RC0E_D0                = 0x000c;
    mb_DDR4R_1D[0].F0RC0F_D0                = 0x0004;
    mb_DDR4R_1D[0].F0RC3x_D0                = 0x0061;
    mb_DDR4R_1D[0].F0RC00_D1                = 0x0000;
    mb_DDR4R_1D[0].F0RC01_D1                = 0x0000;
    mb_DDR4R_1D[0].F0RC08_D1                = 0x0000;
    mb_DDR4R_1D[0].F0RC0A_D1                = 0x0006;
    mb_DDR4R_1D[0].F0RC0D_D1                = 0x0004;
    mb_DDR4R_1D[0].F0RC0E_D1                = 0x000c;
    mb_DDR4R_1D[0].F0RC0F_D1                = 0x0004;
    mb_DDR4R_1D[0].F0RC3x_D1                = 0x0061;
    mb_DDR4R_1D[1].MsgMisc                  = 0x0006;
    mb_DDR4R_1D[1].SequenceCtrl             = 0x0007;	// Bill edit
    mb_DDR4R_1D[1].HdtCtrl                  = 0x00ff;
    mb_DDR4R_1D[1].PhyVref                  = 0x0055;
    mb_DDR4R_1D[1].DFIMRLMargin             = 0x0002;
    mb_DDR4R_1D[1].EnabledDQs               = 0x0048;
    mb_DDR4R_1D[1].CsPresent                = 0x0003;
    mb_DDR4R_1D[1].CsPresentD0              = 0x0003;
    mb_DDR4R_1D[1].CsPresentD1              = 0x0000;
    mb_DDR4R_1D[1].AddrMirror               = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl0             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl1             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl2             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl3             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl4             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl5             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl6             = 0x0000;
    mb_DDR4R_1D[1].AcsmOdtCtrl7             = 0x0000;
    mb_DDR4R_1D[1].X16Present               = 0x0000;
    mb_DDR4R_1D[1].PhyCfg                   = 0x0000;
    mb_DDR4R_1D[1].CsSetupGDDec             = 0x0001;	// Bill edit
    mb_DDR4R_1D[1].MR0                      = 0x0734;	// Bill edit, for 3200AC RL
    mb_DDR4R_1D[1].MR1                      = 0x0001;
    mb_DDR4R_1D[1].MR2                      = 0x0210;
    mb_DDR4R_1D[1].MR3                      = 0x0000;
    mb_DDR4R_1D[1].MR4                      = 0x0000;
    mb_DDR4R_1D[1].MR5                      = 0x0440;	// Bill edit
    mb_DDR4R_1D[1].MR6                      = 0x084f;
    mb_DDR4R_1D[1].ALT_CAS_L                = 0x0000;
    mb_DDR4R_1D[1].ALT_WCAS_L               = 0x0000;
    mb_DDR4R_1D[1].VrefDqR0Nib0             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib1             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib2             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib3             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib4             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib5             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib6             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib7             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib8             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib9             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib10            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib11            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib12            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib13            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib14            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib15            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib16            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib17            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib18            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR0Nib19            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib0             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib1             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib2             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib3             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib4             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib5             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib6             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib7             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib8             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib9             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib10            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib11            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib12            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib13            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib14            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib15            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib16            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib17            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib18            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR1Nib19            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib0             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib1             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib2             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib3             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib4             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib5             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib6             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib7             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib8             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib9             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib10            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib11            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib12            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib13            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib14            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib15            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib16            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib17            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib18            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR2Nib19            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib0             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib1             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib2             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib3             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib4             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib5             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib6             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib7             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib8             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib9             = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib10            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib11            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib12            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib13            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib14            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib15            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib16            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib17            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib18            = 0x004f;
    mb_DDR4R_1D[1].VrefDqR3Nib19            = 0x004f;
    mb_DDR4R_1D[1].F0RC00_D0                = 0x0000;
    mb_DDR4R_1D[1].F0RC01_D0                = 0x0000;
    mb_DDR4R_1D[1].F0RC08_D0                = 0x0000;
    mb_DDR4R_1D[1].F0RC0A_D0                = 0x0002;
    mb_DDR4R_1D[1].F0RC0D_D0                = 0x0004;
    mb_DDR4R_1D[1].F0RC0E_D0                = 0x000c;
    mb_DDR4R_1D[1].F0RC0F_D0                = 0x0004;
    mb_DDR4R_1D[1].F0RC3x_D0                = 0x002c;
    mb_DDR4R_1D[1].F0RC00_D1                = 0x0000;
    mb_DDR4R_1D[1].F0RC01_D1                = 0x0000;
    mb_DDR4R_1D[1].F0RC08_D1                = 0x0000;
    mb_DDR4R_1D[1].F0RC0A_D1                = 0x0002;
    mb_DDR4R_1D[1].F0RC0D_D1                = 0x0004;
    mb_DDR4R_1D[1].F0RC0E_D1                = 0x000c;
    mb_DDR4R_1D[1].F0RC0F_D1                = 0x0004;
    mb_DDR4R_1D[1].F0RC3x_D1                = 0x002c;
    mb_DDR4R_1D[2].MsgMisc                  = 0x0006;
    mb_DDR4R_1D[2].SequenceCtrl             = 0x0007;	// Bill edit
    mb_DDR4R_1D[2].HdtCtrl                  = 0x00ff;
    mb_DDR4R_1D[2].PhyVref                  = 0x0055;
    mb_DDR4R_1D[2].DFIMRLMargin             = 0x0002;
    mb_DDR4R_1D[2].EnabledDQs               = 0x0048;
    mb_DDR4R_1D[2].CsPresent                = 0x0003;
    mb_DDR4R_1D[2].CsPresentD0              = 0x0003;
    mb_DDR4R_1D[2].CsPresentD1              = 0x0000;
    mb_DDR4R_1D[2].AddrMirror               = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl0             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl1             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl2             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl3             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl4             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl5             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl6             = 0x0000;
    mb_DDR4R_1D[2].AcsmOdtCtrl7             = 0x0000;
    mb_DDR4R_1D[2].X16Present               = 0x0000;
    mb_DDR4R_1D[2].PhyCfg                   = 0x0000;
    mb_DDR4R_1D[2].CsSetupGDDec             = 0x0001;	// Bill edit
    mb_DDR4R_1D[2].MR0                      = 0x0104;
    mb_DDR4R_1D[2].MR1                      = 0x0001;
    mb_DDR4R_1D[2].MR2                      = 0x0200;
    mb_DDR4R_1D[2].MR3                      = 0x0000;
    mb_DDR4R_1D[2].MR4                      = 0x0000;
    mb_DDR4R_1D[2].MR5                      = 0x0440;	// Bill edit
    mb_DDR4R_1D[2].MR6                      = 0x004f;
    mb_DDR4R_1D[2].ALT_CAS_L                = 0x0000;
    mb_DDR4R_1D[2].ALT_WCAS_L               = 0x0000;
    mb_DDR4R_1D[2].VrefDqR0Nib0             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib1             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib2             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib3             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib4             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib5             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib6             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib7             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib8             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib9             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib10            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib11            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib12            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib13            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib14            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib15            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib16            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib17            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib18            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR0Nib19            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib0             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib1             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib2             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib3             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib4             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib5             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib6             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib7             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib8             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib9             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib10            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib11            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib12            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib13            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib14            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib15            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib16            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib17            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib18            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR1Nib19            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib0             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib1             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib2             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib3             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib4             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib5             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib6             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib7             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib8             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib9             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib10            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib11            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib12            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib13            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib14            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib15            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib16            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib17            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib18            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR2Nib19            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib0             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib1             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib2             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib3             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib4             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib5             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib6             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib7             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib8             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib9             = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib10            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib11            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib12            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib13            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib14            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib15            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib16            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib17            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib18            = 0x004f;
    mb_DDR4R_1D[2].VrefDqR3Nib19            = 0x004f;
    mb_DDR4R_1D[2].F0RC00_D0                = 0x0000;
    mb_DDR4R_1D[2].F0RC01_D0                = 0x0000;
    mb_DDR4R_1D[2].F0RC08_D0                = 0x0000;
    mb_DDR4R_1D[2].F0RC0A_D0                = 0x0000;
    mb_DDR4R_1D[2].F0RC0D_D0                = 0x0004;
    mb_DDR4R_1D[2].F0RC0E_D0                = 0x000c;
    mb_DDR4R_1D[2].F0RC0F_D0                = 0x0004;
    mb_DDR4R_1D[2].F0RC3x_D0                = 0x0004;
    mb_DDR4R_1D[2].F0RC00_D1                = 0x0000;
    mb_DDR4R_1D[2].F0RC01_D1                = 0x0000;
    mb_DDR4R_1D[2].F0RC08_D1                = 0x0000;
    mb_DDR4R_1D[2].F0RC0A_D1                = 0x0000;
    mb_DDR4R_1D[2].F0RC0D_D1                = 0x0004;
    mb_DDR4R_1D[2].F0RC0E_D1                = 0x000c;
    mb_DDR4R_1D[2].F0RC0F_D1                = 0x0004;
    mb_DDR4R_1D[2].F0RC3x_D1                = 0x0004;
    
        dwc_ddrphy_phyinit_cmnt ("%s End of dwc_ddrphy_phyinit_userCustom_overrideUserInput()\n", printf_header);
}
/** @} */
