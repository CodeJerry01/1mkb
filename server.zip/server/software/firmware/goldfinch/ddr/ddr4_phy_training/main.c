#include <stdio.h>
#include <stdint.h>
#include "common.h"

/* Below variables updated from Flash */
unsigned int pstate_num = 1;
unsigned int dram_freq = 0;
unsigned int dfi_freq_ratio = 1;
unsigned int x8_device = 1;
unsigned int skip_training = 0;
unsigned int cs_dimm0 = 1;
unsigned int cs_dimm1 = 0;
unsigned int rank_num = 1;
unsigned int ad_mirror = 0;
unsigned int cs_mode = 0;

/* General purpose variables */
unsigned int addr, value, offset, offset1, offset2;
unsigned int addr1, addr2, g_offset;

void main()
{
	/* PHY CONFIG */
	printf("PHY INIT\n");
	phy_config_init();
	
	/* SKIP TRAINING */
	printf("SKIP TRAINING\n");
	skip_traininig_1_or_2();

	/* LOAD IMEM */
	printf("IMEM INIT\n");
	imem_init();

	/* LOAD DMEM */
	printf("DMEM INIT\n");
	dmem_init(1);

	/* RUN TRAINING FIRMWARE */
	printf("RUN FIRMWARE\n");
	run_training_firmware();
}
