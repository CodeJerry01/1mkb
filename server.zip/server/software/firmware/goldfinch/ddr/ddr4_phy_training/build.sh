#!/bin/bash

# Remove the previous a.out file if it exists
rm -f a.out
rm -f output

# Compile the C files
gcc main.c phy_config.c skip_train.c dmem.c imem.c train.c

# Check if the a.out file was created
if [ -f a.out ]; then
    echo "Compilation successful. DDR Generic Sequence compiled and sequence writes generated in the output file."
    ./a.out > output
else
    echo "Error: Compilation failed" >&2
    exit 1
fi

