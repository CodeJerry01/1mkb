/** \file
 * \brief Helper function to determine dbyte should be disabled.
 * \addtogroup SrcFunc
 * @{
 */
#include <stdlib.h>
#include <math.h>
#include "dwc_ddrphy_phyinit.h"
/** @brief Helper function to determine if a given DByte is Disabled given PhyInit inputs.
 * @return 1 if disabled, 0 if enabled.
 */
int dwc_ddrphy_phyinit_IsDbyteDisabled(int DbyteNumber) {
    
    char *printf_header;
    printf_header = "// [dwc_ddrphy_phyinit_IsDbyteDisabled]";

    int DisableDbyte;
    DisableDbyte = 0; // default assume Dbyte is Enabled.


    // Implements Section 1.3 of Pub Databook
    DisableDbyte = (DbyteNumber > userInputBasic.NumActiveDbyteDfi0-1 ) ? 1:0;


    // Qualify results against MessageBlock 

    if ( mb_DDR4R_1D[0].EnabledDQs < 1 ||  mb_DDR4R_1D[0].EnabledDQs > 8*userInputBasic.NumActiveDbyteDfi0 )
      {
      dwc_ddrphy_phyinit_assert(0,"%s EnabledDQs(%d). Value must be 0 < EnabledDQs < userInputBasic.NumActiveDbyteDfi0*8.\n",printf_header,mb_DDR4R_1D[0].EnabledDQs);
      }  

    if (DbyteNumber < 8 ) 
      {
      DisableDbyte =  DisableDbyte | (mb_DDR4R_1D[0].DisabledDbyte & (0x1<<DbyteNumber));
      }

     
    return DisableDbyte;
}
/** @} */
