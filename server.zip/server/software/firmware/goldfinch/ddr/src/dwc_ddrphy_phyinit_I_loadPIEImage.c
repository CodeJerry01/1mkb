/** \file
 * \brief implements Step I of initialization sequence
 *
 * This file contains the implementation of dwc_ddrphy_phyinit_I_initPhyConfig
 * function. 
 *
 *  \addtogroup SrcFunc
 *  @{
 */
#include "dwc_ddrphy_phyinit.h"
/** \brief Loads registers after training
 *
 * This function programs the PHY Initialization Engine (PIE) instructions and
 * the associated registers.  
 * 
 * \return void
 * 
 * Detailed list of registers programmed by this function:
 */
void dwc_ddrphy_phyinit_I_loadPIEImage (int skip_training) {
    
    char *printf_header;
    printf_header = "// [phyinit_I_loadPIEImage]";
    
    dwc_ddrphy_phyinit_cmnt ("%s Start of dwc_ddrphy_phyinit_I_loadPIEImage()\n", printf_header);

    unsigned int pstate; 
    int p_addr;


    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_cmnt ("//\n");
    dwc_ddrphy_phyinit_cmnt ("// (I) Load PHY Init Engine Image \n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("// Load the PHY Initialization Engine memory with the provided initialization sequence.\n");
    dwc_ddrphy_phyinit_cmnt ("// See PhyInit App Note for detailed description and function usage\n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    
    dwc_ddrphy_phyinit_cmnt ("// Enable access to the internal CSRs by setting the MicroContMuxSel CSR to 0. \n");
    dwc_ddrphy_phyinit_cmnt ("// This allows the memory controller unrestricted access to the configuration CSRs. \n");
    dwc_ddrphy_phyinit_userCustom_io_write16((tAPBONLY | csr_MicroContMuxSel_ADDR), 0x0);

    dwc_ddrphy_phyinit_cmnt ("%s Programming PIE Production Code\n", printf_header);

    dwc_ddrphy_phyinit_LoadPieProdCode();


    /**
     * - Registers: Seq0BDLY0, Seq0BDLY1, Seq0BDLY2, Seq0BDLY3
     *   - Program PIE instruction delays 
     *   - Dependencies:
     *     - user_input_basic.Frequency
     */
    // Need delays for 0.5us, 1us, 10us, and 25us.
    uint16_t psCount[4][4];
    float delayScale = 1.00;

    // Calculate the counts to obtain the correct delay for each frequency
    // Need to divide by 4 since the delay value are specified in units of
    // 4 clocks.
    double DfiFrq,dllLock;

    for (pstate=0;pstate<userInputBasic.NumPStates;pstate++) {
      p_addr = pstate << 20;
      DfiFrq = (0.5 * userInputBasic.Frequency[pstate]);
      psCount[pstate][0] = (int)(( 0.5 * 0.25 * DfiFrq * delayScale));
      int LowFreqOpt = 0;
      if ( userInputBasic.Frequency[pstate] < 400 ) LowFreqOpt = 7;
      else if ( userInputBasic.Frequency[pstate] < 533 ) LowFreqOpt = 14;
      psCount[pstate][1] = (int)(( 1.0 * 0.25 * DfiFrq * delayScale)) - LowFreqOpt;;
      psCount[pstate][2] = (int)((10.0 * 0.25 * DfiFrq * delayScale));

      if (DfiFrq>266.5) { dllLock=176; } 
      else if (DfiFrq<=266.5 && DfiFrq>200) { dllLock=132; } 
      else { dllLock=64; }

      psCount[pstate][3] = (int)(0.25 * dllLock);

      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY0 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][0]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY0_ADDR), psCount[pstate][0]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY1 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][1]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY1_ADDR), psCount[pstate][1]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY2 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][2]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY2_ADDR), psCount[pstate][2]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY3 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][3]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY3_ADDR), psCount[pstate][3]);

    }
    /**
     * - Registers: Seq0BDisableFlag0 Seq0BDisableFlag1 Seq0BDisableFlag2 
     *   Seq0BDisableFlag3 Seq0BDisableFlag4 Seq0BDisableFlag5
     *   - Program PIE Instruction Disable Flags 
     *   - Dependencies:
     *     - userInputAdvanced.SnpsUmctlOpt
     */
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag0_ADDR), 0x0000);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag1_ADDR), 0x0173);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag2_ADDR), 0x0060);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag3_ADDR), 0x6110);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag4_ADDR), 0x2152);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag5_ADDR), 0xDFBD);
    if (userInputAdvanced.SnpsUmctlOpt == 1) { 
        // Enable Synopsys Uctl Controller DDR4 RDIMM PIE Optimizations
        dwc_ddrphy_phyinit_cmnt ("%s Enable Synopsys Uctl Controller DDR4 RDIMM PIE Optimizations\n", printf_header);
        dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag6_ADDR), 0x6000);
    } else {
        dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag6_ADDR), 0xffff);
    }
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag7_ADDR), 0x6152);




    /**
     * - Registers AcsmPlayback*x* 
     *   - Program Address/Command Sequence Engine (ACSM) registers with
     *     required instructions for retraining algorithm.
     *   - Dependencies:
     *     - user_input_basic.NumPStates
     *     - mb_DDR4R_1D[pstate].F0RC0A_D0
     *     - mb_DDR4R_1D[pstate].F0RC3x_D0
     *     - userInputAdvanced.SnpsUmctlF0RC5x[pstate]
     */

    int acsmplayback[2][4] = {
        {0,0,0,0},
        {0,0,0,0}
    };
    int NumVec=0;
    int vec=0;
    for (pstate=0; pstate<userInputBasic.NumPStates; pstate++)
      {
      p_addr = pstate << 20;
      NumVec=0;

      uint32_t F0RC0A; // DIMM Operating Speed
      F0RC0A = dwc_ddrphy_phyinit_getMb(pstate,"F0RC0A_D0",0); //  use the RCD register value for 1D training. 
      F0RC0A = 0x0a0 | (0xf & F0RC0A );
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d, Programming F0RC0A=%x \n", printf_header, pstate, F0RC0A);
      
      acsmplayback[0][NumVec] = 0x3ff & F0RC0A; 
      acsmplayback[1][NumVec] = (0x1c00 & F0RC0A) >> 10; 
      NumVec += 1;
      
      uint32_t F0RC3x; // Fine Granularity RDIMM Operating Speed
      F0RC3x = dwc_ddrphy_phyinit_getMb(pstate,"F0RC3x_D0",0); //  use the RCD register value for 1D training. 
      F0RC3x = 0x300 | (0xff & F0RC3x );
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d, Programming F0RC3x=%x \n", printf_header, pstate, F0RC3x);
      
      acsmplayback[0][NumVec] = 0x3ff & F0RC3x; 
      acsmplayback[1][NumVec] = (0x1c00 & F0RC3x) >> 10; 
      NumVec += 1;
     
      uint32_t F0RC5x; // F0RC5x: CW Destination Selection & Write/Read Additional QxODT[1:0] Signal High
      F0RC5x = 0x500 | (0xff & userInputAdvanced.SnpsUmctlF0RC5x[pstate]);
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d, Programming F0RC5x=%x \n", printf_header, pstate, F0RC5x);
      
      acsmplayback[0][NumVec] = 0x3ff & F0RC5x;
      acsmplayback[1][NumVec] = (0x1c00 & F0RC5x) >> 10; 
      NumVec += 1;

      for (vec=0; vec<NumVec; vec++)
        {
        dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d, Programming AcsmPlayback0x%d to 0x%x\n", printf_header, pstate, vec, acsmplayback[0][vec]);
        dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | tACSM | (csr_AcsmPlayback0x0_ADDR+vec*2)), acsmplayback[0][vec]);
        
        dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d, Programming AcsmPlayback1x%d to 0x%x\n", printf_header, pstate, vec, acsmplayback[1][vec]);
        dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | tACSM | (csr_AcsmPlayback1x0_ADDR+vec*2)), acsmplayback[1][vec]);
        }
      }
    

    /**
     * Program Training Hardware Registers for mission mode retraining
     * and DRAM drift compensation algorithm.
     *
     */
    uint16_t regData;
    dwc_ddrphy_phyinit_cmnt ("%s Programing Training Hardware Registers for mission mode retraining\n", printf_header);
   /// - Register: AcsmCtrl13
   ///   - Fields: AcsmCkeEnb
    regData=(0xf << csr_AcsmCkeEnb_LSB);
    dwc_ddrphy_phyinit_userCustom_io_write16((c0 | tACSM | csr_AcsmCtrl13_ADDR), regData);
   /// - Register: AcsmCtrl0
   ///   - Fields:
   ///     - AcsmParMode
   ///     - Acsm2TMode
    dwc_ddrphy_phyinit_userCustom_io_write16((c0 | tACSM | csr_AcsmCtrl0_ADDR), csr_AcsmParMode_MASK | csr_Acsm2TMode_MASK );


   /// - Register: CalZap
   ///   - Prepare the calibration controller for mission mode.
   ///     Turn on calibration and hold idle until dfi_init_start is asserted sequence is triggered.
    dwc_ddrphy_phyinit_cmnt ("%s Turn on calibration and hold idle until dfi_init_start is asserted sequence is triggered.\n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tMASTER | csr_CalZap_ADDR), 0x1);

   /// - Register: CalRate
   ///   - Fields:
   ///     - CalRun
   ///     - CalOnce
   ///     - CalInterval
   ///   - Dependencies 
   ///     - user_input_advanced.CalInterval 
   ///     - user_input_advanced.CalRun
   ///     - user_input_advanced.CalOnce

    int CalRate;
    int CalInterval;
    int CalOnce;

    CalInterval = userInputAdvanced.CalInterval;
    CalOnce = userInputAdvanced.CalOnce;

    CalRate = (0x1 << csr_CalRun_LSB) | (CalOnce << csr_CalOnce_LSB) | (CalInterval << csr_CalInterval_LSB);

    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalInterval to 0x%x\n", printf_header, CalInterval);
    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalOnce to 0x%x\n", printf_header, CalOnce);
    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalRun to 0x%x\n", printf_header, 0x1);

    dwc_ddrphy_phyinit_userCustom_io_write16((tMASTER | csr_CalRate_ADDR), CalRate);

   /**
    * At the end of this function, PHY Clk gating register UcclkHclkEnables is
    * set for mission mode.  Additionally APB access is Isolated by setting 
    * MicroContMuxSel.
    */
    dwc_ddrphy_phyinit_cmnt ("%s Disabling Ucclk (PMU) and Hclk (training hardware)\n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tDRTUB | csr_UcclkHclkEnables_ADDR), 0x0);
    
    dwc_ddrphy_phyinit_cmnt ("%s Isolate the APB access from the internal CSRs by setting the MicroContMuxSel CSR to 1. \n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tAPBONLY | csr_MicroContMuxSel_ADDR), 0x1);

    dwc_ddrphy_phyinit_cmnt ("%s End of dwc_ddrphy_phyinit_I_loadPIEImage()\n", printf_header);

}
/** @} */
