/** \file */

#include <dwc_ddrphy_phyinit_userCustom.h>
/*! \def DWC_DDRPHY_PHYINIT_RID
 * cdefine for a PhyInit Revision ID
 */
#define DWC_DDRPHY_PHYINIT_RID 202006

//#############################################################################
// Global Structures : instantiated in dwc_ddrphy_globals.c
//#############################################################################
extern runtime_config_t              runtimeConfig;

extern user_input_basic_t            userInputBasic;
extern user_input_advanced_t         userInputAdvanced;
extern user_input_sim_t              userInputSim;

extern PMU_SMB_DDR4R_1D_t        mb_DDR4R_1D[4];
extern PMU_SMB_DDR4R_1D_t        shdw_DDR4R_1D[4];
extern PMU_SMB_DDR4R_2D_t        mb_DDR4R_2D[4];
extern PMU_SMB_DDR4R_2D_t        shdw_DDR4R_2D[4];

// Function definitions
int dwc_ddrphy_phyinit_setMb (int ps, char *field, int value, int Train2D);
int dwc_ddrphy_phyinit_softSetMb (int ps, char *field, int value, int Train2D);
void dwc_ddrphy_phyinit_initStruct(int Train2D);
