/** \file 
 * \brief calculates messageBlock header based on user_input_basic and user_input_advanced.
 */

#include <stdlib.h>
#include "dwc_ddrphy_phyinit.h"

extern PMU_SMB_DDR4R_1D_t    mb_DDR4R_1D[4];
extern PMU_SMB_DDR4R_2D_t    mb_DDR4R_2D[4];

/**
 *  \addtogroup SrcFunc
 *  @{
 */

/** \brief reads PhyInit inputs structures and sets relevant message bloc
 * parameters.
 * 
 * This function sets Message Block parameters based on user_input_basic and 
 * user_input_advanced. Parameters are only set if not programed by
 * dwc_ddrphy_phyinit_userCustom_overrideUserInput() or
 * dwc_ddrphy_phyinit_setDefault(). user changes in these files takes precedence
 * over this function call.
 * 
 * MessageBlock fields set ::
 *
 *  - DramType
 *  - Pstate              
 *  - DRAMFreq            
 *  - PllBypassEn         
 *  - DfiFreqRatio        
 *  - PhyOdtImpedance     
 *  - PhyDrvImpedance     
 *  - BPZNResVal          
 *  - EnabledDQs
 *  - PhyCfg    
 *  - X16Present   
 * 
 * \return void
 */
void dwc_ddrphy_phyinit_calcMb (int Train2D) { 

    char *printf_header;
    printf_header = "//[dwc_ddrphy_phyinit_calcMb]";

    dwc_ddrphy_phyinit_print ("%s Start of dwc_ddrphy_phyinit_calcMb()\n", printf_header);

    int nad0 = userInputBasic.NumActiveDbyteDfi0;
    int nad1 = 0;

    // a few checks to make sure valid programing.
    if ( nad0 <= 0 || 
         nad1 < 0 ||
         userInputBasic.NumDbyte <= 0) { 
      dwc_ddrphy_phyinit_assert(0,"%s NumActiveDbyteDfi0, NumActiveDbyteDfi0, NumByte out of range.\n",printf_header);
      }

    if ( (nad0 + nad1) > userInputBasic.NumDbyte) { 
      dwc_ddrphy_phyinit_assert(0,"%s NumActiveDbyteDfi0+NumActiveDbyteDfi1 is larger than NumDbyteDfi0\n",printf_header);
      }

    if (userInputBasic.Dfi1Exists==0 && nad1 != 0) {
      dwc_ddrphy_phyinit_assert(0,"%s Dfi1Exists==0 but NumDbyteDfi0 != 0\n",printf_header);
      }
     
   
    uint8_t myps;
    uint16_t res;

    // 1D message block defaults
    for (myps=0; myps<userInputBasic.NumPStates; myps++) {
   
      if ((mb_DDR4R_1D[0].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[1].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[2].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[3].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[0].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[1].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[2].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[3].MR4 & 0x1c0) != 0x0 ) {
        dwc_ddrphy_phyinit_assert(0,"%s Setting DRAM CAL mode is not supported by the PHY. Memory controller may set CAL mode after PHY has entered mission mode. Please check value programmed in mb_DDR4R_1D[*].MR4 or mb_DDR4R_2D[*].MR4 and unset A8:6\n",printf_header);
      }

      if (userInputBasic.DimmType == UDIMM || userInputBasic.DimmType == SODIMM || userInputBasic.DimmType == NODIMM) {
          dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x2,0); // DDR4 UDIMM
      } else if (userInputBasic.DimmType == RDIMM) {
          dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x4,0); // DDR4 RDIMM
      } else if (userInputBasic.DimmType == LRDIMM) {
          dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x5,0); // DDR4 LRDIMM
      } else {
          dwc_ddrphy_phyinit_assert(0,"%s Unsupported DimmType for DDR4!\n", printf_header);
      }

      dwc_ddrphy_phyinit_softSetMb(myps,"Pstate",myps,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"DRAMFreq",userInputBasic.Frequency[myps] * 2,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"PllBypassEn",userInputBasic.PllBypass[myps],0);
      dwc_ddrphy_phyinit_softSetMb(myps,"DfiFreqRatio",(0==userInputBasic.DfiFreqRatio[myps]) ? 0x1 : ((1==userInputBasic.DfiFreqRatio[myps]) ? 0x2 : 0x4),0); 
    if (userInputBasic.HardMacroVer == 4 )  { //HardMacroE
      dwc_ddrphy_phyinit_softSetMb(myps,"PhyOdtImpedance",0,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"PhyDrvImpedance",0,0);
    } else {
      dwc_ddrphy_phyinit_softSetMb(myps,"PhyOdtImpedance",0,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"PhyDrvImpedance",0,0);
    }
      dwc_ddrphy_phyinit_softSetMb(myps,"BPZNResVal",0,0);
  
      dwc_ddrphy_phyinit_softSetMb(myps,"EnabledDQs",nad0*8,0);

      uint16_t DisabledDbyte = 0x0;
      int Dbyte;
      for (Dbyte=0; Dbyte<userInputBasic.NumDbyte && Dbyte<8; Dbyte++) { 
          DisabledDbyte = DisabledDbyte | (dwc_ddrphy_phyinit_IsDbyteDisabled(Dbyte) ? (0x1 << Dbyte) : 0x0);
      }
      dwc_ddrphy_phyinit_softSetMb(myps,"DisabledDbyte",DisabledDbyte,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"PhyCfg",(((mb_DDR4R_1D[myps].MR3 & 0x8) || (mb_DDR4R_2D[myps].MR3 & 0x8)))?0:userInputAdvanced.Is2Ttiming[myps],0);
      dwc_ddrphy_phyinit_softSetMb(myps,"X16Present",(0x10==userInputBasic.DramDataWidth) ? mb_DDR4R_1D[myps].CsPresent : 0x0,0);
      // Only content of the Control Word is required to be programmed.

      // F0RC0D Dimm0
      res = 0x4 + userInputAdvanced.CsMode; // RDIMM, DualCS/QuadCS/Encoded QuadCS
      // Enable Address mirroring by setting DA[3]
      res |= (mb_DDR4R_1D[myps].AddrMirror & mb_DDR4R_1D[myps].CsPresentD0) ? 0x8 : 0x0; 
      res = (0xf & res); 
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0D_D0",res,0);

      // F0RC0D Dimm1
      res = 0x4 + userInputAdvanced.CsMode; // RDIMM, DualCS/QuadCS/Encoded QuadCS
      // Enable Address mirroring by setting DA[3]
      res |= (mb_DDR4R_1D[myps].AddrMirror & mb_DDR4R_1D[myps].CsPresentD1) ? 0x8 : 0x0; 
      res = (0xf & res); 
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0D_D1",res,0);

      // F0RC0A
      // DIMM Operating Speed
      // Implement Table 42 of RCD spec
      res = (userInputBasic.Frequency[myps] <=  800) ? 0x0 : 
            (userInputBasic.Frequency[myps] <=  933) ? 0x1 : 
            (userInputBasic.Frequency[myps] <= 1066) ? 0x2 : 
            (userInputBasic.Frequency[myps] <= 1200) ? 0x3 : 
            (userInputBasic.Frequency[myps] <= 1333) ? 0x4 : 
            (userInputBasic.Frequency[myps] <= 1466) ? 0x5 : 
            (userInputBasic.Frequency[myps] <= 1600) ? 0x6 : 0x0; 
      res =((0xf & res) | ((userInputAdvanced.Context[myps] & 0x1) << 3)); 
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0A_D0",res,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0A_D1",res,0);

      // F0RC3x
      // Fine Granularity RDIMM Operating Speed
      res = (userInputBasic.Frequency[myps] <= 620 ) ? 0 : (userInputBasic.Frequency[myps] - 621)/10;
      res =(0xff & res); 
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC3x_D0",res,0);
      dwc_ddrphy_phyinit_softSetMb(myps,"F0RC3x_D1",res,0);

    } // myps

    // 2D message block defaults
    if (Train2D) {
    for (myps=0; myps<1; myps++) {
   
      if ((mb_DDR4R_1D[0].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[1].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[2].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_1D[3].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[0].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[1].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[2].MR4 & 0x1c0) != 0x0 || 
          (mb_DDR4R_2D[3].MR4 & 0x1c0) != 0x0 ) {
        dwc_ddrphy_phyinit_assert(0,"%s Setting DRAM CAL mode is not supported by the PHY. Memory controller may set CAL mode after PHY has entered mission mode. Please check value programmed in mb_DDR4R_1D[*].MR4 or mb_DDR4R_2D[*].MR4 and unset A8:6\n",printf_header);
      }

        if (userInputBasic.DimmType == UDIMM || userInputBasic.DimmType == SODIMM || userInputBasic.DimmType == NODIMM) {
            dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x2,1); // DDR4 UDIMM
        } else if (userInputBasic.DimmType == RDIMM) {
            dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x4,1); // DDR4 RDIMM
        } else if (userInputBasic.DimmType == LRDIMM) {
            dwc_ddrphy_phyinit_softSetMb(myps,"DramType",0x5,1); // DDR4 LRDIMM
        } else {
            dwc_ddrphy_phyinit_assert(0,"%s Unsupported DimmType for DDR4!\n", printf_header);
        }

        dwc_ddrphy_phyinit_softSetMb(myps,"Pstate",myps,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"DRAMFreq",userInputBasic.Frequency[myps] * 2,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"PllBypassEn",userInputBasic.PllBypass[myps],1);
        dwc_ddrphy_phyinit_softSetMb(myps,"DfiFreqRatio",(0==userInputBasic.DfiFreqRatio[myps]) ? 0x1 : ((1==userInputBasic.DfiFreqRatio[myps]) ? 0x2 : 0x4),1); 
    if (userInputBasic.HardMacroVer == 4 )  { //HardMacroE
        dwc_ddrphy_phyinit_softSetMb(myps,"PhyOdtImpedance",0,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"PhyDrvImpedance",0,1);
    } else {
        dwc_ddrphy_phyinit_softSetMb(myps,"PhyOdtImpedance",0,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"PhyDrvImpedance",0,1);
    }
        dwc_ddrphy_phyinit_softSetMb(myps,"BPZNResVal",0,1);
  
        dwc_ddrphy_phyinit_softSetMb(myps,"EnabledDQs",nad0*8,1);

        uint16_t DisabledDbyte = 0x0;
        int Dbyte;
        for (Dbyte=0; Dbyte<userInputBasic.NumDbyte && Dbyte<8; Dbyte++) { 
            DisabledDbyte = DisabledDbyte | (dwc_ddrphy_phyinit_IsDbyteDisabled(Dbyte) ? (0x1 << Dbyte) : 0x0);
        }
        dwc_ddrphy_phyinit_softSetMb(myps,"DisabledDbyte",DisabledDbyte,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"PhyCfg",(((mb_DDR4R_1D[myps].MR3 & 0x8) || (mb_DDR4R_2D[myps].MR3 & 0x8)))?0:userInputAdvanced.Is2Ttiming[myps],1);
        dwc_ddrphy_phyinit_softSetMb(myps,"X16Present",(0x10==userInputBasic.DramDataWidth) ? mb_DDR4R_2D[myps].CsPresent : 0x0,1);
        // Only content of the Control Word is required to be programmed.

        // F0RC0D Dimm0
        res = 0x4 + userInputAdvanced.CsMode; // RDIMM, DualCS/QuadCS/Encoded QuadCS
        // Enable Address mirroring by setting DA[3]
        res |= (mb_DDR4R_2D[myps].AddrMirror & mb_DDR4R_2D[myps].CsPresentD0) ? 0x8 : 0x0; 
        res = (0xf & res); 
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0D_D0",res,1);

        // F0RC0D Dimm1
        res = 0x4 + userInputAdvanced.CsMode; // RDIMM, DualCS/QuadCS/Encoded QuadCS
        // Enable Address mirroring by setting DA[3]
        res |= (mb_DDR4R_2D[myps].AddrMirror & mb_DDR4R_2D[myps].CsPresentD1) ? 0x8 : 0x0; 
        res = (0xf & res); 
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0D_D1",res,1);

        // F0RC0A
        // DIMM Operating Speed
        // Implement Table 42 of RCD spec
        res = (userInputBasic.Frequency[myps] <=  800) ? 0x0 : 
              (userInputBasic.Frequency[myps] <=  933) ? 0x1 : 
              (userInputBasic.Frequency[myps] <= 1066) ? 0x2 : 
              (userInputBasic.Frequency[myps] <= 1200) ? 0x3 : 
              (userInputBasic.Frequency[myps] <= 1333) ? 0x4 : 
              (userInputBasic.Frequency[myps] <= 1466) ? 0x5 : 
              (userInputBasic.Frequency[myps] <= 1600) ? 0x6 : 0x0; 
        res =((0xf & res) | ((userInputAdvanced.Context[myps] & 0x1) << 3)); 
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0A_D0",res,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC0A_D1",res,1);

        // F0RC3x
        // Fine Granularity RDIMM Operating Speed
        res = (userInputBasic.Frequency[myps] <= 620 ) ? 0 : (userInputBasic.Frequency[myps] - 621)/10;
        res =(0xff & res); 
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC3x_D0",res,1);
        dwc_ddrphy_phyinit_softSetMb(myps,"F0RC3x_D1",res,1);

      } // myps
    } // Train2D

    dwc_ddrphy_phyinit_print ("%s End of dwc_ddrphy_phyinit_calcMb()\n", printf_header);
}
/** @} */
