/** \file */

#include <string.h>
#include "dwc_ddrphy_phyinit.h"


/**  \addtogroup SrcFunc
 *   @{
 */

/** @brief API to read the messageBlock structure in PhyInit.
 *
 *  This function can be used to read training firmware 1D/2D messageBlock fields
 *  for a given PState in the PhyInit Data structure.  As an example, to read MsgMsic to 0x4 for PState 3,
 *  for 1D Training :
 *  @code{.c}
 *  dwc_ddrphy_phyinit_setMB(3, "MsgMisc", 0x4, 0);
 *  @endcode
 *
 *  \note This functions doesn't read the DMEM address in SRAM. It returns
 *  what is programed in the PhyInit messageBlock structure which is used
 *  to write to the SRAM once dwc_ddrphy_phyinit_F_loadDMEM() is called in
 *  dwc_ddrphy_phyinit_sequence().
 *
 *
 * @param[in]   ps      integer between 0-3. Specifies the PState for which the
 * messageBlock field should be set.
 * @param[in]   field   A string representing the messageBlock field to be
 * programed. refer to the messageBlock data structure for definition of fields
 * applicable to each protocol. 
 * @param[in]   Train2D determined if the field should be set on 2D or 1D
 * messageBlock.
 * @return field value on success. Returns following values based on
 * error:
 * - -1 : messageBlock field specified by the input \c field string is not
 * found in the messageBlock data structure.
 * - -2 : when DramType does not support 2D training but a 2D training field is
 * programmed.
 * - -3 : Train2D inputs is neither 1 or 0.
 */
int dwc_ddrphy_phyinit_getMb (int ps, char *field, int Train2D) {

    char *printf_header;
    printf_header = "// [dwc_ddrphy_phyinit_setMb]";

      if (Train2D == 0) {
          if ( strcmp(field, "Reserved00") == 0)
              return mb_DDR4R_1D[ps].Reserved00;
          else if ( strcmp(field, "MsgMisc") == 0)
              return mb_DDR4R_1D[ps].MsgMisc;
          else if ( strcmp(field, "Pstate") == 0)
              return mb_DDR4R_1D[ps].Pstate;
          else if ( strcmp(field, "PllBypassEn") == 0)
              return mb_DDR4R_1D[ps].PllBypassEn;
          else if ( strcmp(field, "DRAMFreq") == 0)
              return mb_DDR4R_1D[ps].DRAMFreq;
          else if ( strcmp(field, "DfiFreqRatio") == 0)
              return mb_DDR4R_1D[ps].DfiFreqRatio;
          else if ( strcmp(field, "BPZNResVal") == 0)
              return mb_DDR4R_1D[ps].BPZNResVal;
          else if ( strcmp(field, "PhyOdtImpedance") == 0)
              return mb_DDR4R_1D[ps].PhyOdtImpedance;
          else if ( strcmp(field, "PhyDrvImpedance") == 0)
              return mb_DDR4R_1D[ps].PhyDrvImpedance;
          else if ( strcmp(field, "PhyVref") == 0)
              return mb_DDR4R_1D[ps].PhyVref;
          else if ( strcmp(field, "DramType") == 0)
              return mb_DDR4R_1D[ps].DramType;
          else if ( strcmp(field, "DisabledDbyte") == 0)
              return mb_DDR4R_1D[ps].DisabledDbyte;
          else if ( strcmp(field, "EnabledDQs") == 0)
              return mb_DDR4R_1D[ps].EnabledDQs;
          else if ( strcmp(field, "CsPresent") == 0)
              return mb_DDR4R_1D[ps].CsPresent;
          else if ( strcmp(field, "CsPresentD0") == 0)
              return mb_DDR4R_1D[ps].CsPresentD0;
          else if ( strcmp(field, "CsPresentD1") == 0)
              return mb_DDR4R_1D[ps].CsPresentD1;
          else if ( strcmp(field, "AddrMirror") == 0)
              return mb_DDR4R_1D[ps].AddrMirror;
          else if ( strcmp(field, "PhyCfg") == 0)
              return mb_DDR4R_1D[ps].PhyCfg;
          else if ( strcmp(field, "SequenceCtrl") == 0)
              return mb_DDR4R_1D[ps].SequenceCtrl;
          else if ( strcmp(field, "HdtCtrl") == 0)
              return mb_DDR4R_1D[ps].HdtCtrl;
          else if ( strcmp(field, "Share2DVrefResult") == 0)
              return mb_DDR4R_1D[ps].Share2DVrefResult;
          else if ( strcmp(field, "Reserved1E") == 0)
              return mb_DDR4R_1D[ps].Reserved1E;
          else if ( strcmp(field, "Reserved1F") == 0)
              return mb_DDR4R_1D[ps].Reserved1F;
          else if ( strcmp(field, "Reserved20") == 0)
              return mb_DDR4R_1D[ps].Reserved20;
          else if ( strcmp(field, "Reserved21") == 0)
              return mb_DDR4R_1D[ps].Reserved21;
          else if ( strcmp(field, "PhyConfigOverride") == 0)
              return mb_DDR4R_1D[ps].PhyConfigOverride;
          else if ( strcmp(field, "DFIMRLMargin") == 0)
              return mb_DDR4R_1D[ps].DFIMRLMargin;
          else if ( strcmp(field, "Reserved5D") == 0)
              return mb_DDR4R_1D[ps].Reserved5D;
          else if ( strcmp(field, "MR0") == 0)
              return mb_DDR4R_1D[ps].MR0;
          else if ( strcmp(field, "MR1") == 0)
              return mb_DDR4R_1D[ps].MR1;
          else if ( strcmp(field, "MR2") == 0)
              return mb_DDR4R_1D[ps].MR2;
          else if ( strcmp(field, "MR3") == 0)
              return mb_DDR4R_1D[ps].MR3;
          else if ( strcmp(field, "MR4") == 0)
              return mb_DDR4R_1D[ps].MR4;
          else if ( strcmp(field, "MR5") == 0)
              return mb_DDR4R_1D[ps].MR5;
          else if ( strcmp(field, "MR6") == 0)
              return mb_DDR4R_1D[ps].MR6;
          else if ( strcmp(field, "X16Present") == 0)
              return mb_DDR4R_1D[ps].X16Present;
          else if ( strcmp(field, "CsSetupGDDec") == 0)
              return mb_DDR4R_1D[ps].CsSetupGDDec;
          else if ( strcmp(field, "RTT_NOM_WR_PARK0") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK0;
          else if ( strcmp(field, "RTT_NOM_WR_PARK1") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK1;
          else if ( strcmp(field, "RTT_NOM_WR_PARK2") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK2;
          else if ( strcmp(field, "RTT_NOM_WR_PARK3") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK3;
          else if ( strcmp(field, "RTT_NOM_WR_PARK4") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK4;
          else if ( strcmp(field, "RTT_NOM_WR_PARK5") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK5;
          else if ( strcmp(field, "RTT_NOM_WR_PARK6") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK6;
          else if ( strcmp(field, "RTT_NOM_WR_PARK7") == 0)
              return mb_DDR4R_1D[ps].RTT_NOM_WR_PARK7;
          else if ( strcmp(field, "AcsmOdtCtrl0") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl0;
          else if ( strcmp(field, "AcsmOdtCtrl1") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl1;
          else if ( strcmp(field, "AcsmOdtCtrl2") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl2;
          else if ( strcmp(field, "AcsmOdtCtrl3") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl3;
          else if ( strcmp(field, "AcsmOdtCtrl4") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl4;
          else if ( strcmp(field, "AcsmOdtCtrl5") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl5;
          else if ( strcmp(field, "AcsmOdtCtrl6") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl6;
          else if ( strcmp(field, "AcsmOdtCtrl7") == 0)
              return mb_DDR4R_1D[ps].AcsmOdtCtrl7;
          else if ( strcmp(field, "VrefDqR0Nib0") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib0;
          else if ( strcmp(field, "VrefDqR0Nib1") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib1;
          else if ( strcmp(field, "VrefDqR0Nib2") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib2;
          else if ( strcmp(field, "VrefDqR0Nib3") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib3;
          else if ( strcmp(field, "VrefDqR0Nib4") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib4;
          else if ( strcmp(field, "VrefDqR0Nib5") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib5;
          else if ( strcmp(field, "VrefDqR0Nib6") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib6;
          else if ( strcmp(field, "VrefDqR0Nib7") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib7;
          else if ( strcmp(field, "VrefDqR0Nib8") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib8;
          else if ( strcmp(field, "VrefDqR0Nib9") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib9;
          else if ( strcmp(field, "VrefDqR0Nib10") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib10;
          else if ( strcmp(field, "VrefDqR0Nib11") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib11;
          else if ( strcmp(field, "VrefDqR0Nib12") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib12;
          else if ( strcmp(field, "VrefDqR0Nib13") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib13;
          else if ( strcmp(field, "VrefDqR0Nib14") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib14;
          else if ( strcmp(field, "VrefDqR0Nib15") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib15;
          else if ( strcmp(field, "VrefDqR0Nib16") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib16;
          else if ( strcmp(field, "VrefDqR0Nib17") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib17;
          else if ( strcmp(field, "VrefDqR0Nib18") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib18;
          else if ( strcmp(field, "VrefDqR0Nib19") == 0)
              return mb_DDR4R_1D[ps].VrefDqR0Nib19;
          else if ( strcmp(field, "VrefDqR1Nib0") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib0;
          else if ( strcmp(field, "VrefDqR1Nib1") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib1;
          else if ( strcmp(field, "VrefDqR1Nib2") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib2;
          else if ( strcmp(field, "VrefDqR1Nib3") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib3;
          else if ( strcmp(field, "VrefDqR1Nib4") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib4;
          else if ( strcmp(field, "VrefDqR1Nib5") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib5;
          else if ( strcmp(field, "VrefDqR1Nib6") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib6;
          else if ( strcmp(field, "VrefDqR1Nib7") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib7;
          else if ( strcmp(field, "VrefDqR1Nib8") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib8;
          else if ( strcmp(field, "VrefDqR1Nib9") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib9;
          else if ( strcmp(field, "VrefDqR1Nib10") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib10;
          else if ( strcmp(field, "VrefDqR1Nib11") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib11;
          else if ( strcmp(field, "VrefDqR1Nib12") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib12;
          else if ( strcmp(field, "VrefDqR1Nib13") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib13;
          else if ( strcmp(field, "VrefDqR1Nib14") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib14;
          else if ( strcmp(field, "VrefDqR1Nib15") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib15;
          else if ( strcmp(field, "VrefDqR1Nib16") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib16;
          else if ( strcmp(field, "VrefDqR1Nib17") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib17;
          else if ( strcmp(field, "VrefDqR1Nib18") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib18;
          else if ( strcmp(field, "VrefDqR1Nib19") == 0)
              return mb_DDR4R_1D[ps].VrefDqR1Nib19;
          else if ( strcmp(field, "VrefDqR2Nib0") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib0;
          else if ( strcmp(field, "VrefDqR2Nib1") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib1;
          else if ( strcmp(field, "VrefDqR2Nib2") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib2;
          else if ( strcmp(field, "VrefDqR2Nib3") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib3;
          else if ( strcmp(field, "VrefDqR2Nib4") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib4;
          else if ( strcmp(field, "VrefDqR2Nib5") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib5;
          else if ( strcmp(field, "VrefDqR2Nib6") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib6;
          else if ( strcmp(field, "VrefDqR2Nib7") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib7;
          else if ( strcmp(field, "VrefDqR2Nib8") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib8;
          else if ( strcmp(field, "VrefDqR2Nib9") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib9;
          else if ( strcmp(field, "VrefDqR2Nib10") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib10;
          else if ( strcmp(field, "VrefDqR2Nib11") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib11;
          else if ( strcmp(field, "VrefDqR2Nib12") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib12;
          else if ( strcmp(field, "VrefDqR2Nib13") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib13;
          else if ( strcmp(field, "VrefDqR2Nib14") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib14;
          else if ( strcmp(field, "VrefDqR2Nib15") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib15;
          else if ( strcmp(field, "VrefDqR2Nib16") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib16;
          else if ( strcmp(field, "VrefDqR2Nib17") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib17;
          else if ( strcmp(field, "VrefDqR2Nib18") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib18;
          else if ( strcmp(field, "VrefDqR2Nib19") == 0)
              return mb_DDR4R_1D[ps].VrefDqR2Nib19;
          else if ( strcmp(field, "VrefDqR3Nib0") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib0;
          else if ( strcmp(field, "VrefDqR3Nib1") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib1;
          else if ( strcmp(field, "VrefDqR3Nib2") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib2;
          else if ( strcmp(field, "VrefDqR3Nib3") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib3;
          else if ( strcmp(field, "VrefDqR3Nib4") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib4;
          else if ( strcmp(field, "VrefDqR3Nib5") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib5;
          else if ( strcmp(field, "VrefDqR3Nib6") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib6;
          else if ( strcmp(field, "VrefDqR3Nib7") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib7;
          else if ( strcmp(field, "VrefDqR3Nib8") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib8;
          else if ( strcmp(field, "VrefDqR3Nib9") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib9;
          else if ( strcmp(field, "VrefDqR3Nib10") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib10;
          else if ( strcmp(field, "VrefDqR3Nib11") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib11;
          else if ( strcmp(field, "VrefDqR3Nib12") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib12;
          else if ( strcmp(field, "VrefDqR3Nib13") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib13;
          else if ( strcmp(field, "VrefDqR3Nib14") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib14;
          else if ( strcmp(field, "VrefDqR3Nib15") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib15;
          else if ( strcmp(field, "VrefDqR3Nib16") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib16;
          else if ( strcmp(field, "VrefDqR3Nib17") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib17;
          else if ( strcmp(field, "VrefDqR3Nib18") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib18;
          else if ( strcmp(field, "VrefDqR3Nib19") == 0)
              return mb_DDR4R_1D[ps].VrefDqR3Nib19;
          else if ( strcmp(field, "F0RC00_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC00_D0;
          else if ( strcmp(field, "F0RC01_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC01_D0;
          else if ( strcmp(field, "F0RC02_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC02_D0;
          else if ( strcmp(field, "F0RC03_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC03_D0;
          else if ( strcmp(field, "F0RC04_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC04_D0;
          else if ( strcmp(field, "F0RC05_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC05_D0;
          else if ( strcmp(field, "F0RC06_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC06_D0;
          else if ( strcmp(field, "F0RC07_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC07_D0;
          else if ( strcmp(field, "F0RC08_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC08_D0;
          else if ( strcmp(field, "F0RC09_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC09_D0;
          else if ( strcmp(field, "F0RC0A_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0A_D0;
          else if ( strcmp(field, "F0RC0B_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0B_D0;
          else if ( strcmp(field, "F0RC0C_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0C_D0;
          else if ( strcmp(field, "F0RC0D_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0D_D0;
          else if ( strcmp(field, "F0RC0E_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0E_D0;
          else if ( strcmp(field, "F0RC0F_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC0F_D0;
          else if ( strcmp(field, "F0RC1x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC1x_D0;
          else if ( strcmp(field, "F0RC2x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC2x_D0;
          else if ( strcmp(field, "F0RC3x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC3x_D0;
          else if ( strcmp(field, "F0RC4x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC4x_D0;
          else if ( strcmp(field, "F0RC5x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC5x_D0;
          else if ( strcmp(field, "F0RC6x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC6x_D0;
          else if ( strcmp(field, "F0RC7x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC7x_D0;
          else if ( strcmp(field, "F0RC8x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC8x_D0;
          else if ( strcmp(field, "F0RC9x_D0") == 0)
              return mb_DDR4R_1D[ps].F0RC9x_D0;
          else if ( strcmp(field, "F0RCAx_D0") == 0)
              return mb_DDR4R_1D[ps].F0RCAx_D0;
          else if ( strcmp(field, "F0RCBx_D0") == 0)
              return mb_DDR4R_1D[ps].F0RCBx_D0;
          else if ( strcmp(field, "F1RC00_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC00_D0;
          else if ( strcmp(field, "F1RC01_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC01_D0;
          else if ( strcmp(field, "F1RC02_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC02_D0;
          else if ( strcmp(field, "F1RC03_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC03_D0;
          else if ( strcmp(field, "F1RC04_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC04_D0;
          else if ( strcmp(field, "F1RC05_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC05_D0;
          else if ( strcmp(field, "F1RC06_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC06_D0;
          else if ( strcmp(field, "F1RC07_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC07_D0;
          else if ( strcmp(field, "F1RC08_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC08_D0;
          else if ( strcmp(field, "F1RC09_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC09_D0;
          else if ( strcmp(field, "F1RC0A_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0A_D0;
          else if ( strcmp(field, "F1RC0B_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0B_D0;
          else if ( strcmp(field, "F1RC0C_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0C_D0;
          else if ( strcmp(field, "F1RC0D_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0D_D0;
          else if ( strcmp(field, "F1RC0E_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0E_D0;
          else if ( strcmp(field, "F1RC0F_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC0F_D0;
          else if ( strcmp(field, "F1RC1x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC1x_D0;
          else if ( strcmp(field, "F1RC2x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC2x_D0;
          else if ( strcmp(field, "F1RC3x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC3x_D0;
          else if ( strcmp(field, "F1RC4x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC4x_D0;
          else if ( strcmp(field, "F1RC5x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC5x_D0;
          else if ( strcmp(field, "F1RC6x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC6x_D0;
          else if ( strcmp(field, "F1RC7x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC7x_D0;
          else if ( strcmp(field, "F1RC8x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC8x_D0;
          else if ( strcmp(field, "F1RC9x_D0") == 0)
              return mb_DDR4R_1D[ps].F1RC9x_D0;
          else if ( strcmp(field, "F1RCAx_D0") == 0)
              return mb_DDR4R_1D[ps].F1RCAx_D0;
          else if ( strcmp(field, "F1RCBx_D0") == 0)
              return mb_DDR4R_1D[ps].F1RCBx_D0;
          else if ( strcmp(field, "F0RC00_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC00_D1;
          else if ( strcmp(field, "F0RC01_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC01_D1;
          else if ( strcmp(field, "F0RC02_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC02_D1;
          else if ( strcmp(field, "F0RC03_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC03_D1;
          else if ( strcmp(field, "F0RC04_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC04_D1;
          else if ( strcmp(field, "F0RC05_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC05_D1;
          else if ( strcmp(field, "F0RC06_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC06_D1;
          else if ( strcmp(field, "F0RC07_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC07_D1;
          else if ( strcmp(field, "F0RC08_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC08_D1;
          else if ( strcmp(field, "F0RC09_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC09_D1;
          else if ( strcmp(field, "F0RC0A_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0A_D1;
          else if ( strcmp(field, "F0RC0B_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0B_D1;
          else if ( strcmp(field, "F0RC0C_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0C_D1;
          else if ( strcmp(field, "F0RC0D_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0D_D1;
          else if ( strcmp(field, "F0RC0E_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0E_D1;
          else if ( strcmp(field, "F0RC0F_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC0F_D1;
          else if ( strcmp(field, "F0RC1x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC1x_D1;
          else if ( strcmp(field, "F0RC2x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC2x_D1;
          else if ( strcmp(field, "F0RC3x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC3x_D1;
          else if ( strcmp(field, "F0RC4x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC4x_D1;
          else if ( strcmp(field, "F0RC5x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC5x_D1;
          else if ( strcmp(field, "F0RC6x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC6x_D1;
          else if ( strcmp(field, "F0RC7x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC7x_D1;
          else if ( strcmp(field, "F0RC8x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC8x_D1;
          else if ( strcmp(field, "F0RC9x_D1") == 0)
              return mb_DDR4R_1D[ps].F0RC9x_D1;
          else if ( strcmp(field, "F0RCAx_D1") == 0)
              return mb_DDR4R_1D[ps].F0RCAx_D1;
          else if ( strcmp(field, "F0RCBx_D1") == 0)
              return mb_DDR4R_1D[ps].F0RCBx_D1;
          else if ( strcmp(field, "F1RC00_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC00_D1;
          else if ( strcmp(field, "F1RC01_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC01_D1;
          else if ( strcmp(field, "F1RC02_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC02_D1;
          else if ( strcmp(field, "F1RC03_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC03_D1;
          else if ( strcmp(field, "F1RC04_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC04_D1;
          else if ( strcmp(field, "F1RC05_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC05_D1;
          else if ( strcmp(field, "F1RC06_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC06_D1;
          else if ( strcmp(field, "F1RC07_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC07_D1;
          else if ( strcmp(field, "F1RC08_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC08_D1;
          else if ( strcmp(field, "F1RC09_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC09_D1;
          else if ( strcmp(field, "F1RC0A_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0A_D1;
          else if ( strcmp(field, "F1RC0B_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0B_D1;
          else if ( strcmp(field, "F1RC0C_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0C_D1;
          else if ( strcmp(field, "F1RC0D_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0D_D1;
          else if ( strcmp(field, "F1RC0E_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0E_D1;
          else if ( strcmp(field, "F1RC0F_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC0F_D1;
          else if ( strcmp(field, "F1RC1x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC1x_D1;
          else if ( strcmp(field, "F1RC2x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC2x_D1;
          else if ( strcmp(field, "F1RC3x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC3x_D1;
          else if ( strcmp(field, "F1RC4x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC4x_D1;
          else if ( strcmp(field, "F1RC5x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC5x_D1;
          else if ( strcmp(field, "F1RC6x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC6x_D1;
          else if ( strcmp(field, "F1RC7x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC7x_D1;
          else if ( strcmp(field, "F1RC8x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC8x_D1;
          else if ( strcmp(field, "F1RC9x_D1") == 0)
              return mb_DDR4R_1D[ps].F1RC9x_D1;
          else if ( strcmp(field, "F1RCAx_D1") == 0)
              return mb_DDR4R_1D[ps].F1RCAx_D1;
          else if ( strcmp(field, "F1RCBx_D1") == 0)
              return mb_DDR4R_1D[ps].F1RCBx_D1;
          else if ( strcmp(field, "ALT_CAS_L") == 0)
              return mb_DDR4R_1D[ps].ALT_CAS_L;
          else if ( strcmp(field, "ALT_WCAS_L") == 0)
              return mb_DDR4R_1D[ps].ALT_WCAS_L;
          else if ( strcmp(field, "D4Misc") == 0)
              return mb_DDR4R_1D[ps].D4Misc;
          else {
              dwc_ddrphy_phyinit_assert(0,"%s unknown messageBlock field name '%s', Train2D=%d\n", printf_header, field,Train2D);
              return -1;
          }
      }
      else if (Train2D == 1) {
              if ( strcmp(field, "Reserved00") == 0)
                return  mb_DDR4R_2D[ps].Reserved00;
              else if ( strcmp(field, "MsgMisc") == 0)
                return  mb_DDR4R_2D[ps].MsgMisc;
              else if ( strcmp(field, "Pstate") == 0)
                return  mb_DDR4R_2D[ps].Pstate;
              else if ( strcmp(field, "PllBypassEn") == 0)
                return  mb_DDR4R_2D[ps].PllBypassEn;
              else if ( strcmp(field, "DRAMFreq") == 0)
                return  mb_DDR4R_2D[ps].DRAMFreq;
              else if ( strcmp(field, "DfiFreqRatio") == 0)
                return  mb_DDR4R_2D[ps].DfiFreqRatio;
              else if ( strcmp(field, "BPZNResVal") == 0)
                return  mb_DDR4R_2D[ps].BPZNResVal;
              else if ( strcmp(field, "PhyOdtImpedance") == 0)
                return  mb_DDR4R_2D[ps].PhyOdtImpedance;
              else if ( strcmp(field, "PhyDrvImpedance") == 0)
                return  mb_DDR4R_2D[ps].PhyDrvImpedance;
              else if ( strcmp(field, "PhyVref") == 0)
                return  mb_DDR4R_2D[ps].PhyVref;
              else if ( strcmp(field, "DramType") == 0)
                return  mb_DDR4R_2D[ps].DramType;
              else if ( strcmp(field, "DisabledDbyte") == 0)
                return  mb_DDR4R_2D[ps].DisabledDbyte;
              else if ( strcmp(field, "EnabledDQs") == 0)
                return  mb_DDR4R_2D[ps].EnabledDQs;
              else if ( strcmp(field, "CsPresent") == 0)
                return  mb_DDR4R_2D[ps].CsPresent;
              else if ( strcmp(field, "CsPresentD0") == 0)
                return  mb_DDR4R_2D[ps].CsPresentD0;
              else if ( strcmp(field, "CsPresentD1") == 0)
                return  mb_DDR4R_2D[ps].CsPresentD1;
              else if ( strcmp(field, "AddrMirror") == 0)
                return  mb_DDR4R_2D[ps].AddrMirror;
              else if ( strcmp(field, "PhyCfg") == 0)
                return  mb_DDR4R_2D[ps].PhyCfg;
              else if ( strcmp(field, "SequenceCtrl") == 0)
                return  mb_DDR4R_2D[ps].SequenceCtrl;
              else if ( strcmp(field, "HdtCtrl") == 0)
                return  mb_DDR4R_2D[ps].HdtCtrl;
              else if ( strcmp(field, "RX2D_TrainOpt") == 0)
                return  mb_DDR4R_2D[ps].RX2D_TrainOpt;
              else if ( strcmp(field, "TX2D_TrainOpt") == 0)
                return  mb_DDR4R_2D[ps].TX2D_TrainOpt;
              else if ( strcmp(field, "Share2DVrefResult") == 0)
                return  mb_DDR4R_2D[ps].Share2DVrefResult;
              else if ( strcmp(field, "Delay_Weight2D") == 0)
                return  mb_DDR4R_2D[ps].Delay_Weight2D;
              else if ( strcmp(field, "Voltage_Weight2D") == 0)
                return  mb_DDR4R_2D[ps].Voltage_Weight2D;
              else if ( strcmp(field, "Reserved1E") == 0)
                return  mb_DDR4R_2D[ps].Reserved1E;
              else if ( strcmp(field, "Reserved1F") == 0)
                return  mb_DDR4R_2D[ps].Reserved1F;
              else if ( strcmp(field, "Reserved20") == 0)
                return  mb_DDR4R_2D[ps].Reserved20;
              else if ( strcmp(field, "Reserved21") == 0)
                return  mb_DDR4R_2D[ps].Reserved21;
              else if ( strcmp(field, "PhyConfigOverride") == 0)
                return  mb_DDR4R_2D[ps].PhyConfigOverride;
              else if ( strcmp(field, "DFIMRLMargin") == 0)
                return  mb_DDR4R_2D[ps].DFIMRLMargin;
              else if ( strcmp(field, "Reserved30") == 0)
                return  mb_DDR4R_2D[ps].Reserved30;
              else if ( strcmp(field, "Reserved31") == 0)
                return  mb_DDR4R_2D[ps].Reserved31;
              else if ( strcmp(field, "Reserved32") == 0)
                return  mb_DDR4R_2D[ps].Reserved32;
              else if ( strcmp(field, "Reserved53") == 0)
                return  mb_DDR4R_2D[ps].Reserved53;
              else if ( strcmp(field, "Reserved58") == 0)
                return  mb_DDR4R_2D[ps].Reserved58;
              else if ( strcmp(field, "Reserved5A") == 0)
                return  mb_DDR4R_2D[ps].Reserved5A;
              else if ( strcmp(field, "Reserved5B") == 0)
                return  mb_DDR4R_2D[ps].Reserved5B;
              else if ( strcmp(field, "Reserved5C") == 0)
                return  mb_DDR4R_2D[ps].Reserved5C;
              else if ( strcmp(field, "Reserved5D") == 0)
                return  mb_DDR4R_2D[ps].Reserved5D;
              else if ( strcmp(field, "MR0") == 0)
                return  mb_DDR4R_2D[ps].MR0;
              else if ( strcmp(field, "MR1") == 0)
                return  mb_DDR4R_2D[ps].MR1;
              else if ( strcmp(field, "MR2") == 0)
                return  mb_DDR4R_2D[ps].MR2;
              else if ( strcmp(field, "MR3") == 0)
                return  mb_DDR4R_2D[ps].MR3;
              else if ( strcmp(field, "MR4") == 0)
                return  mb_DDR4R_2D[ps].MR4;
              else if ( strcmp(field, "MR5") == 0)
                return  mb_DDR4R_2D[ps].MR5;
              else if ( strcmp(field, "MR6") == 0)
                return  mb_DDR4R_2D[ps].MR6;
              else if ( strcmp(field, "X16Present") == 0)
                return  mb_DDR4R_2D[ps].X16Present;
              else if ( strcmp(field, "CsSetupGDDec") == 0)
                return  mb_DDR4R_2D[ps].CsSetupGDDec;
              else if ( strcmp(field, "RTT_NOM_WR_PARK0") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK0;
              else if ( strcmp(field, "RTT_NOM_WR_PARK1") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK1;
              else if ( strcmp(field, "RTT_NOM_WR_PARK2") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK2;
              else if ( strcmp(field, "RTT_NOM_WR_PARK3") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK3;
              else if ( strcmp(field, "RTT_NOM_WR_PARK4") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK4;
              else if ( strcmp(field, "RTT_NOM_WR_PARK5") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK5;
              else if ( strcmp(field, "RTT_NOM_WR_PARK6") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK6;
              else if ( strcmp(field, "RTT_NOM_WR_PARK7") == 0)
                return  mb_DDR4R_2D[ps].RTT_NOM_WR_PARK7;
              else if ( strcmp(field, "AcsmOdtCtrl0") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl0;
              else if ( strcmp(field, "AcsmOdtCtrl1") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl1;
              else if ( strcmp(field, "AcsmOdtCtrl2") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl2;
              else if ( strcmp(field, "AcsmOdtCtrl3") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl3;
              else if ( strcmp(field, "AcsmOdtCtrl4") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl4;
              else if ( strcmp(field, "AcsmOdtCtrl5") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl5;
              else if ( strcmp(field, "AcsmOdtCtrl6") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl6;
              else if ( strcmp(field, "AcsmOdtCtrl7") == 0)
                return  mb_DDR4R_2D[ps].AcsmOdtCtrl7;
              else if ( strcmp(field, "VrefDqR0Nib0") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib0;
              else if ( strcmp(field, "VrefDqR0Nib1") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib1;
              else if ( strcmp(field, "VrefDqR0Nib2") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib2;
              else if ( strcmp(field, "VrefDqR0Nib3") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib3;
              else if ( strcmp(field, "VrefDqR0Nib4") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib4;
              else if ( strcmp(field, "VrefDqR0Nib5") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib5;
              else if ( strcmp(field, "VrefDqR0Nib6") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib6;
              else if ( strcmp(field, "VrefDqR0Nib7") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib7;
              else if ( strcmp(field, "VrefDqR0Nib8") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib8;
              else if ( strcmp(field, "VrefDqR0Nib9") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib9;
              else if ( strcmp(field, "VrefDqR0Nib10") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib10;
              else if ( strcmp(field, "VrefDqR0Nib11") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib11;
              else if ( strcmp(field, "VrefDqR0Nib12") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib12;
              else if ( strcmp(field, "VrefDqR0Nib13") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib13;
              else if ( strcmp(field, "VrefDqR0Nib14") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib14;
              else if ( strcmp(field, "VrefDqR0Nib15") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib15;
              else if ( strcmp(field, "VrefDqR0Nib16") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib16;
              else if ( strcmp(field, "VrefDqR0Nib17") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib17;
              else if ( strcmp(field, "VrefDqR0Nib18") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib18;
              else if ( strcmp(field, "VrefDqR0Nib19") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR0Nib19;
              else if ( strcmp(field, "VrefDqR1Nib0") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib0;
              else if ( strcmp(field, "VrefDqR1Nib1") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib1;
              else if ( strcmp(field, "VrefDqR1Nib2") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib2;
              else if ( strcmp(field, "VrefDqR1Nib3") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib3;
              else if ( strcmp(field, "VrefDqR1Nib4") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib4;
              else if ( strcmp(field, "VrefDqR1Nib5") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib5;
              else if ( strcmp(field, "VrefDqR1Nib6") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib6;
              else if ( strcmp(field, "VrefDqR1Nib7") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib7;
              else if ( strcmp(field, "VrefDqR1Nib8") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib8;
              else if ( strcmp(field, "VrefDqR1Nib9") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib9;
              else if ( strcmp(field, "VrefDqR1Nib10") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib10;
              else if ( strcmp(field, "VrefDqR1Nib11") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib11;
              else if ( strcmp(field, "VrefDqR1Nib12") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib12;
              else if ( strcmp(field, "VrefDqR1Nib13") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib13;
              else if ( strcmp(field, "VrefDqR1Nib14") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib14;
              else if ( strcmp(field, "VrefDqR1Nib15") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib15;
              else if ( strcmp(field, "VrefDqR1Nib16") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib16;
              else if ( strcmp(field, "VrefDqR1Nib17") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib17;
              else if ( strcmp(field, "VrefDqR1Nib18") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib18;
              else if ( strcmp(field, "VrefDqR1Nib19") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR1Nib19;
              else if ( strcmp(field, "VrefDqR2Nib0") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib0;
              else if ( strcmp(field, "VrefDqR2Nib1") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib1;
              else if ( strcmp(field, "VrefDqR2Nib2") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib2;
              else if ( strcmp(field, "VrefDqR2Nib3") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib3;
              else if ( strcmp(field, "VrefDqR2Nib4") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib4;
              else if ( strcmp(field, "VrefDqR2Nib5") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib5;
              else if ( strcmp(field, "VrefDqR2Nib6") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib6;
              else if ( strcmp(field, "VrefDqR2Nib7") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib7;
              else if ( strcmp(field, "VrefDqR2Nib8") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib8;
              else if ( strcmp(field, "VrefDqR2Nib9") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib9;
              else if ( strcmp(field, "VrefDqR2Nib10") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib10;
              else if ( strcmp(field, "VrefDqR2Nib11") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib11;
              else if ( strcmp(field, "VrefDqR2Nib12") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib12;
              else if ( strcmp(field, "VrefDqR2Nib13") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib13;
              else if ( strcmp(field, "VrefDqR2Nib14") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib14;
              else if ( strcmp(field, "VrefDqR2Nib15") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib15;
              else if ( strcmp(field, "VrefDqR2Nib16") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib16;
              else if ( strcmp(field, "VrefDqR2Nib17") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib17;
              else if ( strcmp(field, "VrefDqR2Nib18") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib18;
              else if ( strcmp(field, "VrefDqR2Nib19") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR2Nib19;
              else if ( strcmp(field, "VrefDqR3Nib0") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib0;
              else if ( strcmp(field, "VrefDqR3Nib1") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib1;
              else if ( strcmp(field, "VrefDqR3Nib2") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib2;
              else if ( strcmp(field, "VrefDqR3Nib3") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib3;
              else if ( strcmp(field, "VrefDqR3Nib4") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib4;
              else if ( strcmp(field, "VrefDqR3Nib5") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib5;
              else if ( strcmp(field, "VrefDqR3Nib6") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib6;
              else if ( strcmp(field, "VrefDqR3Nib7") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib7;
              else if ( strcmp(field, "VrefDqR3Nib8") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib8;
              else if ( strcmp(field, "VrefDqR3Nib9") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib9;
              else if ( strcmp(field, "VrefDqR3Nib10") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib10;
              else if ( strcmp(field, "VrefDqR3Nib11") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib11;
              else if ( strcmp(field, "VrefDqR3Nib12") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib12;
              else if ( strcmp(field, "VrefDqR3Nib13") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib13;
              else if ( strcmp(field, "VrefDqR3Nib14") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib14;
              else if ( strcmp(field, "VrefDqR3Nib15") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib15;
              else if ( strcmp(field, "VrefDqR3Nib16") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib16;
              else if ( strcmp(field, "VrefDqR3Nib17") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib17;
              else if ( strcmp(field, "VrefDqR3Nib18") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib18;
              else if ( strcmp(field, "VrefDqR3Nib19") == 0)
                return  mb_DDR4R_2D[ps].VrefDqR3Nib19;
              else if ( strcmp(field, "F0RC00_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC00_D0;
              else if ( strcmp(field, "F0RC01_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC01_D0;
              else if ( strcmp(field, "F0RC02_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC02_D0;
              else if ( strcmp(field, "F0RC03_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC03_D0;
              else if ( strcmp(field, "F0RC04_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC04_D0;
              else if ( strcmp(field, "F0RC05_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC05_D0;
              else if ( strcmp(field, "F0RC06_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC06_D0;
              else if ( strcmp(field, "F0RC07_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC07_D0;
              else if ( strcmp(field, "F0RC08_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC08_D0;
              else if ( strcmp(field, "F0RC09_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC09_D0;
              else if ( strcmp(field, "F0RC0A_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0A_D0;
              else if ( strcmp(field, "F0RC0B_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0B_D0;
              else if ( strcmp(field, "F0RC0C_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0C_D0;
              else if ( strcmp(field, "F0RC0D_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0D_D0;
              else if ( strcmp(field, "F0RC0E_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0E_D0;
              else if ( strcmp(field, "F0RC0F_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC0F_D0;
              else if ( strcmp(field, "F0RC1x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC1x_D0;
              else if ( strcmp(field, "F0RC2x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC2x_D0;
              else if ( strcmp(field, "F0RC3x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC3x_D0;
              else if ( strcmp(field, "F0RC4x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC4x_D0;
              else if ( strcmp(field, "F0RC5x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC5x_D0;
              else if ( strcmp(field, "F0RC6x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC6x_D0;
              else if ( strcmp(field, "F0RC7x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC7x_D0;
              else if ( strcmp(field, "F0RC8x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC8x_D0;
              else if ( strcmp(field, "F0RC9x_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RC9x_D0;
              else if ( strcmp(field, "F0RCAx_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RCAx_D0;
              else if ( strcmp(field, "F0RCBx_D0") == 0)
                return  mb_DDR4R_2D[ps].F0RCBx_D0;
              else if ( strcmp(field, "F1RC00_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC00_D0;
              else if ( strcmp(field, "F1RC01_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC01_D0;
              else if ( strcmp(field, "F1RC02_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC02_D0;
              else if ( strcmp(field, "F1RC03_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC03_D0;
              else if ( strcmp(field, "F1RC04_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC04_D0;
              else if ( strcmp(field, "F1RC05_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC05_D0;
              else if ( strcmp(field, "F1RC06_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC06_D0;
              else if ( strcmp(field, "F1RC07_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC07_D0;
              else if ( strcmp(field, "F1RC08_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC08_D0;
              else if ( strcmp(field, "F1RC09_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC09_D0;
              else if ( strcmp(field, "F1RC0A_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0A_D0;
              else if ( strcmp(field, "F1RC0B_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0B_D0;
              else if ( strcmp(field, "F1RC0C_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0C_D0;
              else if ( strcmp(field, "F1RC0D_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0D_D0;
              else if ( strcmp(field, "F1RC0E_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0E_D0;
              else if ( strcmp(field, "F1RC0F_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC0F_D0;
              else if ( strcmp(field, "F1RC1x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC1x_D0;
              else if ( strcmp(field, "F1RC2x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC2x_D0;
              else if ( strcmp(field, "F1RC3x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC3x_D0;
              else if ( strcmp(field, "F1RC4x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC4x_D0;
              else if ( strcmp(field, "F1RC5x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC5x_D0;
              else if ( strcmp(field, "F1RC6x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC6x_D0;
              else if ( strcmp(field, "F1RC7x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC7x_D0;
              else if ( strcmp(field, "F1RC8x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC8x_D0;
              else if ( strcmp(field, "F1RC9x_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RC9x_D0;
              else if ( strcmp(field, "F1RCAx_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RCAx_D0;
              else if ( strcmp(field, "F1RCBx_D0") == 0)
                return  mb_DDR4R_2D[ps].F1RCBx_D0;
              else if ( strcmp(field, "F0RC00_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC00_D1;
              else if ( strcmp(field, "F0RC01_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC01_D1;
              else if ( strcmp(field, "F0RC02_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC02_D1;
              else if ( strcmp(field, "F0RC03_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC03_D1;
              else if ( strcmp(field, "F0RC04_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC04_D1;
              else if ( strcmp(field, "F0RC05_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC05_D1;
              else if ( strcmp(field, "F0RC06_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC06_D1;
              else if ( strcmp(field, "F0RC07_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC07_D1;
              else if ( strcmp(field, "F0RC08_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC08_D1;
              else if ( strcmp(field, "F0RC09_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC09_D1;
              else if ( strcmp(field, "F0RC0A_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0A_D1;
              else if ( strcmp(field, "F0RC0B_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0B_D1;
              else if ( strcmp(field, "F0RC0C_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0C_D1;
              else if ( strcmp(field, "F0RC0D_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0D_D1;
              else if ( strcmp(field, "F0RC0E_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0E_D1;
              else if ( strcmp(field, "F0RC0F_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC0F_D1;
              else if ( strcmp(field, "F0RC1x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC1x_D1;
              else if ( strcmp(field, "F0RC2x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC2x_D1;
              else if ( strcmp(field, "F0RC3x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC3x_D1;
              else if ( strcmp(field, "F0RC4x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC4x_D1;
              else if ( strcmp(field, "F0RC5x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC5x_D1;
              else if ( strcmp(field, "F0RC6x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC6x_D1;
              else if ( strcmp(field, "F0RC7x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC7x_D1;
              else if ( strcmp(field, "F0RC8x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC8x_D1;
              else if ( strcmp(field, "F0RC9x_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RC9x_D1;
              else if ( strcmp(field, "F0RCAx_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RCAx_D1;
              else if ( strcmp(field, "F0RCBx_D1") == 0)
                return  mb_DDR4R_2D[ps].F0RCBx_D1;
              else if ( strcmp(field, "F1RC00_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC00_D1;
              else if ( strcmp(field, "F1RC01_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC01_D1;
              else if ( strcmp(field, "F1RC02_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC02_D1;
              else if ( strcmp(field, "F1RC03_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC03_D1;
              else if ( strcmp(field, "F1RC04_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC04_D1;
              else if ( strcmp(field, "F1RC05_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC05_D1;
              else if ( strcmp(field, "F1RC06_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC06_D1;
              else if ( strcmp(field, "F1RC07_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC07_D1;
              else if ( strcmp(field, "F1RC08_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC08_D1;
              else if ( strcmp(field, "F1RC09_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC09_D1;
              else if ( strcmp(field, "F1RC0A_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0A_D1;
              else if ( strcmp(field, "F1RC0B_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0B_D1;
              else if ( strcmp(field, "F1RC0C_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0C_D1;
              else if ( strcmp(field, "F1RC0D_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0D_D1;
              else if ( strcmp(field, "F1RC0E_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0E_D1;
              else if ( strcmp(field, "F1RC0F_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC0F_D1;
              else if ( strcmp(field, "F1RC1x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC1x_D1;
              else if ( strcmp(field, "F1RC2x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC2x_D1;
              else if ( strcmp(field, "F1RC3x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC3x_D1;
              else if ( strcmp(field, "F1RC4x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC4x_D1;
              else if ( strcmp(field, "F1RC5x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC5x_D1;
              else if ( strcmp(field, "F1RC6x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC6x_D1;
              else if ( strcmp(field, "F1RC7x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC7x_D1;
              else if ( strcmp(field, "F1RC8x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC8x_D1;
              else if ( strcmp(field, "F1RC9x_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RC9x_D1;
              else if ( strcmp(field, "F1RCAx_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RCAx_D1;
              else if ( strcmp(field, "F1RCBx_D1") == 0)
                return  mb_DDR4R_2D[ps].F1RCBx_D1;
              else if ( strcmp(field, "ALT_CAS_L") == 0)
                return  mb_DDR4R_2D[ps].ALT_CAS_L;
              else if ( strcmp(field, "ALT_WCAS_L") == 0)
                return  mb_DDR4R_2D[ps].ALT_WCAS_L;
              else if ( strcmp(field, "D4Misc") == 0)
                return  mb_DDR4R_2D[ps].D4Misc;
      }
      else {
          dwc_ddrphy_phyinit_assert(0,"%s invalid value for Train2D=%d\n", printf_header, Train2D);
          return -3;
      }

      return 0;
}
/** @} */
