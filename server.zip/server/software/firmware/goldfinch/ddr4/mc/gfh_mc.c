/* SPDX-License-Identifier: Apache-2.0 */
#include <stdio.h>
#include "common.h"

void __attribute__((optimize("O0"))) wait(int cnt)
{
	while(cnt != 0)
		cnt--;
}
	
void gfh_mc_init() 
{
	uint32_t val0;
	uint32_t cnt= 0;

	writel(0x26000ff0, 0x494e4348);
	writel(0x26000ff4, 0x4f4c4446);
	writel(0x26000ff8, 0x20202047);
	writel(0x26000ffc, 0x464c4354);
	val0 = readl(0x26000ff0);
	val0 = readl(0x26000ff4);
	val0 = readl(0x26000ff8);
	val0 = readl(0x26000ffc);

	//D2d Initialization Starts

	writel(0x27009004, 0x49);
	wait(50);
	writel(0x27008004, 0x89);
	wait(50);
	writel(0x27008004, 0x8);
	wait(50);
	writel(0x27009004, 0xa);
	wait(50);
	writel(0x27008004, 0xb);
	wait(50);

	// Polling status register
	do{
		val0 =readl(0x27009004);
		cnt = cnt +1;
		if(cnt>100){
			//  exit(1);
			//set_gpio(18);
		}
	} while((val0 & 0x3) != 0x3 ); 
#if 0
	if (cnt > 100) {
		printf("D2D INIT Timeout");
		//exit(1);
		set_gpio(18);
	}
#endif

	(*(volatile unsigned long int *)(0x27009800)) = 0x0;
	(*(volatile unsigned long int *)(0x27008800)) = 0x0;

	writel(0x27009800, 0x0);
	writel(0x27008800, 0x0);

	(*(volatile unsigned long int *)(0x21000640)) = 0x100c ; //cs-2, 4GB
	(*(volatile unsigned long int *)(0x21000644)) = 0x0 ;
	(*(volatile unsigned long int *)(0x2100065c)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000660)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000664)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000670)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000648)) = 0x11073 ;
	(*(volatile unsigned long int *)(0x2100064c)) = 0x11083 ;
	(*(volatile unsigned long int *)(0x21000650)) = 0x40f ;
	(*(volatile unsigned long int *)(0x21000654)) = 0x1c6 ;
	(*(volatile unsigned long int *)(0x21000658)) = 0x1f ;
	(*(volatile unsigned long int *)(0x21000180)) = 0x11140 ;
	(*(volatile unsigned long int *)(0x21000100)) = 0x1 ;
	(*(volatile unsigned long int *)(0x21000184)) = 0x1f94 ;
	(*(volatile unsigned long int *)(0x21000080)) = 0x7bdeffff ;
	(*(volatile unsigned long int *)(0x21000008)) = 0x0 ;
	(*(volatile unsigned long int *)(0x2100019c)) = 0x2 ;
	(*(volatile unsigned long int *)(0x21000008)) = 0x1 ;
	(*(volatile unsigned long int *)(0x2100019c)) = 0x2 ;
	(*(volatile unsigned long int *)(0x21000008)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000188)) = 0x1018180 ;
	(*(volatile unsigned long int *)(0x2100018c)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000190)) = 0x0 ;
	(*(volatile unsigned long int *)(0x210001c0)) = 0x600006 ;
	(*(volatile unsigned long int *)(0x210001c4)) = 0x80000 ;
	(*(volatile unsigned long int *)(0x21000340)) = 0x64000140 ;
	(*(volatile unsigned long int *)(0x21000344)) = 0x28010 ;
	(*(volatile unsigned long int *)(0x21000348)) = 0x11000 ;
	(*(volatile unsigned long int *)(0x2100034c)) = 0x40020080 ;
	(*(volatile unsigned long int *)(0x21000354)) = 0x180800 ;
	(*(volatile unsigned long int *)(0x2100035c)) = 0x4c183422 ;
	(*(volatile unsigned long int *)(0x21000360)) = 0xc180c08 ;
	(*(volatile unsigned long int *)(0x21000364)) = 0x181808 ;
	(*(volatile unsigned long int *)(0x21000368)) = 0x4404 ;
	(*(volatile unsigned long int *)(0x21000388)) = 0xc00100 ;
	(*(volatile unsigned long int *)(0x21000398)) = 0x40009110 ;
	(*(volatile unsigned long int *)(0x210003a0)) = 0x1008280a ;
	(*(volatile unsigned long int *)(0x210003b8)) = 0x0 ;
	(*(volatile unsigned long int *)(0x210003c4)) = 0x0 ;
	(*(volatile unsigned long int *)(0x210003c8)) = 0x1011404 ;
	(*(volatile unsigned long int *)(0x210003d0)) = 0x70008 ;
	(*(volatile unsigned long int *)(0x210003d4)) = 0x0 ;
	(*(volatile unsigned long int *)(0x210003d8)) = 0x101;
	(*(volatile unsigned long int *)(0x210003dc)) = 0xa0 ;
	(*(volatile unsigned long int *)(0x210003e0)) = 0x5020 ;
	(*(volatile unsigned long int *)(0x210003e4)) = 0x181c ;
	(*(volatile unsigned long int *)(0x21000008)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000500)) = 0x0 ;
	(*(volatile unsigned long int *)(0x21000504)) = 0x4000 ;
	(*(volatile unsigned long int *)(0x2100050c)) = 0x60b00000 ;
	(*(volatile unsigned long int *)(0x21000510)) = 0x400 ;
	(*(volatile unsigned long int *)(0x2100057c)) = 0x34102010 ;
	(*(volatile unsigned long int *)(0x21000580)) = 0x60806 ;
	(*(volatile unsigned long int *)(0x21000584)) = 0x501f40 ;
	(*(volatile unsigned long int *)(0x21000008)) = 0x0 ;
	(*(volatile unsigned long int *)(0x2100030c)) = 0x20b0b ;
	(*(volatile unsigned long int *)(0x21000310)) = 0x1313 ;
	(*(volatile unsigned long int *)(0x21000314)) = 0xffff0003 ;
	//(*(volatile unsigned long int *)(0x21000324)) = 0x45914259 ;
	(*(volatile unsigned long int *)(0x21000040)) = 0x43 ;
	(*(volatile unsigned long int *)(0x21000050)) = 0x4017 ;
	(*(volatile unsigned long int *)(0x21000054)) = 0x5143 ;
	(*(volatile unsigned long int *)(0x2100025c)) = 0x1 ;
}

void gfh_mc_post_init()
{
	uint32_t val0;
	uint32_t cnt= 0;

	(*(volatile unsigned long int*)(0x21000304)) = 0x10000001;
	(*(volatile unsigned long int*)(0x21000008)) = 0x0;

	do{
		val0 = readl(0x2100032c);
		cnt = cnt+1;
	} while(val0 != 0x1) ; 

#if 0
	if (cnt > 100) {
		printf("DFI PHY INIT Timeout");
		set_gpio(18);
	}
#endif
	cnt = 0;
	(*(volatile unsigned long int*)(0x21000008)) = 0x0000000000000000;
	(*(volatile unsigned long int*)(0x21000268)) = 0x303;

	// Polling status register
	do{
		val0 =readl(0x21000280);
	} while(val0 != 0x33 ); 
	cnt = 0;

	// extended
	(*(volatile unsigned long int*)(0x21000008)) = 0x0000000000000000;
	(*(volatile unsigned long int*)(0x210001a4)) = 0x00240000;
	do{
		val0 =readl(0x21000280);	
	} while(val0 != 0x33 ); 

	(*(volatile unsigned long int*)(0x210001a4)) = 0x10200000;
	(*(volatile unsigned long int*)(0x21000008)) = 0x0000000000000001;

	do{
		val0 =readl(0x21000280);	
	} while(val0 != 0x11 ); 	
	(*(volatile unsigned long int*)(0x21000588)) = 0x0000000000001008;
}
