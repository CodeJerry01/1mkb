#include <stdio.h>

extern void spd_i2c_read(void);
extern void ddr_phy_init(void);
extern void gfh_mc_init(void);
extern void gfh_mc_post_init(void);

void main()
{
	spd_i2c_read();

	gfh_mc_init();

	ddr_phy_init();

	gfh_mc_post_init();

	while(1);
}

