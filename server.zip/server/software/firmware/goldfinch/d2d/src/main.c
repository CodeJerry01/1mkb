#include <stdio.h>
#include <stdint.h>
#include <metal/gpio.h>
#include <metal/interrupt.h>
#include <metal/drivers/riscv_cpu.h>
#include "i3c.h"
#if 0
#include "d2d.h"

blynx_bow_t d2d;
D2dLLRegBlock d2dLL;
#endif

int32_t main(void) {
    uint8_t err;
    debug_gpio_set(0x7);
    
	err = i3c_slave_init();
    if (err !=0){
        //printf("ERROR: I3C Slave init failed - %d\n", err);
        return -1;
    }
    
    i3c_slave_send_fw_dnld_resp();

#if 0 //will enable along with D2D code
	d2d_mode_init();

    while (i3c_slave_get_d2d_status() != 0x1);
    i3c_slave_send_d2d_resp(i3c_slave_get_d2d_status());
    d2d_set_rx_mode_train();
    d2d_mode_train();
    d2d_skew_correction();

    while (i3c_slave_get_d2d_status() != 0x2); //need to remove
    i3c_slave_send_d2d_resp(i3c_slave_get_d2d_status());
    d2d_set_tx_mode_idle();
    d2d_poll_rx_for_tx_idle_mode();
    d2d_set_rx_mode_wait();

    while (i3c_slave_get_d2d_status() != 0x3);
    i3c_slave_send_d2d_resp(i3c_slave_get_d2d_status());
    d2d_set_tx_mode_run();
    d2d_poll_rx_mode_run();
	//printf("%s\n", __func__);
#endif

	while(1){
		__asm__ volatile ("wfi");
	}
return 0;
}
