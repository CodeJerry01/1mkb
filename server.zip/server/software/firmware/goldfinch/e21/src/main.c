/* Copyright 2019 SiFive, Inc */
/* SPDX-License-Identifier: Apache-2.0 */

#include <stdint.h>

int32_t main() 
{
	//Jump execution to TIM1
    //Using this firmware to validate fw copy over I3C
	void (*jump_to_TIM_address)(void) = (void (*)())0x80020000;
	jump_to_TIM_address();

	return 0;
}
