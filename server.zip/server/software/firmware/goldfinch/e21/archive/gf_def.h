/* -------------------------------------------------------------------------------
 *
 * Copyright(C) 2022 FLC Technology Group Inc.
 * All Rights Reserved
 * Added by Jasper Chen <jiechen@flctechgroup.com>
 *  -------------------------------------------------------------------------------
*/

#ifndef __GF_DEF_H
#define __GF_DEF_H

#define KEY_START				0x30020000

/* Global definitions */
#define DDR_MC_COUNT			1

/* MC definitions */
#define DDR4_DEFAULT_NUM		1

#define DDR4_CH_NUM				1
#define DDR4_CS_NUM				1

#define DDR_PHY_BASE_REMAP	0x26000008

#define DDR4_MC_BASE_ADDR		0x21000000
#define DDR4_PHY_BASE_ADDR		0x21100000

#define MC_REG_RANGE			0x00040000		
#define PHY_REG_RANGE			0x01000000

#define PHY_REG_WIDTH			4
#define PHY_REG_CH_OFFSET		0x00080000

/* HOST CMD definitions */
/* For Goldfinch, there is no command interface so far. */
#define CMD_ADDR				0x60000000
#define RSP_ADDR				0x60001000
#define UC_REMAP_ADDR			0x60000000

#define CMD_TYPE_OFFSET			0x0
#define CMD_ID_OFFSET			0x4
#define CMD_ADDR_OFFSET			0x8
#define CMD_LEN_OFFSET			0x10
#define CMD_PAYLOAD_OFFSET		0x20
#define CMD_PAYLOAD2_OFFSET		0x28
#define RSP_ID_OFFSET			0x4
#define RSP_DATA_OFFSET   0x10

#define CMD_PENDING			0x5555
#define CMD_PASS				0x1111
#define CMD_FAIL				0xffff

/* Interconnect definitions */

#define readc(a)      (*(volatile unsigned char *)(a))
#define writec(v, a)  (*(volatile unsigned char *)(a)) = (unsigned char)(v)
#define reads(a)      (*(volatile unsigned short *)(a))
#define writes(v, a)  (*(volatile unsigned short *)(a)) = (unsigned short)(v)
#define readl(a)      (*(volatile unsigned int *)(a))
#define writel(v, a)  (*(volatile unsigned int *)(a)) = (unsigned int)(v)
#define readw(a)      (*(volatile unsigned long long *)(a))
#define writew(v, a)  (*(volatile unsigned long long *)(a)) = (unsigned long long)(v)

#endif /* __GF_DEF_H */

