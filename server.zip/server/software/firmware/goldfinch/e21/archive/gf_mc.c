/* -------------------------------------------------------------------------------
 *
 * Copyright(C) 2022 FLC Technology Group Inc.
 * All Rights Reserved
 * Added by Jasper Chen <jiechen@flctechgroup.com>
 *  -------------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <metal/compiler.h>
#include "gf_mc.h"
#include "gf_uc.h"
#include "gf_def.h"

#define VCS_ENV					0
#define MENTOR_SIM				0
#define PHY_INIT				0

static int ddr4McNum = DDR4_DEFAULT_NUM;
extern char * buf;

static inline void gf_write_ddr4_phy_reg(int idx, int offset, int val)
{
	uint32_t addr;
	int rVal;

	addr = DDR4_PHY_BASE_ADDR + offset * PHY_REG_WIDTH;
#if PHY_REG_WIDTH == 2
	writes(val, addr);
#elif PHY_REG_WIDTH == 4
	writes(val, addr);
#else
	writec(val, addr);
#endif

	return;
}

static void gf_ddr4_phy_cfg(int idx)
{
	int i;

	gf_write_ddr4_phy_reg(idx, 0xb01, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x5, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4005, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x405, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4405, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x43, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4043, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x443, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4443, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x6, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4006, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x406, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4406, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x7, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4007, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x407, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4407, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x8, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4008, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x408, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4408, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x9, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4009, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x409, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4409, 0x4);
	gf_write_ddr4_phy_reg(idx, 0xa, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x400a, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x40a, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x440a, 0x4);

#if VCS_ENV == 1
	gf_write_ddr4_phy_reg(idx, 0x42, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4042, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x442, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4442, 0x0);
#else
	gf_write_ddr4_phy_reg(idx, 0x42, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4042, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x442, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4442, 0x1);
#endif

	gf_write_ddr4_phy_reg(idx, 0x41, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4041, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x441, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x4441, 0x4);
	gf_write_ddr4_phy_reg(idx, 0x1, 0x3);
	gf_write_ddr4_phy_reg(idx, 0x4001, 0x3);
	gf_write_ddr4_phy_reg(idx, 0x401, 0x3);
	gf_write_ddr4_phy_reg(idx, 0x4401, 0x3);

#if VCS_ENV == 1
	gf_write_ddr4_phy_reg(idx, 0x58, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4058, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x458, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4458, 0x1);
#else
	gf_write_ddr4_phy_reg(idx, 0x58, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4058, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x458, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4458, 0x0);
#endif

	gf_write_ddr4_phy_reg(idx, 0x3, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4003, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x403, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4403, 0x1);
	//gf_write_ddr4_phy_reg(idx, 0x0, 0x1);
	//gf_write_ddr4_phy_reg(idx, 0x4000, 0x1);
	//gf_write_ddr4_phy_reg(idx, 0x400, 0x1);
	//gf_write_ddr4_phy_reg(idx, 0x4400, 0x1);
#if VCS_ENV == 1
	gf_write_ddr4_phy_reg(idx, 0x0, 0x2);
	gf_write_ddr4_phy_reg(idx, 0x4000, 0x2);
	gf_write_ddr4_phy_reg(idx, 0x400, 0x2);
	gf_write_ddr4_phy_reg(idx, 0x4400, 0x2);
#elif MENTOR_SIM == 1
	gf_write_ddr4_phy_reg(idx, 0x0, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4000, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x400, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4400, 0x1);
#else
	gf_write_ddr4_phy_reg(idx, 0x0, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4000, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x400, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4400, 0x0);
#endif

	//gf_write_ddr4_phy_reg(idx, 0x40, 0x10);
	//gf_write_ddr4_phy_reg(idx, 0x4040, 0x10);
	//gf_write_ddr4_phy_reg(idx, 0x440, 0x10);
	//gf_write_ddr4_phy_reg(idx, 0x4440, 0x10);
	gf_write_ddr4_phy_reg(idx, 0x40, 0x20);
	gf_write_ddr4_phy_reg(idx, 0x4040, 0x20);
	gf_write_ddr4_phy_reg(idx, 0x440, 0x20);
	gf_write_ddr4_phy_reg(idx, 0x4440, 0x20);

	//gf_write_ddr4_phy_reg(idx, 0x2, 0x0);
	//gf_write_ddr4_phy_reg(idx, 0x4002, 0x0);
	//gf_write_ddr4_phy_reg(idx, 0x402, 0x0);
	//gf_write_ddr4_phy_reg(idx, 0x4402, 0x0);
#if VCS_ENV == 1
	gf_write_ddr4_phy_reg(idx, 0x2, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4002, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x402, 0x1);
	gf_write_ddr4_phy_reg(idx, 0x4402, 0x1);
#elif MENTOR_SIM == 1
	gf_write_ddr4_phy_reg(idx, 0x2, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4002, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x402, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4402, 0x0);
#else
	gf_write_ddr4_phy_reg(idx, 0x2, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4002, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x402, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x4402, 0x0);
#endif

	gf_write_ddr4_phy_reg(idx, 0xb00, 0x5);
	gf_write_ddr4_phy_reg(idx, 0x801, 0x1);

#if VCS_ENV == 0
	gf_write_ddr4_phy_reg(idx, 0x800F, 0x0);
	gf_write_ddr4_phy_reg(idx, 0x840F, 0x0);

	gf_write_ddr4_phy_reg(idx, 0x8018, 0x0);
#endif

	gf_write_ddr4_phy_reg(idx, 0x68, 0x1ff);
	gf_write_ddr4_phy_reg(idx, 0x4068, 0x1ff);
	gf_write_ddr4_phy_reg(idx, 0x68, 0xf);
	gf_write_ddr4_phy_reg(idx, 0x4068, 0xf);

	return;
}

static void gf_wait_mrw(int ch, uint32_t base)
{
	int j, val;

	for (j = 1; j < 200; j++) {
		val = readl(base + CH_MC_STATUS);
		if ((val & 0x00800000) == 0x0) {
			break;
		}
	}
	if (j == 200) {
		sprintf(buf, "Error: wait CH%d PEND MRW timeout\n", ch);
		write(STDOUT_FILENO, buf, strlen(buf));
	}

	return;
}

static void gf_ddr_mc_cfg(int idx)
{
	uint32_t i, j, val, mask = 0;
	uint32_t base = DDR4_MC_BASE_ADDR;

	writel(0x0, base + PAGED_REG_SEL);
	writel(0x01000, base + CH_DFI_PHY_CNTL0);

#if VCS_ENV == 1
	writel(0x2500, base + CH_DFI_PHY_CNTL1);
#else
	writel(0x2900, base + CH_DFI_PHY_CNTL1);
#endif

	writel(0x130, base + ADDR_MAP0);
	writel(0x5000 + 0x100 * idx, base + ADDR_MAP1);
	writel(0x0, base + DEVICE_CONFIG3);

	writel(0x00000348, base + DEVICE_CONFIG0);
	writel(0x00000080, base + REGION_DEVICE_CONFIG1);

	writel(0x00001140, base + DEVICE_TYPE);

	for (i = 0; i < DDR4_CH_NUM; i++) {
		val = (i & 0x1) << 4;
		writel(val, base + PAGED_REG_SEL);
		writel(0xf10, base + CH_DEVICE_MODE);
		writel(0x00b10100, base + CH_DEVICE_CONFIG0);
		writel(0x00000000, base + CH_DEVICE_CONFIG1);
		writel(0x00000000, base + CH_DEVICE_CONFIG2);
	}

	/* Timing setup */
	for (i = 0; i < DDR4_CH_NUM; i++) {
		val = (i & 0x1) << 4;
		writel(val, base + PAGED_REG_SEL);
		writel(0x42A000D6, base + CH_DRAM_TIMING_INIT0);
		writel(0x0001AB0B, base + CH_DRAM_TIMING_INIT1);
		writel(0x00025500, base + CH_DRAM_TIMING_INIT2);
		writel(0x40020080, base + CH_DRAM_TIMING_ZQC0);
		writel(0x00018080, base + CH_DRAM_TIMING_MR0);
		writel(0x33102317, base + CH_DRAM_TIMING_CORE0);
		writel(0x08100806, base + CH_DRAM_TIMING_CORE1);
		writel(0x00101006, base + CH_DRAM_TIMING_CORE2);
		writel(0x00030404, base + CH_DRAM_TIMING_CORE3);
		writel(0x05060410, base + CH_DRAM_TIMING_CORE4);
		writel(0x00C3024B, base + CH_DRAM_TIMING_REF0);
		writel(0x40007255, base + CH_DRAM_TIMING_SR0);
		writel(0x0B062587, base + CH_DRAM_TIMING_PD0);
		writel(0x00000000, base + CH_DRAM_TIMING_MISC0);
		writel(0x00000000, base + CH_DRAM_TIMING_ODT0);
		writel(0x01010D04, base + CH_DRAM_TIMING_MISC1);
		writel(0x00000000, base + CH_DRAM_TIMING_OFFSPEC0);
		writel(0x00000000, base + CH_DRAM_TIMING_OFFSPEC1);

		writel(0x0, base + CH_MC_PHY_STAGE_FLOP_CNTL);
		writel(0x0, base + CH_RAS_CNTL);

#if VCS_ENV == 1
		writel(0x00002500, base + CH_DFI_PHY_CNTL1);
#else
		writel(0x00002900, base + CH_DFI_PHY_CNTL1);
#endif
	}

	writel(0x02, base + MISC_CNTL);

#if PHY_INIT == 1
	writel(0x1, base + DFI_PHY_CNTL2);
#else 
	writel(0x0, base + DFI_PHY_CNTL2);
#endif

#if PHY_INIT == 1
	for (i = 0; i < DDR4_CH_NUM; i++) {
		val = (i & 0x1) << 4;
		writel(val, base + PAGED_REG_SEL);
		writel(0x8, base + CH_REQ_CMD);
	}
#else
#if 1
	writel((1 << 28) | 0x1, base + DFI_USER_CMD0);
	gf_ddr4_phy_cfg(idx);
#endif

	for (i = 0; i < DDR4_CH_NUM; i++) {
		val = (i & 0x1) << 4;
		writel(val, base + PAGED_REG_SEL);

		for (j = 1; j < 200; j++) {
			val = readl(base + CH_DFI_PHY_STATUS);
			if (val & 0x1) {
				break;
			}
		}
		if (j == 200) {
			sprintf(buf, "Error: wait CH%d PHY INIT timeout\n", i);
			write(STDOUT_FILENO, buf, strlen(buf));
		}
	}
#endif

#if PHY_INIT == 0
	for (i = 0; i < DDR4_CH_NUM; i++) {
		val = (i & 0x1) << 4;
		writel(val, base + PAGED_REG_SEL);
		writel(0x1, base + CH_REQ_CMD);

		for (j = 1; j < 200; j++) {
			val = readl(base + CH_DRAM_POWER_STATUS);
			if (val & 0x1) {
				break;
			}
		}
		if (j == 200) {
			sprintf(buf, "Error: wait CH%d DRAM INIT timeout\n", i);
			write(STDOUT_FILENO, buf, strlen(buf));
		}
	}

	for (i = 0; i < DDR4_CH_NUM; i++) {
		writel(0x20000 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20100 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20200 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20300 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20400 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20500 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);

		writel(0x20600 | (i << 28), base + USER_CMD);
		gf_wait_mrw(i, base);
	}
#endif

	return;
}

int gf_set_ddr_mc_count(int cnt)
{
	ddr4McNum = cnt;
	return ddr4McNum;
}

void gf_mc_init()
{
	int i;

	for (i = 0; i < ddr4McNum; i++) {
		gf_ddr_mc_cfg(i);
	}

	/* Barrier */
	__asm volatile("fence io, rw" : : : "memory");

	return;
}

