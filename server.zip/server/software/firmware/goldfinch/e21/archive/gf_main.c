/* Copyright 2019 SiFive, Inc */
/* SPDX-License-Identifier: Apache-2.0 */

/* Standard includes. */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/* Freedom metal includes. */
#include <metal/machine.h>
#include <metal/machine/platform.h>

#include <metal/lock.h>
#include <metal/uart.h>
#include <metal/interrupt.h>
#include <metal/clock.h>

#include "gf_mc.h"
#include "gf_uc.h"
#include "gf_def.h"

/* Priorities used by the tasks. */
#if( portUSING_MPU_WRAPPERS == 1 )
/* Adding portPRIVILEGE_BIT on task priority permit to this task to be executed into privilleged mode
 * if not, the task will not have access to the global variable. if you need to have access to global 
 * variable, you need to define region and change the function to call to create a task. in order to
 * avoid confusion, it is made in a different example (see example-freertos-blinky-pmp)
 */
#define mainQUEUE_RECEIVE_TASK_PRIORITY		((tskIDLE_PRIORITY + 2) | portPRIVILEGE_BIT)
#define mainQUEUE_SEND_TASK_PRIORITY		       ((tskIDLE_PRIORITY + 1) | portPRIVILEGE_BIT)
#else
#define mainQUEUE_RECEIVE_TASK_PRIORITY		(tskIDLE_PRIORITY + 2)
#define mainQUEUE_SEND_TASK_PRIORITY		   (tskIDLE_PRIORITY + 1)
#endif

#define mainQUEUE_LENGTH					(4)
/*-----------------------------------------------------------*/

/*
 * Functions:
 * 		- setupHardware: Setup Hardware according CPU and Board.
 */
static int setupHardware(void);
static int setupHardwareEpilog(void);

/*
 * The tasks as described in the comments at the top of this file.
 */
extern void vPortSetupTimerInterrupt(void);

/*-----------------------------------------------------------*/

/* The queue used by both tasks. */
static QueueHandle_t xQueue = NULL;
static QueueHandle_t xBinarySemaphore = NULL;

struct metal_cpu *cpu0;
struct metal_interrupt *cpu_intr;
struct metal_gpio *gpio;

/*-----------------------------------------------------------*/

#if 0
static void hostCmdHandlerTask(void *pvParameters)
{
	uint32_t ret = 0;

	/* Remove compiler warning about unused parameter. */
	(void)pvParameters;

	for ( ; ; ) {

	}

	vTaskEndScheduler();
}
#endif

int main(void)
{
	const char * const pcMessage = "Case: goldfinch_main start\n";
	const char * const pcMessageEnd = "Case: goldfinch_main passed\n";
#if 0
	TaskHandle_t xHandle_hostCmdHandlerTask;
#endif

	setupHardware();
	write(STDOUT_FILENO, pcMessage, strlen(pcMessage));
	
	/* Create the queue. */
	xQueue = xQueueCreate(mainQUEUE_LENGTH, sizeof(uint32_t));
	xBinarySemaphore = xSemaphoreCreateBinary();

	if (xQueue != NULL && 
		xBinarySemaphore != NULL) {
#if 0
		xTaskCreate(hostCmdHandlerTask, 
					"HOST_CMD_HANDLER", 
					configMINIMAL_STACK_SIZE, 
					NULL, 
					configMAX_PRIORITIES - 1, 
					&xHandle_hostCmdHandlerTask);
#endif
		setupHardwareEpilog();

		/* Start the tasks and timer running. */
		vTaskStartScheduler();

		/**
		 * If all is well, the scheduler will now be running, and the following 
		 * line will never be reached.  If the following line does execute, then 
		 * there was insufficient FreeRTOS heap memory available for the Idle and/or 
		 * timer tasks to be created. or task have stoppped the Scheduler 
		 * 
		 */
#if 0
		vTaskDelete(xHandle_hostCmdHandlerTask);
#endif
	}

	write(STDOUT_FILENO, pcMessageEnd, strlen(pcMessageEnd));
}

static int setupHardware(void)
{
	int rc = 0;
	uint32_t cmdType, ret = 0;
	uint64_t addr, len;

	cpu0 = metal_cpu_get(metal_cpu_get_current_hartid());
	if (cpu0 == NULL) {
		return 1;
	}

	cpu_intr = metal_cpu_interrupt_controller(cpu0);
	if (cpu_intr == NULL) {
		return 3;
	}
	metal_interrupt_init(cpu_intr);
	if (rc < 0) {
		return (rc * -1);
	}

#if 0
	gpio = metal_gpio_get_device(0);
	if (gpio == NULL) {
		return 4;
	}
	// Set pin11/12 as output, and output 0 first.
	metal_gpio_set_pin(gpio, PIN_INIT_DONE, 0);
	metal_gpio_enable_output(gpio, PIN_INIT_DONE);
	metal_gpio_set_pin(gpio, PIN_CMD_DONE, 0);
	metal_gpio_enable_output(gpio, PIN_CMD_DONE);
	// Set pin13/14/15/16 as input.
	metal_gpio_enable_input(gpio, PIN_HOST0_IN);
#endif

	// MC configuration
	gf_set_ddr_mc_count(DDR_MC_COUNT);
	gf_mc_init();

#if 0
	// Set pin12 to indicate initialization done.
	metal_gpio_set_pin(gpio, PIN_INIT_DONE, 1);

	for ( ; ; ) {
		if (metal_gpio_get_input_pin(gpio, PIN_HOST0_IN)) {
			ret = gf_cmd_handler(0);
		}
		if (metal_gpio_get_input_pin(gpio, PIN_HOST1_IN)) {
			ret = gf_cmd_handler(1);
		} 
		if (metal_gpio_get_input_pin(gpio, PIN_HOST2_IN)) {
			ret = gf_cmd_handler(2);
		}
		if (metal_gpio_get_input_pin(gpio, PIN_HOST3_IN)) {
			ret = gf_cmd_handler(3);
		}
	}
#endif

	__asm__ volatile ("wfi");

	return 0;
}

static int setupHardwareEpilog(void)
{
	int ret;

	vPortSetupTimerInterrupt();

	if (metal_interrupt_enable(cpu_intr, 0) == -1) {
		return 6;
	}

	return 0;
}

/*-----------------------------------------------------------*/


void vApplicationMallocFailedHook(void)
{
	/* vApplicationMallocFailedHook() will only be called if
	configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
	function that will get called if a call to pvPortMalloc() fails.
	pvPortMalloc() is called internally by the kernel whenever a task, queue,
	timer or semaphore is created.  It is also called by various parts of the
	demo application.  If heap_1.c or heap_2.c are used, then the size of the
	heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
	FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
	to query the size of free heap space that remains (although it does not
	provide information on how the remaining heap might be fragmented). */
	taskDISABLE_INTERRUPTS();
	_exit(1);
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook(void)
{
	/* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
	to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
	task.  It is essential that code added to this hook function never attempts
	to block in any way (for example, call xQueueReceive() with a block time
	specified, or call vTaskDelay()).  If the application makes use of the
	vTaskDelete() API function (as this demo application does) then it is also
	important that vApplicationIdleHook() is permitted to return to its calling
	function, because it is the responsibility of the idle task to clean up
	memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
	(void)pcTaskName;
	(void)pxTask;

	/* Run time stack overflow checking is performed if
	configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();

	write(STDOUT_FILENO, "ERROR Stack overflow on func: ", 30);
	write(STDOUT_FILENO, pcTaskName, strlen(pcTaskName));

	_exit(1);
}
/*-----------------------------------------------------------*/

void vApplicationTickHook(void)
{
	/* The tests in the full demo expect some interaction with interrupts. */
}
/*-----------------------------------------------------------*/

void vAssertCalled(void)
{
	taskDISABLE_INTERRUPTS();
	_exit(1);
}

