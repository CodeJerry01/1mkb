/* -------------------------------------------------------------------------------
 *
 * Copyright(C) 2022 FLC Technology Group Inc.
 * All Rights Reserved
 * Added by Jasper Chen <jiechen@flctechgroup.com>
 *  -------------------------------------------------------------------------------
*/

#ifndef __GF_UC_H
#define __GF_UC_H

#include <metal/secure.h>
#include "gf_def.h"

#define KEY_SIZE					32
#define IV_SIZE					16
#define KEY_OFFSET              		32
#define IV_OFFSET               		16
#define HASH_SIZE               		32
#define BATCH_SIZE              		4096

int aes256(struct metal_secure *secure, uint8_t * pIn, int size, uint8_t * pOut);
int sha256(struct metal_secure *secure, uint8_t * pIn, int shaSize, uint8_t * pOut, int useRam);
void generateKey(uint8_t * pIn);

int gf_cmd_handler(int idx);

#endif  /* __GF_UC_H */

