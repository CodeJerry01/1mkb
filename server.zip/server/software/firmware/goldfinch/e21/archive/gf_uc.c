/* -------------------------------------------------------------------------------
 *
 * Copyright(C) 2022 FLC Technology Group Inc.
 * All Rights Reserved
 * Added by Jasper Chen <jiechen@flctechgroup.com>
 *  -------------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <metal/compiler.h>
#include <metal/sflash.h>
#include <metal/secure.h>
#include <metal/uart.h>
#include <metal/gpio.h>
#include "gf_uc.h"
#include "gf_def.h"

char buf[64];
static uint8_t key[KEY_SIZE];
static uint8_t iv[IV_SIZE];

static uint8_t shaBuf[HASH_SIZE];
static uint8_t shaRam[BATCH_SIZE];

int aes256(struct metal_secure *secure, uint8_t * pIn, int size, uint8_t * pOut)
{
    int i;

    if (metal_secure_aes_dev_init(secure, SEC_ENG_AES_CBC, 
                        SEC_ENG_AES_KEY_256BITS) != 0) {
        return 1;
    }    
    if (metal_secure_aes_set_key(secure, key, 32, iv, 
                        SEC_ENG_AES_DECRYPTION) != 0) {
        return 2;
    } 
    if (metal_secure_aes_decrypt(secure, pIn, size, 0, pOut) != 0) {
        return 3;
    }
    metal_secure_aes_dev_deinit(secure);

    return 0;
}

int sha256(struct metal_secure *secure, uint8_t * pIn, int shaSize, uint8_t * pOut, int useRam)
{
    int i, rc, inputLen;
    uint8_t * pInput;

    if (metal_secure_sha_open(secure, SEC_ENG_SHA256) != 0) {
        return 1;
    }
    while (shaSize > 0) {
        if (shaSize > BATCH_SIZE) {
            inputLen = BATCH_SIZE;
        } else {
            inputLen = shaSize;
        }
        if (useRam) {
            memcpy(shaRam, pIn, inputLen);
            pInput = shaRam;
        } else {
            pInput = pIn;
        }
        rc = metal_secure_sha_write(secure, 0, pInput, inputLen);
        if (rc) {
            return 2;
        }
        shaSize -= inputLen;
        pIn += inputLen;
    }
    rc = metal_secure_sha_read(secure, 0, pOut, 32);
    if (rc) {
        return 3;
    }
    metal_secure_sha_close(secure);

    return 0;
}

void generateKey(uint8_t * pIn)
{
    int i;

    for (i = 0; i < IV_SIZE; i++) {
        iv[i] = pIn[((i + IV_OFFSET) * 7) % 64];
    }
    for (i = 0; i < KEY_SIZE; i++) {
        key[i] = pIn[((i + KEY_OFFSET) * 7) % 64];
    }

    return;
}

static int getBootConfig(struct metal_gpio *gpio)
{
	int pb, pf, ret;

#if 0
	pb = metal_gpio_get_input_pin(gpio, BOOT_PIN);
	pf = metal_gpio_get_input_pin(gpio, FLASH_FORMAT_PIN);
	ret = (pf << 1) + pb;
#else
	ret = 3;			//BURN_FLASH_HEX
#endif
	return ret;
}

static int gf_uart_update(int toFlash)
{
	int ret = 0;

	return ret;
}

int gf_cmd_handler(int idx)
{
	return 0;
}

