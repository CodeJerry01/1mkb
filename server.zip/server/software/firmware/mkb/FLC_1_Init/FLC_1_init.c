#include "FLC1.h"
#define MAX_NUM_FLC1_CACHE_ADDR_MAPS		16
#define MAX_NUM_FLC1_UNCACHE_ADDR_MAPS 		3
#define FLC1_AHB_SLAVE_ACCESS_BASE_ADDR      0x22010000
#define FLC2_AHB_SLAVE_ACCESS_BASE_ADDR      0x22020000

typedef struct {

	uint64_t addr_min;
	uint64_t addr_max;
	uint8_t region_size;
	uint8_t devsel;
	bool valid;
} flc_mem_region_t; 

// Function to perform AHB read (memory-mapped)
void FLC1_do_ahb_read_getval(uint32_t address, uint32_t *rd_data) {
    // Use volatile to prevent compiler optimization on memory-mapped I/O access
    volatile uint32_t *reg_addr = (volatile uint32_t *)(FLC1_AHB_SLAVE_ACCESS_BASE_ADDR + address);
    
    // Read the value from the register
    *rd_data = *reg_addr;
}

// Function to perform AHB write (memory-mapped)
void FLC1_do_ahb_write(uint32_t address, uint32_t data) {
    // Use volatile to prevent compiler optimization on memory-mapped I/O access
    volatile uint32_t *reg_addr = (volatile uint32_t *)(FLC1_AHB_SLAVE_ACCESS_BASE_ADDR + address);
    
    // Write the data to the register
    *reg_addr = data;
}

void do_flc1_init(uint8_t slice_num) 
{
    uint32_t slice_num_offset = (slice_num * 0x01000000);
    uint32_t rd_data;
    bool sram_init_done = false;
    uint32_t no_flc1_cores;
    uint32_t wr_data_m, wr_data_m_h;
#ifdef FPGA
    no_flc1_cores = 1; // FPGA has single instance of flc1
#else/
    no_flc1_cores = 2; // Assume two cores for non-FPGA
#endif
    printf("START: Configuring FLC1 initialization for slice %d\n", slice_num);
    unsigned long long addr_min;
	unsigned int region_size;
	unsigned int valid;
	unsigned long wr_data_m;
	unsigned long wr_data_m_h;
	for (uint32_t i = 0; i < no_flc1_cores; i++) 
	{
        sram_init_done = false;
        // 1. Waiting for SRAM init done
        while (!sram_init_done) {
//            FLC1_do_ahb_read_getval(FLC__SRAM__INIT + slice_num_offset, &rd_data);
			rd_data = FLC1_Regs->FLC_SRAM_Init;
			sram_init_done = rd_data & 0x1; // Check the first bit
            //usleep(5); // Wait for 5 microseconds
		}
		// 2. Configure Cache Memory for FLC1
		for (int addr_map = 0; addr_map < MAX_NUM_FLC1_CACHE_ADDR_MAPS; addr_map++)
		{
			addr_min = flc1_core_cache_region_mem[slice_num][addr_map].addr_min;
			region_size = flc1_core_cache_region_mem[slice_num][addr_map].region_size;
			valid = flc1_core_cache_region_mem[slice_num][addr_map].valid;

			// Create the write data
			wr_data_m = (addr_min >> 12) << 6 | (region_size & 0xFFF) | (valid & 0x1);
			wr_data_m_h = (addr_min >> 32);
			
			//printf("wr_data_m_h = 0x%08X, wr_data_m = 0x%08X\n", wr_data_m_h, wr_data_m);
			FLC1_Regs->
			FLC1_do_ahb_write(FLC__ADDR__MAP_0__H + slice_num_offset + (addr_map * 8), wr_data_m_h);
			FLC1_do_ahb_write(FLC__ADDR__MAP_0 + slice_num_offset + (addr_map * 8), wr_data_m);
		}
		 
		// 3. Configure Un-Cache Memory for FLC1
		for (int addr_map = 0; addr_map < MAX_NUM_FLC1_UNCACHE_ADDR_MAPS; addr_map++) {
			addr_min = flc1_core_uncache_region_mem[slice_num][addr_map].addr_min;
			region_size = flc1_core_uncache_region_mem[slice_num][addr_map].region_size;
			valid = flc1_core_uncache_region_mem[slice_num][addr_map].valid;

			// Create the write data
			wr_data_m = (addr_min >> 12) << 6 | (region_size & 0xFFF) | (valid & 0x1);
			wr_data_m_h = (addr_min >> 32);

			// Log the write data
			printf("wr_data_m_h = 0x%lx, wr_data_m = 0x%lx\n", wr_data_m_h, wr_data_m);

			// Perform the AHB write
			FLC1_do_ahb_write(FLC1__NC__ADDR__MAP_H + slice_num_offset + (addr_map * 8), wr_data_m_h);
			FLC1_do_ahb_write(FLC1__NC__ADDR__MAP + slice_num_offset + (addr_map * 8), wr_data_m);
		}
		
		// Perform memory-mapped reads and writes
		FLC1_do_ahb_read_getval(FLC__DEBUG__CONTROL + slice_num_offset, &rd_data);
		FLC1_do_ahb_write(FLC__DEBUG__CONTROL + slice_num_offset, 0x03200000);
		FLC1_do_ahb_write(FLC__INTERLEAVE__CONTROL + slice_num_offset, 0x00000000);
		FLC1_do_ahb_write(FLC__UNLOCK__LINE__SET + slice_num_offset, 0x00010001);

		// Increment the offset for the next slice
		slice_num_offset += 0x00040000;

		// Print a message (equivalent of `uvm_info`)
		printf("END : Configured FLC1 initialization for slice %d(d)\n", slice_num);	
	}
}
