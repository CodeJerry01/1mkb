#include <metal/gpio.h>
#include <metal/interrupt.h>
#include <metal/drivers/riscv_cpu.h>
#include "FLC_local_timer.h"
#include <stdio.h>
#include <FreeRTOS.h>
#define TIMER2_INTR_IRQ5	METAL_INTERRUPT_ID_LC5
#define TIMER3_INTR_IRQ6	METAL_INTERRUPT_ID_LC6

//void MsgTimerExp1(void *) __attribute__((interrupt));
//void MsgTimerExp2(void *) __attribute__((interrupt));
void MsgTimerExp1(void *);
void MsgTimerExp2(void *);

void MsgTimerExp1(void *arg){
	TIMER_INT_Type *CompID = (TIMER_INT_Type *)arg;
	printf("timer1 expired - comp ID type : %d\n", *CompID);
}

void MsgTimerExp2(void *arg){
	TIMER_INT_Type *CompID = (TIMER_INT_Type *)arg;
	printf("timer2 expired - comp ID type : %d\n", *CompID);
}

#define TIMER1												\
{															\
	.timerCh = TIMER_CH0,									\
	.clkSrc = TIMER_CLKSRC_FCLK,							\
	.countMode = TIMER_COUNT_FREERUN,						\
	.plTrigSrc = (TIMER_PRELOAD_TRIG_NONE | TIMER_PRELOAD_TRIG_COMP0 | TIMER_PRELOAD_TRIG_COMP1 | TIMER_PRELOAD_TRIG_COMP2),	\
	.IntrMode = TIMER_MATCH_LEVEL_INTR,						\
	.clockDivision = 1,										\
	.matchVal0 = 1000000,									\
	.matchVal1 = 2000000,									\
	.matchVal2 = 3000000,									\
	.preLoadVal = 0,										\
	.UserCallback = &MsgTimerExp1,							\
	.InterruptNo = TIMER2_INTR_IRQ5,						\
}

#define TIMER2 												\
{															\
	.timerCh = TIMER_CH1,									\
	.clkSrc = TIMER_CLKSRC_FCLK,							\
	.countMode = TIMER_COUNT_FREERUN,						\
	.plTrigSrc = (TIMER_PRELOAD_TRIG_NONE | TIMER_PRELOAD_TRIG_COMP0 | TIMER_PRELOAD_TRIG_COMP1 | TIMER_PRELOAD_TRIG_COMP2),	\
	.IntrMode = TIMER_MATCH_LEVEL_INTR,						\
	.clockDivision = 1,										\
	.matchVal0 = 1000000,									\
	.matchVal1 = 2000000,									\
	.matchVal2 = 3000000,									\
	.preLoadVal = 0,										\
	.UserCallback = &MsgTimerExp2,							\
	.InterruptNo = TIMER3_INTR_IRQ6,						\
}

TIMER_CFG_Type Timer[MAX_TIMERS] = {TIMER1, TIMER2};

void main(){

	FLC_TimerCounter_Init(&Timer[0]);
	FLC_TimerCounter_Configure(&Timer[0]);
	FLC_SetTimerIntr(&Timer[0]);
	FLC_Timer_Enable(&Timer[0]);
	
	FLC_TimerCounter_Init(&Timer[1]);
	FLC_TimerCounter_Configure(&Timer[1]);
	FLC_SetTimerIntr(&Timer[1]);
	FLC_Timer_Enable(&Timer[1]);	
}
