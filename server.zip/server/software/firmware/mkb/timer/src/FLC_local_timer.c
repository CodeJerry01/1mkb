#include <metal/gpio.h>
#include <metal/interrupt.h>
#include <metal/drivers/riscv_cpu.h>
#include "FLC_local_timer.h"
#include "FLC_Interrupt.h"
#include <stdio.h>
#define TIMER2_INTR_IRQ5	METAL_INTERRUPT_ID_LC5
#define TIMER3_INTR_IRQ6	METAL_INTERRUPT_ID_LC6

typedef void(intCallback_Type)(void *);
intCallback_Type *timerIntCbfArray[MAX_TIMERS] = { NULL, NULL};

void FLC_TimerCH0_ExpiryHandler() __attribute__((interrupt));
void FLC_TimerCH1_ExpiryHandler() __attribute__((interrupt));

void FLC_TimerCH0_ExpiryHandler(){
    TIMER_CFG_Type lTimerCfg;
	lTimerCfg.timerCh = TIMER_CH0;
	
	if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_0) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_0);
		timerIntCbfArray[TIMER_CH0](TIMER_INT_COMP_0);

	}else if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_1) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_1);
		timerIntCbfArray[TIMER_CH0](TIMER_INT_COMP_1);

	}else if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_2) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_2);
		timerIntCbfArray[TIMER_CH0](TIMER_INT_COMP_2);
	}
}

void FLC_TimerCH1_ExpiryHandler(){
  	TIMER_CFG_Type lTimerCfg;
	lTimerCfg.timerCh = TIMER_CH1;
	
	if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_0) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_0);
		timerIntCbfArray[TIMER_CH1](TIMER_INT_COMP_0);

	}else if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_1) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_1);
		timerIntCbfArray[TIMER_CH1](TIMER_INT_COMP_1);

	}else if(SET == TIMER_GetMatchStatus(&lTimerCfg, TIMER_INT_COMP_2) ){
		FLC_ClearIntStatus(&lTimerCfg, TIMER_INT_COMP_2);
		timerIntCbfArray[TIMER_CH1](TIMER_INT_COMP_2);
	}
}

/* 
 * @brief Configure timer clock source: 
 * Clock Source for Timer 3:2 - CS#2 / 6:5 - CS#3 / 9:8 - CSWDT 
 *	2’d0 - fclk
 *	2’d1 - f32k_clk
 *	2’d2 - 1 kHz
 *	2’d3 - PLL 32MHz
 *	Read the TCCR register 
 *  Configure only new configuration bits without disturbing existing configuration
 *  Write to the register
 */
FLC_Err_Type FLC_ClkSrc_Cfg(TIMER_CFG_Type *aTimerCfg){
	
	/* Check the parameters whether configured properly or not*/
//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCfg->timerCh));
//    CHECK_PARAM(IS_TIMER_CLKSRC_TYPE(aTimerCfg->clkSrc));
	
	uint32_t lRegVal = 0;
	lRegVal = FLC_RD_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCCR);
	switch(aTimerCfg->timerCh){
		case TIMER_CH0:
			lRegVal = FLC_SET_REG_BITS_VAL(lRegVal, TIMER_CS_1, aTimerCfg->clkSrc);
		break;
		case TIMER_CH1:
			lRegVal = FLC_SET_REG_BITS_VAL(lRegVal, TIMER_CS_2, aTimerCfg->clkSrc);
		break; 
		default:
			return ERROR;
		break;
	}
	FLC_WR_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCCR, lRegVal);
	return SUCCESS;
}
/**
* Configure timer clock division :
*	23:16 TCDR3  Timer3 clock division value bits
*	15:8 TCDR2  Timer2 clock division value bits
* Read TCDR Register
* Configure only new configuration bits without disturbing existing configuration
* Write to the register
*/
FLC_Err_Type FLC_ClkDivision_Cfg(TIMER_CFG_Type *aTimerCfg){
	
	/* Check the parameters whether configured properly or not*/
	//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));
	uint32_t lRegVal = 0;
	lRegVal = FLC_RD_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCDR);
	switch(aTimerCfg->timerCh){
		case TIMER_CH0:
			lRegVal = FLC_SET_REG_BITS_VAL(lRegVal, TIMER_TCDR2, aTimerCfg->clockDivision);
		break;
		case TIMER_CH1:
			lRegVal = FLC_SET_REG_BITS_VAL(lRegVal, TIMER_TCDR3, aTimerCfg->clockDivision);
		break;
		default:
			return ERROR;
		break;
	}
	
	FLC_WR_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCDR, lRegVal);
	return SUCCESS;
}
/**
 *	TIMER set count mode:preload or free run
 * 	b2 TIM3MODE count mdoe bits
 *	1’b0 - pre-load mode
 *	1’b1 - free run mode
 *	
 *	b1 TIM2MODE count mode bits
 *	1’b0 - pre-load mode
 *	1’b1 - free run mode
 *  
 *  b0 : Res
 *
 *  Read the TCMR register 
 *  Configure only new configuration bits without disturbing existing configuration
 *  Write to the register
*/
FLC_Err_Type FLC_CountMode_Cfg(TIMER_CFG_Type *aTimerCfg){
	
	/* Check the parameters whether configured properly or not*/
//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));
//    CHECK_PARAM(IS_TIMER_COUNTMODE_TYPE(aTimerCfg->countMode));

	uint32_t lRegval;
	
	lRegval = FLC_RD_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TCMR_OFFSET);
    lRegval &= (~(1 << (aTimerCfg->timerCh + 1)));//+1 is for bit management as per reg set, Resetting specific bit only
    lRegval |= (aTimerCfg->countMode << (aTimerCfg->timerCh + 1));

    FLC_WR_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TCMR_OFFSET, lRegval);
	
	return SUCCESS;
}

/*
* TIMER set preload trigger source,COMP0,COMP1,COMP2 or None in Registers TPLCR2/3.
* 1:0 TPLCR2/3 Timer3 pre-load control bits
*	2’d0 - No pre-load
*	2’d1 - Pre-load with match comparator 0
*	2’d2 - Pre-load with match comparator 1
*	2’d3 - Pre-load with match comparator 2
*/
FLC_Err_Type FLC_Preload_Cfg(TIMER_CFG_Type *aTimerCfg){
	
	/* Check the parameters whether configured properly or not*/
//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));
//    CHECK_PARAM(IS_TIMER_PRELOAD_TRIG_TYPE(aTimerCfg->plTrigSrc));
	FLC_WR_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TPLCR2_OFFSET + (4 * aTimerCfg->timerCh), aTimerCfg->plTrigSrc);
	return SUCCESS;
}

/**
* TIMER set preload register low 32bits value of TPLVR2/3 Registers.
* 31:0 TPLVR3  32’h0 Timer3 pre-load value bits
*/
FLC_Err_Type FLC_SetPreloadValue(TIMER_CFG_Type *aTimerCfg){
    /* Check the parameters whether configured properly or not*/
//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));
	FLC_WR_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TPLVR2_OFFSET + (4 * aTimerCfg->timerCh), aTimerCfg->preLoadVal);
	return SUCCESS;
}

/**
* TIMER set specified channel and comparator compare value
* Setting TMR2_0/2_1/2_2/3_0/3_1/3_2 registers
* 31:0 TMR2.0/2.1/2.2/3.0/3.1/3.2  32’hffffffff Timer2,3 match registers 0/1/2
* aTimerCfg : Timer configuration structure
* cmpNo : TIMER comparator ID type
* val: TIMER match comapre register value
* return error status
*/
FLC_Err_Type FLC_SetCompValue(TIMER_CFG_Type *aTimerCfg,TIMER_Comp_ID_Type cmpNo, uint32_t val)
{
    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCh));
    //CHECK_PARAM(IS_TIMER_COMP_ID_TYPE(cmpNo));

    FLC_WR_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TMR2_0_OFFSET + 4 * ((TIMER_MAX_MATCH * aTimerCfg->timerCh) + cmpNo), val);
	return SUCCESS;
}
/**
* This function return the current configured comparator value in to register
* by reading TMR2_0/2_1/2_2/3_0/3_1/3_2
*/
uint32_t FLC_GetCompValue(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo)
{
    uint32_t tmpVal;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCh));
    //CHECK_PARAM(IS_TIMER_COMP_ID_TYPE(cmpNo));

    tmpVal = FLC_RD_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TMR2_0_OFFSET + (4 * ((TIMER_MAX_MATCH * aTimerCfg->timerCh) + cmpNo)));
    return tmpVal;
}

/**
* TIMER get the specified channel count value
* This routine return the current timer counter value by reading TCVWR2/3 registers
* return TIMER count register value
* 31:0 TCVWR3  32’h0 Timer2/3 capture value of counter
*/
uint32_t FLC_GetPresentCounterVal(TIMER_CFG_Type *aTimerCfg)
{
    uint32_t tmpVal;
    uint32_t tmpAddr;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCh));

    /* TO avoid risk of reading, don't read TCVWR directly*/
    /* request for read*/
    tmpAddr = FLC_LOCAL_TIMER_BASE + TIMER_TCVWR2_OFFSET + (4 * aTimerCfg -> timerCh);
    //FLC_WR_WORD(tmpAddr, 1);

    /* Need wait */
    tmpVal = FLC_RD_WORD(tmpAddr);
    tmpVal = FLC_RD_WORD(tmpAddr);
    tmpVal = FLC_RD_WORD(tmpAddr);

    return tmpVal;
}

/**
*  TIMER get specified channel and comparator match status
* aTimerCfg : Timer structure
* cmpNo: TIMER comparator ID type
* return SET or RESET
* Reads TMRS2/3 register based on the channel and return which comparator interrupt has SET.
* b2 T3MR2S  Timer2/3 match register 2 status/Clear interrupt would also
clear this bit
* b1 T3MR1S  Timer2/3 match register 1 status/Clear interrupt would also
clear this bit
* b0 T3MR0S  Timer2/3 match register 0 status/Clear interrupt would also
clear this bit
*/
Reg_Sts_Type TIMER_GetMatchStatus(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo)
{
    uint32_t tmpVal;
    Reg_Sts_Type bitStatus = RESET;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCh));
    //CHECK_PARAM(IS_TIMER_COMP_ID_TYPE(cmpNo));

    tmpVal = FLC_RD_WORD(FLC_LOCAL_TIMER_BASE + TIMER_TMSR2_OFFSET + (4 * aTimerCfg->timerCh));

    switch (cmpNo) {
        case TIMER_COMP_ID_0:
            bitStatus = FLC_IS_REG_BIT_SET(tmpVal, TIMER_TMSR_0) ? SET : RESET;
            break;

        case TIMER_COMP_ID_1:
            bitStatus = FLC_IS_REG_BIT_SET(tmpVal, TIMER_TMSR_1) ? SET : RESET;
            break;

        case TIMER_COMP_ID_2:
            bitStatus = FLC_IS_REG_BIT_SET(tmpVal, TIMER_TMSR_2) ? SET : RESET;
            break;

        default:
            break;
    }

    return bitStatus;
}

/**
* TIMER clear interrupt status
* cmpNo: TIMER macth comparator ID type
* aTimerCfg : Timer configuration structure
* b2 TCLR2.2/3.2  Timer2/3 Interrupt clear for match comparator 2
* b1 TCLR2.1/3.1  Timer2/3 Interrupt clear for match comparator 1
* b0 TCLR2.0/3.0  Timer2/3 Interrupt clear for match comparator 0
* This function will be used to clear certain comparators interrutps after being interrutped
*/
void FLC_ClearIntStatus(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo)
{
    uint32_t ltmpAddr;
    uint32_t ltmpVal;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCh));
    //CHECK_PARAM(IS_TIMER_COMP_ID_TYPE(cmpNo));

    ltmpAddr = FLC_LOCAL_TIMER_BASE + TIMER_TICR2_OFFSET + (4 * aTimerCfg->timerCh);

    ltmpVal = FLC_RD_WORD(ltmpAddr);
    ltmpVal |= (1 << cmpNo);

    FLC_WR_WORD(ltmpAddr, ltmpVal);
}

void FLC_Timer_Disable(TIMER_CFG_Type *aTimerCfg)
{
    uint32_t ltmpVal;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));

    ltmpVal = FLC_RD_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCER);
    ltmpVal &= (~(1 << (aTimerCfg->timerCh + 1)));

    FLC_WR_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCER, ltmpVal);
}

void FLC_Timer_Enable(TIMER_CFG_Type *aTimerCfg)
{
    uint32_t ltmpVal;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));

    ltmpVal = FLC_RD_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCER);
    ltmpVal |= (1 << (aTimerCfg->timerCh + 1));

    FLC_WR_REG(FLC_LOCAL_TIMER_BASE, TIMER_TCER, ltmpVal);
}

/**
* TIMER mask or unmask function or all comparator interrupts
*
* Reads from TIER2 reg,
* Configures/cleares bits based on Mask/Unmask
* Wrties to registers addr.
* b2 TIER3.2/2.2  1’b0 Timer3/2 match register 2 interrupt enable bit
* b1 TIER3.1/2.1  1’b0 Timer3/2 match register 1 interrupt enable bit
* b0 TIER3.0/2.0  1’b0 Timer3/2 match register 0 interrupt enable bit
* 
* This function Disables or Enables (Masks / Unmasks) particular comparator interrutps based on necessity
*/
void FLC_Timer_IntMask(TIMER_CFG_Type *aTimerCfg, TIMER_INT_Type intType, Mask_Type intMask)
{
    uint32_t lRegAddr;
    uint32_t lRegData;

    /* Check the parameters */
    //CHECK_PARAM(IS_TIMER_CHAN_TYPE(aTimerCfg->timerCh));
    //CHECK_PARAM(IS_TIMER_INT_TYPE(intType));
    //CHECK_PARAM(IS_BL_MASK_TYPE(intMask));

    lRegAddr = FLC_LOCAL_TIMER_BASE + TIMER_TIER2_OFFSET + (4 * aTimerCfg->timerCh);
    lRegData = FLC_RD_WORD(lRegAddr);

    switch (intType) {
        case TIMER_INT_COMP_0:
            if (intMask == UNMASK) {
                /* Enable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_0));
            } else {
                /* Disable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_0));
            }

            break;

        case TIMER_INT_COMP_1:
            if (intMask == UNMASK) {
                /* Enable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_1));
            } else {
                /* Disable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_1));
            }

            break;

        case TIMER_INT_COMP_2:
            if (intMask == UNMASK) {
                /* Enable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_2));
            } else {
                /* Disable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_2));
            }

            break;

        case TIMER_INT_ALL:
            if (intMask == UNMASK) {
                /* Enable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_0));
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_1));
                FLC_WR_WORD(lRegAddr, FLC_SET_REG_BIT(lRegData, TIMER_TIER_2));
            } else {
                /* Disable this interrupt */
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_0));
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_1));
                FLC_WR_WORD(lRegAddr, FLC_CLR_REG_BIT(lRegData, TIMER_TIER_2));
            }

            break;

        default:
            break;
    }
}
/**
* This function configures match values to the respective comparators.
* Handling based on counter mode (free running / pre-load)
*
*/
FLC_Err_Type FLC_TimerCounter_Configure(TIMER_CFG_Type *aTimerCfg){

	uint32_t compare_count1,compare_count2,compare_count3,clkval,unit;
	/**Get the clock value here*/
    if (aTimerCfg->timerCh == TIMER_CH0) {
        //clkval = peripheral_clock_get(PERIPHERAL_CLOCK_TIMER0);
		clkval = 1000000;
    } else {
        //clkval = peripheral_clock_get(PERIPHERAL_CLOCK_TIMER1);
		clkval = 1000000;
    }

    if (clkval % 1000000 == 0) {
        unit = 1000000; //1us
    } else if (clkval % 100000 == 0) {
        unit = 100000; //10us
    } else if (clkval % 10000 == 0) {
        unit = 10000; //100us
    } else if (clkval % 1000 == 0) {
        unit = 1000; //1ms
    } else if (clkval % 100 == 0) {
        unit = 100; //10ms
    } else if (clkval % 10 == 0) {
        unit = 10; //100ms
    } else if (clkval % 1 == 0) {
        unit = 1; //s
    } else {
    }

    compare_count1 = aTimerCfg->matchVal0 / (1000000 / unit) * (clkval / unit);
    compare_count2 = aTimerCfg->matchVal1 / (1000000 / unit) * (clkval / unit);
    compare_count3 = aTimerCfg->matchVal2 / (1000000 / unit) * (clkval / unit);
	
	/* Configure match compare values */
    if ((compare_count1 < 1) || (compare_count2 < 1) || (compare_count3 < 1)) {
        return ERROR;
    }

	if(aTimerCfg->countMode == TIMER_COUNT_PRELOAD) {
		
		/* Configure timer preload value */
        FLC_SetPreloadValue(aTimerCfg);
		
		/* Configure match compare values */
		if (aTimerCfg->matchVal0 > 1 + aTimerCfg->preLoadVal) {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_0, (compare_count1 - 2));
		} else {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_0, compare_count1);
		}

		if (aTimerCfg->matchVal1 > 1 + aTimerCfg->preLoadVal) {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_1, (compare_count2 - 2) );
		} else {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_1, compare_count2);
		}

		if (aTimerCfg->matchVal2 > 1 + aTimerCfg->preLoadVal) {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_2, (compare_count3 - 2) );
		} else {
			FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_2, compare_count3);
		}
	} else{
	   /* Configure match compare values only iff they are valid count*/
		if (aTimerCfg->matchVal0 > 1) {
            FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_0, compare_count1 - 2);
        }
		if (aTimerCfg->matchVal1 > 1) {
            FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_1, compare_count2 - 2);
        }
		if (aTimerCfg->matchVal2 > 1) {
            FLC_SetCompValue(aTimerCfg, TIMER_COMP_ID_2, compare_count3 - 2);
        } 
	}
	
	/* Enable timer match interrupt */
	/* Note: if not enabled(Unmasked) match interrupt, TIMER_GetMatchStatus will not work
	and status bit will not set */
	FLC_Timer_IntMask(aTimerCfg, TIMER_INT_COMP_0, UNMASK);
	FLC_Timer_IntMask(aTimerCfg, TIMER_INT_COMP_1, UNMASK);
	FLC_Timer_IntMask(aTimerCfg, TIMER_INT_COMP_2, UNMASK);
	
	return SUCCESS;
}


/**
* 1. Clock source configuration
* 2. Clock Division Configuration
* 3. Count Mode Configuration
* 4. if count_mode == pre-load then 
*	configure preload trigger src and 
*			  pre-load val
* 
*/
FLC_Err_Type FLC_TimerCounter_Init(TIMER_CFG_Type *aTimerCfg){
	
	FLC_Err_Type lRetSts = SUCCESS;
//    CHECK_PARAM(IS_TIMER_CHAN_TYPE(timerCfg->timerCh));
	lRetSts = FLC_ClkSrc_Cfg(aTimerCfg);
	if(lRetSts != SUCCESS){
		printf("clock src configuration failed with status : %d\n",lRetSts);
		return lRetSts;
	}
	lRetSts = FLC_ClkDivision_Cfg(aTimerCfg);
	if(lRetSts != SUCCESS){
		printf("clock Division config failed with status : %d\n",lRetSts);
		return lRetSts;
	}

	lRetSts = FLC_CountMode_Cfg(aTimerCfg);
	if(lRetSts != SUCCESS){
		printf("clock count config failed with status : %d\n",lRetSts);
		return lRetSts;
	}

	if(aTimerCfg->countMode == TIMER_COUNT_PRELOAD){
		lRetSts = FLC_Preload_Cfg(aTimerCfg);
		if(lRetSts != SUCCESS){
			printf("clock preload config failed with status : %d\n",lRetSts);
			return lRetSts;
		}

		lRetSts = FLC_SetPreloadValue(aTimerCfg);
		if(lRetSts != SUCCESS){
			printf("clock preload set failed with status : %d\n",lRetSts);
			return lRetSts;
		}

	}
	return lRetSts;
}

FLC_Err_Type FLC_TimerRegisterIntrCb(TIMER_CFG_Type *aTimerCfg){
	uint8_t retsts = 0;
	Intr_Cfg_t lTimerIntrCfg;
	lTimerIntrCfg.Intr_Controller_type = METAL_CLIC_CONTROLLER;
	//lTimerIntrCfg.vector_mode = METAL_SELECTIVE_VECTOR_MODE;
	//lTimerIntrCfg.Intr_Control = INTR_EN;
	lTimerIntrCfg.Interrupt_ID = aTimerCfg->InterruptNo;

	if(aTimerCfg->timerCh == TIMER_CH0){
		lTimerIntrCfg.callback = &FLC_TimerCH0_ExpiryHandler;
		timerIntCbfArray[aTimerCfg->timerCh] = aTimerCfg->UserCallback;
	}else if(aTimerCfg->timerCh == TIMER_CH1){
		lTimerIntrCfg.callback = &FLC_TimerCH1_ExpiryHandler;
		timerIntCbfArray[aTimerCfg->timerCh] = aTimerCfg->UserCallback;
	}
	retsts = FLC_IntCb_Register(&lTimerIntrCfg);

	if(retsts != 0)
		return ERROR;

	return SUCCESS;
}
/**
 *This routine shall be used for configuring interrupt to the timers.
 *
 * returns return status if failure to register and 0 if success
 */
FLC_Err_Type FLC_SetTimerIntr(TIMER_CFG_Type *aTimerCfg){
	
	uint8_t retsts = 0;
	Intr_Cfg_t lTimerIntrCfg;
	lTimerIntrCfg.Intr_Controller_type = METAL_CLIC_CONTROLLER;
	lTimerIntrCfg.vector_mode = METAL_SELECTIVE_VECTOR_MODE;
	lTimerIntrCfg.Intr_Control = INTR_EN;
	lTimerIntrCfg.Interrupt_ID = aTimerCfg->InterruptNo;
	
	//Callback registering	
	if(aTimerCfg->timerCh == TIMER_CH0){
		lTimerIntrCfg.callback = &FLC_TimerCH0_ExpiryHandler;
		timerIntCbfArray[aTimerCfg->timerCh] = aTimerCfg->UserCallback;
	}else if(aTimerCfg->timerCh == TIMER_CH1){
		lTimerIntrCfg.callback = &FLC_TimerCH1_ExpiryHandler;
		timerIntCbfArray[aTimerCfg->timerCh] = aTimerCfg->UserCallback;
	}
	retsts = FLC_Intr_Register(&lTimerIntrCfg);
	if(retsts != 0 ){
		printf("Timer intr registering failed with Error status %d\n",retsts);
		return ERROR;
	}
	return SUCCESS;
}
