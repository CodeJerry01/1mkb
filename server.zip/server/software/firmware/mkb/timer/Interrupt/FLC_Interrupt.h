#include <metal/interrupt.h>
#include <metal/drivers/riscv_cpu.h>

typedef enum
{
	INTR_DIS = 0,
	INTR_EN,
}FLC_Interrupt_Ctrl;

typedef void (*callback_func)(void);
typedef struct 
{
	metal_intr_cntrl_type Intr_Controller_type;
	metal_vector_mode vector_mode;
	callback_func callback;
	FLC_Interrupt_Ctrl Intr_Control;
	uint32_t Interrupt_ID;
}Intr_Cfg_t;


uint8_t FLC_Intr_Register(Intr_Cfg_t *IntCfg);
uint8_t FLC_IntCb_Register(Intr_Cfg_t *IntCfg);


