#include "FLC_Interrupt.h"
#include <stdio.h>

uint8_t FLC_Intr_Register(Intr_Cfg_t *IntCfg){
	
	struct metal_interrupt *sInterrupt;
	struct metal_interrupt *s_cpu_intr;
	struct metal_cpu *s_cpu;
	
	s_cpu = metal_cpu_get(metal_cpu_get_current_hartid());
	if (s_cpu == NULL) {
	     return 2;
	}
	
	s_cpu_intr = metal_cpu_interrupt_controller(s_cpu);
	if (s_cpu_intr == NULL) {
	     printf("Cpu interrupt controller failed\n");
	     return 3;
	}

	if(IntCfg->Intr_Control == INTR_EN){

		metal_interrupt_init(s_cpu_intr);
	}

	sInterrupt = metal_interrupt_get_controller(IntCfg->Intr_Controller_type, (int)s_cpu);	
	if(sInterrupt == NULL) {
	printf("Get interrupt controller failed\n");
	}

	if(IntCfg->Intr_Control == INTR_DIS){
	    metal_interrupt_disable(sInterrupt, IntCfg->Interrupt_ID);
    	metal_interrupt_disable(s_cpu_intr, IntCfg->Interrupt_ID);
    	metal_interrupt_disable(s_cpu_intr, METAL_INTERRUPT_ID_BASE);
		return 0;
	}

	metal_interrupt_init(sInterrupt);
	
	if(metal_interrupt_set_vector_mode(sInterrupt, IntCfg->vector_mode) != 0) {
		printf("Set interrupt vector mode failed\n");
		return 4;
	}
	
	if(metal_interrupt_register_vector_handler(sInterrupt,IntCfg->Interrupt_ID,IntCfg->callback,NULL) != 0) {
		printf("Set interrupt register handler failed\n");
		return 5;
	}
	
	if(metal_interrupt_enable(sInterrupt,IntCfg->Interrupt_ID) != 0) {
		printf("Set interrupt vector enable failed\n");
		return 6;
	}
	if (metal_interrupt_enable(s_cpu_intr, 0) != 0) {
    	printf("CPU interrupt enable failed\n");
    	return 8;
	}
}

uint8_t FLC_IntCb_Register(Intr_Cfg_t *IntCfg){
	
	struct metal_interrupt *sInterrupt;
	struct metal_cpu *s_cpu;

	s_cpu = metal_cpu_get(metal_cpu_get_current_hartid());
	if (s_cpu == NULL) {
	     return 2;
	}

	sInterrupt = metal_interrupt_get_controller(IntCfg->Intr_Controller_type, (int)s_cpu);	
	if(sInterrupt == NULL) {
		printf("Get interrupt controller failed\n");
		return 4;
	}

	if(metal_interrupt_register_vector_handler(sInterrupt,IntCfg->Interrupt_ID,IntCfg->callback,NULL) != 0) {
		printf("Set interrupt register handler failed\n");
		return 5;
	}
	
//	if(metal_interrupt_enable(sInterrupt,IntCfg->Interrupt_ID) != 0) {
//		printf("Set interrupt vector enable failed\n");
//		return 6;
//	}
//	if (metal_interrupt_enable(s_cpu_intr, 0) != 0) {
//  	printf("CPU interrupt enable failed\n");
//    	return 8;
//	}
	
	return 0;
}
