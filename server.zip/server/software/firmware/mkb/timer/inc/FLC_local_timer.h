
#define FLC_LOCAL_TIMER_BASE       ((uint32_t)0x20003000)
#define MAX_TIMERS	2
#define TIMER_MAX_MATCH 3
/**
 * Memory access macro
 */
#define FLC_RD_WORD(addr)       (*((volatile uint32_t *)(uintptr_t)(addr)))
#define FLC_WR_WORD(addr, val)  ((*(volatile uint32_t *)(uintptr_t)(addr)) = (val))



/**
 * Register access macro
 */
#define FLC_RD_REG(base_addr, regname)                  FLC_RD_WORD(base_addr + regname##_OFFSET)
#define FLC_WR_REG(addr, regname, val)             FLC_WR_WORD(addr + regname##_OFFSET, val)
#define FLC_IS_REG_BIT_SET(val, bitname)           (((val) & (1U << (bitname##_POS))) != 0)

/*
*
*/
#define FLC_SET_REG_BITS_VAL(val, bitname, bitval) (((val)&bitname##_UMSK) | ((uint32_t)(bitval) << bitname##_POS))
#define FLC_CLR_REG_BIT(val, bitname)              ((val)&bitname##_UMSK)
#define FLC_SET_REG_BIT(val, bitname)              ((val) | (1U << bitname##_POS))

/* 0x0 : TCCR */
#define TIMER_TCCR_OFFSET (0x0)
#define TIMER_CS_1        TIMER_CS_1
#define TIMER_CS_1_POS    (2U)
#define TIMER_CS_1_LEN    (2U)
#define TIMER_CS_1_MSK    (((1U << TIMER_CS_1_LEN) - 1) << TIMER_CS_1_POS)
#define TIMER_CS_1_UMSK   (~(((1U << TIMER_CS_1_LEN) - 1) << TIMER_CS_1_POS))
#define TIMER_CS_2        TIMER_CS_2
#define TIMER_CS_2_POS    (5U)
#define TIMER_CS_2_LEN    (2U)
#define TIMER_CS_2_MSK    (((1U << TIMER_CS_2_LEN) - 1) << TIMER_CS_2_POS)
#define TIMER_CS_2_UMSK   (~(((1U << TIMER_CS_2_LEN) - 1) << TIMER_CS_2_POS))
#define TIMER_CS_WDT      TIMER_CS_WDT
#define TIMER_CS_WDT_POS  (8U)
#define TIMER_CS_WDT_LEN  (2U)
#define TIMER_CS_WDT_MSK  (((1U << TIMER_CS_WDT_LEN) - 1) << TIMER_CS_WDT_POS)
#define TIMER_CS_WDT_UMSK (~(((1U << TIMER_CS_WDT_LEN) - 1) << TIMER_CS_WDT_POS))

/* 0x10 : TMR2_0 */
#define TIMER_TMR2_0_OFFSET (0x10)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x14 : TMR2_1 */
#define TIMER_TMR2_1_OFFSET (0x14)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x18 : TMR2_2 */
#define TIMER_TMR2_2_OFFSET (0x18)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x1C : TMR3_0 */
#define TIMER_TMR3_0_OFFSET (0x1C)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x20 : TMR3_1 */
#define TIMER_TMR3_1_OFFSET (0x20)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x24 : TMR3_2 */
#define TIMER_TMR3_2_OFFSET (0x24)
#define TIMER_TMR           TIMER_TMR
#define TIMER_TMR_POS       (0U)
#define TIMER_TMR_LEN       (32U)
#define TIMER_TMR_MSK       (((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS)
#define TIMER_TMR_UMSK      (~(((1U << TIMER_TMR_LEN) - 1) << TIMER_TMR_POS))

/* 0x2C : TCR2 */
#define TIMER_TCR2_OFFSET (0x2C)
#define TIMER_TCR         TIMER_TCR
#define TIMER_TCR_POS     (0U)
#define TIMER_TCR_LEN     (32U)
#define TIMER_TCR_MSK     (((1U << TIMER_TCR_LEN) - 1) << TIMER_TCR_POS)
#define TIMER_TCR_UMSK    (~(((1U << TIMER_TCR_LEN) - 1) << TIMER_TCR_POS))

/* 0x30 : TCR3 */
#define TIMER_TCR3_OFFSET (0x30)
#define TIMER_TCR         TIMER_TCR
#define TIMER_TCR_POS     (0U)
#define TIMER_TCR_LEN     (32U)
#define TIMER_TCR_MSK     (((1U << TIMER_TCR_LEN) - 1) << TIMER_TCR_POS)
#define TIMER_TCR_UMSK    (~(((1U << TIMER_TCR_LEN) - 1) << TIMER_TCR_POS))

/* 0x38 : TMSR2 */
#define TIMER_TMSR2_OFFSET (0x38)
#define TIMER_TMSR_0       TIMER_TMSR_0
#define TIMER_TMSR_0_POS   (0U)
#define TIMER_TMSR_0_LEN   (1U)
#define TIMER_TMSR_0_MSK   (((1U << TIMER_TMSR_0_LEN) - 1) << TIMER_TMSR_0_POS)
#define TIMER_TMSR_0_UMSK  (~(((1U << TIMER_TMSR_0_LEN) - 1) << TIMER_TMSR_0_POS))
#define TIMER_TMSR_1       TIMER_TMSR_1
#define TIMER_TMSR_1_POS   (1U)
#define TIMER_TMSR_1_LEN   (1U)
#define TIMER_TMSR_1_MSK   (((1U << TIMER_TMSR_1_LEN) - 1) << TIMER_TMSR_1_POS)
#define TIMER_TMSR_1_UMSK  (~(((1U << TIMER_TMSR_1_LEN) - 1) << TIMER_TMSR_1_POS))
#define TIMER_TMSR_2       TIMER_TMSR_2
#define TIMER_TMSR_2_POS   (2U)
#define TIMER_TMSR_2_LEN   (1U)
#define TIMER_TMSR_2_MSK   (((1U << TIMER_TMSR_2_LEN) - 1) << TIMER_TMSR_2_POS)
#define TIMER_TMSR_2_UMSK  (~(((1U << TIMER_TMSR_2_LEN) - 1) << TIMER_TMSR_2_POS))

/* 0x3C : TMSR3 */
#define TIMER_TMSR3_OFFSET (0x3C)
#define TIMER_TMSR_0       TIMER_TMSR_0
#define TIMER_TMSR_0_POS   (0U)
#define TIMER_TMSR_0_LEN   (1U)
#define TIMER_TMSR_0_MSK   (((1U << TIMER_TMSR_0_LEN) - 1) << TIMER_TMSR_0_POS)
#define TIMER_TMSR_0_UMSK  (~(((1U << TIMER_TMSR_0_LEN) - 1) << TIMER_TMSR_0_POS))
#define TIMER_TMSR_1       TIMER_TMSR_1
#define TIMER_TMSR_1_POS   (1U)
#define TIMER_TMSR_1_LEN   (1U)
#define TIMER_TMSR_1_MSK   (((1U << TIMER_TMSR_1_LEN) - 1) << TIMER_TMSR_1_POS)
#define TIMER_TMSR_1_UMSK  (~(((1U << TIMER_TMSR_1_LEN) - 1) << TIMER_TMSR_1_POS))
#define TIMER_TMSR_2       TIMER_TMSR_2
#define TIMER_TMSR_2_POS   (2U)
#define TIMER_TMSR_2_LEN   (1U)
#define TIMER_TMSR_2_MSK   (((1U << TIMER_TMSR_2_LEN) - 1) << TIMER_TMSR_2_POS)
#define TIMER_TMSR_2_UMSK  (~(((1U << TIMER_TMSR_2_LEN) - 1) << TIMER_TMSR_2_POS))

/* 0x44 : TIER2 */
#define TIMER_TIER2_OFFSET (0x44)
#define TIMER_TIER_0       TIMER_TIER_0
#define TIMER_TIER_0_POS   (0U)
#define TIMER_TIER_0_LEN   (1U)
#define TIMER_TIER_0_MSK   (((1U << TIMER_TIER_0_LEN) - 1) << TIMER_TIER_0_POS)
#define TIMER_TIER_0_UMSK  (~(((1U << TIMER_TIER_0_LEN) - 1) << TIMER_TIER_0_POS))
#define TIMER_TIER_1       TIMER_TIER_1
#define TIMER_TIER_1_POS   (1U)
#define TIMER_TIER_1_LEN   (1U)
#define TIMER_TIER_1_MSK   (((1U << TIMER_TIER_1_LEN) - 1) << TIMER_TIER_1_POS)
#define TIMER_TIER_1_UMSK  (~(((1U << TIMER_TIER_1_LEN) - 1) << TIMER_TIER_1_POS))
#define TIMER_TIER_2       TIMER_TIER_2
#define TIMER_TIER_2_POS   (2U)
#define TIMER_TIER_2_LEN   (1U)
#define TIMER_TIER_2_MSK   (((1U << TIMER_TIER_2_LEN) - 1) << TIMER_TIER_2_POS)
#define TIMER_TIER_2_UMSK  (~(((1U << TIMER_TIER_2_LEN) - 1) << TIMER_TIER_2_POS))

/* 0x48 : TIER3 */
#define TIMER_TIER3_OFFSET (0x48)
#define TIMER_TIER_0       TIMER_TIER_0
#define TIMER_TIER_0_POS   (0U)
#define TIMER_TIER_0_LEN   (1U)
#define TIMER_TIER_0_MSK   (((1U << TIMER_TIER_0_LEN) - 1) << TIMER_TIER_0_POS)
#define TIMER_TIER_0_UMSK  (~(((1U << TIMER_TIER_0_LEN) - 1) << TIMER_TIER_0_POS))
#define TIMER_TIER_1       TIMER_TIER_1
#define TIMER_TIER_1_POS   (1U)
#define TIMER_TIER_1_LEN   (1U)
#define TIMER_TIER_1_MSK   (((1U << TIMER_TIER_1_LEN) - 1) << TIMER_TIER_1_POS)
#define TIMER_TIER_1_UMSK  (~(((1U << TIMER_TIER_1_LEN) - 1) << TIMER_TIER_1_POS))
#define TIMER_TIER_2       TIMER_TIER_2
#define TIMER_TIER_2_POS   (2U)
#define TIMER_TIER_2_LEN   (1U)
#define TIMER_TIER_2_MSK   (((1U << TIMER_TIER_2_LEN) - 1) << TIMER_TIER_2_POS)
#define TIMER_TIER_2_UMSK  (~(((1U << TIMER_TIER_2_LEN) - 1) << TIMER_TIER_2_POS))


/* 0x50 : TPLVR2 */
#define TIMER_TPLVR2_OFFSET (0x50)
#define TIMER_TPLVR         TIMER_TPLVR
#define TIMER_TPLVR_POS     (0U)
#define TIMER_TPLVR_LEN     (32U)
#define TIMER_TPLVR_MSK     (((1U << TIMER_TPLVR_LEN) - 1) << TIMER_TPLVR_POS)
#define TIMER_TPLVR_UMSK    (~(((1U << TIMER_TPLVR_LEN) - 1) << TIMER_TPLVR_POS))

/* 0x54 : TPLVR3 */
#define TIMER_TPLVR3_OFFSET (0x54)
#define TIMER_TPLVR         TIMER_TPLVR
#define TIMER_TPLVR_POS     (0U)
#define TIMER_TPLVR_LEN     (32U)
#define TIMER_TPLVR_MSK     (((1U << TIMER_TPLVR_LEN) - 1) << TIMER_TPLVR_POS)
#define TIMER_TPLVR_UMSK    (~(((1U << TIMER_TPLVR_LEN) - 1) << TIMER_TPLVR_POS))


/* 0x5C : TPLCR2 */
#define TIMER_TPLCR2_OFFSET (0x5C)
#define TIMER_TPLCR         TIMER_TPLCR
#define TIMER_TPLCR_POS     (0U)
#define TIMER_TPLCR_LEN     (2U)
#define TIMER_TPLCR_MSK     (((1U << TIMER_TPLCR_LEN) - 1) << TIMER_TPLCR_POS)
#define TIMER_TPLCR_UMSK    (~(((1U << TIMER_TPLCR_LEN) - 1) << TIMER_TPLCR_POS))

/* 0x60 : TPLCR3 */
#define TIMER_TPLCR3_OFFSET (0x60)
#define TIMER_TPLCR         TIMER_TPLCR
#define TIMER_TPLCR_POS     (0U)
#define TIMER_TPLCR_LEN     (2U)
#define TIMER_TPLCR_MSK     (((1U << TIMER_TPLCR_LEN) - 1) << TIMER_TPLCR_POS)
#define TIMER_TPLCR_UMSK    (~(((1U << TIMER_TPLCR_LEN) - 1) << TIMER_TPLCR_POS))

/* 0x78 : TICR2 */
#define TIMER_TICR2_OFFSET (0x78)
#define TIMER_TCLR_0       TIMER_TCLR_0
#define TIMER_TCLR_0_POS   (0U)
#define TIMER_TCLR_0_LEN   (1U)
#define TIMER_TCLR_0_MSK   (((1U << TIMER_TCLR_0_LEN) - 1) << TIMER_TCLR_0_POS)
#define TIMER_TCLR_0_UMSK  (~(((1U << TIMER_TCLR_0_LEN) - 1) << TIMER_TCLR_0_POS))
#define TIMER_TCLR_1       TIMER_TCLR_1
#define TIMER_TCLR_1_POS   (1U)
#define TIMER_TCLR_1_LEN   (1U)
#define TIMER_TCLR_1_MSK   (((1U << TIMER_TCLR_1_LEN) - 1) << TIMER_TCLR_1_POS)
#define TIMER_TCLR_1_UMSK  (~(((1U << TIMER_TCLR_1_LEN) - 1) << TIMER_TCLR_1_POS))
#define TIMER_TCLR_2       TIMER_TCLR_2
#define TIMER_TCLR_2_POS   (2U)
#define TIMER_TCLR_2_LEN   (1U)
#define TIMER_TCLR_2_MSK   (((1U << TIMER_TCLR_2_LEN) - 1) << TIMER_TCLR_2_POS)
#define TIMER_TCLR_2_UMSK  (~(((1U << TIMER_TCLR_2_LEN) - 1) << TIMER_TCLR_2_POS))

/* 0x7C : TICR3 */
#define TIMER_TICR3_OFFSET (0x7C)
#define TIMER_TCLR_0       TIMER_TCLR_0
#define TIMER_TCLR_0_POS   (0U)
#define TIMER_TCLR_0_LEN   (1U)
#define TIMER_TCLR_0_MSK   (((1U << TIMER_TCLR_0_LEN) - 1) << TIMER_TCLR_0_POS)
#define TIMER_TCLR_0_UMSK  (~(((1U << TIMER_TCLR_0_LEN) - 1) << TIMER_TCLR_0_POS))
#define TIMER_TCLR_1       TIMER_TCLR_1
#define TIMER_TCLR_1_POS   (1U)
#define TIMER_TCLR_1_LEN   (1U)
#define TIMER_TCLR_1_MSK   (((1U << TIMER_TCLR_1_LEN) - 1) << TIMER_TCLR_1_POS)
#define TIMER_TCLR_1_UMSK  (~(((1U << TIMER_TCLR_1_LEN) - 1) << TIMER_TCLR_1_POS))
#define TIMER_TCLR_2       TIMER_TCLR_2
#define TIMER_TCLR_2_POS   (2U)
#define TIMER_TCLR_2_LEN   (1U)
#define TIMER_TCLR_2_MSK   (((1U << TIMER_TCLR_2_LEN) - 1) << TIMER_TCLR_2_POS)
#define TIMER_TCLR_2_UMSK  (~(((1U << TIMER_TCLR_2_LEN) - 1) << TIMER_TCLR_2_POS))

/* 0x84 : TCER */
#define TIMER_TCER_OFFSET (0x84)
#define TIMER2_EN         TIMER2_EN
#define TIMER2_EN_POS     (1U)
#define TIMER2_EN_LEN     (1U)
#define TIMER2_EN_MSK     (((1U << TIMER2_EN_LEN) - 1) << TIMER2_EN_POS)
#define TIMER2_EN_UMSK    (~(((1U << TIMER2_EN_LEN) - 1) << TIMER2_EN_POS))
#define TIMER3_EN         TIMER3_EN
#define TIMER3_EN_POS     (2U)
#define TIMER3_EN_LEN     (1U)
#define TIMER3_EN_MSK     (((1U << TIMER3_EN_LEN) - 1) << TIMER3_EN_POS)
#define TIMER3_EN_UMSK    (~(((1U << TIMER3_EN_LEN) - 1) << TIMER3_EN_POS))

/* 0x88 : TCMR */
#define TIMER_TCMR_OFFSET (0x88)
#define TIMER2_MODE       TIMER2_MODE
#define TIMER2_MODE_POS   (1U)
#define TIMER2_MODE_LEN   (1U)
#define TIMER2_MODE_MSK   (((1U << TIMER2_MODE_LEN) - 1) << TIMER2_MODE_POS)
#define TIMER2_MODE_UMSK  (~(((1U << TIMER2_MODE_LEN) - 1) << TIMER2_MODE_POS))
#define TIMER3_MODE       TIMER3_MODE
#define TIMER3_MODE_POS   (2U)
#define TIMER3_MODE_LEN   (1U)
#define TIMER3_MODE_MSK   (((1U << TIMER3_MODE_LEN) - 1) << TIMER3_MODE_POS)
#define TIMER3_MODE_UMSK  (~(((1U << TIMER3_MODE_LEN) - 1) << TIMER3_MODE_POS))
/* 0xA8 : TCVWR2 */
#define TIMER_TCVWR2_OFFSET (0xA8)
#define TIMER_TCVWR         TIMER_TCVWR
#define TIMER_TCVWR_POS     (0U)
#define TIMER_TCVWR_LEN     (32U)
#define TIMER_TCVWR_MSK     (((1U << TIMER_TCVWR_LEN) - 1) << TIMER_TCVWR_POS)
#define TIMER_TCVWR_UMSK    (~(((1U << TIMER_TCVWR_LEN) - 1) << TIMER_TCVWR_POS))

/* 0xAC : TCVWR3 */
#define TIMER_TCVWR3_OFFSET (0xAC)
#define TIMER_TCVWR         TIMER_TCVWR
#define TIMER_TCVWR_POS     (0U)
#define TIMER_TCVWR_LEN     (32U)
#define TIMER_TCVWR_MSK     (((1U << TIMER_TCVWR_LEN) - 1) << TIMER_TCVWR_POS)
#define TIMER_TCVWR_UMSK    (~(((1U << TIMER_TCVWR_LEN) - 1) << TIMER_TCVWR_POS))

/* 0xBC : TCDR */
#define TIMER_TCDR_OFFSET (0xBC)
#define TIMER_TCDR2       TIMER_TCDR2
#define TIMER_TCDR2_POS   (8U)
#define TIMER_TCDR2_LEN   (8U)
#define TIMER_TCDR2_MSK   (((1U << TIMER_TCDR2_LEN) - 1) << TIMER_TCDR2_POS)
#define TIMER_TCDR2_UMSK  (~(((1U << TIMER_TCDR2_LEN) - 1) << TIMER_TCDR2_POS))
#define TIMER_TCDR3       TIMER_TCDR3
#define TIMER_TCDR3_POS   (16U)
#define TIMER_TCDR3_LEN   (8U)
#define TIMER_TCDR3_MSK   (((1U << TIMER_TCDR3_LEN) - 1) << TIMER_TCDR3_POS)
#define TIMER_TCDR3_UMSK  (~(((1U << TIMER_TCDR3_LEN) - 1) << TIMER_TCDR3_POS))
#define TIMER_WCDR        TIMER_WCDR
#define TIMER_WCDR_POS    (24U)
#define TIMER_WCDR_LEN    (8U)
#define TIMER_WCDR_MSK    (((1U << TIMER_WCDR_LEN) - 1) << TIMER_WCDR_POS)
#define TIMER_WCDR_UMSK   (~(((1U << TIMER_WCDR_LEN) - 1) << TIMER_WCDR_POS))



/**
 *  @brief TIMER channel type definition
 */
typedef enum {
    TIMER_CH0,    /*!< TIMER channel 0 port define */
    TIMER_CH1,    /*!< TIMER channel 1 port define */
    TIMER_CH_MAX, /*!<  */
} TIMER_Chan_Type;

/**
 *  @brief TIMER clock source type definition
 */
typedef enum {
    TIMER_CLKSRC_FCLK, /*!< TIMER clock source :System CLK */
    TIMER_CLKSRC_32K,  /*!< TIMER clock source :32K CLK */
    TIMER_CLKSRC_1K,   /*!< TIMER clock source :1K CLK,Only for Timer not for Watchdog */
    TIMER_CLKSRC_XTAL, /*!< TIMER clock source :XTAL CLK */
} TIMER_ClkSrc_Type;

/**
 *  @brief TIMER preload source type definition
 */
typedef enum {
    TIMER_PRELOAD_TRIG_NONE,  /*!< TIMER no preload source, just free run */
    TIMER_PRELOAD_TRIG_COMP0, /*!< TIMER count register preload triggered by comparator 0 */
    TIMER_PRELOAD_TRIG_COMP1, /*!< TIMER count register preload triggered by comparator 1 */
    TIMER_PRELOAD_TRIG_COMP2, /*!< TIMER count register preload triggered by comparator 2 */
} TIMER_PreLoad_Trig_Type;

/**
 *  @brief TIMER match compare ID type definition
 */
typedef enum {
    TIMER_COMP_ID_0, /*!< TIMER match compare ID 0 define */
    TIMER_COMP_ID_1, /*!< TIMER match compare ID 1 define */
    TIMER_COMP_ID_2, /*!< TIMER match compare ID 2 define */
} TIMER_Comp_ID_Type;

/**
 *  @brief TIMER count register run mode type definition
 */
typedef enum {
    TIMER_COUNT_PRELOAD, /*!< TIMER count register preload from comparator register */
    TIMER_COUNT_FREERUN, /*!< TIMER count register free run */
} TIMER_CountMode_Type;

/**
 *  @brief TIMER Match Interrupt mode register type definition
 */
typedef enum {
    TIMER_MATCH_LEVEL_INTR, /*!< TIMER Interrupt configired for Level Interrupt trigger */
    TIMER_MATCH_PULSE_INTR, /*!< TIMER Interrupt configired for Pulse Interrupt trigger */
} TIMER_MatchIntrMode_Type;

/**
 *  @brief TIMER interrupt type definition
 */
typedef enum {
    TIMER_INT_COMP_0, /*!< Comparator 0 match cause interrupt */
    TIMER_INT_COMP_1, /*!< Comparator 1 match cause interrupt */
    TIMER_INT_COMP_2, /*!< Comparator 2 match cause interrupt */
    TIMER_INT_ALL,    /*!<  */
} TIMER_INT_Type;

/**
 * @brief Mask type definition
 */
typedef enum {
    UNMASK = 0,
    MASK = 1
} Mask_Type;

/**
 * @brief Status type definition
 */
typedef enum {
    RESET = 0,
    SET = 1,
} Reg_Sts_Type;

/**
 * @brief Error type definition
 */
typedef enum {
    SUCCESS = 0,
    ERROR = 1,
    TIMEOUT = 2,
    INVALID = 3, /* invalid arguments */
    NORESC = 4   /* no resource or resource temperary unavailable */
} FLC_Err_Type;

/**
 *  @brief TIMER configuration structure type definition
 */
typedef struct
{
    TIMER_Chan_Type timerCh;           /*!< Timer channel */
    TIMER_ClkSrc_Type clkSrc;          /*!< Timer clock source */
	TIMER_CountMode_Type countMode;    /*!< Timer count mode */
	TIMER_PreLoad_Trig_Type plTrigSrc; /*!< Timer count register preload trigger source slelect, Valid only if count mode is preload */
    TIMER_MatchIntrMode_Type IntrMode; /*!< Timer match interrupt mode */
	uint8_t clockDivision;             /*!< Timer clock divison value */
    uint32_t matchVal0;               /*!< Timer match 0 value 0 */
    uint32_t matchVal1;                /*!< Timer match 1 value 0 */
    uint32_t matchVal2;                /*!< Timer match 2 value 0 */
    uint32_t preLoadVal;               /*!< Timer preload value, only valid if count mode is set to preload */
    void (*UserCallback)(void *);            /*!< Pointer to the callback function for this respective timer*/
	uint32_t InterruptNo;
} TIMER_CFG_Type;

FLC_Err_Type FLC_TimerCounter_Init(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_TimerCounter_Configure(TIMER_CFG_Type *aTimerCfg);
void FLC_Timer_IntMask(TIMER_CFG_Type *aTimerCfg, TIMER_INT_Type intType, Mask_Type intMask);
void FLC_Timer_Enable(TIMER_CFG_Type *aTimerCfg);
void FLC_Timer_Disable(TIMER_CFG_Type *aTimerCfg);
void FLC_ClearIntStatus(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo);
Reg_Sts_Type TIMER_GetMatchStatus(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo);
uint32_t FLC_GetPresentCounterVal(TIMER_CFG_Type *aTimerCfg);
uint32_t FLC_GetCompValue(TIMER_CFG_Type *aTimerCfg, TIMER_Comp_ID_Type cmpNo);
FLC_Err_Type FLC_SetCompValue(TIMER_CFG_Type *aTimerCfg,TIMER_Comp_ID_Type cmpNo, uint32_t val);
FLC_Err_Type FLC_SetPreloadValue(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_Preload_Cfg(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_CountMode_Cfg(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_ClkDivision_Cfg(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_ClkSrc_Cfg(TIMER_CFG_Type *aTimerCfg);
FLC_Err_Type FLC_SetTimerIntr(TIMER_CFG_Type *aTimerCfg);




