#include <stdint.h>

#include "common.h"
#include "spi_common.h"
#include "flash_mem_layout.h"

#define TIM0_ADDR 0x80000000
void (*jump_to_TIM0)(void) = (void (*)())TIM0_ADDR;

#define TIM1_ADDR 0x80020000
void (*jump_to_TIM1)(void) = (void (*)())TIM1_ADDR;

uint8_t test_pattern[] = {  0xFE, 0x01, 0xFF, 0x00,   
                            0xFC, 0x03, 0xFD, 0x02,   
                            0xFA, 0x05, 0xFB, 0x04,   
                            0xF8, 0x07, 0xF9, 0x06,   
                            0xF6, 0x09, 0xF7, 0x08,   
                            0xF4, 0x0B, 0xF5, 0x0A,   
                            0xF2, 0x0D, 0xF3, 0x0C,   
                            0xF0, 0x0F, 0xF1, 0x0E,   
                            0xEE, 0x11, 0xEF, 0x10,   
                            0xEC, 0x13, 0xED, 0x12,   
                            0xEA, 0x15, 0xEB, 0x14,   
                            0xE8, 0x17, 0xE9, 0x16,   
                            0xE6, 0x19, 0xE7, 0x18,   
                            0xE4, 0x1B, 0xE5, 0x1A,   
                            0xE2, 0x1D, 0xE3, 0x1C,   
                            0xE0, 0x1F, 0xE1, 0x1E, };

int32_t main(void) {
	uint32_t nodePos, qspi_mode_en = 1;
	uint32_t bufLen;
	uint8_t flashBlockInfo[sizeof(FlashBlockInfo)];
	uint8_t flashData[sizeof(FlashData)];
	FlashBlockInfo *pFlashBlockInfo;
	FlashData *pFlashData;
	
	spi_copy_data(0x0, flashBlockInfo, sizeof(flashBlockInfo));
	nodePos = 0;
    pFlashBlockInfo = (FlashBlockInfo *)flashBlockInfo;
	do {
    spi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart + (nodePos * sizeof(FlashData))), flashData, sizeof(flashData));
	nodePos++;
    pFlashData = (FlashData *)flashData;
	}while(!pFlashData->isLastNode && pFlashData->labelCode != LC_QSPI_TEST_DATA);

	if(pFlashData->labelCode != LC_QSPI_TEST_DATA)
		return -1;

	qspi_mode_init();
	bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
	uint8_t buffer[bufLen];
	qspi_copy_data((uint8_t *)pFlashData->sAddr, buffer, bufLen);

    for (uint32_t i = 0; i < pFlashData->len; i++){
        if(buffer[i] != test_pattern[i]){
            qspi_mode_en = 0;
            break;
        }  
    }

    if (qspi_mode_en == 0){
        /* TODO:Configure flash back to spi mode */
	    nodePos = 0;
	    do {
            spi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart + (nodePos * sizeof(flashData))), flashData, sizeof(flashData));
            nodePos++;
            pFlashData = (FlashData *)flashData;
	    }while(!pFlashData->isLastNode && pFlashData->labelCode != LC_MKB_FW);
	    if(pFlashData->labelCode != LC_MKB_FW)
		    return -1;
	    bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
    	spi_copy_data((uint8_t *)pFlashData->sAddr, (uint8_t *)TIM0_ADDR, bufLen);
    }else{
	    nodePos = 0;
	    do {
            qspi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart + (nodePos * sizeof(flashData))), flashData, sizeof(flashData));
            nodePos++;
            pFlashData = (FlashData *)flashData;
	    }while(!pFlashData->isLastNode && pFlashData->labelCode != LC_MKB_FW);
	    if(pFlashData->labelCode != LC_MKB_FW) {
		    return -1;
        }
	    bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
    	qspi_copy_data((uint8_t *)pFlashData->sAddr, (uint8_t *)TIM0_ADDR, bufLen);
    }

	jump_to_TIM0();

	return 0;
}
