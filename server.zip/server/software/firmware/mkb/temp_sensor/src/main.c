#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <metal/cpu.h>
#include <metal/machine.h>
#include <metal/timer.h>
#include <metal/interrupt.h>

#define FLC_RW_REG_TS_CTRL		0x26000760	
#define FLC_R_REG_TS_OUT_1		0x26000764
#define FLC_R_REG_TS_OUT_2		0x26000768
#define FLC_R_REG_TS_OUT_3		0x2600076C

#define MODE_8BIT
#define MODE_10BIT
#define MODE_12BIT

#define CAL5	4094
#define EQBS(Cnt)	( (Cnt/CAL5) - 0.5 )
#define SLOPE		220.5 //slope in uncalib mode is B
#define OFFSET		42.74 //offset in uncalib mode is A
#define CONST		(-0.16)// C
#define FCLK		4 //Clock is 4Mhz

// we need to Simulate interface with an interrupt
typedef struct {
    bool temp_sensor_irq;
	
} mkb_dut_probe_intf_t;

mkb_dut_probe_intf_t probe_if;

float temp_count = 0;

// Function to simulate Reg read and write operations
void do_ahb_read_getval(uint32_t address, uint32_t *data) {
	*data = address;
}

void do_ahb_write(uint32_t address, uint32_t data) {
	uint32_t *ptr = (uint32_t *)address;  // Directly point to the memory address
    *ptr = data;
}

void mkb_temp_sensor_seq() {
    uint32_t rd_data = 0;
    uint32_t rd_data_1 = 0;
	
    // Simulate body function
    do_ahb_read_getval(FLC_RW_REG_TS_CTRL, &rd_data);
    rd_data |= (1 << 0);  // Asserting reset., b0 - 1 -> Reset En
    rd_data &= ~(1 << 14); // Deasserting power down., b14 - 0-> Turn on 
    do_ahb_write(FLC_RW_REG_TS_CTRL, rd_data);

	/**En and Disable loads*/
    do_ahb_read_getval(FLC_RW_REG_TS_CTRL, &rd_data);
    rd_data |= (1 << 15);  // config_load_en., b15 - 1 -> Load En
	
    rd_data = (rd_data & ~(0xFF << 2)) | (0x40 << 2); // config_load ., b9:2 - 0x40 ie., bit 8 to 1 
    do_ahb_write(FLC_RW_REG_TS_CTRL, rd_data);

	//usleep(1);
	
    do_ahb_read_getval(FLC_RW_REG_TS_CTRL, &rd_data);
    rd_data &= ~(1 << 15);  // config_load_en., b15 - 0 -> Load Dis
    rd_data &= ~(0xFF << 2); // config_load., b9:2 - 0x00 ie., disabling load value
    do_ahb_write(FLC_RW_REG_TS_CTRL, rd_data);
	
	//usleep(50);
	
	/**Applying run*/
	do_ahb_read_getval(FLC_RW_REG_TS_CTRL, &rd_data);
	rd_data |= (1<<1);//Applying run., b1 - 1 -> Run apply
	do_ahb_write(FLC_RW_REG_TS_CTRL, rd_data);
	
	//usleep(85);
	
	// This below code shall be in IRQ or a timer exp that polls in certail freq.
    // Simulate wait for IRQ here, sensor_irw variable shall have status of interrupt.
    if (probe_if.temp_sensor_irq) {
        do_ahb_read_getval(FLC_R_REG_TS_OUT_1, &rd_data_1);//Read the status register once interrupt has occurred
        if ((rd_data_1 & (1 << 12)) == 0) {
            printf("TS_IRQ is high but status register is not updated\n");
        }
		temp_count = (rd_data_1 & 0xFFF);
        printf("conversion value = %03x\n", temp_count);

        do_ahb_read_getval(FLC_RW_REG_TS_CTRL, &rd_data);
        rd_data &= ~(1 << 1);  // Deasserting run
        do_ahb_write(FLC_RW_REG_TS_CTRL, rd_data);

        do_ahb_read_getval(FLC_R_REG_TS_OUT_1, &rd_data_1);
        while (rd_data_1 & (1 << 12)) { //if status register b12 is high, untill it goes low, loop here for b12 to 0
            do_ahb_read_getval(FLC_R_REG_TS_OUT_1, &rd_data_1);
        }
		do_ahb_read_getval(FLC_R_REG_TS_OUT_1, &rd_data_1);
    }
}


float mkb_sensor_calc_temp(float temp_count)
{
	float temperature_val = EQBS(temp_count) * (SLOPE + OFFSET + CONST) * FCLK;
	return temperature_val; 
}

void timer_exp_handler()
{
	printf("Failed to get CPU interrupt controller\n");
}
struct metal_timer *timer;
struct metal_interrupt *timer_intr;
struct metal_cpu *cpu;

#define TIMER_INTERVAL_MS 1000  // Timer interval in milliseconds

uint32_t init_interrupts(){
	
	int hartID = metal_cpu_get_current_hartid();
    
	cpu = metal_cpu_get(hartID);
	// Get the interrupt controller for the CPU
    struct metal_interrupt *cpu_intr = metal_cpu_interrupt_controller(cpu);
    if (cpu_intr == NULL) {
        printf("Failed to get CPU interrupt controller\n");
        return -1;
    }
    metal_interrupt_init(cpu_intr);
#if 0
	/**Registering metal timer interrupts here */
	struct metal_interrupt *timer_int = metal_cpu_timer_interrupt_controller(cpu);
   	if(!timer_int) {
	  printf("Failed to get cpu timer interrupt controller\n");
	  return -1;
	}
	metal_interrupt_init(timer_int);
#endif
}
int timer_init()
{
	int hartID = metal_cpu_get_current_hartid();
    
	cpu = metal_cpu_get(hartID);
 	
	// Get the timer device
    timer = metal_cpu_timer_get(cpu);
    if (timer == NULL) {
        printf("Failed to get timer\n");
        return -1;
    }
  	// Get the interrupt controller for the timer
    timer_intr = metal_timer_interrupt_controller(timer);
    if (timer_intr == NULL) {
        printf("Failed to get timer interrupt controller\n");
        return -1;
    }	
	metal_interrupt_init(timer_intr);
	
//	int timer_id = metal_cpu_timer_get_interrupt_id(cpu);

   	int rc = metal_interrupt_register_handler(timer_intr, 0, timer_exp_handler, cpu);
   	if(rc != 0) {
      /* Failed to register interrupt handler */
   	}
}

void start_timer(){

	// Set the timer interval
    metal_timer_set_compare(timer, 0, metal_timer_get_rate_hz(timer) / (1000 / TIMER_INTERVAL_MS));

    // Enable the timer interrupt
    metal_interrupt_enable(timer_intr, 0);
    metal_cpu_set_mtimecmp(cpu, metal_timer_get_compare(timer, 0));

    // Enable interrupts in the CPU
    metal_cpu_enable_interrupts(cpu);
}

int main() {
    // Initialize probe interface
	float temperature_val = 0.0;
    probe_if.temp_sensor_irq = false;

	init_interrupts();
	//Timer initializations
	timer_init();
	
	start_timer();
	
	// Simulate sequence
    mkb_temp_sensor_seq();
	temperature_val = mkb_sensor_calc_temp(temp_count);
	printf("temp value is : %f\n", temperature_val);
	
    return 0;
}

