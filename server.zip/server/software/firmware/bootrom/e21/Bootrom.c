#include <stdio.h>
#include <stdint.h>
#include <flash_mem_layout.h>
#include <spi_common.h>

#define TIM0_ADDR 0x80000000
#define TIM1_ADDR 0x80020000
#define FSBL_JUMP_ADDR 0x80020000
#define GPIO_BOOT_MODE 	19 
#define TEST_FAILURE 1
#define TEST_SUCCESS 0
void (*jump_to_TIM0)(void) = (void (*)())TIM0_ADDR;
void (*jump_to_TIM1)(void) = (void (*)())TIM1_ADDR;
void (*jump_to_FSBL)(void) = (void (*)())FSBL_JUMP_ADDR;


int main() 
{
	// GPIO_19 is high. Going to start SPI copy 
	uint8_t flashBlockInfo[sizeof(FlashBlockInfo)];
    FlashBlockInfo *pFlashBlockInfo;
    FlashData *pFlashData;
    uint8_t flashData[sizeof(FlashData)];
    uint32_t bufLen;
	if(spi_copy_data(0x0, flashBlockInfo, sizeof(flashBlockInfo)) != TEST_SUCCESS) 
	{
		return TEST_FAILURE;
	}
    pFlashBlockInfo = (FlashBlockInfo *)flashBlockInfo;
	if(spi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart), flashData, sizeof(flashData)) != TEST_SUCCESS) 
	{
		return TEST_FAILURE;
	}
    pFlashData = (FlashData *)flashData;

	bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
	if(spi_copy_data((uint8_t *)pFlashData->sAddr, (uint8_t *)FSBL_JUMP_ADDR, bufLen) != TEST_SUCCESS)
	{
		return TEST_FAILURE;
	}
	jump_to_FSBL();
}

#if 0
#include <stdio.h>
#include <stdint.h>

#include <metal/gpio.h>
#include <metal/interrupt.h>
#include <metal/drivers/riscv_cpu.h>

#include <spi_common.h>
#include <flash_mem_layout.h>
#include <i3c.h>

#include <stdio.h>
#include <stdint.h>
#include <flash_mem_layout.h>


#define TIM0_ADDR 0x80000000
#define TIM1_ADDR 0x80020000
#define FSBL_JUMP_ADDR 0x80020000
#define GPIO_BOOT_MODE 	19 
#define TEST_FAILURE 1
#define TEST_SUCCESS 0

struct metal_gpio *gpio;

typedef enum {
	//I3C_BOOT,
	SPI_BOOT
} e_bootmode;

void (*jump_to_TIM0)(void) = (void (*)())TIM0_ADDR;
void (*jump_to_TIM1)(void) = (void (*)())TIM1_ADDR;
void (*jump_to_FSBL)(void) = (void (*)())FSBL_JUMP_ADDR;

int get_boot_mode(e_bootmode *bootmode) {
	metal_gpio_enable_input(gpio, GPIO_BOOT_MODE); //pin 19
	*bootmode = metal_gpio_get_input_pin(gpio, GPIO_BOOT_MODE);

	return TEST_SUCCESS;
}

int spi_boot_handler()
{
	// GPIO_19 is high. Going to start SPI copy 
	debug_gpio_set(0x2);
#if !SKIP_FLASH_COPY	
	uint8_t flashBlockInfo[sizeof(FlashBlockInfo)];
    FlashBlockInfo *pFlashBlockInfo;
    FlashData *pFlashData;
    uint8_t flashData[sizeof(FlashData)];
    uint32_t bufLen;
	if(spi_copy_data(0x0, flashBlockInfo, sizeof(flashBlockInfo)) != TEST_SUCCESS) 
	{
		//printf("SPI boot failed");
		return TEST_FAILURE;
	}
    pFlashBlockInfo = (FlashBlockInfo *)flashBlockInfo;
	if(spi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart), flashData, sizeof(flashData)) != TEST_SUCCESS) 
	{
		//printf("SPI boot failed");
		return TEST_FAILURE;
	}
    pFlashData = (FlashData *)flashData;

	debug_gpio_set(0x3);
	bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
	if(spi_copy_data((uint8_t *)pFlashData->sAddr, (uint8_t *)FSBL_JUMP_ADDR, bufLen) != TEST_SUCCESS)
	{
		//printf("SPI boot failed");
		return TEST_FAILURE;
	}
	debug_gpio_set(0x4);
#endif /* !SKIP_FLASH_COPY */

	jump_to_FSBL();

}
int main() 
{
	e_bootmode bootmode;

	gpio = metal_gpio_get_device(0);
	if (gpio == NULL) {
		return TEST_FAILURE;
	}

	// BootROM execution started
	debug_gpio_set(0x1);

	if(get_boot_mode(&bootmode) != TEST_SUCCESS) {
		//printf("Get bootmode failed");
		return 4;
	}
	return spi_boot_handler();

	if((bootmode == I3C_BOOT) || (bootmode == SPI_BOOT))
	{
		switch(bootmode) 
		{
			case SPI_BOOT:
				// GPIO_19 is high. Going to start SPI copy 
				debug_gpio_set(0x2);
#if !SKIP_FLASH_COPY
				uint8_t flashBlockInfo[sizeof(FlashBlockInfo)];
                FlashBlockInfo *pFlashBlockInfo;
                FlashData *pFlashData;
                uint8_t flashData[sizeof(FlashData)];
                uint32_t bufLen;

				if(spi_copy_data(0x0, flashBlockInfo, sizeof(flashBlockInfo)) != TEST_SUCCESS) 
				{
					//printf("SPI boot failed");
					return TEST_FAILURE;
				}
                pFlashBlockInfo = (FlashBlockInfo *)flashBlockInfo;

				if(spi_copy_data((uint8_t *)(pFlashBlockInfo->flashDataStart), flashData, sizeof(flashData)) != TEST_SUCCESS) 
				{
					//printf("SPI boot failed");
					return TEST_FAILURE;
				}
                pFlashData = (FlashData *)flashData;

				debug_gpio_set(0x3);
	            bufLen = pFlashData->len + ((pFlashData->len%4)?(4-(pFlashData->len%4)):0);
				if(spi_copy_data((uint8_t *)pFlashData->sAddr, (uint8_t *)FSBL_JUMP_ADDR, bufLen) != TEST_SUCCESS)
				{
					//printf("SPI boot failed");
					return TEST_FAILURE;
				}
				debug_gpio_set(0x4);
#endif /* !SKIP_FLASH_COPY */

				jump_to_FSBL();

				break;
			case I3C_BOOT:
				debug_gpio_set(0x2);

				if(i3c_slave_init() != TEST_SUCCESS)
				{
					return TEST_FAILURE;
				}
                
				break;
			default:
				return TEST_FAILURE;
				//printf("Invalid bootmode selected");
				break;
		}
	}
	return 0;

}
#endif
