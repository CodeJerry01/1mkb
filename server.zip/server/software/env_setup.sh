#!/bin/bash

export HOME_DIR=$( dirname "$( readlink -f -- "$0"; )"; )
export RISCV_PATH=/projects/mockingbird/lib/riscv64-unknown-elf-toolchain-10.2.0-2020.12.8-x86_64-linux-ubuntu14
#export RISCV_PATH=$HOME_DIR/../e21_riscv_toolchain
export SDK_PATH=$HOME_DIR/../e21_sdk
