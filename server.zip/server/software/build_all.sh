cmake -DCMAKE_TOOLCHAIN_FILE=../cmake_config/e21_toolchain_debug.cmake .. && make bootrom_e21 && make mkb_flash_fw && make gfh_fw && make gfh_d2d_fw && make HelloRTOS
