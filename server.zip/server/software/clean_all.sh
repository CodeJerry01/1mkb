reset && rm -rf ../build/*
