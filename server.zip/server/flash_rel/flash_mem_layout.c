#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <endian.h>
#include <dirent.h>

#include "../software/firmware/common/flash_mem_layout.h"

#define QSPI_INFO_BLOCK_SIZE 32

// Define levels for messages
#define ERROR_LEVEL 1
#define INFO_LEVEL 2
#define DEBUG_LEVEL 3
#define BOOTROM_START_ADDR	0x60
// Define the current level (change this as needed)
#define CURRENT_LEVEL DEBUG_LEVEL
#define BOOT_XIP_0x60	1

FlashBlockInfo flash_block_info;

FlashDataInfo *p_flash_data_info;


// Generalized print function with level and variable arguments
void printMessage(int level, const char *format, ...) {
    // Check if the message level is less than or equal to the current level
    if (level <= CURRENT_LEVEL) {
        // Initialize variable arguments list
        va_list args;
        va_start(args, format);

        // Print the message using vprintf function
        vprintf(format, args);

        // Clean up the variable arguments list
        va_end(args);
    }
}
	
int32_t getFileSize(char file_name[]) {
    FILE *file = fopen(file_name, "r");
    long size;

    if (file == NULL) {
        printf("%s:Error opening binary file:%s", __func__, file_name);
        return -1;
    }
    // Move the file pointer to the end of the file
    fseek(file, 0, SEEK_END);

    // Get the current position of the file pointer, which gives the size of the file
    size = ftell(file);

    // Move the file pointer back to the beginning of the file
    fseek(file, 0, SEEK_SET);

    fclose(file);
    return size;
}

int32_t bin2hex(char b_filename[], char h_filename[]) {
    FILE *binary_file, *hex_file;
    uint8_t byte;
    size_t bytes_read;

    // Open the binary file in binary read mode
    binary_file = fopen(b_filename, "rb");
    if (binary_file == NULL) {
        perror("Error opening binary file");
        return 1;
    }

    // Open the hex file in write mode
    hex_file = fopen(h_filename, "w");
    if (hex_file == NULL) {
        perror("Error opening hex file");
        fclose(binary_file);
        return 2;
    }

    // Read binary file byte by byte and write hex characters to the hex file
    uint32_t i = 0;
    while (fread(&byte, sizeof(byte), 1, binary_file) > 0) {
        i++;
        fprintf(hex_file, "%02X", byte);
        if (i == 4) {
            i = 0;
            fprintf(hex_file, "\n"); // Add newline after every 4 bytes
        }
    }

    // Close files
    fclose(binary_file);
    fclose(hex_file);

    printf("output File:%s\n", h_filename);

    return 0;
}
/**
 * Pranay,26Aug'24
 * This function is being used to copy bootrom_e21 bin file contents at required offset ie., BOOTROM_START_ADDR
 * MKB_FSBL/MKB_XIP_FSBL shall be copied from BOOTROM_START_ADDR + bootrom_e21.bin file length therefore update start adrr accordingly
 */
int32_t boot_xip_copy(FILE *qf_fp_bin){
    printf("In boot XIP\n");
	char bootrom_xip_file_path[]="output/bin/bootrom_e21.bin";
    int32_t mkb_xip_size = 0;
 	FILE *bootrom_xip_hex_fp;
	size_t nbytes_written =0;
    printf("File ABS path:%s\n", bootrom_xip_file_path);
   	mkb_xip_size = getFileSize(bootrom_xip_file_path);
    
	if(mkb_xip_size == -1)
		printf("bootrom hex size read error\n");
   
    flash_block_info.flashDataStart = (htobe32(BOOTROM_START_ADDR) + htobe32(mkb_xip_size));
    fwrite(&flash_block_info, sizeof(FlashBlockInfo), 1, qf_fp_bin);
    printf("flash data header start address:0x%x\n", be32toh(flash_block_info.flashDataStart));
	//This shall be required if we want to place tables at beginning and then start bootrom hex and mkbl hex ... but for that initial addr shall be taken care of
    //size = getFileSize(qf_fp_bin);//Track the size here so that after writing bootrom hex file we can jump back to this address and write table below 

    // Seek to the desired offset in the destination file
    if (fseek(qf_fp_bin,(BOOTROM_START_ADDR), SEEK_SET) != 0)
	printf("Error seeking in destination file:%s", qf_fp_bin);
 	
	bootrom_xip_hex_fp = fopen(bootrom_xip_file_path, "r");
    // Check if file opened successfully
    if (bootrom_xip_hex_fp == NULL) {
        printf("Error opening file:%s.\n", bootrom_xip_hex_fp);
        return 3;
    } 
    //Below code is required for sanity check if the bin file contents are available or not
    fseek(bootrom_xip_hex_fp, 0, SEEK_END);
      if (ftell(bootrom_xip_hex_fp) == 0) {
     printf("Source file is empty.\n");
     return 3;
    }

    //seek over the file poin:ter back to the beginning of the file    
    fseek(bootrom_xip_hex_fp, 0, SEEK_SET);
    if (ferror(bootrom_xip_hex_fp)) {
      printf("Error reading from source file.\n");
      return 3;
    }

    //Ensure source file descriptor is at beginning of file
    fseek(bootrom_xip_hex_fp, 0, SEEK_SET);

    unsigned char rbuffer[4096];
    size_t nbytes_read; 
    /**Copying from xip bin to target bin*/
    while ((nbytes_read = fread(rbuffer, 1, 4096, bootrom_xip_hex_fp)) > 0) {
		    nbytes_written = fwrite(rbuffer, 1, nbytes_read, qf_fp_bin);
    		if(nbytes_written != nbytes_read){
				printf("bootrom bin file read write error\n");
		}
		else{
			printf("read : 0x%x\t - write : 0x%x\n" ,nbytes_read,nbytes_written);
   		}
    }
    
    //fseek(qf_fp_bin,(size), SEEK_SET); //This shall be required if we want to place tables at beginning and then start bootrom hex and mkbl hex ... but for that initial addr shall be taken care of
 
    fclose(bootrom_xip_hex_fp); 
	return 0;
}
 
int32_t main() {

    /* IMPORTANT NOTE:
     * Always keep MKB fsbl as first hex file, bootrom blindly belives in this
     */ 
	FlashDataInfo flash_data_info[] ={
		/* start_addr               length			        label_code	    	        last_node 		    path		*/
		{ { htobe32(0x00000000),	htobe32(0x00000000), htobe32(LC_MKB_FSBL),	    	htobe32(0x0)	},	"mkb_xip_fsbl"},
		{ { htobe32(0x00000000),    htobe32(0x00000000), htobe32(LC_QSPI_TEST_DATA),    htobe32(0x0)	},	"qspi_test_data"},
		{ { htobe32(0x00000000),	htobe32(0x00000000), htobe32(LC_MKB_FW),	        htobe32(0x0)	},	"mkb_flash_fw"},
//		{ { htobe32(0x00000000),	htobe32(0x00000000), htobe32(LC_GFH_FSBL),	        htobe32(0x0)	},	"gfh_fsbl_fw"},
		{ { htobe32(0x00000000),	htobe32(0x00000000), htobe32(LC_GFH_D2D),	        htobe32(0x0)	},	"gfh_d2d_fw"},
//		{ { htobe32(0x00000000),	htobe32(0x00000000), htobe32(LC_MKB_XIP),		htobe32(0x0)	},	"mkb_xip"},
		{ { htobe32(0x00000060),        htobe32(0x00000000), htobe32(LC_GFH_FW),                htobe32(0x1)    },      "gfh_fw"},
	};
    FILE *qf_fp_bin, *source_file;
    char qf_binfile[] = "output/bin/qspi_mem_layout.bin";
    int flashBlockInfoSize, i;
    int32_t numOfBlocks = 0;
    size_t bytes_read;
    char buffer[1024];
    char *flash_ver = getenv("FLASH_VERSION");
    char qf_hex_file[256] = {0};
	uint8_t retStatus = 0;
	 
    p_flash_data_info = flash_data_info;

    if(flash_ver == NULL){
	    printf("FLASH_VERSION not set\n");
	    return 2;
    }
    sprintf(qf_hex_file, "%s/%s.hex", flash_ver, flash_ver);
    printf("FLASH_VERSION:%s\n", flash_ver);

    flash_block_info.flashDataStart = htobe32(sizeof(FlashBlockInfo));
    sprintf(flash_block_info.flashMemVer, "%s", flash_ver);
    
    // Open file for writing
    qf_fp_bin = fopen(qf_binfile, "wb+");
    
    // Check if file opened successfully
    if (qf_fp_bin == NULL) {
        printf("Error opening file:%s.\n", qf_binfile);
        return 3;
    }
#ifndef BOOT_XIP_0x60//This flag shall be enabled for XIP mode and bootrom addr 0x60
    numOfBlocks = sizeof(flash_data_info)/sizeof(FlashDataInfo);
    flashBlockInfoSize = numOfBlocks * sizeof(FlashData);
    printf("flash block info size:0x%x\n", flashBlockInfoSize);
    printf("flash data header start address:0x%x\n", be32toh(flash_block_info.flashDataStart));

    fwrite(&flash_block_info, sizeof(FlashBlockInfo), 1, qf_fp_bin);
#else
    numOfBlocks = sizeof(flash_data_info)/sizeof(FlashDataInfo);
    flashBlockInfoSize = numOfBlocks * sizeof(FlashData);
	
	retStatus = boot_xip_copy(qf_fp_bin);
	if(retStatus != 0){
		return retStatus;
	}

#endif /*BOOTROM_ADDR_0x60**/

    // Write random data byte by byte in hexadecimal format
    for (i = 0; i < numOfBlocks; i++) {
	int32_t start_offset = 0;
	char file_abs_path[256];
    int32_t f_size;
	DIR *dir;
    struct dirent *ent;
	    // Directory containing the files
    const char *directory = "output/bin";

    memset(file_abs_path, 0, sizeof(file_abs_path));
    // Firmware release name
    const char *firmware_name = flash_data_info[i].flashFirmware;
	if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            // Match files with ".bin" extension and firmware release name prefix
            if (strstr(ent->d_name, firmware_name) != NULL && strstr(ent->d_name, ".bin") != NULL) {
				snprintf(file_abs_path, sizeof(file_abs_path), "%s/%s", directory, ent->d_name);
                break;
            }
        }
        closedir(dir);
    } else {
        // Error opening directory
        printf("Error opening directory:%s", directory);
        return EXIT_FAILURE;
    }

	if (i == 0)
		start_offset = be32toh(flash_block_info.flashDataStart) + flashBlockInfoSize;
	else
		start_offset = be32toh(flash_data_info[i-1].flash_data.sAddr) + be32toh(flash_data_info[i-1].flash_data.len);

	start_offset += (start_offset%4) ? (4 - (start_offset%4)):0;
	printf("start_offset:0x%x\n",start_offset);
	printf("FILE ABS path:%s\n", file_abs_path);
    f_size = getFileSize(file_abs_path);
    if (f_size == -1)
        return 4;
	flash_data_info[i].flash_data.len = htobe32(f_size);
	flash_data_info[i].flash_data.sAddr = htobe32(start_offset);
	//printf("sAddr :0x%X - be32h 0x%X\n",flash_data_info[i].flash_data.sAddr, be32toh(flash_data_info[i].flash_data.sAddr));
	fwrite(&flash_data_info[i].flash_data, sizeof(FlashData), 1, qf_fp_bin);
	printf("%s: start_addr0x%x, len:0x%x\n", flash_data_info[i].flashFirmware, be32toh(flash_data_info[i].flash_data.sAddr), be32toh(flash_data_info[i].flash_data.len));

    if(flash_data_info[i].flash_data.isLastNode) {
        break;
    }
    }

    for (i=0; i < numOfBlocks; i++){
	char file_abs_path[256];
	DIR *dir;
    struct dirent *ent;
	    // Directory containing the files
    const char *directory = "output/bin";

    memset(file_abs_path, 0, sizeof(file_abs_path));
    // Firmware release name
    const char *firmware_name = flash_data_info[i].flashFirmware;
	if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            // Match files with ".bin" extension and firmware release name prefix
            if (strstr(ent->d_name, firmware_name) != NULL && strstr(ent->d_name, ".bin") != NULL) {
				snprintf(file_abs_path, sizeof(file_abs_path), "%s/%s", directory, ent->d_name);
                break;
            }
        }
        closedir(dir);
    } else {
        // Error opening directory
        perror("Error opening directory");
        return EXIT_FAILURE;
    }

	source_file = fopen(file_abs_path, "rb");
	if (source_file == NULL) {
        	printf("Error opening source file:%s\n", flash_data_info[i].flashFirmware);
		return 5;
	}

	// Seek to the desired offset in the destination file
	if (fseek(qf_fp_bin, be32toh(flash_data_info[i].flash_data.sAddr), SEEK_SET) != 0) {
	printf("Error seeking in destination file:%s", flash_data_info[i].flashFirmware);
	fclose(source_file);
	fclose(qf_fp_bin);
	return 6;
	}

	unsigned char buffer[4096];
	size_t bytes_read;
	while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0) {
        	fwrite(buffer, 1, bytes_read, qf_fp_bin);
	}

		// Close both files
	fclose(source_file);
	
    if(flash_data_info[i].flash_data.isLastNode) {
        break;
    }
   }
   // Close the file
   fclose(qf_fp_bin);

   if (bin2hex(qf_binfile, qf_hex_file) != 0) {
        return 7;
   }
    
    return 0;
}
