#!/bin/bash

#######################################################################
# Flash Memory Replica Creator Script
# 
# This script executes a compiled C ELF file to create a replica
# of flash memory contents. The C program is responsible for reading
# the flash memory and generating the replica data. The replica data
# can be used for testing, backup, or analysis purposes.
#
# Usage: sh $0 filename <target folder>
#
# Output:
#   flash replica hex file will be created inside source path with .hex
#   and temp .bins will be stored inside a temp folder with name output
#
#######################################################################

# Check if the filename is provided as argument
if [ $# -ne 2 ]; then
    echo "Usage: $0 filename <target folder>"
    exit 1
fi

filename=$1
tgt_dir=$2

# Check if the file exists
if [ ! -f "$filename" ]; then
    echo "File not found: $filename"
    exit 1
fi

# Define ANSI escape sequence for flashing text
flash="\033[5m"

# Reset ANSI escape sequence to default
reset="\033[0m"

# Check if the target directory exists
if [ -d "$tgt_dir" ]; then
    echo "Directory $tgt_dir exists."
else
    echo "Directory $tgt_dir does not exist."
	mkdir -p $tgt_dir
fi

# Read the file line by line using cat
cat "$filename" | while IFS= read -r line; do
    # Split the line into name and directory name
    name=$(echo "$line" | cut -d':' -f1)
    file_loc=$(echo "$line" | cut -d':' -f2)

    # Print the name and corresponding directory name
    echo "Name: $name, Directory Name: $file_loc"

	if [ ! -f "$file_loc" ]; then
    	echo -e "${flash}FAILED: file not found:$file_loc${reset}"
		exit 2
	fi

	cp -f $file_loc $tgt_dir/

done

# Now we got all source files collected

# Specify the folder containing the hex files
input_folder=$tgt_dir
# Remove trailing slash, if any
s_path="${input_folder%/}"

# Get the last directory name (version)
last_dirname=$(basename "$s_path")
export FLASH_VERSION="$last_dirname"


# Create the output folder remove if it exist
output_folder="$PWD/output"
rm -rf "$output_folder"
mkdir -p "$output_folder/bin"

# Define ANSI escape sequence for flashing text
flash="\033[5m"

# Reset ANSI escape sequence to default
reset="\033[0m"


# Iterate over all hex files in the input folder
for file in "$input_folder"/*.hex; do
    # Check if the file exists and is readable
    if [ -f "$file" ] && [ -r "$file" ]; then
        # Get the filename without the path
        filename=$(basename "$file")
        
        # Remove the .hex extension from the filename and add .bin extension
        output_filename="${filename%.hex}.bin"
        
        # Run xxd -r command to convert hex to binary
        xxd -r -p "$file" "$output_folder/bin/$output_filename"
		if [ $? -ne 0 ]; then
			echo -e "${flash}ERROR: xxd not found${reset}"
			exit 1
		fi
        echo "Converted $file to $output_folder/bin/$output_filename"
    else
        echo "Error: $file does not exist or is not readable."
        exit 1
    fi
done

# compile flash mem layout create source code
gcc flash_mem_layout.c -o "$output_folder"/flash_mem_layout
return_value=$?
if [ $? -ne 0 ]; then
    echo -e "${flash}ERROR: C program compilation failed${reset}"
    exit $return_value
fi

# execute flash mem layout create routine
"$output_folder"/flash_mem_layout
return_value=$?
if [ $return_value -eq 0 ]; then
    echo "C program executed successfully."
else
    echo -e "${flash}ERROR: C program failed with return code${reset}"
    exit $return_value
fi

